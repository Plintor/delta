package delta.modules.hud.sources;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import meteordevelopment.meteorclient.utils.network.Http;

public class ESixTwoOne extends Source {
   private int maxPage = 30;

   public void reset() {
      this.maxPage = 30;
   }

   public String randomImage(String filter, Source.Size size) {
      int pageNum = this.random.nextInt(1, this.maxPage);
      JsonObject result = (JsonObject)Http.get("https://e621.net/posts.json?limit=320&tags=" + filter + "&page=" + pageNum).sendJson(JsonObject.class);
      JsonElement var6 = result.get("posts");
      if (var6 instanceof JsonArray) {
         JsonArray array = (JsonArray)var6;
         if (array.size() <= 0) {
            this.maxPage = pageNum - 1;
            return null;
         }

         JsonElement var7 = array.get(this.random.nextInt(array.size()));
         if (var7 instanceof JsonObject) {
            JsonObject post = (JsonObject)var7;
            String url = post.get(size.toString()).getAsJsonObject().get("url").getAsString();
            return url;
         }
      }

      return null;
   }
}
