package delta.modules.hud.sources;

import delta.modules.hud.E621Hud;
import java.net.URLEncoder;
import java.util.Random;

public abstract class Source {
   protected final Random random = new Random();

   public abstract void reset();

   protected abstract String randomImage(String var1, Source.Size var2);

   public String getRandomImage(String filter, Source.Size size) {
      try {
         return this.randomImage(URLEncoder.encode(filter, "UTF-8"), size);
      } catch (Exception var4) {
         E621Hud.LOG.error("Failed to fetch an image.", var4);
         return null;
      }
   }

   public static Source getSource(Source.SourceType type) {
      Object var10000;
      switch(type) {
      case e621:
         var10000 = new ESixTwoOne();
         break;
      case gelbooru:
         var10000 = new GelBooru("https://gelbooru.com/", 700);
         break;
      case rule34:
         var10000 = new GelBooru("https://api.rule34.xxx/", 700);
         break;
      default:
         var10000 = null;
      }

      return (Source)var10000;
   }

   public static enum Size {
      preview,
      sample,
      file;

      // $FF: synthetic method
      private static Source.Size[] $values() {
         return new Source.Size[]{preview, sample, file};
      }
   }

   public static enum SourceType {
      e621,
      gelbooru,
      rule34;

      // $FF: synthetic method
      private static Source.SourceType[] $values() {
         return new Source.SourceType[]{e621, gelbooru, rule34};
      }
   }
}
