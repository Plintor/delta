package delta.modules.hud.sources;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import meteordevelopment.meteorclient.utils.network.Http;

public class GelBooru extends Source {
   private final String domain;
   private final int lastPage;

   public GelBooru(String domain, int lastPage) {
      this.domain = domain;
      this.lastPage = lastPage;
   }

   public void reset() {
   }

   public String randomImage(String filter, Source.Size size) {
      String query = String.format("%s/index.php?page=dapi&s=post&q=index&tags=%s&pid=%d&json=1&limit=10", this.domain, filter, this.random.nextInt(0, this.lastPage));
      JsonElement result = (JsonElement)Http.get(query).sendJson(JsonElement.class);
      if (result == null) {
         return null;
      } else {
         JsonElement var8;
         if (result instanceof JsonArray) {
            JsonArray array = (JsonArray)result;
            var8 = array.get(this.random.nextInt(0, 11));
            if (var8 instanceof JsonObject) {
               JsonObject post = (JsonObject)var8;
               String url = post.get(size.toString() + "_url").getAsString();
               return url;
            }
         } else if (result instanceof JsonObject) {
            JsonObject object = (JsonObject)result;
            var8 = object.get("post");
            if (var8 instanceof JsonArray) {
               JsonArray array = (JsonArray)var8;
               JsonElement var9 = array.get(this.random.nextInt(0, 11));
               if (var9 instanceof JsonObject) {
                  JsonObject post = (JsonObject)var9;
                  String url = post.get(size.toString() + "_url").getAsString();
                  return url;
               }
            }
         }

         return null;
      }
   }
}
