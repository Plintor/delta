package delta.modules.hud;

import baritone.api.utils.Helper;
import delta.modules.hud.sources.ESixTwoOne;
import delta.modules.hud.sources.Source;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.GL;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.network.Http;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;

public class ImageHUD extends HudElement {
    public static final HudElementInfo<ImageHUD> INFO;
    private boolean locked = false;
    private boolean empty = true;
    private int ticks = 0;
    private Source source = new ESixTwoOne();
    private static final Identifier TEXID;
    private final SettingGroup sgGeneral;
    private final Setting<Double> imgWidth;
    private final Setting<Double> imgHeight;
    private final Setting<String> tags;
    private final Setting<Source.Size> size;
    private final Setting<Source.SourceType> sourceType;
    private final Setting<Integer> refreshRate;

    public ImageHUD() {
        super(INFO);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.imgWidth = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("width")).description("The scale of the image.")).defaultValue(100.0D).min(10.0D).sliderRange(70.0D, 1000.0D).build());
        this.imgHeight = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("height")).description("The scale of the image.")).defaultValue(100.0D).min(10.0D).sliderRange(70.0D, 1000.0D).build());
        this.tags = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("tags")).description("Tags")).defaultValue("femboy")).onChanged((v) -> {
            this.source.reset();
            this.empty = true;
        })).build());
        this.size = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("size")).description("Size mode.")).defaultValue(Source.Size.preview)).onChanged((v) -> {
            this.source.reset();
            this.empty = true;
        })).build());
        this.sourceType = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("source")).description("Source Type.")).defaultValue(Source.SourceType.e621)).onChanged((v) -> {
            this.source = Source.getSource(v);
            this.source.reset();
            this.empty = true;
        })).build());
        this.refreshRate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("refresh-rate")).description("How often to change (ticks).")).defaultValue(1200)).max(3000).min(20).build());
    }

    private static ImageHUD create() {
        return new ImageHUD();
    }

    @EventHandler
    public void onTick(Post event) {
        if (Helper.mc.world != null) {
            ++this.ticks;
            if (this.ticks >= (Integer)this.refreshRate.get()) {
                this.ticks = 0;
                this.loadImage();
            }

        }
    }

    public void render(HudRenderer renderer) {
        if (this.empty) {
            this.loadImage();
        } else {
            GL.bindTexture(TEXID);
            Renderer2D.TEXTURE.begin();
            Renderer2D.TEXTURE.texQuad((double)this.x, (double)this.y, (Double)this.imgWidth.get(), (Double)this.imgHeight.get(), Utils.WHITE);
            Renderer2D.TEXTURE.render((MatrixStack)null);
        }
    }

    private void loadImage() {
        if (!this.locked && this.source != null) {
            (new Thread(() -> {
                try {
                    this.locked = true;
                    String url = this.source.getRandomImage((String)this.tags.get(), (Source.Size)this.size.get());
                    if (url == null) {
                        this.locked = false;
                        return;
                    }

                    E621Hud.LOG.info(url);
                    NativeImage img = NativeImage.read(Http.get(url).sendInputStream());
                    Helper.mc.getTextureManager().registerTexture(TEXID, new NativeImageBackedTexture(img));
                    this.empty = false;
                } catch (Exception var3) {
                    E621Hud.LOG.error("Failed to render the image.", var3);
                }

                this.locked = false;
            })).start();
            this.setSize((Double)this.imgWidth.get(), (Double)this.imgHeight.get());
        }
    }

    static {
        INFO = new HudElementInfo(Hud.GROUP, "e621-image", "sex", ImageHUD::create);
        TEXID = new Identifier("e621", "tex");
    }
}
