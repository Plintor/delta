package delta.modules.hud;

import delta.DeltaHack;
import java.util.Calendar;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.hud.elements.TextHud;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;

public class WelcomeHud extends HudElement {
   public static final HudElementInfo<WelcomeHud> INFO;
   private final SettingGroup sgGeneral;
   private final Setting<WelcomeHud.Mode> mode;
   private final Setting<String> morningGreeting;
   private final Setting<String> afternoonGreeting;
   private final Setting<String> eveningGreeting;
   private final Setting<String> customGreeting;
   private String leftText;
   private String rightText;
   private double leftWidth;

   public WelcomeHud() {
      super(INFO);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("mode")).description("What text to show for the greeting.")).defaultValue(WelcomeHud.Mode.Normal)).build());
      this.morningGreeting = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("morning-greeting")).description("What to display as a greeting during morning hours.")).defaultValue("Good Morning")).visible(() -> {
         return this.mode.get() == WelcomeHud.Mode.Normal;
      })).build());
      this.afternoonGreeting = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("afternoon-greeting")).description("What to display as a greeting during afternoon hours.")).defaultValue("Good Afternoon")).visible(() -> {
         return this.mode.get() == WelcomeHud.Mode.Normal;
      })).build());
      this.eveningGreeting = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("evening-greeting")).description("What to display as a greeting during evening hours.")).defaultValue("Good Evening")).visible(() -> {
         return this.mode.get() == WelcomeHud.Mode.Normal;
      })).build());
      this.customGreeting = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("custom-greeting")).description("What the greeting should say.")).defaultValue("Welcome to Banana+")).visible(() -> {
         return this.mode.get() == WelcomeHud.Mode.Custom;
      })).build());
   }

   public void tick(HudRenderer renderer) {
      Calendar calendar = Calendar.getInstance();
      int localTime = calendar.get(11);
      if (this.mode.get() == WelcomeHud.Mode.Custom) {
         this.leftText = (String)this.customGreeting.get();
      } else {
         if (localTime <= 12) {
            this.leftText = (String)this.morningGreeting.get();
         }

         if (localTime >= 13 && localTime <= 16) {
            this.leftText = (String)this.afternoonGreeting.get();
         }

         if (localTime >= 17) {
            this.leftText = (String)this.eveningGreeting.get();
         }
      }

      this.leftText = this.leftText + ", ";
      this.rightText = ((NameProtect)Modules.get().get(NameProtect.class)).getName(MeteorClient.mc.method_1548().method_1676());
      this.leftWidth = renderer.textWidth(this.leftText);
      double rightWidth = renderer.textWidth(this.rightText);
      this.box.setSize(this.leftWidth + rightWidth, renderer.textHeight());
   }

   public void render(HudRenderer renderer) {
      double x = (double)this.x;
      double y = (double)this.y;
      if (this.isInEditor()) {
         renderer.text("Welcome Hud", x, y, TextHud.getSectionColor(0), true);
      } else {
         renderer.text(this.leftText, x, y, TextHud.getSectionColor(0), true);
         renderer.text(this.rightText, x + this.leftWidth, y, TextHud.getSectionColor(1), true);
      }
   }

   static {
      INFO = new HudElementInfo(DeltaHack.HUD_GROUP, "welcome-hud", "Display a friendly welcome to Banana+.", WelcomeHud::new);
   }

   public static enum Mode {
      Normal,
      Custom;

      // $FF: synthetic method
      private static WelcomeHud.Mode[] $values() {
         return new WelcomeHud.Mode[]{Normal, Custom};
      }
   }
}
