package delta.modules.hud;

import delta.DeltaHack;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.hud.Alignment;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.hud.elements.TextHud;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class BindsHud extends HudElement {
   public static final HudElementInfo<BindsHud> INFO;
   private final SettingGroup sgGeneral;
   private final Setting<BindsHud.Sort> sortMode;
   private final Setting<BindsHud.ColorMode> colorMode;
   private final Setting<Double> rainbowSpeed;
   private final Setting<Double> rainbowSpread;
   private final Setting<SettingColor> flatColor;
   private final Setting<Boolean> outlines;
   private final Setting<Integer> outlineWidth;
   private final Setting<Boolean> shadow;
   private final Setting<Alignment> alignment;
   private final List<Module> modules;
   private final Color rainbow;
   private double rainbowHue1;
   private double rainbowHue2;
   private double prevX;
   private double prevTextLength;
   private Color prevColor;

   public BindsHud() {
      super(INFO);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sortMode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("sort-mode")).description("How to sort active modules.")).defaultValue(BindsHud.Sort.Biggest)).build());
      this.colorMode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("color-mode")).description("What color to use for active modules.")).defaultValue(BindsHud.ColorMode.Rainbow)).build());
      this.rainbowSpeed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("rainbow-speed")).description("Rainbow speed of rainbow color mode.")).defaultValue(0.05D).sliderMin(0.01D).sliderMax(0.2D).decimalPlaces(4).visible(() -> {
         return this.colorMode.get() == BindsHud.ColorMode.Rainbow;
      })).build());
      this.rainbowSpread = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("rainbow-spread")).description("Rainbow spread of rainbow color mode.")).defaultValue(0.01D).sliderMin(0.001D).sliderMax(0.05D).decimalPlaces(4).visible(() -> {
         return this.colorMode.get() == BindsHud.ColorMode.Rainbow;
      })).build());
      this.flatColor = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("flat-color")).description("Color for flat color mode.")).defaultValue(new SettingColor(225, 25, 25))).visible(() -> {
         return this.colorMode.get() == BindsHud.ColorMode.Flat;
      })).build());
      this.outlines = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("outlines")).description("Whether or not to render outlines")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("outline-width")).description("Outline width")).defaultValue(2)).min(1).sliderMin(1);
      Setting var10003 = this.outlines;
      Objects.requireNonNull(var10003);
      this.outlineWidth = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.shadow = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("shadow")).description("Renders shadow behind text.")).defaultValue(true)).build());
      this.alignment = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("alignment")).description("Horizontal alignment.")).defaultValue(Alignment.Auto)).build());
      this.modules = new ArrayList();
      this.rainbow = new Color(255, 255, 255);
      this.prevColor = new Color();
   }

   public void tick(HudRenderer renderer) {
      if (Modules.get() == null) {
         this.box.setSize(renderer.textWidth("Keybind List"), renderer.textHeight());
      } else {
         this.modules.clear();
         this.modules.addAll(Modules.get().getAll().stream().filter((modulex) -> {
            return modulex.keybind.isSet();
         }).toList());
         this.modules.sort((o1, o2) -> {
            double _1 = this.getModuleWidth(renderer, o1);
            double _2 = this.getModuleWidth(renderer, o2);
            if (this.sortMode.get() == BindsHud.Sort.Smallest) {
               double temp = _1;
               _1 = _2;
               _2 = temp;
            }

            int a = Double.compare(_1, _2);
            if (a == 0) {
               return 0;
            } else {
               return a < 0 ? 1 : -1;
            }
         });
         double width = 0.0D;
         double height = 0.0D;

         for(int i = 0; i < this.modules.size(); ++i) {
            Module module = (Module)this.modules.get(i);
            width = Math.max(width, this.getModuleWidth(renderer, module));
            height += renderer.textHeight((Boolean)this.shadow.get());
            if (i > 0) {
               height += 2.0D;
            }
         }

         this.box.setSize(width, height);
      }
   }

   public void render(HudRenderer renderer) {
      double x = (double)this.x;
      double y = (double)this.y;
      if (Modules.get() == null) {
         renderer.text("Keybind List", x, y, TextHud.getSectionColor(0), (Boolean)this.shadow.get());
      } else {
         this.rainbowHue1 += (Double)this.rainbowSpeed.get() * renderer.delta;
         if (this.rainbowHue1 > 1.0D) {
            --this.rainbowHue1;
         } else if (this.rainbowHue1 < -1.0D) {
            ++this.rainbowHue1;
         }

         this.rainbowHue2 = this.rainbowHue1;
         this.prevX = x;

         for(int i = 0; i < this.modules.size(); ++i) {
            double offset = this.alignX(this.getModuleWidth(renderer, (Module)this.modules.get(i)), (Alignment)this.alignment.get());
            this.renderModule(renderer, this.modules, i, x + offset, y);
            this.prevX = x + offset;
            y += 2.0D + renderer.textHeight((Boolean)this.shadow.get());
         }

      }
   }

   private void renderModule(HudRenderer renderer, List<Module> modules, int index, double x, double y) {
      Module module = (Module)modules.get(index);
      Color color = (Color)this.flatColor.get();
      BindsHud.ColorMode colorMode = (BindsHud.ColorMode)this.colorMode.get();
      if (colorMode == BindsHud.ColorMode.Random) {
         color = module.color;
      } else if (colorMode == BindsHud.ColorMode.Rainbow) {
         this.rainbowHue2 += (Double)this.rainbowSpread.get();
         int c = java.awt.Color.HSBtoRGB((float)this.rainbowHue2, 1.0F, 1.0F);
         this.rainbow.r = Color.toRGBAR(c);
         this.rainbow.g = Color.toRGBAG(c);
         this.rainbow.b = Color.toRGBAB(c);
         color = this.rainbow;
      }

      renderer.text(module.title, x, y, color, (Boolean)this.shadow.get());
      double textHeight = renderer.textHeight((Boolean)this.shadow.get());
      double textLength = renderer.textWidth(module.title, (Boolean)this.shadow.get());
      String info = module.keybind.toString();
      renderer.text(info, x + renderer.textWidth(module.title) + renderer.textWidth(" "), y, TextHud.getSectionColor(1), (Boolean)this.shadow.get());
      textLength += renderer.textWidth(" ") + renderer.textWidth(info);
      if ((Boolean)this.outlines.get()) {
         if (index == 0) {
            renderer.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y - 2.0D, (double)(Integer)this.outlineWidth.get(), textHeight + 4.0D, this.prevColor, this.prevColor, color, color);
            renderer.quad(x + textLength + 2.0D, y - 2.0D, (double)(Integer)this.outlineWidth.get(), textHeight + 4.0D, this.prevColor, this.prevColor, color, color);
            renderer.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y - 2.0D - (double)(Integer)this.outlineWidth.get(), textLength + 4.0D + (double)((Integer)this.outlineWidth.get() * 2), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         } else if (index == modules.size() - 1) {
            renderer.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y, (double)(Integer)this.outlineWidth.get(), textHeight + 2.0D + (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            renderer.quad(x + textLength + 2.0D, y, (double)(Integer)this.outlineWidth.get(), textHeight + 2.0D + (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            renderer.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y + textHeight + 2.0D, textLength + 4.0D + (double)((Integer)this.outlineWidth.get() * 2), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         }

         if (index > 0) {
            if (index < modules.size() - 1) {
               renderer.quad(x - 2.0D - (double)(Integer)this.outlineWidth.get(), y, (double)(Integer)this.outlineWidth.get(), textHeight + 2.0D, this.prevColor, this.prevColor, color, color);
               renderer.quad(x + textLength + 2.0D, y, (double)(Integer)this.outlineWidth.get(), textHeight + 2.0D, this.prevColor, this.prevColor, color, color);
            }

            renderer.quad(Math.min(this.prevX, x) - 2.0D - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX, x) == x ? y : y - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX, x) - 2.0D - (Math.min(this.prevX, x) - 2.0D - (double)(Integer)this.outlineWidth.get()), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
            renderer.quad(Math.min(this.prevX + this.prevTextLength, x + textLength) + 2.0D, Math.min(this.prevX + this.prevTextLength, x + textLength) == x + textLength ? y : y - (double)(Integer)this.outlineWidth.get(), Math.max(this.prevX + this.prevTextLength, x + textLength) + 2.0D + (double)(Integer)this.outlineWidth.get() - (Math.min(this.prevX + this.prevTextLength, x + textLength) + 2.0D), (double)(Integer)this.outlineWidth.get(), this.prevColor, this.prevColor, color, color);
         }
      }

      this.prevTextLength = textLength;
      this.prevColor = color;
   }

   private double getModuleWidth(HudRenderer renderer, Module module) {
      double width = renderer.textWidth(module.title);
      String info = module.keybind.toString();
      width += renderer.textWidth(" ") + renderer.textWidth(info);
      return width;
   }

   static {
      INFO = new HudElementInfo(DeltaHack.HUD_GROUP, "binds-hud", "Displays modules you've binded keys to.", BindsHud::new);
   }

   public static enum Sort {
      Biggest,
      Smallest;

      // $FF: synthetic method
      private static BindsHud.Sort[] $values() {
         return new BindsHud.Sort[]{Biggest, Smallest};
      }
   }

   public static enum ColorMode {
      Flat,
      Random,
      Rainbow;

      // $FF: synthetic method
      private static BindsHud.ColorMode[] $values() {
         return new BindsHud.ColorMode[]{Flat, Random, Rainbow};
      }
   }
}
