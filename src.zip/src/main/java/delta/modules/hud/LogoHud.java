package delta.modules.hud;

import delta.DeltaHack;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;

public class LogoHud extends HudElement {
    public static final HudElementInfo<LogoHud> INFO;
    private final SettingGroup sgGeneral;
    private final Setting<Double> scale;
    private static final Identifier LOGO;

    public LogoHud() {
        super(INFO);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.scale = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("scale")).description("How large the logo should be.")).defaultValue(2.0D).min(0.1D).sliderRange(0.0D, 4.0D).build());
    }

    public Identifier getNormal() {
        return LOGO;
    }

    public void tick(HudRenderer renderer) {
        this.box.setSize(90.0D * (Double)this.scale.get(), 90.0D * (Double)this.scale.get());
    }

    public void render(HudRenderer renderer) {
        if (Utils.canUpdate()) {
            double x = (double)this.x;
            double y = (double)this.y;
            int w = this.getWidth();
            int h = this.getHeight();
            Color color = new Color(255, 255, 255);
            Renderer2D.TEXTURE.begin();
            Renderer2D.TEXTURE.texQuad(x, y, (double)w, (double)h, color);
            Renderer2D.TEXTURE.render((MatrixStack)null);
        }
    }

    static {
        INFO = new HudElementInfo(DeltaHack.HUD_GROUP, "logo-hud", "| OBED |", LogoHud::new);
        LOGO = new Identifier("assets", "logo.png");
    }
}
