package delta.modules.hud;

import delta.DeltaHack;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Names;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.item.BedItem;
import net.minecraft.item.EndCrystalItem;
import net.minecraft.item.EnchantedGoldenAppleItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class ItemCounter extends HudElement {
    public static final HudElementInfo<ItemCounter> INFO;
    private final SettingGroup sgGeneral;
    private final Setting<ItemCounter.SortMode> sortMode;
    private final Setting<List<Item>> items;
    private final ArrayList<String> itemCounter;
    private final HashMap<Item, Integer> itemCounts;

    public ItemCounter() {
        super(INFO);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sortMode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("sort-mode")).description("How to sort the binds list.")).defaultValue(ItemCounter.SortMode.Shortest)).build());
        this.items = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)(new meteordevelopment.meteorclient.settings.ItemListSetting.Builder()).name("items")).description("Which items to display in the counter list.")).defaultValue(new ArrayList(0))).build());
        this.itemCounter = new ArrayList();
        this.itemCounts = new HashMap();
    }

    public void tick(HudRenderer renderer) {
        if (Utils.canUpdate()) {
            this.updateCounter();
            double width = 0.0D;
            double height = 0.0D;
            int i = 0;
            if (this.itemCounter.isEmpty()) {
                String t = "Item Counter";
                width = Math.max(width, renderer.textWidth(t));
                height += renderer.textHeight();
            } else {
                for(Iterator var9 = this.itemCounter.iterator(); var9.hasNext(); ++i) {
                    String counter = (String)var9.next();
                    width = Math.max(width, renderer.textWidth(counter));
                    height += renderer.textHeight();
                    if (i > 0) {
                        height += 2.0D;
                    }
                }
            }

            this.box.setSize(width, height);
        }
    }

    public void render(HudRenderer renderer) {
        if (Utils.canUpdate()) {
            this.updateCounter();
            double x = (double)this.x;
            double y = (double)this.y;
            int i = 0;
            if (this.itemCounter.isEmpty()) {
                String var7 = "Item Counter";
            } else {
                for(Iterator var9 = this.itemCounter.iterator(); var9.hasNext(); ++i) {
                    String counter = (String)var9.next();
                    y += renderer.textHeight();
                    if (i > 0) {
                        y += 2.0D;
                    }
                }
            }

        }
    }

    private void updateCounter() {
        ((List)this.items.get()).sort(Comparator.comparingDouble((value) -> {
            return (double)getName(value).length();
        }));
        this.itemCounter.clear();
        Iterator var1 = ((List)this.items.get()).iterator();

        while(var1.hasNext()) {
            Item item = (Item)var1.next();
            ArrayList var10000 = this.itemCounter;
            String var10001 = getName(item);
            var10000.add(var10001 + ": " + InvUtils.find(new Item[]{item}).count());
        }

        if (((ItemCounter.SortMode)this.sortMode.get()).equals(ItemCounter.SortMode.Shortest)) {
            this.itemCounter.sort(Comparator.comparing(String::length));
        } else {
            this.itemCounter.sort(Comparator.comparing(String::length).reversed());
        }

    }

    public static String getName(Item item) {
        if (item instanceof BedItem) {
            return "Fuck You!!!!!";
        } else if (item instanceof ExperienceBottleItem) {
            return "XP Bottles";
        } else if (item instanceof EndCrystalItem) {
            return "Crystals";
        } else if (item instanceof EnchantedGoldenAppleItem) {
            return "Gapples";
        } else if (item instanceof EnderPearlItem) {
            return "Pearls";
        } else if (item == Items.TOTEM_OF_UNDYING) {
            return "Totems";
        } else {
            return item == Items.ENDER_CHEST ? "Echests" : Names.get(item);
        }
    }

    static {
        INFO = new HudElementInfo(DeltaHack.HUD_GROUP, "item-counter", "Count different items in text.", ItemCounter::new);
    }

    public static enum SortMode {
        Longest,
        Shortest;

        // $FF: synthetic method
        private static ItemCounter.SortMode[] $values() {
            return new ItemCounter.SortMode[]{Longest, Shortest};
        }
    }
}
