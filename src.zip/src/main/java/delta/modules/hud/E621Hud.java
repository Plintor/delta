package delta.modules.hud;

import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.hud.Hud;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import org.slf4j.Logger;

public class E621Hud extends MeteorAddon {
   public static final Logger LOG = LogUtils.getLogger();

   public void onInitialize() {
      LOG.info("Initializing E621");
      Hud hud = Hud.get();
      hud.register(ImageHUD.INFO);
   }

   public String getPackage() {
      return "bananaplus.modules.hud";
   }

   public String getWebsite() {
      return "https://github.com/AntiCope/meteor-e621-integration";
   }

   public GithubRepo getRepo() {
      return new GithubRepo("AntiCope", "meteor-e621-integration");
   }

   public String getCommit() {
      String commit = ((ModContainer)FabricLoader.getInstance().getModContainer("e621-hud").get()).getMetadata().getCustomValue("github:sha").getAsString();
      return commit.isEmpty() ? null : commit.trim();
   }
}
