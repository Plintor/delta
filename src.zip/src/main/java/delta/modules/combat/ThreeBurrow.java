package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class ThreeBurrow extends Module {
    private final SettingGroup sgDefault;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> onlyInHole;
    public final Setting<Integer> maxJumps1;
    public final Setting<Integer> maxJumps2;
    private final Setting<Boolean> cope;
    private final Setting<Boolean> groundCope;
    public final Setting<Integer> maxCope;
    private final Setting<WorldUtils.SwitchMode> switchMode;
    private final Setting<WorldUtils.PlaceMode> placeMode;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> center;
    private final Setting<Double> threshold;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> notify;
    private static BlockPos pos;
    private static int jumps;
    private static int jumps2;
    private static int copes;
    private static final Pool<Mutable> copePool = new Pool(Mutable::new);
    private static final List<Mutable> copeList = new ArrayList();

    public ThreeBurrow() {
        super(DeltaHack.Combat, "3-block-burrow", "Attempts to clip you into a block using Air Jump.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.blocks = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("block")).description("What blocks to use for surrounding.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.onlyInHole = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-holes")).description("Stops you from burrowing when not in a hole.")).defaultValue(false)).build());
        this.maxJumps1 = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fail-times-1")).description("How much after-place jump fails can be dealt with.")).defaultValue(1)).sliderRange(1, 5).range(1, 5).build());
        this.maxJumps2 = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fail-times-2")).description("How much after-place jump fails can be dealt with.")).defaultValue(3)).sliderRange(1, 5).range(1, 5).build());
        this.cope = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("cope")).description("tries to TP when exceeded jump limit")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-ground-cope")).description("only TPs to ground positions")).defaultValue(true);
        Setting var10003 = this.cope;
        Objects.requireNonNull(var10003);
        this.groundCope = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fail-times-3")).description("How much cope fails can be dealt with.")).defaultValue(5)).sliderRange(1, 5);
        var10003 = this.cope;
        Objects.requireNonNull(var10003);
        this.maxCope = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var1.visible(var10003::get)).range(1, 5).build());
        this.switchMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("switch-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.SwitchMode.Both)).build());
        this.placeMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("place-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.PlaceMode.Both)).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Faces the block you place server-side.")).defaultValue(true)).build());
        this.center = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center")).description("Centers you when surrounding.")).defaultValue(true)).build());
        var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var2 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("center-threshold")).description("don't touch this unless you know what you're doing.")).defaultValue(0.31D).range(0.0D, 1.0D).sliderRange(0.3D, 0.5D);
        var10003 = this.center;
        Objects.requireNonNull(var10003);
        this.threshold = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var2.visible(var10003::get)).build());
        this.swing = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when placing the blocks.")).defaultValue(false)).build());
        this.notify = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("info")).description("Notifies you about the module's work.")).defaultValue(true)).build());
    }

    public void onActivate() {
        pos = null;
        jumps = 0;
        jumps2 = 0;
        copes = 0;
        if (EntityUtil.isMonke(this.mc.player, true, BlockUtil.BlastResistantType.Any) && (Boolean)this.onlyInHole.get()) {
            if ((Boolean)this.notify.get()) {
                this.error("Not in a hole!", new Object[0]);
            }

            this.toggle();
        } else {
            pos = EntityUtil.playerPos(this.mc.player);
            if (!BlockUtil.isReplaceable(pos)) {
                if ((Boolean)this.notify.get()) {
                    this.error("Already burrowed!", new Object[0]);
                }

                this.toggle();
            } else if (!BlockUtil.isReplaceable(pos.up())) {
                if ((Boolean)this.notify.get()) {
                    this.error("Can't burrow in prone!", new Object[0]);
                }

                this.toggle();
            } else if (!BlockUtil.isReplaceable(pos.up(2))) {
                if ((Boolean)this.notify.get()) {
                    this.error("Not enough headroom to burrow!", new Object[0]);
                }

                this.toggle();
            } else {
                if (!this.mc.player.isOnGround()) {
                    if ((Boolean)this.notify.get()) {
                        this.error("Not on ground!", new Object[0]);
                    }

                    this.toggle();
                }

            }
        }
    }

    @EventHandler
    private void onTick(Pre event) {
        if ((Boolean)this.center.get()) {
            PlayerUtil.centerTwo((Double)this.threshold.get());
        }

        FindItemResult item = InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        });
        if ((Boolean)this.rotate.get()) {
            Vec3d a = Vec3d.ofBottomCenter(pos);
            Rotations.rotate(Rotations.getYaw(a), Rotations.getPitch(a));
        }

        BlockPos p = EntityUtil.playerPos(this.mc.player);
        if (!BlockUtil.isReplaceable(pos)) {
            if (p.equals(pos)) {
                if ((Boolean)this.notify.get()) {
                    this.info("Successfully Burrowed.", new Object[0]);
                }

                this.toggle();
            } else if (jumps2 < (Integer)this.maxJumps2.get()) {
                this.mc.player.jump();
                ++jumps2;
            } else if ((Boolean)this.cope.get()) {
                if (copes < (Integer)this.maxCope.get()) {
                    Iterator var4 = copeList.iterator();

                    while(var4.hasNext()) {
                        Mutable blockPos = (Mutable)var4.next();
                        copePool.free(blockPos);
                    }

                    copeList.clear();
                    BlockIterator.register(4, 4, (blockPosx, blockState) -> {
                        if (blockState.getMaterial().isReplaceable() && (!(Boolean)this.groundCope.get() || BlockUtil.isFullBlock(blockPosx.down())) && !blockPosx.equals(p)) {
                            copeList.add(((Mutable)copePool.get()).set(blockPosx));
                        }

                    });
                    BlockIterator.after(() -> {
                        if (copeList.isEmpty()) {
                            if ((Boolean)this.notify.get()) {
                                this.error("Couldn't find a cope pos!", new Object[0]);
                            }

                            this.toggle();
                        } else {
                            copeList.sort(Comparator.comparingDouble((value) -> {
                                return PlayerUtil.squaredDistance((double)value.getX() + 0.5D, (double)value.getY() + 0.5D, (double)value.getZ() + 0.5D) * -1.0D;
                            }));
                            this.mc.player.setPosition(Vec3d.ofBottomCenter((Vec3i)copeList.get(0)));
                            ++copes;
                        }
                    });
                } else {
                    if ((Boolean)this.notify.get()) {
                        this.error("Exceeded max cope count!", new Object[0]);
                    }

                    this.toggle();
                }
            } else {
                if ((Boolean)this.notify.get()) {
                    this.error("Exceeded max jump count!", new Object[0]);
                }

                this.toggle();
            }
        } else {
            if (!item.found()) {
                if ((Boolean)this.notify.get()) {
                    this.error("Burrow item not found!", new Object[0]);
                }

                this.toggle();
                return;
            }

            if (this.mc.player.isOnGround()) {
                if (jumps >= (Integer)this.maxJumps1.get()) {
                    if ((Boolean)this.notify.get()) {
                        this.error("Exceeded max jump count!", new Object[0]);
                    }

                    this.toggle();
                    return;
                }

                this.mc.player.jump();
                ++jumps;
            }

            if (WorldUtils.place(pos, item, false, 0, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), true, true) && (Boolean)this.notify.get()) {
                this.info("Placed block.", new Object[0]);
            }
        }

    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() > 10.0F;
    }
}
