package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.RenderUtil;
import delta.utils.TimerUtils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.BreakBlockEvent;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.DamageUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class CevBreaker extends Module {
    private final SettingGroup sgDefault;
    private final Setting<Double> enemyRange;
    private final Setting<Double> cevRange;
    private final Setting<Boolean> onlyTopBlock;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> supportDelay;
    private final Setting<Boolean> onlyHole;
    private final Setting<Boolean> selfToggle;
    private final Setting<Double> minHealth;
    private final Setting<SortPriority> priority;
    private final SettingGroup sgMining;
    private final Setting<CevBreaker.MineMode> mineMode;
    private final Setting<Boolean> silentSwitch;
    private final Setting<Boolean> instant;
    private final Setting<Boolean> bypass;
    private final Setting<Boolean> autoSwap;
    private final Setting<Integer> swapDelay;
    private final Setting<Boolean> delayCrystal;
    private final Setting<Integer> delay;
    private final SettingGroup sgCrystal;
    private final Setting<CevBreaker.CrystalMode> crystalMode;
    private final Setting<Double> breakingProgress;
    private final SettingGroup sgPause;
    private final Setting<Boolean> pauseOnEat;
    private final Setting<Boolean> pauseOnDrink;
    private final SettingGroup sgRender;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> sideColor2;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> lineColor2;
    private final Setting<Integer> width;
    private int i;
    private final TimerUtils timer;
    private final TimerUtils swapTimer;
    private final Mutable blockPos;
    private Direction direction;
    private BlockPos pos;
    private boolean shouldSwapBack;
    private PlayerEntity target;
    private int timerPlace;
    private final List<BlockPos> cevArray;

    public CevBreaker() {
        super(DeltaHack.Old, "proxima-cev-breaker", "Exposes the enemy to crystal damage from above (retard edition)");
        this.sgDefault = this.settings.createGroup("Default");
        this.enemyRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("enemy-range")).description("The radius in which players get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.cevRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("cev-range")).description("The radius in which cev get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.onlyTopBlock = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-top-block")).description("Hold city pos.")).defaultValue(false)).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Automatically rotates you towards the city block.")).defaultValue(true)).build());
        this.supportDelay = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("support-delay")).defaultValue(6)).min(4).max(20).sliderMin(4).sliderMax(20).build());
        this.onlyHole = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-hole")).description(".")).defaultValue(true)).build());
        this.selfToggle = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("self-toggle")).description(".")).defaultValue(false)).build());
        this.minHealth = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("min-health")).description("The minimum health required for Cev to work.")).defaultValue(4.0D).range(0.0D, 20.0D).sliderMax(36.0D).build());
        this.priority = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.ClosestAngle)).build());
        this.sgMining = this.settings.createGroup("Mining");
        this.mineMode = this.sgMining.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mine-mode")).description(".")).defaultValue(CevBreaker.MineMode.Vanilla)).build());
        this.silentSwitch = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("silent-switch")).description("instant.")).defaultValue(false)).build());
        this.instant = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("instant")).description("instant.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgMining;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("bypass")).description("instant.")).defaultValue(true);
        Setting var10003 = this.instant;
        Objects.requireNonNull(var10003);
        this.bypass = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.autoSwap = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-swap")).description("automatically swap between pick and your item.")).defaultValue(true)).visible(() -> {
            return (Boolean)this.instant.get() && (Boolean)this.bypass.get();
        })).build());
        this.swapDelay = this.sgMining.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("swap-delay")).defaultValue(50)).range(10, 100).sliderRange(10, 60).visible(() -> {
            return (Boolean)this.instant.get() && (Boolean)this.bypass.get() && (Boolean)this.autoSwap.get();
        })).build());
        this.delayCrystal = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("delay-crystal")).description("troll people that don't know what cev is")).defaultValue(true)).visible(() -> {
            return (Boolean)this.instant.get() && (Boolean)this.bypass.get() && (Boolean)this.autoSwap.get();
        })).build());
        var10001 = this.sgMining;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).defaultValue(0)).range(0, 20).sliderRange(0, 20);
        var10003 = this.instant;
        Objects.requireNonNull(var10003);
        this.delay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var1.visible(var10003::get)).build());
        this.sgCrystal = this.settings.createGroup("Crystal");
        this.crystalMode = this.sgCrystal.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("crystal-mode")).description(".")).defaultValue(CevBreaker.CrystalMode.Smart)).visible(() -> {
            return !(Boolean)this.instant.get() && !((CevBreaker.MineMode)this.mineMode.get()).equals(CevBreaker.MineMode.Packet);
        })).build());
        this.breakingProgress = this.sgCrystal.add(((Builder)((Builder)((Builder)(new Builder()).name("breaking-progress")).description("Block breaking progress at which to spam crystals")).defaultValue(0.95D).min(0.0D).sliderMax(1.0D).visible(() -> {
            return this.crystalMode.get() == CevBreaker.CrystalMode.Smart && !(Boolean)this.instant.get() && !((CevBreaker.MineMode)this.mineMode.get()).equals(CevBreaker.MineMode.Packet);
        })).build());
        this.sgPause = this.settings.createGroup("Pause");
        this.pauseOnEat = this.sgPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-eat")).description("Pauses while eating.")).defaultValue(true)).build());
        this.pauseOnDrink = this.sgPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-drink")).description("Pauses while drinking.")).defaultValue(true)).build());
        this.sgRender = this.settings.createGroup("Render");
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders the current block being mined.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color.")).defaultValue(new SettingColor(28, 255, 15, 75))).build());
        this.sideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color-2")).description("The side color.")).defaultValue(new SettingColor(100, 255, 15, 55))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 27))).build());
        this.lineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color-2")).description("The line color.")).defaultValue(new SettingColor(152, 255, 15))).build());
        this.width = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).defaultValue(1)).min(1).max(5).sliderMin(1).sliderMax(4).build());
        this.timer = new TimerUtils();
        this.swapTimer = new TimerUtils();
        this.blockPos = new Mutable(0, -1, 0);
        this.shouldSwapBack = false;
        this.cevArray = new ArrayList<BlockPos>() {
            {
                this.add(new BlockPos(1, 1, 0));
                this.add(new BlockPos(-1, 1, 0));
                this.add(new BlockPos(0, 1, 1));
                this.add(new BlockPos(0, 1, -1));
            }
        };
    }

    @EventHandler
    private void onBreak(BreakBlockEvent event) {
        if (event.blockPos.equals(this.pos)) {
            if (this.shouldSwapBack) {
                InvUtils.swapBack();
                this.shouldSwapBack = false;
            }

            if ((Boolean)this.selfToggle.get()) {
                this.toggle();
            }
        }

    }

    public void onDeactivate() {
        this.shouldSwapBack = false;
        this.i = 0;
        BlockPos renderPos = null;
        this.timer.reset();
    }

    @EventHandler
    private void onTick(Pre event) {
        if (!((double)EntityUtils.getTotalHealth(this.mc.player) <= (Double)this.minHealth.get())) {
            if (!PlayerUtils.shouldPause(false, (Boolean)this.pauseOnEat.get(), (Boolean)this.pauseOnDrink.get())) {
                if (TargetUtils.isBadTarget(this.target, (Double)this.enemyRange.get())) {
                    this.target = TargetUtils.getPlayerTarget((Double)this.enemyRange.get(), (SortPriority)this.priority.get());
                }

                if (!TargetUtils.isBadTarget(this.target, (Double)this.enemyRange.get())) {
                    if (!(Boolean)this.onlyHole.get() || !EntityUtil.isMonke(true, this.target)) {
                        BlockPos pos = this.getBlock(this.target);
                        this.pos = pos;
                        if (pos != null) {
                            if (!(PlayerUtil.distanceFromEye(pos) > (Double)this.cevRange.get()) && BlockUtil.isAir(pos.up())) {
                                this.mc.world.getEntities().forEach((entity) -> {
                                    if (entity instanceof EndCrystalEntity && entity.getBlockPos().equals(pos.up()) && DamageUtils.crystalDamage(this.target, entity.getPos()) > 5.0D && DamageUtils.crystalDamage(this.mc.player, entity.getPos()) < (double)this.mc.player.getHealth() - 2.0D * (Double)this.minHealth.get()) {
                                        this.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, this.mc.player.isSneaking()));
                                    }

                                });
                                if (BlockUtil.getBlock(pos) == Blocks.OBSIDIAN) {
                                    if ((!(Boolean)this.autoSwap.get() || !(Boolean)this.bypass.get() || !(Boolean)this.instant.get() || this.mc.player.isCreative()) && (Boolean)this.delayCrystal.get()) {
                                        if (((CevBreaker.CrystalMode)this.crystalMode.get()).equals(CevBreaker.CrystalMode.Smart) && this.crystalMode.isVisible() && (double)((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress() >= (Double)this.breakingProgress.get()) {
                                            this.placeCrystal(pos);
                                        } else if (((CevBreaker.CrystalMode)this.crystalMode.get()).equals(CevBreaker.CrystalMode.Strict) || (Boolean)this.instant.get() || ((CevBreaker.MineMode)this.mineMode.get()).equals(CevBreaker.MineMode.Packet)) {
                                            this.placeCrystal(pos);
                                        }
                                    }

                                    if (BlockUtils.canBreak(pos)) {
                                        if ((Boolean)this.instant.get()) {
                                            if (this.i == 0) {
                                                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.UP));
                                                ++this.i;
                                            }

                                            if ((Boolean)this.bypass.get()) {
                                                if (this.swapTimer.hasPassed((double)((float)(Integer)this.swapDelay.get() * 50.0F)) && (Boolean)this.autoSwap.get() && !this.shouldSwapBack) {
                                                    int slotE = InvUtils.findInHotbar((itemStack) -> {
                                                        return itemStack.getItem() == Items.DIAMOND_PICKAXE || itemStack.getItem() == Items.NETHERITE_PICKAXE;
                                                    }).slot();
                                                    if ((Boolean)this.delayCrystal.get()) {
                                                        this.placeCrystal(pos);
                                                    }

                                                    if (slotE != -1) {
                                                        InvUtils.swap(slotE, true);
                                                        this.shouldSwapBack = true;
                                                        this.swapTimer.reset();
                                                    }
                                                } else {
                                                    this.shouldSwapBack = false;
                                                }

                                                if (this.timer.hasPassed((double)((float)(Integer)this.delay.get() * 50.0F))) {
                                                    if (this.direction == null) {
                                                        this.direction = Direction.UP;
                                                    }

                                                    this.mc.interactionManager.updateBlockBreakingProgress(pos, this.direction);
                                                    this.mc.interactionManager.cancelBlockBreaking();
                                                    this.timer.reset();
                                                }
                                            } else {
                                                this.instaMine(pos);
                                            }
                                        } else if ((Boolean)this.rotate.get()) {
                                            Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), () -> {
                                                this.simpleMine(pos);
                                            });
                                        } else {
                                            this.simpleMine(pos);
                                        }
                                    }
                                }

                                if (BlockUtil.isAir(pos)) {
                                    this.placeObsidian(pos);
                                }

                            } else {
                                this.pos = null;
                            }
                        }
                    }
                }
            }
        }
    }

    private void placeObsidian(BlockPos pos) {
        if (this.timerPlace <= 0) {
            BlockUtils.place(pos, InvUtils.findInHotbar(new Item[]{Items.OBSIDIAN}), (Boolean)this.rotate.get(), 50, false);
            this.timerPlace = (Integer)this.supportDelay.get();
        } else {
            --this.timerPlace;
        }

    }

    private void instaMine(BlockPos pos) {
        int slot = InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() == Items.DIAMOND_PICKAXE || itemStack.getItem() == Items.NETHERITE_PICKAXE;
        }).slot();
        if (this.mc.player.getAbilities().creativeMode) {
            slot = this.mc.player.getInventory().selectedSlot;
        }

        int prev = this.mc.player.getInventory().selectedSlot;
        this.mc.player.getInventory().selectedSlot = slot;
        if ((Boolean)this.swing.get()) {
            this.mc.player.swingHand(Hand.MAIN_HAND);
        } else {
            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        }

        if (this.timer.hasPassed((double)((float)(Integer)this.delay.get() * 50.0F))) {
            if ((Boolean)this.rotate.get()) {
                Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
                });
            } else {
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
            }

            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            this.timer.reset();
        }

        if ((Boolean)this.silentSwitch.get()) {
            this.mc.player.getInventory().selectedSlot = prev;
        }

    }

    private void simpleMine(BlockPos pos) {
        int slot = InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() == Items.DIAMOND_PICKAXE || itemStack.getItem() == Items.NETHERITE_PICKAXE;
        }).slot();
        if (this.mc.player.getAbilities().creativeMode) {
            slot = this.mc.player.getInventory().selectedSlot;
        }

        int prev = this.mc.player.getInventory().selectedSlot;
        this.mc.player.getInventory().selectedSlot = slot;
        if (((CevBreaker.MineMode)this.mineMode.get()).equals(CevBreaker.MineMode.Vanilla)) {
            BlockUtils.breakBlock(pos, (Boolean)this.swing.get());
        } else {
            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.DOWN));
            if ((Boolean)this.swing.get()) {
                this.mc.player.swingHand(Hand.MAIN_HAND);
            }

            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.DOWN));
        }

        if ((Boolean)this.silentSwitch.get()) {
            this.mc.player.getInventory().selectedSlot = prev;
        }

    }

    private void placeCrystal(BlockPos pos) {
        if (this.mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL) {
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.OFF_HAND, new BlockHitResult(this.mc.player.getPos(), Direction.UP, pos, true));
        } else if (this.mc.player.getOffHandStack().getItem() != Items.END_CRYSTAL) {
            FindItemResult crystalSlot = InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL});
            if (!crystalSlot.found()) {
                this.error("No crystals", new Object[0]);
                return;
            }

            int prev = this.mc.player.getInventory().selectedSlot;
            this.mc.player.getInventory().selectedSlot = crystalSlot.slot();
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, new BlockHitResult(this.mc.player.getPos(), Direction.UP, pos, true));
            this.mc.player.getInventory().selectedSlot = prev;
        }

    }

    private BlockPos getBlock(PlayerEntity target) {
        BlockPos pos = target.getBlockPos();
        if (target.isInSwimmingPose()) {
            pos = pos.down();
        }

        if (!BlockUtil.isAir(pos.up(3)) || BlockUtil.getBlock(pos.up(2)) != Blocks.OBSIDIAN && BlockUtil.getBlock(pos.up(2)) != Blocks.AIR) {
            if ((Boolean)this.onlyTopBlock.get()) {
                return null;
            } else {
                List<BlockPos> array = new ArrayList();
                Iterator var4 = this.cevArray.iterator();

                while(true) {
                    BlockPos newPos;
                    do {
                        do {
                            if (!var4.hasNext()) {
                                array.sort(Comparator.comparing((blockPos) -> {
                                    return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos);
                                }));
                                if (array.isEmpty()) {
                                    return null;
                                }

                                return (BlockPos)array.get(0);
                            }

                            BlockPos ppos = (BlockPos)var4.next();
                            newPos = pos.add(ppos);
                        } while(!BlockUtil.isAir(newPos.up()));
                    } while(BlockUtil.getBlock(newPos) != Blocks.OBSIDIAN && BlockUtil.getBlock(newPos) != Blocks.AIR);

                    if (BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), newPos) <= (Double)this.cevRange.get()) {
                        array.add(newPos);
                    }
                }
            }
        } else {
            return pos.up(2);
        }
    }

    @EventHandler
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        if ((Boolean)this.instant.get() && (Boolean)this.bypass.get()) {
            this.timer.reset();
            this.direction = event.direction;
            this.blockPos.set(event.blockPos);
            this.cum();
            event.cancel();
        }

    }

    private void cum() {
        if (!this.wontMine()) {
            if ((Boolean)this.rotate.get()) {
                if (this.direction == null) {
                    this.direction = Direction.UP;
                }

                Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                });
                Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, this.blockPos, this.direction));
                });
            } else {
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, this.blockPos, this.direction));
            }

        }
    }

    private boolean wontMine() {
        return this.blockPos.getY() == -1 || !BlockUtils.canBreak(this.blockPos);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && this.pos != null && !this.mc.world.getBlockState(this.pos).isAir()) {
            if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Sides)) {
                RenderUtil.S(event, this.pos, 0.99D, 0.0D, 0.01D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                RenderUtil.TAB(event, this.pos, 0.99D, 0.01D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                if ((Integer)this.width.get() == 2) {
                    RenderUtil.S(event, this.pos, 0.98D, 0.0D, 0.02D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, this.pos, 0.98D, 0.02D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }

                if ((Integer)this.width.get() == 3) {
                    RenderUtil.S(event, this.pos, 0.97D, 0.0D, 0.03D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, this.pos, 0.97D, 0.03D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }

                if ((Integer)this.width.get() == 4) {
                    RenderUtil.S(event, this.pos, 0.96D, 0.0D, 0.04D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, this.pos, 0.96D, 0.04D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }
            }

            if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Lines)) {
                RenderUtil.FS(event, this.pos, 0.0D, true, true, (Color)this.sideColor.get(), (Color)this.sideColor2.get());
            }

            if (BlockUtil.distance(this.mc.player.getBlockPos(), this.pos) > 6.0D) {
                this.pos = null;
            }
        }

    }

    public static enum MineMode {
        Vanilla,
        Packet;

        // $FF: synthetic method
        private static CevBreaker.MineMode[] $values() {
            return new CevBreaker.MineMode[]{Vanilla, Packet};
        }
    }

    public static enum CrystalMode {
        Smart,
        Strict;

        // $FF: synthetic method
        private static CevBreaker.CrystalMode[] $values() {
            return new CevBreaker.CrystalMode[]{Smart, Strict};
        }
    }
}
