package delta.modules.combat;

import com.google.common.util.concurrent.AtomicDouble;
import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.utils.DamageUtil;
import delta.utils.PlayerUtil;
import delta.utils.TimerUtils;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.entity.EntityRemovedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Sent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixininterface.IBox;
import meteordevelopment.meteorclient.mixininterface.IRaycastContext;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.EndCrystalItem;
import net.minecraft.item.EnchantedGoldenAppleItem;
import net.minecraft.item.Item;
import net.minecraft.item.HoeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class RozaliyaAura extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgPlace;
    private final SettingGroup sgFacePlace;
    private final SettingGroup sgBreak;
    private final SettingGroup sgFastBreak;
    private final SettingGroup sgPause;
    private final SettingGroup sgRender;
    public final Setting<Boolean> debug;
    public final Setting<Double> explosionRadiusToTarget;
    private final Setting<Boolean> predictMovement;
    private final Setting<Boolean> ignoreTerrain;
    private final Setting<Boolean> fullBlocks;
    public final Setting<Boolean> hideSwings;
    private final Setting<RozaliyaAura.AutoSwitchMode> autoSwitch;
    private final Setting<Boolean> noGapSwitch;
    private final Setting<Boolean> rotate;
    private final Setting<RozaliyaAura.YawStepMode> yawStepMode;
    private final Setting<Double> yawSteps;
    private final Setting<Boolean> doPlace;
    public final Setting<Integer> placeDelay;
    private final Setting<Double> placeRange;
    private final Setting<Double> placeWallsRange;
    private final Setting<Boolean> placement112;
    private final Setting<Boolean> smallBox;
    private final Setting<RozaliyaAura.SupportMode> support;
    private final Setting<Integer> supportDelay;
    public final Setting<Boolean> facePlace;
    public final Setting<Boolean> slowFacePlace;
    public final Setting<RozaliyaAura.SlowMode> slowFPMode;
    public final Setting<Integer> slowFPAge;
    private final Setting<Boolean> antiWeakness;
    public final Setting<Double> BminDamage;
    private final Setting<Integer> attackFrequency;
    private final Setting<RozaliyaAura.CancelCrystalMode> cancelCrystalMode;
    private final Setting<Integer> cancelTicks;
    public final Setting<Integer> breakDelay;
    private final Setting<Boolean> smartDelay;
    private final Setting<Integer> switchDelay;
    private final Setting<Double> breakRange;
    private final Setting<Double> breakWallsRange;
    private final Setting<Boolean> attemptCheck;
    private final Setting<Integer> breakAttempts;
    private final Setting<Integer> ticksExisted;
    private final Setting<Boolean> fastBreak;
    private final Setting<Boolean> freqCheck;
    private final Setting<Boolean> minDcheck;
    public final Setting<Boolean> targetPopInvincibility;
    public final Setting<Integer> targetPopInvincibilityTime;
    private final Setting<Double> pauseAtHealth;
    private final Setting<Boolean> eatPause;
    private final Setting<Boolean> drinkPause;
    private final Setting<Boolean> minePause;
    public final Setting<Boolean> renderSwing;
    private final Setting<RozaliyaAura.RenderMode> renderMode;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Integer> fadeTime;
    private final Setting<Integer> fadeAmount;
    private final Setting<Integer> renderTime;
    private final Setting<SettingColor> placeSideColor;
    private final Setting<SettingColor> placeLineColor;
    private final Setting<Boolean> renderBreak;
    private final Setting<Integer> renderBreakTime;
    private final Setting<SettingColor> breakSideColor;
    private final Setting<SettingColor> breakLineColor;
    private final Setting<Boolean> renderDamage;
    private final Setting<Double> damageScale;
    private final Setting<SettingColor> damageColor;
    public int breakTimer;
    private int placeTimer;
    private int switchTimer;
    private int ticksPassed;
    private final Vec3d vec3d;
    private final Vec3d playerEyePos;
    private final Vec3 vec3;
    private final Mutable blockPos;
    private final Box box;
    private final Vec3d vec3dRayTraceEnd;
    private RaycastContext raycastContext;
    private boolean placing;
    private int placingTimer;
    public final Mutable placingCrystalBlockPos;
    private final IntSet removed;
    private final Int2IntMap attemptedBreaks;
    private final Int2IntMap waitingToExplode;
    public int attacks;
    private double serverYaw;
    private float pDamage;
    private int bestTargetTimer;
    private boolean didRotateThisTick;
    private boolean isLastRotationPos;
    private final Vec3d lastRotationPos;
    private double lastYaw;
    private double lastPitch;
    private int lastRotationTimer;
    public TimerUtils targetPoppedTimer;
    private int renderTimer;
    private int breakRenderTimer;
    private final Mutable renderPos;
    private final Mutable breakRenderPos;
    private final Pool<RozaliyaAura.RenderBlock> renderBlockPool;
    private final List<RozaliyaAura.RenderBlock> renderBlocks;
    private final Pool<RozaliyaAura.RenderBlock> renderBreakBlockPool;
    private final List<RozaliyaAura.RenderBlock> renderBreakBlocks;
    private double damage;

    public RozaliyaAura() {
        super(DeltaHack.Autist, "Rozaliya-aura", "Finally");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgPlace = this.settings.createGroup("Place");
        this.sgFacePlace = this.settings.createGroup("Face Place");
        this.sgBreak = this.settings.createGroup("Break");
        this.sgFastBreak = this.settings.createGroup("Fast Break");
        this.sgPause = this.settings.createGroup("Pause");
        this.sgRender = this.settings.createGroup("Render");
        this.debug = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("debug-mode")).description("Informs you what the CA is doing.")).defaultValue(false)).build());
        this.explosionRadiusToTarget = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("place-radius")).description("How far crystals can be placed from the target.")).defaultValue(10.0D).range(1.0D, 12.0D).sliderRange(1.0D, 12.0D).build());
        this.predictMovement = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("predict-movement")).description("Predict the target's movement.")).defaultValue(true)).build());
        this.ignoreTerrain = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("ignore-terrain")).description("Ignore blocks if they can be blown up by crystals.")).defaultValue(false)).build());
        this.fullBlocks = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("full-blocks")).description("Treat anvils and ender chests as full blocks.")).defaultValue(false)).build());
        this.hideSwings = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("hide-swings")).description("Whether to send hand swing packets to the server.")).defaultValue(false)).build());
        this.autoSwitch = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("auto-switch")).description("Switches to crystals in your hotbar once a target is found.")).defaultValue(RozaliyaAura.AutoSwitchMode.Silent)).build());
        this.noGapSwitch = this.sgGeneral.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("No Gap Switch")).description("Disables normal auto switch when you are holding a gap.")).defaultValue(true)).visible(() -> {
            return this.autoSwitch.get() == RozaliyaAura.AutoSwitchMode.Normal;
        })).build());
        this.rotate = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("Rotates server-side towards the crystals being hit/placed.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("yaw-steps-mode")).description("When to run the yaw steps check.")).defaultValue(RozaliyaAura.YawStepMode.Break);
        Setting var10003 = this.rotate;
        Objects.requireNonNull(var10003);
        this.yawStepMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("yaw-steps")).description("Maximum degrees to rotate in one tick.")).defaultValue(180.0D).range(1.0D, 180.0D).sliderRange(1.0D, 180.0D);
        var10003 = this.rotate;
        Objects.requireNonNull(var10003);
        this.yawSteps = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var1.visible(var10003::get)).build());
        this.doPlace = this.sgPlace.add(((Builder)((Builder)((Builder)(new Builder()).name("place")).description("If the CA should place crystals.")).defaultValue(true)).build());
        var10001 = this.sgPlace;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var2 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("place-delay")).description("The delay in ticks to wait to place a crystal after it's exploded.")).defaultValue(0)).range(0, 20).sliderRange(0, 20);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.placeDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgPlace;
        var1 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("place-range")).description("How far away you can place crystals.")).defaultValue(5.5D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.placeRange = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgPlace;
        var1 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("place-walls-range")).description("How far away you can place crystals through blocks.")).defaultValue(5.5D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.placeWallsRange = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgPlace;
        Builder var3 = (Builder)((Builder)((Builder)(new Builder()).name("1.12-placement")).description("Uses 1.12 crystal placement.")).defaultValue(false);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.placement112 = var10001.add(((Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgPlace;
        var3 = (Builder)((Builder)((Builder)(new Builder()).name("small-box")).description("Allows you to place in 1x1x1 box instead of 1x2x1 boxes.")).defaultValue(false);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.smallBox = var10001.add(((Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgPlace;
        var10002 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("support")).description("Places a support block in air if no other position have been found.")).defaultValue(RozaliyaAura.SupportMode.Disabled);
        var10003 = this.doPlace;
        Objects.requireNonNull(var10003);
        this.support = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var10002.visible(var10003::get)).build());
        this.supportDelay = this.sgPlace.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("support-delay")).description("Delay in ticks after placing support block.")).defaultValue(1)).min(0).visible(() -> {
            return this.support.get() != RozaliyaAura.SupportMode.Disabled && (Boolean)this.doPlace.get();
        })).build());
        this.facePlace = this.sgFacePlace.add(((Builder)((Builder)((Builder)(new Builder()).name("face-place")).description("Will place crystals against the enemy's face.")).defaultValue(false)).build());
        var10001 = this.sgFacePlace;
        var3 = (Builder)((Builder)((Builder)(new Builder()).name("slow-place")).description("Place slower while face placing to reserve crystals.")).defaultValue(false);
        var10003 = this.facePlace;
        Objects.requireNonNull(var10003);
        this.slowFacePlace = var10001.add(((Builder)var3.visible(var10003::get)).build());
        this.slowFPMode = this.sgFacePlace.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("slow-FP-mode")).description("How to measure the delay for slow face place.")).defaultValue(RozaliyaAura.SlowMode.Delay)).visible(() -> {
            return (Boolean)this.facePlace.get() && (Boolean)this.slowFacePlace.get();
        })).build());
        this.slowFPAge = this.sgFacePlace.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("slow-FP-age")).description("How old a crystal must be server-side in ticks to be broken.")).defaultValue(3)).range(0, 20).sliderRange(0, 20).visible(() -> {
            return (Boolean)this.facePlace.get() && (Boolean)this.slowFacePlace.get() && this.slowFPMode.get() != RozaliyaAura.SlowMode.Delay;
        })).build());
        this.antiWeakness = this.sgBreak.add(((Builder)((Builder)((Builder)(new Builder()).name("anti-weakness")).description("Switches to tools with high enough damage to explode the crystal with weakness effect.")).defaultValue(true)).build());
        this.BminDamage = this.sgBreak.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-break-damage")).description("Minimum break damage the crystal needs to deal to your target.")).defaultValue(6.0D).range(0.0D, 36.0D).sliderRange(0.0D, 36.0D).build());
        this.attackFrequency = this.sgBreak.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("attack-frequency")).description("Maximum hits to do per second.")).defaultValue(25)).range(1, 30).sliderRange(1, 30).build());
        this.cancelCrystalMode = this.sgBreak.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("cancel-mode")).description("PositionMode to use for the crystals to be removed from the world.")).defaultValue(RozaliyaAura.CancelCrystalMode.NoDesync)).build());
        this.cancelTicks = this.sgBreak.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("cancel-ticks")).description("How long a tick should exist before being canceled.")).defaultValue(3)).range(1, 5).sliderRange(1, 5).build());
        this.breakDelay = this.sgBreak.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-delay")).description("The delay in ticks to wait to break a crystal after it's placed.")).defaultValue(0)).min(0).sliderRange(0, 20).build());
        this.smartDelay = this.sgBreak.add(((Builder)((Builder)((Builder)(new Builder()).name("smart-delay")).description("Only breaks crystals when the target can receive damage.")).defaultValue(false)).build());
        this.switchDelay = this.sgBreak.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("switch-delay")).description("The delay in ticks to wait to break a crystal after switching hotbar slot.")).defaultValue(0)).min(0).sliderMax(10).build());
        this.breakRange = this.sgBreak.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("break-range")).description("Range in which to break crystals.")).defaultValue(4.0D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D).build());
        this.breakWallsRange = this.sgBreak.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("break-walls-range")).description("Range in which to break crystals when behind blocks.")).defaultValue(4.0D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D).build());
        this.attemptCheck = this.sgBreak.add(((Builder)((Builder)((Builder)(new Builder()).name("break-attempt-check")).description("Whether to account for how many times you try to hit a crystal.")).defaultValue(false)).build());
        var10001 = this.sgBreak;
        var2 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-attempts")).description("How many times to hit a crystal before finding a new placement.")).defaultValue(2)).sliderRange(0, 5);
        var10003 = this.attemptCheck;
        Objects.requireNonNull(var10003);
        this.breakAttempts = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var2.visible(var10003::get)).build());
        this.ticksExisted = this.sgBreak.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("ticks-existed")).description("Amount of ticks a crystal needs to have existed for it to be attacked.")).defaultValue(1)).sliderRange(0, 10).min(0).build());
        this.fastBreak = this.sgFastBreak.add(((Builder)((Builder)((Builder)(new Builder()).name("fast-break")).description("Ignores break delay and tries to break the crystal as soon as it's spawned in the world.")).defaultValue(true)).build());
        var10001 = this.sgFastBreak;
        var3 = (Builder)((Builder)((Builder)(new Builder()).name("frequency-check")).description("Will not try to fast break if your attack exceeds the attack frequency.")).defaultValue(true);
        var10003 = this.fastBreak;
        Objects.requireNonNull(var10003);
        this.freqCheck = var10001.add(((Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgFastBreak;
        var3 = (Builder)((Builder)((Builder)(new Builder()).name("damage-check")).description("Check if the crystal meets min damage first.")).defaultValue(true);
        var10003 = this.fastBreak;
        Objects.requireNonNull(var10003);
        this.minDcheck = var10001.add(((Builder)var3.visible(var10003::get)).build());
        this.targetPopInvincibility = this.sgBreak.add(((Builder)((Builder)((Builder)(new Builder()).name("target-pop-invincibility")).description("Tries to pause certain actions when your enemy just popped.")).defaultValue(false)).build());
        var10001 = this.sgBreak;
        var2 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("target-pop-time")).description("How many milliseconds to consider for target-pop invincibility")).defaultValue(450)).sliderRange(1, 2000);
        var10003 = this.targetPopInvincibility;
        Objects.requireNonNull(var10003);
        this.targetPopInvincibilityTime = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var2.visible(var10003::get)).build());
        this.pauseAtHealth = this.sgPause.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("pause-health")).description("Pauses when you go below a certain health.")).defaultValue(5.0D).min(0.0D).build());
        this.eatPause = this.sgPause.add(((Builder)((Builder)((Builder)(new Builder()).name("pause-on-eat")).description("Pauses Crystal Aura when eating.")).defaultValue(true)).build());
        this.drinkPause = this.sgPause.add(((Builder)((Builder)((Builder)(new Builder()).name("pause-on-drink")).description("Pauses Crystal Aura when drinking.")).defaultValue(true)).build());
        this.minePause = this.sgPause.add(((Builder)((Builder)((Builder)(new Builder()).name("pause-on-mine")).description("Pauses Crystal Aura when mining.")).defaultValue(false)).build());
        this.renderSwing = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render-swing")).description("Whether to swing your hand client side")).defaultValue(true)).build());
        this.renderMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("render-mode")).description("The mode to render in.")).defaultValue(RozaliyaAura.RenderMode.Normal)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None;
        })).build());
        this.fadeTime = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fade-time")).description("Tick duration for rendering placing.")).defaultValue(8)).range(0, 20).sliderRange(0, 20).visible(() -> {
            return this.renderMode.get() == RozaliyaAura.RenderMode.Fade;
        })).build());
        this.fadeAmount = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fade-amount")).description("How strong the fade should be.")).defaultValue(8)).range(0, 100).sliderRange(0, 100).visible(() -> {
            return this.renderMode.get() == RozaliyaAura.RenderMode.Fade;
        })).build());
        this.renderTime = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("place-time")).description("How long to render placements for.")).defaultValue(10)).range(0, 20).sliderRange(0, 20).visible(() -> {
            return this.renderMode.get() == RozaliyaAura.RenderMode.Normal;
        })).build());
        this.placeSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("place-side-color")).description("The side color of the block overlay.")).defaultValue(new SettingColor(255, 255, 255, 45))).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && this.shapeMode.get() != ShapeMode.Lines;
        })).build());
        this.placeLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("place-line-color")).description("The line color of the block overlay.")).defaultValue(new SettingColor(255, 255, 255, 255))).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && this.shapeMode.get() != ShapeMode.Sides;
        })).build());
        this.renderBreak = this.sgRender.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("break")).description("Renders a block overlay over the block the crystals are broken on.")).defaultValue(false)).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None;
        })).build());
        this.renderBreakTime = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-time")).description("How long to render breaking for.")).defaultValue(7)).range(0, 20).sliderRange(0, 20).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && (Boolean)this.renderBreak.get() && this.renderMode.get() == RozaliyaAura.RenderMode.Normal;
        })).build());
        this.breakSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("break-side-color")).description("The side color of the block overlay.")).defaultValue(new SettingColor(255, 255, 255, 45))).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && (Boolean)this.renderBreak.get() && this.shapeMode.get() != ShapeMode.Lines;
        })).build());
        this.breakLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("break-line-color")).description("The line color of the block overlay.")).defaultValue(new SettingColor(255, 255, 255, 255))).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && (Boolean)this.renderBreak.get() && this.shapeMode.get() != ShapeMode.Sides;
        })).build());
        this.renderDamage = this.sgRender.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("damage")).description("Renders crystal damage text in the block overlay.")).defaultValue(true)).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None;
        })).build());
        this.damageScale = this.sgRender.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("damage-scale")).description("How big the damage text should be.")).defaultValue(1.25D).min(1.0D).sliderMax(4.0D).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && (Boolean)this.renderDamage.get();
        })).build());
        this.damageColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("damage-color")).description("What the color of the damage text should be.")).defaultValue(new SettingColor(255, 255, 255, 255))).visible(() -> {
            return this.renderMode.get() != RozaliyaAura.RenderMode.None && (Boolean)this.renderDamage.get();
        })).build());
        this.vec3d = new Vec3d(0.0D, 0.0D, 0.0D);
        this.playerEyePos = new Vec3d(0.0D, 0.0D, 0.0D);
        this.vec3 = new Vec3();
        this.blockPos = new Mutable();
        this.box = new Box(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
        this.vec3dRayTraceEnd = new Vec3d(0.0D, 0.0D, 0.0D);
        this.placingCrystalBlockPos = new Mutable();
        this.removed = new IntOpenHashSet();
        this.attemptedBreaks = new Int2IntOpenHashMap();
        this.waitingToExplode = new Int2IntOpenHashMap();
        this.lastRotationPos = new Vec3d(0.0D, 0.0D, 0.0D);
        this.targetPoppedTimer = new TimerUtils();
        this.renderPos = new Mutable();
        this.breakRenderPos = new Mutable();
        this.renderBlockPool = new Pool(() -> {
            return new RozaliyaAura.RenderBlock();
        });
        this.renderBlocks = new ArrayList();
        this.renderBreakBlockPool = new Pool(() -> {
            return new RozaliyaAura.RenderBlock();
        });
        this.renderBreakBlocks = new ArrayList();
    }

    public void onActivate() {
        this.breakTimer = 0;
        this.placeTimer = 0;
        this.ticksPassed = 0;
        this.raycastContext = new RaycastContext(new Vec3d(0.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, 0.0D), ShapeType.COLLIDER, FluidHandling.NONE, this.mc.player);
        this.placing = false;
        this.placingTimer = 0;
        this.attacks = 0;
        this.serverYaw = (double)this.mc.player.getYaw();
        this.pDamage = 0.0F;
        this.bestTargetTimer = 0;
        this.lastRotationTimer = this.getLastRotationStopDelay();
        this.renderTimer = 0;
        this.breakRenderTimer = 0;
        Iterator var1 = this.renderBlocks.iterator();

        RozaliyaAura.RenderBlock renderBlock;
        while(var1.hasNext()) {
            renderBlock = (RozaliyaAura.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        var1 = this.renderBreakBlocks.iterator();

        while(var1.hasNext()) {
            renderBlock = (RozaliyaAura.RenderBlock)var1.next();
            this.renderBreakBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    public void onDeactivate() {
        this.attemptedBreaks.clear();
        this.waitingToExplode.clear();
        this.removed.clear();
        Iterator var1 = this.renderBlocks.iterator();

        RozaliyaAura.RenderBlock renderBlock;
        while(var1.hasNext()) {
            renderBlock = (RozaliyaAura.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        var1 = this.renderBreakBlocks.iterator();

        while(var1.hasNext()) {
            renderBlock = (RozaliyaAura.RenderBlock)var1.next();
            this.renderBreakBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    private int getLastRotationStopDelay() {
        return Math.max(10, (Integer)this.placeDelay.get() / 2 + (Integer)this.breakDelay.get() / 2 + 10);
    }

    @EventHandler
    private void onPreTick(Pre event) {
        if (this.renderTimer > 0) {
            --this.renderTimer;
        }

        if (this.breakRenderTimer > 0) {
            --this.breakRenderTimer;
        }

        this.renderBlocks.forEach(RozaliyaAura.RenderBlock::tick);
        this.renderBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        this.renderBreakBlocks.forEach(RozaliyaAura.RenderBlock::tick);
        this.renderBreakBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        this.didRotateThisTick = false;
        ++this.lastRotationTimer;
        if (this.placing) {
            if (this.placingTimer > 0) {
                --this.placingTimer;
            } else {
                this.placing = false;
            }
        }

        if (this.ticksPassed < 20) {
            ++this.ticksPassed;
        } else {
            this.ticksPassed = 0;
            this.attacks = 0;
        }

        if (this.bestTargetTimer > 0) {
            --this.bestTargetTimer;
        }

        this.pDamage = 0.0F;
        if (this.breakTimer > 0) {
            --this.breakTimer;
        }

        if (this.placeTimer > 0) {
            --this.placeTimer;
        }

        if (this.switchTimer > 0) {
            --this.switchTimer;
        }

        IntIterator it = this.waitingToExplode.keySet().iterator();

        while(it.hasNext()) {
            int id = it.nextInt();
            int ticks = this.waitingToExplode.get(id);
            if (ticks >= (Integer)this.cancelTicks.get()) {
                it.remove();
                this.removed.remove(id);
            } else {
                this.waitingToExplode.put(id, ticks + 1);
            }
        }

        if (!PlayerUtils.shouldPause((Boolean)this.minePause.get(), (Boolean)this.eatPause.get(), (Boolean)this.drinkPause.get()) && !(PlayerUtils.getTotalHealth() <= (Double)this.pauseAtHealth.get())) {
            ((IVec3d)this.playerEyePos).set(this.mc.player.getPos().x, this.mc.player.getPos().y + (double)this.mc.player.getEyeHeight(this.mc.player.getPose()), this.mc.player.getPos().z);
            this.doBreak();
            this.doPlace();
            if (this.cancelCrystalMode.get() == RozaliyaAura.CancelCrystalMode.Hit) {
                this.removed.forEach((idx) -> {
                    ((Entity)Objects.requireNonNull(this.mc.world.getEntityById(idx))).kill();
                });
                this.removed.clear();
            }

        } else {
            if ((Boolean)this.debug.get()) {
                this.warning("Pausing", new Object[0]);
            }

        }
    }

    @EventHandler(
        priority = -866
    )
    private void onPreTickLast(Pre event) {
        if ((Boolean)this.rotate.get() && this.lastRotationTimer < this.getLastRotationStopDelay() && !this.didRotateThisTick) {
            Rotations.rotate(this.isLastRotationPos ? Rotations.getYaw(this.lastRotationPos) : this.lastYaw, this.isLastRotationPos ? Rotations.getPitch(this.lastRotationPos) : this.lastPitch, -100, (Runnable)null);
        }

    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (event.entity instanceof EndCrystalEntity) {
            if (this.placing && event.entity.getBlockPos().equals(this.placingCrystalBlockPos)) {
                this.placing = false;
                this.placingTimer = 0;
            }

            if ((Boolean)this.fastBreak.get()) {
                if ((Boolean)this.freqCheck.get() && this.attacks > (Integer)this.attackFrequency.get()) {
                    return;
                }

                float damage = this.getBreakDamage(event.entity, false);
                if ((Boolean)this.minDcheck.get() && (double)damage < (Double)this.BminDamage.get()) {
                    return;
                }

                this.doBreak(event.entity);
            }

        }
    }

    @EventHandler
    private void onEntityRemoved(EntityRemovedEvent event) {
        if (event.entity instanceof EndCrystalEntity) {
            this.removed.remove(event.entity.getId());
            this.waitingToExplode.remove(event.entity.getId());
        }

    }

    private void setRotation(boolean isPos, Vec3d pos, double yaw, double pitch) {
        this.didRotateThisTick = true;
        this.isLastRotationPos = isPos;
        if (isPos) {
            ((IVec3d)this.lastRotationPos).set(pos.x, pos.y, pos.z);
        } else {
            this.lastYaw = yaw;
            this.lastPitch = pitch;
        }

        this.lastRotationTimer = 0;
    }

    private void doBreak() {
        if (this.breakTimer <= 0 && this.switchTimer <= 0 && this.attacks < (Integer)this.attackFrequency.get() && (this.targetPoppedTimer.passedMillis((long)(Integer)this.targetPopInvincibilityTime.get()) || !(Boolean)this.targetPopInvincibility.get())) {
            float bestDamage = 0.0F;
            Entity crystal = null;
            Iterator var3 = this.mc.world.getEntities().iterator();

            while(var3.hasNext()) {
                Entity entity = (Entity)var3.next();
                float damage = this.getBreakDamage(entity, true);
                if (damage > bestDamage) {
                    bestDamage = damage;
                    crystal = entity;
                }
            }

            if (crystal != null) {
                this.doBreak(crystal);
            }

        }
    }

    private float getBreakDamage(Entity entity, boolean checkCrystalAge) {
        if (!(entity instanceof EndCrystalEntity)) {
            return 0.0F;
        } else if (this.removed.contains(entity.getId())) {
            return 0.0F;
        } else if ((Boolean)this.attemptCheck.get() && this.attemptedBreaks.get(entity.getId()) > (Integer)this.breakAttempts.get()) {
            return 0.0F;
        } else if (checkCrystalAge && entity.age < (Integer)this.ticksExisted.get()) {
            return 0.0F;
        } else if ((Boolean)this.slowFacePlace.get() && this.slowFPMode.get() != RozaliyaAura.SlowMode.Delay && (Boolean)this.facePlace.get() && this.mc.player.getY() < (double)this.placingCrystalBlockPos.getY() && checkCrystalAge && entity.age < (Integer)this.slowFPAge.get()) {
            return 0.0F;
        } else if (this.isOutOfBreakRange(entity)) {
            return 0.0F;
        } else {
            this.blockPos.set(entity.getBlockPos()).move(0, -1, 0);
            float damage = this.getDamageToTargets(entity.getPos(), true, false);
            boolean facePlaced = (Boolean)this.facePlace.get() && damage > 1.0F;
            return !facePlaced && (double)damage < (Double)this.BminDamage.get() ? 0.0F : damage;
        }
    }

    private void doBreak(Entity crystal) {
        if ((Boolean)this.antiWeakness.get()) {
            StatusEffectInstance weakness = this.mc.player.getStatusEffect(StatusEffects.WEAKNESS);
            StatusEffectInstance strength = this.mc.player.getStatusEffect(StatusEffects.STRENGTH);
            if (weakness != null && (strength == null || strength.getAmplifier() <= weakness.getAmplifier()) && !this.isValidWeaknessItem(this.mc.player.getMainHandStack())) {
                if (!InvUtils.swap(InvUtils.findInHotbar(this::isValidWeaknessItem).slot(), false)) {
                    return;
                }

                this.switchTimer = 1;
                return;
            }
        }

        boolean attacked = true;
        if (!(Boolean)this.rotate.get()) {
            CrystalUtils.attackCrystal(crystal, (Boolean)this.renderSwing.get());
        } else {
            double yaw = Rotations.getYaw(crystal);
            double pitch = Rotations.getPitch(crystal, Target.Feet);
            if (this.doYawSteps(yaw, pitch)) {
                this.setRotation(true, crystal.getPos(), 0.0D, 0.0D);
                Rotations.rotate(yaw, pitch, 50, () -> {
                    CrystalUtils.attackCrystal(crystal, (Boolean)this.renderSwing.get());
                });
            } else {
                attacked = false;
            }
        }

        if (attacked) {
            this.removed.add(crystal.getId());
            this.attemptedBreaks.put(crystal.getId(), this.attemptedBreaks.get(crystal.getId()) + 1);
            this.waitingToExplode.put(crystal.getId(), 0);
            this.renderBreakBlocks.add(((RozaliyaAura.RenderBlock)this.renderBreakBlockPool.get()).set(crystal.getBlockPos().down()));
            this.breakRenderPos.set(crystal.getBlockPos().down());
            this.breakRenderTimer = (Integer)this.renderBreakTime.get();
        }

    }

    private boolean isValidWeaknessItem(ItemStack itemStack) {
        if (itemStack.getItem() instanceof ToolItem && !(itemStack.getItem() instanceof HoeItem)) {
            ToolMaterial material = ((ToolItem)itemStack.getItem()).getMaterial();
            return material == ToolMaterials.DIAMOND || material == ToolMaterials.NETHERITE;
        } else {
            return false;
        }
    }

    @EventHandler
    private void onPacketSend(Send event) {
        if (event.packet instanceof UpdateSelectedSlotC2SPacket) {
            this.switchTimer = (Integer)this.switchDelay.get();
        }

    }

    private void doPlace() {
        if ((Boolean)this.doPlace.get() && this.placeTimer <= 0) {
            if (InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL}).found()) {
                if (this.autoSwitch.get() != RozaliyaAura.AutoSwitchMode.None || this.mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL || this.mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL) {
                    Iterator var1 = this.mc.world.getEntities().iterator();

                    Entity entity;
                    do {
                        if (!var1.hasNext()) {
                            AtomicDouble bestDamage = new AtomicDouble(0.0D);
                            AtomicReference<Mutable> bestBlockPos = new AtomicReference(new Mutable());
                            AtomicBoolean isSupport = new AtomicBoolean(this.support.get() != RozaliyaAura.SupportMode.Disabled);
                            BlockIterator.register((int)Math.ceil((Double)this.placeRange.get()), (int)Math.ceil((Double)this.placeRange.get()), (bp, blockState) -> {
                                boolean hasBlock = blockState.isOf(Blocks.BEDROCK) || blockState.isOf(Blocks.OBSIDIAN);
                                if (!hasBlock) {
                                    if (!isSupport.get()) {
                                        return;
                                    }

                                    if (!blockState.getMaterial().isReplaceable()) {
                                        return;
                                    }
                                }

                                this.blockPos.set(bp.getX(), bp.getY() + 1, bp.getZ());
                                if (this.mc.world.getBlockState(this.blockPos).isAir()) {
                                    if ((Boolean)this.placement112.get()) {
                                        this.blockPos.move(0, 1, 0);
                                        if (!this.mc.world.getBlockState(this.blockPos).isAir()) {
                                            return;
                                        }
                                    }

                                    ((IVec3d)this.vec3d).set((double)bp.getX() + 0.5D, (double)(bp.getY() + 1), (double)bp.getZ() + 0.5D);
                                    this.blockPos.set(bp).move(0, 1, 0);
                                    if (!this.isOutOfPlaceRange(this.vec3d, this.blockPos)) {
                                        int x = bp.getX();
                                        int y = bp.getY() + 1;
                                        int z = bp.getZ();
                                        ((IBox)this.box).set((double)x + 0.001D, (double)y, (double)z + 0.001D, (double)x + 0.999D, (double)(y + ((Boolean)this.smallBox.get() ? 1 : 2)), (double)z + 0.999D);
                                        if (!this.intersectsWithEntities(this.box)) {
                                            float damage = this.getDamageToTargets(this.vec3d, false, !hasBlock && this.support.get() == RozaliyaAura.SupportMode.Fast);
                                            if ((double)damage > bestDamage.get() || isSupport.get() && hasBlock) {
                                                bestDamage.set((double)damage);
                                                ((Mutable)bestBlockPos.get()).set(bp);
                                            }

                                            if (hasBlock) {
                                                isSupport.set(false);
                                            }

                                        }
                                    }
                                }
                            });
                            BlockIterator.after(() -> {
                                if (!(bestDamage.get() < (Double)this.BminDamage.get())) {
                                    BlockHitResult result = this.getPlaceInfo((BlockPos)bestBlockPos.get());
                                    ((IVec3d)this.vec3d).set((double)result.getBlockPos().getX() + 0.5D + (double)result.getSide().getVector().getX() * 0.5D, (double)result.getBlockPos().getY() + 0.5D + (double)result.getSide().getVector().getY() * 0.5D, (double)result.getBlockPos().getZ() + 0.5D + (double)result.getSide().getVector().getZ() * 0.5D);
                                    if ((Boolean)this.rotate.get()) {
                                        double yaw = Rotations.getYaw(this.vec3d);
                                        double pitch = Rotations.getPitch(this.vec3d);
                                        if (this.yawStepMode.get() == RozaliyaAura.YawStepMode.Break || this.doYawSteps(yaw, pitch)) {
                                            this.setRotation(true, this.vec3d, 0.0D, 0.0D);
                                            Rotations.rotate(yaw, pitch, 50, () -> {
                                                this.placeCrystal(result, bestDamage.get(), isSupport.get() ? (BlockPos)bestBlockPos.get() : null);
                                            });
                                            this.placeTimer += (Integer)this.placeDelay.get();
                                        }
                                    } else {
                                        this.placeCrystal(result, bestDamage.get(), isSupport.get() ? (BlockPos)bestBlockPos.get() : null);
                                        this.placeTimer += (Integer)this.placeDelay.get();
                                    }

                                }
                            });
                            return;
                        }

                        entity = (Entity)var1.next();
                    } while(!(this.getBreakDamage(entity, false) > 1.0F));

                }
            }
        }
    }

    private BlockHitResult getPlaceInfo(BlockPos blockPos) {
        ((IVec3d)this.vec3d).set(this.mc.player.getX(), this.mc.player.getY() + (double)this.mc.player.getEyeHeight(this.mc.player.getPose()), this.mc.player.getZ());
        Direction[] var2 = Direction.values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Direction side = var2[var4];
            ((IVec3d)this.vec3dRayTraceEnd).set((double)blockPos.getX() + 0.5D + (double)side.getVector().getX() * 0.5D, (double)blockPos.getY() + 0.5D + (double)side.getVector().getY() * 0.5D, (double)blockPos.getZ() + 0.5D + (double)side.getVector().getZ() * 0.5D);
            ((IRaycastContext)this.raycastContext).set(this.vec3d, this.vec3dRayTraceEnd, ShapeType.COLLIDER, FluidHandling.NONE, this.mc.player);
            BlockHitResult result = this.mc.world.raycast(this.raycastContext);
            if (result != null && result.getType() == Type.BLOCK && result.getBlockPos().equals(blockPos)) {
                return result;
            }
        }

        Direction side = (double)blockPos.getY() > this.vec3d.y ? Direction.DOWN : Direction.UP;
        return new BlockHitResult(this.vec3d, side, blockPos, false);
    }

    private void placeCrystal(BlockHitResult result, double damage, BlockPos supportBlock) {
        Item targetItem = supportBlock == null ? Items.END_CRYSTAL : Items.OBSIDIAN;
        FindItemResult item = InvUtils.findInHotbar(new Item[]{targetItem});
        if (item.found()) {
            int prevSlot = this.mc.player.getInventory().selectedSlot;
            if (this.mc.player.getOffHandStack().getItem() instanceof EndCrystalItem || this.autoSwitch.get() != RozaliyaAura.AutoSwitchMode.Normal || !(Boolean)this.noGapSwitch.get() || !(this.mc.player.getMainHandStack().getItem() instanceof EnchantedGoldenAppleItem)) {
                if (this.autoSwitch.get() != RozaliyaAura.AutoSwitchMode.None && !item.isOffhand()) {
                    InvUtils.swap(item.slot(), false);
                }

                Hand hand = item.getHand();
                if (hand != null) {
                    if (supportBlock == null) {
                        this.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(hand, result, 0));
                        if ((Boolean)this.renderSwing.get()) {
                            this.mc.player.swingHand(hand);
                        }

                        if (!(Boolean)this.hideSwings.get()) {
                            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
                        }

                        if ((Boolean)this.debug.get()) {
                            this.info("Placing", new Object[0]);
                        }

                        this.placing = true;
                        this.placingTimer = 4;
                        this.placingCrystalBlockPos.set(result.getBlockPos()).move(0, 1, 0);
                        this.renderBlocks.add(((RozaliyaAura.RenderBlock)this.renderBlockPool.get()).set(result.getBlockPos()));
                        this.renderTimer = (Integer)this.renderTime.get();
                        this.renderPos.set(result.getBlockPos());
                        this.damage = damage;
                    } else {
                        BlockUtils.place(supportBlock, item, false, 0, (Boolean)this.renderSwing.get(), true, false);
                        this.placeTimer += (Integer)this.supportDelay.get();
                        if ((Integer)this.supportDelay.get() == 0) {
                            this.placeCrystal(result, damage, (BlockPos)null);
                        }
                    }

                    if (this.autoSwitch.get() == RozaliyaAura.AutoSwitchMode.Silent) {
                        InvUtils.swap(prevSlot, false);
                    }

                }
            }
        }
    }

    @EventHandler
    private void onPacketSent(Sent event) {
        if (event.packet instanceof PlayerMoveC2SPacket) {
            this.serverYaw = (double)((PlayerMoveC2SPacket)event.packet).getYaw((float)this.serverYaw);
        }

    }

    public boolean doYawSteps(double targetYaw, double targetPitch) {
        targetYaw = MathHelper.wrapDegrees(targetYaw) + 180.0D;
        double serverYaw = MathHelper.wrapDegrees(this.serverYaw) + 180.0D;
        if (distanceBetweenAngles(serverYaw, targetYaw) <= (Double)this.yawSteps.get()) {
            return true;
        } else {
            double delta = Math.abs(targetYaw - serverYaw);
            double yaw = this.serverYaw;
            if (serverYaw < targetYaw) {
                if (delta < 180.0D) {
                    yaw += (Double)this.yawSteps.get();
                } else {
                    yaw -= (Double)this.yawSteps.get();
                }
            } else if (delta < 180.0D) {
                yaw -= (Double)this.yawSteps.get();
            } else {
                yaw += (Double)this.yawSteps.get();
            }

            this.setRotation(false, (Vec3d)null, yaw, targetPitch);
            Rotations.rotate(yaw, targetPitch, -100, (Runnable)null);
            return false;
        }
    }

    private static double distanceBetweenAngles(double alpha, double beta) {
        double phi = Math.abs(beta - alpha) % 360.0D;
        return phi > 180.0D ? 360.0D - phi : phi;
    }

    private boolean isOutOfPlaceRange(Vec3d vec3d, BlockPos blockPos) {
        ((IRaycastContext)this.raycastContext).set(this.playerEyePos, vec3d, ShapeType.COLLIDER, FluidHandling.NONE, this.mc.player);
        BlockHitResult result = this.mc.world.raycast(this.raycastContext);
        boolean behindWall = result == null || !result.getBlockPos().equals(blockPos);
        double distance = this.mc.player.getEyePos().distanceTo(vec3d);
        return distance > behindWall ? (Double)this.placeWallsRange.get() : (Double)this.placeRange.get();
    }

    private boolean isOutOfBreakRange(Entity entity) {
        boolean behindWall = !this.mc.player.canSee(entity);
        double distance = PlayerUtil.distanceFromEye(entity);
        return distance > behindWall ? (Double)this.breakWallsRange.get() : (Double)this.breakRange.get();
    }

    private float getDamageToTargets(Vec3d vec3d, boolean breaking, boolean fast) {
        float damage = 0.0F;
        if (fast) {
            if (!(Boolean)this.smartDelay.get() || !breaking || this.mc.player.hurtTime <= 0) {
                damage = DamageUtil.crystalDamage(this.mc.player, vec3d, (Boolean)this.predictMovement.get(), (double)((Double)this.explosionRadiusToTarget.get()).floatValue(), (Boolean)this.ignoreTerrain.get(), (Boolean)this.fullBlocks.get());
            }
        } else {
            if ((Boolean)this.smartDelay.get() && breaking && this.mc.player.hurtTime > 0) {
                return 0.0F;
            }

            float dmg = DamageUtil.crystalDamage(this.mc.player, vec3d, (Boolean)this.predictMovement.get(), (double)((Double)this.explosionRadiusToTarget.get()).floatValue(), (Boolean)this.ignoreTerrain.get(), (Boolean)this.fullBlocks.get());
            if (dmg > this.pDamage) {
                this.pDamage = dmg;
                this.bestTargetTimer = 10;
            }

            damage = dmg;
        }

        return damage;
    }

    private boolean intersectsWithEntities(Box box) {
        return EntityUtils.intersectsWithEntity(box, (entity) -> {
            return !entity.isSpectator() && !this.removed.contains(entity.getId());
        });
    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        Packet var3 = event.packet;
        if (var3 instanceof EntityStatusS2CPacket) {
            EntityStatusS2CPacket p = (EntityStatusS2CPacket)var3;
            if (p.getStatus() == 35) {
                Entity entity = p.getEntity(this.mc.world);
                if (entity instanceof PlayerEntity) {
                    if (entity.equals(this.mc.player) && (Boolean)this.targetPopInvincibility.get()) {
                        this.targetPoppedTimer.reset();
                    }

                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.renderMode.get() == RozaliyaAura.RenderMode.Fade) {
            this.renderBlocks.sort(Comparator.comparingInt((o) -> {
                return -o.ticks;
            }));
            this.renderBlocks.forEach((renderBlock) -> {
                renderBlock.render(event, (Color)this.placeSideColor.get(), (Color)this.placeLineColor.get(), (ShapeMode)this.shapeMode.get());
            });
            if ((Boolean)this.renderBreak.get()) {
                this.renderBreakBlocks.sort(Comparator.comparingInt((o) -> {
                    return -o.ticks;
                }));
                this.renderBreakBlocks.forEach((renderBlock) -> {
                    renderBlock.render(event, (Color)this.breakSideColor.get(), (Color)this.breakLineColor.get(), (ShapeMode)this.shapeMode.get());
                });
            }
        } else if (this.renderMode.get() == RozaliyaAura.RenderMode.Normal) {
            if (this.renderTimer > 0) {
                event.renderer.box(this.renderPos, (Color)this.placeSideColor.get(), (Color)this.placeLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

            if (this.breakRenderTimer > 0 && (Boolean)this.renderBreak.get() && !this.mc.world.getBlockState(this.breakRenderPos).isAir()) {
                int preSideA = 0;
                int preLineA = 0;
                if (this.renderMode.get() == RozaliyaAura.RenderMode.Fade) {
                    preSideA = ((SettingColor)this.placeSideColor.get()).a;
                    SettingColor var10000 = (SettingColor)this.placeSideColor.get();
                    var10000.a -= 20;
                    ((SettingColor)this.placeSideColor.get()).validate();
                    preLineA = ((SettingColor)this.breakLineColor.get()).a;
                    var10000 = (SettingColor)this.breakLineColor.get();
                    var10000.a -= 20;
                    ((SettingColor)this.breakLineColor.get()).validate();
                }

                event.renderer.box(this.breakRenderPos, (Color)this.breakSideColor.get(), (Color)this.breakLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                ((SettingColor)this.breakSideColor.get()).a = preSideA;
                ((SettingColor)this.breakLineColor.get()).a = preLineA;
            }
        }

    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (this.renderMode.get() != RozaliyaAura.RenderMode.None && this.renderTimer > 0 && (Boolean)this.renderDamage.get()) {
            this.vec3.set((double)this.renderPos.getX() + 0.5D, (double)this.renderPos.getY() + 0.5D, (double)this.renderPos.getZ() + 0.5D);
            if (NametagUtils.to2D(this.vec3, (Double)this.damageScale.get())) {
                NametagUtils.begin(this.vec3);
                TextRenderer.get().begin(1.0D, false, true);
                String text = String.format("%.1f", this.damage);
                double w = TextRenderer.get().getWidth(text) * 0.5D;
                TextRenderer.get().render(text, -w, 0.0D, (Color)this.damageColor.get(), true);
                TextRenderer.get().end();
                NametagUtils.end();
            }

        }
    }

    public static enum AutoSwitchMode {
        Normal,
        Silent,
        None;

        // $FF: synthetic method
        private static RozaliyaAura.AutoSwitchMode[] $values() {
            return new RozaliyaAura.AutoSwitchMode[]{Normal, Silent, None};
        }
    }

    public static enum YawStepMode {
        Break,
        All;

        // $FF: synthetic method
        private static RozaliyaAura.YawStepMode[] $values() {
            return new RozaliyaAura.YawStepMode[]{Break, All};
        }
    }

    public static enum SupportMode {
        Disabled,
        Accurate,
        Fast;

        // $FF: synthetic method
        private static RozaliyaAura.SupportMode[] $values() {
            return new RozaliyaAura.SupportMode[]{Disabled, Accurate, Fast};
        }
    }

    public static enum SlowMode {
        Delay,
        Age,
        Both;

        // $FF: synthetic method
        private static RozaliyaAura.SlowMode[] $values() {
            return new RozaliyaAura.SlowMode[]{Delay, Age, Both};
        }
    }

    public static enum CancelCrystalMode {
        Hit,
        NoDesync;

        // $FF: synthetic method
        private static RozaliyaAura.CancelCrystalMode[] $values() {
            return new RozaliyaAura.CancelCrystalMode[]{Hit, NoDesync};
        }
    }

    public static enum RenderMode {
        Normal,
        Fade,
        None;

        // $FF: synthetic method
        private static RozaliyaAura.RenderMode[] $values() {
            return new RozaliyaAura.RenderMode[]{Normal, Fade, None};
        }
    }

    public class RenderBlock {
        public Mutable pos = new Mutable();
        public int ticks;

        public RozaliyaAura.RenderBlock set(BlockPos blockPos) {
            this.pos.set(blockPos);
            this.ticks = (Integer)RozaliyaAura.this.fadeTime.get();
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
            int preSideA = sides.a;
            int preLineA = lines.a;
            sides.a = (int)((double)sides.a * ((double)this.ticks / (double)(Integer)RozaliyaAura.this.fadeAmount.get()));
            lines.a = (int)((double)lines.a * ((double)this.ticks / (double)(Integer)RozaliyaAura.this.fadeAmount.get()));
            event.renderer.box(this.pos, sides, lines, shapeMode, 0);
            sides.a = preSideA;
            lines.a = preLineA;
        }
    }
}
