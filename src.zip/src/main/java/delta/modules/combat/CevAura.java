package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.utils.BlockUtil;
import delta.utils.DamageUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.RenderUtil;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class CevAura extends Module {
    private final SettingGroup sgDefault;
    private final SettingGroup sgTarget;
    private final SettingGroup sgRender;
    private final Setting<CevAura.CrystalMode> crystalMode;
    private final Setting<Double> breakingProgress;
    private final Setting<Integer> supportDelay;
    private final Setting<Double> actionRange;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> swing;
    private final Setting<CevAura.Priority> blockPrio;
    private final Setting<Integer> crystalDelay;
    private final Setting<Double> enemyRange;
    private final Setting<Boolean> noTargetDisable;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<SortPriority> tarPrio;
    private final Setting<Double> minHealth;
    private final Setting<Boolean> render;
    private final Setting<Boolean> renderProgress;
    private final Setting<Double> progressTextScale;
    private final Setting<SettingColor> textColor;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> sideColor2;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> lineColor2;
    private final Setting<Integer> width;
    private final Setting<Boolean> notify;
    private final Vec3 vec32;
    private final Vec3 vec3;
    private static PlayerEntity target;
    private static BlockPos minePos;
    private static int timer;

    public CevAura() {
        super(DeltaHack.Combat, "cev-aura", "Exposes the enemy to crystal damage from above");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgTarget = this.settings.createGroup("Targeting");
        this.sgRender = this.settings.createGroup("Render");
        this.crystalMode = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("crystal-mode")).description(".")).defaultValue(CevAura.CrystalMode.Any)).build());
        this.breakingProgress = this.sgDefault.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("breaking-progress")).description("-")).defaultValue(0.95D).min(0.0D).sliderMax(1.0D).visible(() -> {
            return this.crystalMode.get() == CevAura.CrystalMode.Any;
        })).build());
        this.supportDelay = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("support-delay")).sliderRange(0, 10).defaultValue(3)).min(0).build());
        this.actionRange = this.sgDefault.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("action-range")).description("The radius in which blocks get targeted.")).defaultValue(4.5D).min(0.0D).sliderMax(6.0D).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates to the blocks you break server side.")).defaultValue(true)).build());
        this.swing = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when breaking the blocks.")).defaultValue(true)).build());
        this.blockPrio = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("block-priority")).description("How to select the block to mine.")).defaultValue(CevAura.Priority.TopBlock)).build());
        this.crystalDelay = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("crystal-delay")).description("The amount of ticks to wait before placing the crystal.")).defaultValue(1)).min(0).sliderMax(5).visible(() -> {
            return this.crystalMode.get() == CevAura.CrystalMode.Strict;
        })).build());
        this.enemyRange = this.sgTarget.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("enemy-range")).description("The radius in which entities get targeted.")).defaultValue(7.0D).min(0.0D).sliderMax(10.0D).build());
        this.noTargetDisable = this.sgTarget.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("no-targets-disable")).description("disabling when no target.")).defaultValue(false)).build());
        this.entities = this.sgTarget.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("entities")).description("Entities to attack.")).defaultValue(new Object2BooleanOpenHashMap(0))).onlyAttackable().build());
        this.tarPrio = this.sgTarget.add(((Builder)((Builder)((Builder)(new Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.ClosestAngle)).build());
        this.minHealth = this.sgTarget.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-health")).description("The minimum health required for Cev to work.")).defaultValue(7.0D).range(0.0D, 20.0D).sliderMax(36.0D).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Render the the .")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-progress")).description("Renders the current block being mined.");
        Setting var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.renderProgress = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).defaultValue(true)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("text-scale")).description("How big the damage text should be.")).defaultValue(1.25D).min(1.0D).sliderMax(4.0D);
        var10003 = this.renderProgress;
        Objects.requireNonNull(var10003);
        this.progressTextScale = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.ColorSetting.Builder var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("text-color")).description("The text color.")).defaultValue(new SettingColor(255, 255, 255));
        var10003 = this.renderProgress;
        Objects.requireNonNull(var10003);
        this.textColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        this.shapeMode = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Lines)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color.")).defaultValue(new SettingColor(28, 255, 15, 75))).build());
        this.sideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color-2")).description("The side color.")).defaultValue(new SettingColor(100, 255, 15, 55))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 27))).build());
        this.lineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color-2")).description("The line color.")).defaultValue(new SettingColor(152, 255, 15))).build());
        this.width = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).defaultValue(1)).min(1).max(5).sliderMin(1).sliderMax(4).build());
        this.notify = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).defaultValue(false)).build());
        this.vec32 = new Vec3();
        this.vec3 = new Vec3();
    }

    public void onActivate() {
        minePos = null;
        target = null;
        timer = 0;
    }

    public String getInfoString() {
        return this.mc.player == null ? "..." : ((double)EntityUtils.getTotalHealth(this.mc.player) > (Double)this.minHealth.get() ? (target != null ? target.getEntityName() + " " + timer : "Awaiting for target...") : "Health too low!");
    }

    @EventHandler
    public void onTick(Pre event) {
        List<Entity> targets = new ArrayList();
        TargetUtils.getList(targets, this::entityCheck, (SortPriority)this.tarPrio.get(), 1);
        if (targets.isEmpty()) {
            if ((Boolean)this.noTargetDisable.get()) {
                this.toggle();
            }

            target = null;
        } else {
            target = (PlayerEntity)targets.get(0);
            Iterator var3 = this.mc.world.getEntities().iterator();

            while(var3.hasNext()) {
                Entity entity = (Entity)var3.next();
                if (entity instanceof EndCrystalEntity && DamageUtil.crystalDamage(target, entity.getPos(), (Double)this.actionRange.get() + 2.0D) >= 6.0F) {
                    if ((Boolean)this.notify.get()) {
                        this.info("Found a crystal to break.", new Object[0]);
                    }

                    CrystalUtils.attackCrystal(entity, (Boolean)this.swing.get());
                    timer = 0;
                }
            }

            if (target.isOnGround()) {
                minePos = null;
                ++timer;
                if (!((double)EntityUtils.getTotalHealth(this.mc.player) <= (Double)this.minHealth.get())) {
                    FindItemResult fr = InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL});
                    FindItemResult sb = InvUtils.findInHotbar((itemStack) -> {
                        return this.isCombatBlock(Block.getBlockFromItem(itemStack.getItem()));
                    });
                    if (!fr.found()) {
                        if ((Boolean)this.notify.get()) {
                            this.warning("No crystals!", new Object[0]);
                        }

                    } else {
                        BlockPos pPos = EntityUtil.playerPos(target);
                        pPos = pPos.up(Math.round(target.getEyeHeight(target.getPose())) - 1);
                        List<BlockPos> check = this.getCevPos(pPos);
                        check.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                        Collections.reverse(check);
                        if (this.blockPrio.get() == CevAura.Priority.TopBlock && this.isCevable(pPos.up())) {
                            minePos = pPos.up();
                        } else {
                            Iterator var7 = check.iterator();

                            while(var7.hasNext()) {
                                BlockPos p = (BlockPos)var7.next();
                                if (this.isCevable(p)) {
                                    minePos = p;
                                }
                            }
                        }

                        if (minePos != null) {
                            boolean crystal = CrystalUtils.isCrystalOnPos(minePos.up());
                            boolean spam = this.crystalMode.get() == CevAura.CrystalMode.Any && !this.mc.player.isCreative();
                            float progress = ((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress();
                            if (crystal || spam) {
                                BlockUtil.mineBlock(minePos, (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                            }

                            if (!crystal && (timer > (Integer)this.crystalDelay.get() && !spam || this.mc.player.isCreative() || spam && (double)progress >= (Double)this.breakingProgress.get())) {
                                if ((Boolean)this.notify.get() && spam) {
                                    this.info("hit needed breaking progress at " + progress, new Object[0]);
                                }

                                CrystalUtils.placeCrystal(fr, minePos.up(), (Boolean)this.swing.get(), spam);
                                timer = 0;
                            }
                        } else {
                            BlockPos checkB = this.blockPrio.get() == CevAura.Priority.TopBlock ? pPos.up() : (BlockPos)check.get(check.size() - 1);

                            for(int i = 1; i <= check.size(); ++i) {
                                if (BlockUtil.isReplaceable(checkB) && timer > (Integer)this.supportDelay.get() && sb.found()) {
                                    BlockUtils.place(checkB, sb, (Boolean)this.rotate.get(), 50, false);
                                    timer = 0;
                                }

                                if (BlockUtil.isBreakable(checkB.up())) {
                                    BlockUtil.mineBlock(checkB.up(), (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                                }

                                checkB = (BlockPos)check.get(check.size() - i);
                            }
                        }

                    }
                }
            }
        }
    }

    private boolean isCevable(BlockPos pos) {
        return this.isCombatBlock(BlockUtil.getBlock(pos)) && (CrystalUtils.canPlace(pos.up(), (Double)this.actionRange.get(), true) || CrystalUtils.isCrystalOnPos(pos.up()));
    }

    private boolean isCombatBlock(Block block) {
        return block.equals(Blocks.OBSIDIAN) || block.equals(Blocks.BEDROCK) && this.mc.player.isCreative();
    }

    private List<BlockPos> getCevPos(BlockPos pos) {
        return new ArrayList<BlockPos>() {
            {
                Direction[] var3 = Direction.values();
                int var4 = var3.length;

                for(int var5 = 0; var5 < var4; ++var5) {
                    Direction dir = var3[var5];
                    if (dir != Direction.DOWN) {
                        this.add(pos.offset(dir));
                    }
                }

            }
        };
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && minePos != null && BlockUtil.isBreakable(minePos)) {
            if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Sides)) {
                for(int i = 1; i <= 4; ++i) {
                    if ((Integer)this.width.get() == i) {
                        RenderUtil.S(event, minePos, (double)(1.0F - (float)i / 100.0F), 0.0D, (double)((float)i / 100.0F), (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                        RenderUtil.TAB(event, minePos, (double)(1.0F - (float)i / 100.0F), (double)((float)i / 100.0F), true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    }
                }
            }

            if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Lines)) {
                RenderUtil.FS(event, minePos, 0.0D, true, true, (Color)this.sideColor.get(), (Color)this.sideColor2.get());
            }

        }
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if ((Boolean)this.render.get() && (Boolean)this.renderProgress.get() && minePos != null && !this.mc.player.isCreative()) {
            this.vec3.set((double)minePos.getX() + 0.5D, (double)minePos.getY() + 0.5D, (double)minePos.getZ() + 0.5D);
            this.vec32.set((double)minePos.getX() + 0.5D, (double)minePos.getY() + 0.8D, (double)minePos.getZ() + 0.5D);
            float ownBreakingStage = ((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress();
            String text;
            double w;
            if (NametagUtils.to2D(this.vec32, (Double)this.progressTextScale.get())) {
                NametagUtils.begin(this.vec32);
                TextRenderer.get().begin(1.0D, true, true);
                text = target.getEntityName();
                w = TextRenderer.get().getWidth(text) / 2.0D;
                TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                TextRenderer.get().end();
                NametagUtils.end();
            }

            if (NametagUtils.to2D(this.vec3, (Double)this.progressTextScale.get())) {
                NametagUtils.begin(this.vec3);
                TextRenderer.get().begin(1.0D, false, true);
                Object[] var10001 = new Object[]{ownBreakingStage * 100.0F};
                text = String.format("%.2f", var10001) + "%";
                w = TextRenderer.get().getWidth(text) / 2.0D;
                TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                TextRenderer.get().end();
                NametagUtils.end();
            }

        }
    }

    private boolean entityCheck(Entity entity) {
        if (!entity.equals(this.mc.player) && !entity.equals(this.mc.cameraEntity)) {
            if ((!(entity instanceof LivingEntity) || !((LivingEntity)entity).isDead()) && entity.isAlive()) {
                if (PlayerUtil.distanceFromEye(entity) > (Double)this.enemyRange.get()) {
                    return false;
                } else if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType())) {
                    return false;
                } else if (entity instanceof PlayerEntity) {
                    return ((PlayerEntity)entity).isCreative() ? false : Friends.get().shouldAttack((PlayerEntity)entity);
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static enum CrystalMode {
        Any("Spam crystals"),
        Strict("For strict servers");

        final String name;

        private CrystalMode(String name) {
            this.name = name;
        }

        public String toString() {
            return this.name;
        }

        // $FF: synthetic method
        private static CevAura.CrystalMode[] $values() {
            return new CevAura.CrystalMode[]{Any, Strict};
        }
    }

    public static enum Priority {
        NearestBlock("Nearest block first"),
        TopBlock("Top block first");

        final String name;

        private Priority(String name) {
            this.name = name;
        }

        public String toString() {
            return this.name;
        }

        // $FF: synthetic method
        private static CevAura.Priority[] $values() {
            return new CevAura.Priority[]{NearestBlock, TopBlock};
        }
    }
}
