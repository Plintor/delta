package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.WorldUtils;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.AbstractBlockAccessor;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.Block;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.PositionAndOnGround;

public class BurrowPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgPlacing;
    private final Setting<BurrowPlus.Block> block;
    private final Setting<BurrowPlus.Block> fallbackBlock;
    private final Setting<Boolean> onlyInHole;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> debug;
    private final Setting<Boolean> centerMode;
    private final Setting<Boolean> instant;
    private final Setting<Boolean> automatic;
    private final Setting<Double> triggerHeight;
    private final Setting<BurrowPlus.RubberbandDirection> rubberbandDirection;
    private final Setting<Integer> minRubberbandHeight;
    private final Setting<Integer> maxRubberbandHeight;
    private final Setting<Double> timer;
    private final Mutable blockPos;
    private boolean shouldBurrow;

    public BurrowPlus() {
        super(DeltaHack.Combat, "burrow+", "Attempts to clip you into a block.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgPlacing = this.settings.createGroup("Placing");
        this.block = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("block")).description("The block to use for Burrow.")).defaultValue(BurrowPlus.Block.Anvil)).build());
        this.fallbackBlock = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("fallback-block")).description("The fallback block to use for Burrow.")).defaultValue(BurrowPlus.Block.EChest)).build());
        this.onlyInHole = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-holes")).description("Stops you from burrowing when not in a hole.")).defaultValue(false)).build());
        this.onlyOnGround = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Stops you from burrowing when not on the ground.")).defaultValue(false)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Faces the block you place server-side.")).defaultValue(true)).build());
        this.debug = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("debug")).defaultValue(false)).build());
        this.centerMode = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center")).description("Should it center you before burrowing.")).defaultValue(true)).build());
        this.instant = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("instant")).description("Jumps with packets rather than vanilla jump.")).defaultValue(true)).build());
        this.automatic = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("automatic")).description("Automatically burrows on activate rather than waiting for jump.")).defaultValue(true)).build());
        this.triggerHeight = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("trigger-height")).description("How high you have to jump before a rubberband is triggered.")).defaultValue(1.12D).range(0.01D, 1.4D).sliderRange(0.01D, 1.4D).build());
        this.rubberbandDirection = this.sgPlacing.add(((Builder)((Builder)((Builder)(new Builder()).name("rubberband-direction")).description("Which direction to rubberband you when your are burrowing.")).defaultValue(BurrowPlus.RubberbandDirection.Up)).build());
        this.minRubberbandHeight = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("min-height")).description("Min height to rubberband.")).defaultValue(3)).min(2).sliderRange(2, 30).build());
        this.maxRubberbandHeight = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("max-height")).description("Max height to rubberband.")).defaultValue(7)).min(2).sliderRange(2, 30).build());
        this.timer = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("timer")).description("Timer override.")).defaultValue(1.0D).min(0.01D).sliderRange(0.01D, 10.0D).build());
        this.blockPos = new Mutable();
    }

    public void onActivate() {
        if ((Boolean)this.onlyOnGround.get() && !this.mc.player.isOnGround()) {
            this.error("Not on the ground, disabling.", new Object[0]);
            this.toggle();
        } else if (!this.mc.world.getBlockState(WorldUtils.roundBlockPos(this.mc.player.getPos())).getMaterial().isReplaceable()) {
            this.error("Already burrowed, disabling.", new Object[0]);
            this.toggle();
        } else if (EntityUtil.isMonke(this.mc.player, true, BlockUtil.BlastResistantType.Any) && (Boolean)this.onlyInHole.get()) {
            this.error("Not in a hole, disabling.", new Object[0]);
            this.toggle();
        } else if (!this.checkHead()) {
            this.error("Not enough headroom to burrow, disabling.", new Object[0]);
            this.toggle();
        } else {
            FindItemResult result = this.getItem();
            if (!result.isHotbar() && !result.isOffhand()) {
                result = this.getFallbackItem();
            }

            if (!result.isHotbar() && !result.isOffhand()) {
                this.error("No burrow block found, disabling.", new Object[0]);
                this.toggle();
            } else {
                this.blockPos.set(WorldUtils.roundBlockPos(this.mc.player.getPos()));
                ((Timer)Modules.get().get(Timer.class)).setOverride((Double)this.timer.get());
                this.shouldBurrow = false;
                if ((Boolean)this.automatic.get()) {
                    if ((Boolean)this.instant.get()) {
                        this.shouldBurrow = true;
                    } else {
                        this.mc.player.jump();
                    }
                } else {
                    this.info("Waiting for manual jump.", new Object[0]);
                }

            }
        }
    }

    public void onDeactivate() {
        ((Timer)Modules.get().get(Timer.class)).setOverride(1.0D);
    }

    @EventHandler
    private void onTick(Pre event) {
        if (!(Boolean)this.instant.get()) {
            this.shouldBurrow = this.mc.player.getY() > (double)this.blockPos.getY() + (Double)this.triggerHeight.get();
        }

        if (!this.shouldBurrow && (Boolean)this.instant.get()) {
            this.blockPos.set(WorldUtils.roundBlockPos(this.mc.player.getPos()));
        }

        if (this.shouldBurrow) {
            if ((Boolean)this.rotate.get()) {
                Rotations.rotate(Rotations.getYaw(WorldUtils.roundBlockPos(this.mc.player.getPos())), Rotations.getPitch(WorldUtils.roundBlockPos(this.mc.player.getPos())), 50, this::burrow);
            } else {
                this.burrow();
            }

            this.toggle();
        }

    }

    @EventHandler
    private void onKey(KeyEvent event) {
        if ((Boolean)this.instant.get() && !this.shouldBurrow) {
            if (event.action == KeyAction.Press && this.mc.options.jumpKey.matchesKey(event.key, 0)) {
                this.shouldBurrow = true;
            }

            this.blockPos.set(WorldUtils.roundBlockPos(this.mc.player.getPos()));
        }

    }

    private void burrow() {
        FindItemResult block = this.getItem();
        if (!block.isHotbar() && !block.isOffhand()) {
            block = this.getFallbackItem();
        }

        if (this.mc.player.getInventory().getStack(block.slot()).getItem() instanceof BlockItem) {
            if ((Boolean)this.centerMode.get()) {
                PlayerUtils.centerPlayer();
            }

            if ((Boolean)this.instant.get()) {
                this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + 0.4D, this.mc.player.getZ(), false));
                this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + 0.75D, this.mc.player.getZ(), false));
                this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + 1.01D, this.mc.player.getZ(), false));
                this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + 1.15D, this.mc.player.getZ(), false));
            }

            InvUtils.swap(block.slot(), true);
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, new BlockHitResult(Utils.vec3d(this.blockPos), Direction.UP, this.blockPos, false));
            this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            InvUtils.swapBack();
            if ((Boolean)this.instant.get()) {
                if (this.rubberbandDirection.get() == BurrowPlus.RubberbandDirection.Up) {
                    this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + (double)this.upperSpace(), this.mc.player.getZ(), false));
                    if ((Boolean)this.debug.get()) {
                        this.info(String.valueOf(this.upperSpace()), new Object[0]);
                    }
                } else {
                    this.mc.player.networkHandler.sendPacket(new PositionAndOnGround(this.mc.player.getX(), this.mc.player.getY() + (double)this.lowerSpace(), this.mc.player.getZ(), false));
                    if ((Boolean)this.debug.get()) {
                        this.info(String.valueOf(this.lowerSpace()), new Object[0]);
                    }
                }
            } else if (this.rubberbandDirection.get() == BurrowPlus.RubberbandDirection.Up) {
                this.mc.player.updatePosition(this.mc.player.getX(), this.mc.player.getY() + (double)this.upperSpace(), this.mc.player.getZ());
                if ((Boolean)this.debug.get()) {
                    this.info(String.valueOf(this.upperSpace()), new Object[0]);
                }
            } else {
                this.mc.player.updatePosition(this.mc.player.getX(), this.mc.player.getY() + (double)this.upperSpace(), this.mc.player.getZ());
                if ((Boolean)this.debug.get()) {
                    this.info(String.valueOf(this.lowerSpace()), new Object[0]);
                }
            }

        }
    }

    private FindItemResult getItem() {
        FindItemResult var10000;
        switch((BurrowPlus.Block)this.block.get()) {
            case EChest:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ENDER_CHEST});
                break;
            case Anvil:
                var10000 = InvUtils.findInHotbar((itemStack) -> {
                    return Block.getBlockFromItem(itemStack.getItem()) instanceof AnvilBlock;
                });
                break;
            case AncientDebris:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ANCIENT_DEBRIS});
                break;
            case Netherite:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.NETHERITE_BLOCK});
                break;
            case Anchor:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.RESPAWN_ANCHOR});
                break;
            case EnchantingTable:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ENCHANTING_TABLE});
                break;
            case Held:
                var10000 = new FindItemResult(this.mc.player.getInventory().selectedSlot, this.mc.player.getMainHandStack().getCount());
                break;
            default:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.OBSIDIAN, Items.CRYING_OBSIDIAN});
        }

        return var10000;
    }

    private FindItemResult getFallbackItem() {
        FindItemResult var10000;
        switch((BurrowPlus.Block)this.fallbackBlock.get()) {
            case EChest:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ENDER_CHEST});
                break;
            case Anvil:
                var10000 = InvUtils.findInHotbar((itemStack) -> {
                    return Block.getBlockFromItem(itemStack.getItem()) instanceof AnvilBlock;
                });
                break;
            case AncientDebris:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ANCIENT_DEBRIS});
                break;
            case Netherite:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.NETHERITE_BLOCK});
                break;
            case Anchor:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.RESPAWN_ANCHOR});
                break;
            case EnchantingTable:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.ENCHANTING_TABLE});
                break;
            case Held:
                var10000 = new FindItemResult(this.mc.player.getInventory().selectedSlot, this.mc.player.getMainHandStack().getCount());
                break;
            default:
                var10000 = InvUtils.findInHotbar(new Item[]{Items.OBSIDIAN, Items.CRYING_OBSIDIAN});
        }

        return var10000;
    }

    private boolean checkHead() {
        BlockState blockState1 = this.mc.world.getBlockState(this.blockPos.set(this.mc.player.getX() + 0.3D, this.mc.player.getY() + 2.3D, this.mc.player.getZ() + 0.3D));
        BlockState blockState2 = this.mc.world.getBlockState(this.blockPos.set(this.mc.player.getX() + 0.3D, this.mc.player.getY() + 2.3D, this.mc.player.getZ() - 0.3D));
        BlockState blockState3 = this.mc.world.getBlockState(this.blockPos.set(this.mc.player.getX() - 0.3D, this.mc.player.getY() + 2.3D, this.mc.player.getZ() - 0.3D));
        BlockState blockState4 = this.mc.world.getBlockState(this.blockPos.set(this.mc.player.getX() - 0.3D, this.mc.player.getY() + 2.3D, this.mc.player.getZ() + 0.3D));
        boolean air1 = blockState1.getMaterial().isReplaceable();
        boolean air2 = blockState2.getMaterial().isReplaceable();
        boolean air3 = blockState3.getMaterial().isReplaceable();
        boolean air4 = blockState4.getMaterial().isReplaceable();
        return air1 & air2 & air3 & air4;
    }

    private int upperSpace() {
        for(int dy = (Integer)this.minRubberbandHeight.get(); dy <= (Integer)this.maxRubberbandHeight.get(); ++dy) {
            BlockState blockState1 = this.mc.world.getBlockState(WorldUtils.roundBlockPos(this.mc.player.getPos()).up(dy));
            BlockState blockState2 = this.mc.world.getBlockState(WorldUtils.roundBlockPos(this.mc.player.getPos()).up(dy + 1));
            boolean air1 = !((AbstractBlockAccessor)blockState1.getBlock()).isCollidable();
            boolean air2 = !((AbstractBlockAccessor)blockState2.getBlock()).isCollidable();
            if (air1 & air2) {
                return dy;
            }
        }

        return 0;
    }

    private int lowerSpace() {
        for(int dy = -(Integer)this.minRubberbandHeight.get(); dy >= -(Integer)this.maxRubberbandHeight.get(); --dy) {
            BlockState blockState1 = this.mc.world.getBlockState(WorldUtils.roundBlockPos(this.mc.player.getPos()).up(dy));
            BlockState blockState2 = this.mc.world.getBlockState(WorldUtils.roundBlockPos(this.mc.player.getPos()).up(dy + 1));
            boolean air1 = !((AbstractBlockAccessor)blockState1.getBlock()).isCollidable();
            boolean air2 = !((AbstractBlockAccessor)blockState2.getBlock()).isCollidable();
            if (air1 & air2) {
                return dy;
            }
        }

        return 0;
    }

    public static enum Block {
        EChest,
        Obsidian,
        Anvil,
        AncientDebris,
        Netherite,
        Anchor,
        EnchantingTable,
        Held;

        // $FF: synthetic method
        private static BurrowPlus.Block[] $values() {
            return new BurrowPlus.Block[]{EChest, Obsidian, Anvil, AncientDebris, Netherite, Anchor, EnchantingTable, Held};
        }
    }

    public static enum RubberbandDirection {
        Up,
        Down;

        // $FF: synthetic method
        private static BurrowPlus.RubberbandDirection[] $values() {
            return new BurrowPlus.RubberbandDirection[]{Up, Down};
        }
    }
}
