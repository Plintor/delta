package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.InvUtil;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class Offhand extends Module {
    public static Offhand instance;
    private final SettingGroup sg_general;
    public final Setting<Offhand.OffhandMode> cfg_mode;
    public final Setting<Integer> cfg_min_health;

    public Offhand() {
        super(DeltaHack.Combat, "totem-hand", "Working only with auto totem in smart mode.");
        this.sg_general = this.settings.getDefaultGroup();
        this.cfg_mode = this.sg_general.add(((Builder)((Builder)(new Builder()).name("mode")).defaultValue(Offhand.OffhandMode.smart)).build());
        this.cfg_min_health = this.sg_general.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("min-health")).visible(() -> {
            return this.cfg_mode.get() == Offhand.OffhandMode.normal;
        })).defaultValue(17)).sliderMin(2).sliderMax(36).build());
        instance = this;
    }

    public void tick() {
        if (this.isActive()) {
            Item offhand_item = this.mc.player.getOffHandStack().getItem();
            Item mainhand_item = this.mc.player.getMainHandStack().getItem();
            Item cursor_item = this.mc.player.currentScreenHandler.getCursorStack().getItem();
            if (offhand_item != Items.END_CRYSTAL && mainhand_item != Items.END_CRYSTAL) {
                if (cursor_item == Items.END_CRYSTAL) {
                    InvUtil.Click(45);
                } else {
                    int crystal_id = this.GetCryId();
                    if (crystal_id != -1) {
                        InvUtil.Move(crystal_id);
                    }
                }
            }
        }
    }

    private int GetCryId() {
        int hotbar_start = InvUtil.GetFirstHotbarSlotId();

        int i;
        for(i = hotbar_start; i < hotbar_start + 9; ++i) {
            if (this.mc.player.currentScreenHandler.getSlot(i).getStack().getItem() == Items.END_CRYSTAL) {
                return i;
            }
        }

        for(i = 0; i < hotbar_start; ++i) {
            if (this.mc.player.currentScreenHandler.getSlot(i).getStack().getItem() == Items.END_CRYSTAL) {
                return i;
            }
        }

        return -1;
    }

    public static enum OffhandMode {
        smart,
        normal;

        // $FF: synthetic method
        private static Offhand.OffhandMode[] $values() {
            return new Offhand.OffhandMode[]{smart, normal};
        }
    }
}
