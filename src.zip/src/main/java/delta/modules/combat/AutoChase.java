package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.BlockHitResult;

public class AutoChase extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<AutoChase.Mode> mode;
    private final Setting<Double> speed;
    private final Setting<Double> hSpeed;
    private final Setting<Double> offset;
    private final Setting<Double> minSpeed;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> smoothRotation;
    private final Setting<Double> enemyRange;
    private final Setting<Double> radius;
    private final Setting<Boolean> tog;
    private final Setting<Boolean> update;
    private final Setting<Boolean> ignoreNaked;
    private final Setting<Boolean> resetTarget;
    private final Setting<Boolean> limitY;
    private final Setting<SortPriority> priority;
    private PlayerEntity target;
    private float pepis;
    private float penis;
    private Vec3d targetPenis;

    public String getInfoString() {
        return this.target != null ? this.target.getEntityName() : "Awaiting for target...";
    }

    public AutoChase() {
        super(DeltaHack.Combat, "auto-elytra-chase", "Automatically chases runaway monke's using elytra.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.mode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("mode")).description("Flying mode")).defaultValue(AutoChase.Mode.eFly)).build());
        this.speed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("speed")).description("The speed at which you dash. This value will be divided by 20 for Accelerate mode.")).defaultValue(3.0D).range(0.0D, 20.0D).sliderRange(0.0D, 6.0D).build());
        this.hSpeed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("horizontal-speed-cap")).description("The max speed at which you can ascend.")).defaultValue(2.5D).range(0.0D, 20.0D).sliderRange(0.0D, 6.0D).visible(() -> {
            return this.mode.get() == AutoChase.Mode.Boost || this.mode.get() == AutoChase.Mode.eFly;
        })).build());
        this.offset = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("Y-offset")).description("The Y offset below the target (use this to support monkes when air cpvping)")).defaultValue(3.0D).range(0.0D, 20.0D).sliderRange(0.0D, 10.0D).build());
        this.minSpeed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-acceleration-speed")).description("The speed to trigger the acceleration")).defaultValue(1.0D).range(0.0D, 20.0D).sliderRange(0.0D, 10.0D).visible(() -> {
            return this.mode.get() == AutoChase.Mode.Accelerate;
        })).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("-")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("smooth-rotation")).description("-")).defaultValue(false);
        Setting var10003 = this.rotate;
        Objects.requireNonNull(var10003);
        this.smoothRotation = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.enemyRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("enemy-range")).description("The radius in which players get targeted.")).defaultValue(50.0D).min(0.0D).sliderMax(100.0D).build());
        this.radius = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("stop-radius")).description("The radius from the target in which you stop moving.")).defaultValue(2.0D).range(1.0D, 99.0D).sliderMax(5.0D).build());
        this.tog = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-off")).description("Toggle off when you are in the specified radius from the target.")).defaultValue(false)).build());
        this.update = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("update-target")).description("Update the targeted player each tick.")).defaultValue(false)).build());
        this.ignoreNaked = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-nakeds")).description("Will not target naked players.")).defaultValue(false)).build());
        this.resetTarget = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("reset")).description("Reset the target on disable.")).defaultValue(true)).build());
        this.limitY = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("height-limit")).description("Do not go higher than the build limit.")).defaultValue(true)).build());
        this.priority = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.LowestDistance)).build());
    }

    @EventHandler(
        priority = 100
    )
    private void onPreTick(Pre event) {
        if (this.mc.player == null || !PlayerUtil.isElytraFlying() && this.mode.get() != AutoChase.Mode.Fly) {
            if ((Boolean)this.resetTarget.get()) {
                this.target = null;
            }

        } else {
            if (TargetUtils.isBadTarget(this.target, (Double)this.enemyRange.get()) || (Boolean)this.update.get() || this.target.getY() > 330.0D && (Boolean)this.limitY.get()) {
                this.target = TargetUtils.getPlayerTarget((Double)this.enemyRange.get(), (SortPriority)this.priority.get());
            }

            if (!TargetUtils.isBadTarget(this.target, (Double)this.enemyRange.get()) && (!(this.target.getY() > 330.0D) || !(Boolean)this.limitY.get())) {
                if (EntityUtil.isNaked(this.target) && (Boolean)this.ignoreNaked.get()) {
                    this.target = null;
                } else {
                    this.targetPenis = this.target.getPos().add(0.0D, -(Double)this.offset.get(), 0.0D);
                    if (BlockUtil.horizontalDistance(this.mc.player.getPos(), this.targetPenis) < (Double)this.radius.get() && this.targetPenis.getY() - (Double)this.radius.get() <= this.mc.player.getY() && this.mc.player.getY() < this.target.getY() - (Double)this.offset.get() / 5.0D) {
                        PlayerUtil.stopPlayer();
                        if ((Boolean)this.tog.get()) {
                            this.toggle();
                        }

                    } else {
                        this.pepis = (float)MathHelper.wrapDegrees(Rotations.getYaw(this.targetPenis));
                        this.penis = (float)MathHelper.wrapDegrees(Rotations.getPitch(this.targetPenis));
                        if ((Boolean)this.rotate.get()) {
                            this.mc.player.setYaw(this.pepis);
                        }

                        if (this.mode.get() != AutoChase.Mode.Fly && (Boolean)this.rotate.get()) {
                            this.mc.player.setPitch(this.penis);
                        }

                        if (this.mode.get() == AutoChase.Mode.Firework) {
                            HitResult hitResult = this.mc.getCameraEntity().raycast((double)this.mc.interactionManager.getReachDistance(), 0.0F, false);
                            if (!(hitResult instanceof BlockHitResult)) {
                                PlayerUtil.stopPlayer();
                            }
                        }

                        if (this.mode.get() == AutoChase.Mode.Accelerate) {
                            double deltaY = this.targetPenis.getY() - (Double)this.radius.get() > this.mc.player.getY() ? (Double)this.speed.get() : 0.0D;
                            if (this.targetPenis.getY() - this.mc.player.getY() <= (Double)this.radius.get() / 2.0D) {
                                deltaY = -(Double)this.speed.get();
                            }

                            this.mc.player.addVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.pepis))) * (Double)this.speed.get() / 20.0D, deltaY / 20.0D, (double)MathHelper.cos((float)Math.toRadians((double)this.pepis)) * (Double)this.speed.get() / 20.0D);
                        }

                        if (this.mode.get() == AutoChase.Mode.Boost && PlayerUtil.horizontalSpeed() <= (Double)this.minSpeed.get() || this.mode.get() == AutoChase.Mode.eFly) {
                            this.mc.player.setVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.pepis))) * (Double)this.speed.get(), MathHelper.clamp((double)(-MathHelper.sin((float)Math.toRadians((double)this.penis))) * (Double)this.speed.get(), -(Double)this.hSpeed.get(), (Double)this.hSpeed.get()), (double)MathHelper.cos((float)Math.toRadians((double)this.pepis)) * (Double)this.speed.get());
                        }

                    }
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.smoothRotation.get() && (Boolean)this.rotate.get() && this.mc.player != null && (PlayerUtil.isElytraFlying() || this.mode.get() == AutoChase.Mode.Fly) && this.targetPenis != null) {
            this.pepis = (float)MathHelper.wrapDegrees(Rotations.getYaw(this.targetPenis));
            this.penis = (float)MathHelper.wrapDegrees(Rotations.getPitch(this.targetPenis));
            this.mc.player.setYaw(this.pepis);
            if (this.mode.get() != AutoChase.Mode.Fly) {
                this.mc.player.setPitch(this.penis);
            }

        }
    }

    public void onDeactivate() {
        if ((Boolean)this.resetTarget.get()) {
            this.target = null;
        }

    }

    public static enum Mode {
        Boost,
        Accelerate,
        Firework,
        eFly,
        Fly;

        // $FF: synthetic method
        private static AutoChase.Mode[] $values() {
            return new AutoChase.Mode[]{Boost, Accelerate, Firework, eFly, Fly};
        }
    }
}
