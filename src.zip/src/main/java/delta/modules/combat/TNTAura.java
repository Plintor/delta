package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.InvUtil;
import delta.utils.RenderUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_2879;
import net.minecraft.class_3965;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2846.class_2847;

public class TNTAura extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Double> targetRange;
   private final Setting<TNTAura.tntPlaceMode> tntPlaceModeSetting;
   private final Setting<Integer> trapDelay;
   private final Setting<Integer> tntDelay;
   private final Setting<SortPriority> priority;
   private final Setting<List<class_2248>> blocks;
   private final Setting<Boolean> breakBurrow;
   private final Setting<Boolean> breakSelfTrap;
   private final Setting<Boolean> instant;
   private final Setting<Integer> delay;
   private final Setting<Boolean> onlyInHole;
   private final Setting<Boolean> rotate;
   private final SettingGroup sgRender;
   private final Setting<Boolean> render;
   private final Setting<TNTAura.RenderMode> renderMode;
   private final Setting<Integer> fadeTick;
   private final Setting<Boolean> alwaysRender;
   private final Setting<Boolean> swing;
   private final Setting<ShapeMode> tntShapeMode;
   private final Setting<SettingColor> tntSideColor;
   private final Setting<SettingColor> tntSideColor2;
   private final Setting<SettingColor> tntLineColor;
   private final Setting<SettingColor> tntLineColor2;
   private final Setting<ShapeMode> trapShapeMode;
   private final Setting<SettingColor> trapSideColor;
   private final Setting<SettingColor> trapSideColor2;
   private final Setting<SettingColor> trapLineColor;
   private final Setting<SettingColor> trapLineColor2;
   private final Setting<Integer> width;
   private final Pool<TNTAura.RenderBlock> renderTNTBlockPool;
   private final List<TNTAura.RenderBlock> renderTNTBlocks;
   private final Pool<TNTAura.RenderBlock> renderTrapBlockPool;
   private final List<TNTAura.RenderBlock> renderTrapBlocks;
   private final ArrayList<class_243> trap;
   private final ArrayList<class_243> surr;
   private class_1657 target;
   private int timer;
   private int ticks;
   private int i;

   public TNTAura() {
      super(DeltaHack.Autist, "TNT-aura", "trolls your enemy with tnt");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.targetRange = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("target-range")).description("The radius in which players get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
      this.tntPlaceModeSetting = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("tnt-place-mode")).description("How to select the player to target.")).defaultValue(TNTAura.tntPlaceMode.HEAD)).build());
      this.trapDelay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("trap-delay")).description("How many ticks between block placements.")).defaultValue(1)).build());
      this.tntDelay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("tnt-delay")).description("How many ticks between block placements.")).defaultValue(1)).build());
      this.priority = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.LowestHealth)).build());
      this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for surround.")).defaultValue(Collections.singletonList(class_2246.field_10540))).build());
      this.breakBurrow = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-burrow")).description("Break target's self-trap automatically.")).defaultValue(false)).build());
      this.breakSelfTrap = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-self-trap")).description("Break target's self-trap automatically.")).defaultValue(false)).build());
      this.instant = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("instant")).description("instant.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).defaultValue(0)).min(0).max(20).sliderMin(0).sliderMax(20);
      Setting var10003 = this.instant;
      Objects.requireNonNull(var10003);
      this.delay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.onlyInHole = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-hole")).description("Rotates towards blocks when placing.")).defaultValue(true)).visible(() -> {
         return ((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.HEAD);
      })).build());
      this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates towards blocks when placing.")).defaultValue(true)).build());
      this.sgRender = this.settings.createGroup("Render");
      this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Render surround.")).defaultValue(false)).build());
      this.renderMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("render-mode")).description("Which way to render surround.")).defaultValue(TNTAura.RenderMode.Fade)).build());
      this.fadeTick = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fade-tick")).description("The slot auto move moves beds to.")).defaultValue(8)).visible(() -> {
         return this.renderMode.get() == TNTAura.RenderMode.Fade;
      })).build());
      var10001 = this.sgRender;
      meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("always")).description("Render surround blocks always.")).defaultValue(false);
      var10003 = this.render;
      Objects.requireNonNull(var10003);
      this.alwaysRender = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).visible(() -> {
         return this.renderMode.get() != TNTAura.RenderMode.Fade;
      })).build());
      this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Render swing.")).defaultValue(false)).build());
      this.tntShapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("tnt-shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.tntSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-side-color")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
      this.tntSideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-side-color-2")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
      this.tntLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
      this.tntLineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-line-color-2")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
      this.trapShapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("trap-shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.trapSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-side-color")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
      this.trapSideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-side-color-2")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
      this.trapLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
      this.trapLineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-line-color-2")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
      this.width = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).defaultValue(1)).min(1).max(5).sliderMin(1).sliderMax(4).build());
      this.renderTNTBlockPool = new Pool(TNTAura.RenderBlock::new);
      this.renderTNTBlocks = new ArrayList();
      this.renderTrapBlockPool = new Pool(TNTAura.RenderBlock::new);
      this.renderTrapBlocks = new ArrayList();
      this.trap = new ArrayList<class_243>() {
         {
            this.add(new class_243(0.0D, 3.0D, 0.0D));
            this.add(new class_243(1.0D, 2.0D, 0.0D));
            this.add(new class_243(-1.0D, 2.0D, 0.0D));
            this.add(new class_243(0.0D, 2.0D, 1.0D));
            this.add(new class_243(0.0D, 2.0D, -1.0D));
         }
      };
      this.surr = new ArrayList<class_243>() {
         {
            this.add(new class_243(0.0D, -1.0D, 0.0D));
            this.add(new class_243(1.0D, 0.0D, 0.0D));
            this.add(new class_243(-1.0D, 0.0D, 0.0D));
            this.add(new class_243(0.0D, 0.0D, 1.0D));
            this.add(new class_243(0.0D, 0.0D, -1.0D));
         }
      };
   }

   public void onDeactivate() {
      this.i = 0;
      Iterator var1 = this.renderTNTBlocks.iterator();

      TNTAura.RenderBlock renderBlock;
      while(var1.hasNext()) {
         renderBlock = (TNTAura.RenderBlock)var1.next();
         this.renderTNTBlockPool.free(renderBlock);
      }

      this.renderTNTBlocks.clear();
      var1 = this.renderTrapBlocks.iterator();

      while(var1.hasNext()) {
         renderBlock = (TNTAura.RenderBlock)var1.next();
         this.renderTrapBlockPool.free(renderBlock);
      }

      this.renderTrapBlocks.clear();
   }

   public void onActivate() {
      Iterator var1 = this.renderTNTBlocks.iterator();

      TNTAura.RenderBlock renderBlock;
      while(var1.hasNext()) {
         renderBlock = (TNTAura.RenderBlock)var1.next();
         this.renderTNTBlockPool.free(renderBlock);
      }

      this.renderTNTBlocks.clear();
      var1 = this.renderTrapBlocks.iterator();

      while(var1.hasNext()) {
         renderBlock = (TNTAura.RenderBlock)var1.next();
         this.renderTrapBlockPool.free(renderBlock);
      }

      this.renderTrapBlocks.clear();
   }

   @EventHandler
   private void onTick(Pre event) {
      if (TargetUtils.isBadTarget(this.target, (Double)this.targetRange.get())) {
         this.target = TargetUtils.getPlayerTarget((Double)this.targetRange.get(), (SortPriority)this.priority.get());
      }

      if (this.target == null) {
         ChatUtils.error("No target found... disabling.", new Object[0]);
         this.toggle();
      } else {
         class_2338 ppos = this.target.method_24515();
         this.renderTNTBlocks.forEach(TNTAura.RenderBlock::tick);
         this.renderTNTBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
         });
         this.renderTrapBlocks.forEach(TNTAura.RenderBlock::tick);
         this.renderTrapBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
         });
         FindItemResult pick;
         if (BlockUtil.getBlock(ppos) != class_2246.field_10124 && BlockUtil.getBlock(ppos) != class_2246.field_10375 && (Boolean)this.breakBurrow.get()) {
            pick = InvUtil.findPick();
            if (pick.found()) {
               InvUtil.updateSlot(pick.slot());
               if (!(Boolean)this.instant.get()) {
                  BlockUtils.breakBlock(ppos.method_10086(2), true);
               }

               if ((Boolean)this.instant.get()) {
                  if (this.i == 0) {
                     this.mc.method_1562().method_2883(new class_2846(class_2847.field_12968, ppos.method_10086(2), class_2350.field_11036));
                     if ((Boolean)this.swing.get()) {
                        this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
                     }

                     ++this.i;
                  }

                  if (this.ticks >= (Integer)this.delay.get()) {
                     this.ticks = 0;
                     if ((Boolean)this.rotate.get()) {
                        Rotations.rotate(Rotations.getYaw(ppos.method_10086(2)), Rotations.getPitch(ppos.method_10086(2)), () -> {
                           this.mc.method_1562().method_2883(new class_2846(class_2847.field_12973, ppos.method_10086(2), class_2350.field_11036));
                        });
                     } else {
                        this.mc.method_1562().method_2883(new class_2846(class_2847.field_12973, ppos.method_10086(2), class_2350.field_11036));
                     }

                     if ((Boolean)this.swing.get()) {
                        this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
                     }
                  } else {
                     ++this.ticks;
                  }
               }

               return;
            }
         }

         if (BlockUtil.getBlock(ppos.method_10086(2)) != class_2246.field_10124 && BlockUtil.getBlock(ppos.method_10086(2)) != class_2246.field_10375 && (Boolean)this.breakSelfTrap.get()) {
            pick = InvUtil.findPick();
            if (pick.found()) {
               InvUtil.updateSlot(pick.slot());
               if (!(Boolean)this.instant.get()) {
                  BlockUtils.breakBlock(ppos.method_10086(2), true);
               }

               if ((Boolean)this.instant.get()) {
                  if (this.i == 0) {
                     this.mc.method_1562().method_2883(new class_2846(class_2847.field_12968, ppos.method_10086(2), class_2350.field_11036));
                     if ((Boolean)this.swing.get()) {
                        this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
                     }

                     ++this.i;
                  }

                  if (this.ticks >= (Integer)this.delay.get()) {
                     this.ticks = 0;
                     if ((Boolean)this.rotate.get()) {
                        Rotations.rotate(Rotations.getYaw(ppos.method_10086(2)), Rotations.getPitch(ppos.method_10086(2)), () -> {
                           this.mc.method_1562().method_2883(new class_2846(class_2847.field_12973, ppos.method_10086(2), class_2350.field_11036));
                        });
                     } else {
                        this.mc.method_1562().method_2883(new class_2846(class_2847.field_12973, ppos.method_10086(2), class_2350.field_11036));
                     }

                     if ((Boolean)this.swing.get()) {
                        this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
                     }
                  } else {
                     ++this.ticks;
                  }
               }

               return;
            }
         }

         class_243 b;
         class_2338 pos;
         Iterator var6;
         if (((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.HEAD) || ((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.MIX)) {
            if (((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.HEAD) && (Boolean)this.onlyInHole.get() && EntityUtil.isMonke(false, this.target)) {
               return;
            }

            var6 = this.getTrapDesign().iterator();

            while(var6.hasNext()) {
               b = (class_243)var6.next();
               pos = ppos.method_10080(b.field_1352, b.field_1351, b.field_1350);
               if (this.mc.field_1687.method_8320(pos).method_26215()) {
                  if (this.ticks >= (Integer)this.trapDelay.get()) {
                     BlockUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                        return ((List)this.blocks.get()).contains(class_2248.method_9503(itemStack.method_7909()));
                     }), (Boolean)this.rotate.get(), 100, (Boolean)this.swing.get(), false);
                     this.renderTrapBlocks.add(((TNTAura.RenderBlock)this.renderTrapBlockPool.get()).set(pos, (Integer)this.fadeTick.get()));
                     this.ticks = 0;
                  } else {
                     ++this.ticks;
                  }
               }
            }

            if (this.isTraped(this.target)) {
               if (this.timer >= (Integer)this.tntDelay.get()) {
                  BlockUtils.place(this.target.method_24515().method_10086(2), InvUtils.findInHotbar(new class_1792[]{class_1802.field_8626}), (Boolean)this.rotate.get(), 100, true);
                  this.renderTNTBlocks.add(((TNTAura.RenderBlock)this.renderTNTBlockPool.get()).set(this.target.method_24515().method_10086(2), (Integer)this.fadeTick.get()));
                  this.timer = 0;
               } else {
                  ++this.timer;
               }
            }

            if (BlockUtil.getBlock(this.target.method_24515().method_10086(2)) == class_2246.field_10375) {
               this.flintAndSteel(this.target.method_24515().method_10086(2));
            }
         }

         if (((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.LEGS) || ((TNTAura.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(TNTAura.tntPlaceMode.MIX)) {
            var6 = this.getSurrDesign().iterator();

            while(var6.hasNext()) {
               b = (class_243)var6.next();
               pos = ppos.method_10080(b.field_1352, b.field_1351, b.field_1350);
               if (this.mc.field_1687.method_8320(pos).method_26215()) {
                  if (this.timer >= (Integer)this.tntDelay.get()) {
                     BlockUtils.place(pos, InvUtils.findInHotbar(new class_1792[]{class_1802.field_8626}), (Boolean)this.rotate.get(), 100, true);
                     this.timer = 0;
                  } else {
                     ++this.timer;
                  }
               }

               if (BlockUtil.getBlock(pos) == class_2246.field_10375) {
                  this.flintAndSteel(pos);
               }
            }
         }

      }
   }

   private void flintAndSteel(class_2338 pos) {
      FindItemResult flint = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8884});
      int fire = flint.slot();
      if (fire != -1) {
         if (fire != -1) {
            this.mc.field_1724.method_31548().field_7545 = fire;
            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(this.mc.field_1724.method_19538(), class_2350.field_11036, pos, true));
            if ((Boolean)this.swing.get()) {
               this.mc.method_1562().method_2883(new class_2879(class_1268.field_5808));
            }
         }

      }
   }

   private boolean isTraped(class_1309 entity) {
      return BlockUtil.getBlock(entity.method_24515().method_10069(0, 3, 0)) != class_2246.field_10124 && BlockUtil.getBlock(entity.method_24515().method_10069(1, 2, 0)) != class_2246.field_10124 && BlockUtil.getBlock(entity.method_24515().method_10069(-1, 2, 0)) != class_2246.field_10124 && BlockUtil.getBlock(entity.method_24515().method_10069(0, 2, 1)) != class_2246.field_10124 && BlockUtil.getBlock(entity.method_24515().method_10069(0, 2, 1)) != class_2246.field_10124;
   }

   private ArrayList<class_243> getTrapDesign() {
      ArrayList<class_243> trapDesign = new ArrayList(this.trap);
      return trapDesign;
   }

   private ArrayList<class_243> getSurrDesign() {
      ArrayList<class_243> surrDesign = new ArrayList(this.surr);
      return surrDesign;
   }

   @EventHandler(
      priority = -100
   )
   private void onRender(Render3DEvent event) {
      if ((Boolean)this.render.get()) {
         if (this.renderMode.get() == TNTAura.RenderMode.Fade) {
            this.renderTNTBlocks.sort(Comparator.comparingInt((o) -> {
               return -o.ticks;
            }));
            this.renderTNTBlocks.forEach((renderBlock) -> {
               renderBlock.render(event, (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
            });
            this.renderTrapBlocks.sort(Comparator.comparingInt((o) -> {
               return -o.ticks;
            }));
            this.renderTrapBlocks.forEach((renderBlock) -> {
               renderBlock.render(event, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
            });
         } else {
            if (this.target == null) {
               return;
            }

            class_2338 br = this.target.method_24515();
            if (BlockUtil.getBlock(br.method_10086(2)) == class_2246.field_10124) {
               this.renderD(event, br.method_10086(2), (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
            }

            if ((Boolean)this.alwaysRender.get()) {
               this.renderD(event, br.method_10086(2), (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
            }

            Iterator var3 = this.getTrapDesign().iterator();

            while(var3.hasNext()) {
               class_243 b = (class_243)var3.next();
               class_2338 bb = br.method_10080(b.field_1352, b.field_1351, b.field_1350);
               if (BlockUtil.getBlock(bb) == class_2246.field_10124) {
                  this.renderD(event, bb, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
               }

               if ((Boolean)this.alwaysRender.get()) {
                  this.renderD(event, bb, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
               }
            }
         }
      }

   }

   private void renderD(Render3DEvent event, class_2338 pos, Color side1, Color side2, Color line1, Color line2, ShapeMode shapeMode, int width) {
      if (shapeMode.equals(ShapeMode.Lines) || shapeMode.equals(ShapeMode.Both)) {
         RenderUtil.S(event, pos, 0.99D, 0.0D, 0.01D, line1, line2);
         RenderUtil.TAB(event, pos, 0.99D, 0.01D, true, true, line1, line2);
         if (width == 2) {
            RenderUtil.S(event, pos, 0.98D, 0.0D, 0.02D, line1, line2);
            RenderUtil.TAB(event, pos, 0.98D, 0.02D, true, true, line1, line2);
         }

         if (width == 3) {
            RenderUtil.S(event, pos, 0.97D, 0.0D, 0.03D, line1, line2);
            RenderUtil.TAB(event, pos, 0.97D, 0.03D, true, true, line1, line2);
         }

         if (width == 4) {
            RenderUtil.S(event, pos, 0.96D, 0.0D, 0.04D, line1, line2);
            RenderUtil.TAB(event, pos, 0.96D, 0.04D, true, true, line1, line2);
         }
      }

      if (shapeMode.equals(ShapeMode.Sides) || shapeMode.equals(ShapeMode.Both)) {
         RenderUtil.FS(event, pos, 0.0D, true, true, side1, side2);
      }

   }

   public static enum tntPlaceMode {
      HEAD,
      LEGS,
      MIX;

      // $FF: synthetic method
      private static TNTAura.tntPlaceMode[] $values() {
         return new TNTAura.tntPlaceMode[]{HEAD, LEGS, MIX};
      }
   }

   public static enum RenderMode {
      Fade,
      Default;

      // $FF: synthetic method
      private static TNTAura.RenderMode[] $values() {
         return new TNTAura.RenderMode[]{Fade, Default};
      }
   }

   public static class RenderBlock {
      public class_2339 pos = new class_2339();
      public int ticks;

      public TNTAura.RenderBlock set(class_2338 blockPos, int ticks) {
         this.pos.method_10101(blockPos);
         this.ticks = ticks;
         return this;
      }

      public void tick() {
         --this.ticks;
      }

      public void render(Render3DEvent event, Color side1, Color side2, Color line1, Color line2, ShapeMode shapeMode, int width) {
         int preSideA = side1.a;
         int preSideB = side2.a;
         int preLineA = line1.a;
         int preLineB = line2.a;
         side1.a = (int)((double)side1.a * ((double)this.ticks / 10.0D));
         side2.a = (int)((double)side2.a * ((double)this.ticks / 10.0D));
         line1.a = (int)((double)line1.a * ((double)this.ticks / 10.0D));
         line2.a = (int)((double)line2.a * ((double)this.ticks / 10.0D));
         if (shapeMode.equals(ShapeMode.Lines) || shapeMode.equals(ShapeMode.Both)) {
            RenderUtil.S(event, this.pos, 0.99D, 0.0D, 0.01D, line1, line2);
            RenderUtil.TAB(event, this.pos, 0.99D, 0.01D, true, true, line1, line2);
            if (width == 2) {
               RenderUtil.S(event, this.pos, 0.98D, 0.0D, 0.02D, line1, line2);
               RenderUtil.TAB(event, this.pos, 0.98D, 0.02D, true, true, line1, line2);
            }

            if (width == 3) {
               RenderUtil.S(event, this.pos, 0.97D, 0.0D, 0.03D, line1, line2);
               RenderUtil.TAB(event, this.pos, 0.97D, 0.03D, true, true, line1, line2);
            }

            if (width == 4) {
               RenderUtil.S(event, this.pos, 0.96D, 0.0D, 0.04D, line1, line2);
               RenderUtil.TAB(event, this.pos, 0.96D, 0.04D, true, true, line1, line2);
            }
         }

         if (shapeMode.equals(ShapeMode.Sides) || shapeMode.equals(ShapeMode.Both)) {
            RenderUtil.FS(event, this.pos, 0.0D, true, true, side1, side2);
         }

         side1.a = preSideA;
         side2.a = preSideB;
         line1.a = preLineA;
         line2.a = preLineB;
      }
   }
}
