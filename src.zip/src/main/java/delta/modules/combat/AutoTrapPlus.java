package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.util.PacketUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.Vec3dInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.hit.BlockHitResult;

public class AutoTrapPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgMisc;
    private final SettingGroup sgRender;
    private final Setting<Integer> delay;
    private final Setting<Integer> bpt;
    private final Setting<Double> range;
    private final Setting<Double> placeRange;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> rotate;
    private final Setting<List<Block>> blocks;
    private final Setting<Keybind> underBind;
    private final Setting<Boolean> placeCrystal;
    private final Setting<Integer> progress;
    private final Setting<Integer> iterations;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> pauseOnUse;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Setting<Boolean> renderTwo;
    private final Setting<SettingColor> cideColor;
    private final Setting<SettingColor> clineColor;
    private final List<BlockPos> mainPositions;
    private final List<BlockPos> underPositions;
    private final List<BlockPos> extraPositions;
    private List<PlayerEntity> targets;
    private int timer;
    private boolean bindStatus;
    private boolean shouldUnderneath;
    private boolean doALittleTrolling;
    private Vec3i DALTVec;
    private BlockPos DALTBlock;

    public AutoTrapPlus() {
        super(DeltaHack.Combat, "auto-trap+", "Places obsidian above your enemy's head.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgMisc = this.settings.createGroup("Misc");
        this.sgRender = this.settings.createGroup("Render");
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Extra delay between block bursts.")).defaultValue(1)).sliderRange(0, 5).build());
        this.bpt = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks-per-tick")).description("How many blocks can be placed per one tick.")).defaultValue(1)).sliderRange(1, 5).build());
        this.range = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("enemy-range")).description("The range in which you get the targets.")).defaultValue(4.0D).sliderRange(1.0D, 5.0D).range(0.0D, 6.0D).build());
        this.placeRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("place-range")).description("The range in which you place blocks.")).defaultValue(4.0D).sliderRange(1.0D, 5.0D).range(0.0D, 6.0D).build());
        this.packet = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("packet")).description("Packet block placing method.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when placing.")).defaultValue(false)).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("Which blocks used for placing.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.underBind = this.sgMisc.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("place-underneath-bind")).description("Pressing this button makes you surround the enemy")).defaultValue(Keybind.none())).build());
        this.placeCrystal = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-crystals-on-city")).description("Trolls the enemy with crystals if it's trying to pearl away.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgMisc;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("progress")).description("The break progress of blocks (recommended to use a multiple of 25)")).range(0, 100).sliderRange(0, 100).defaultValue(50);
        Setting var10003 = this.placeCrystal;
        Objects.requireNonNull(var10003);
        this.progress = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgMisc;
        var10002 = (Builder)((Builder)((Builder)(new Builder()).name("max-distance")).description("The max distance from the player to troll them.")).range(2, 5).sliderRange(2, 4).defaultValue(3);
        var10003 = this.placeCrystal;
        Objects.requireNonNull(var10003);
        this.iterations = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.onlyOnGround = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only when you standing on blocks.")).defaultValue(true)).build());
        this.pauseOnUse = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-use")).description("Pauses if player is using item.")).defaultValue(true)).build());
        this.notify = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("Pauses if player is using item.")).defaultValue(true)).build());
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Client side hand-swing")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-place")).description("Renders a block overlay where the obsidian will be placed.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-crystal")).description("-")).defaultValue(true);
        var10003 = this.placeCrystal;
        Objects.requireNonNull(var10003);
        this.renderTwo = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.cideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("cide-color")).description("-")).defaultValue(new SettingColor(255, 0, 200, 15))).visible(() -> {
            return (Boolean)this.placeCrystal.get() && (Boolean)this.renderTwo.get();
        })).build());
        this.clineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("cline-color")).description("-")).defaultValue(new SettingColor(255, 255, 255, 255))).visible(() -> {
            return (Boolean)this.placeCrystal.get() && (Boolean)this.renderTwo.get();
        })).build());
        this.mainPositions = new ArrayList();
        this.underPositions = new ArrayList();
        this.extraPositions = new ArrayList();
        this.targets = new ArrayList();
    }

    public void onActivate() {
        this.shouldUnderneath = false;
        this.doALittleTrolling = false;
        this.bindStatus = false;
        this.timer = 0;
        this.underPositions.clear();
        this.targets.clear();
    }

    @EventHandler
    private void onTick(Pre event) {
        if (!(Boolean)this.onlyOnGround.get() || this.mc.player.isOnGround()) {
            if (!(Boolean)this.pauseOnUse.get() || !this.mc.player.isUsingItem()) {
                if (this.timer != 0) {
                    --this.timer;
                } else {
                    this.timer = (Integer)this.delay.get();
                    FindItemResult block = InvUtils.findInHotbar((itemStack) -> {
                        return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                    });
                    this.targets = EntityUtil.getTargetsInRange((Double)this.range.get());
                    this.mainPositions.clear();
                    this.underPositions.clear();
                    this.extraPositions.clear();
                    if (block.found() && !this.targets.isEmpty()) {
                        if (((Keybind)this.underBind.get()).isPressed()) {
                            if (!this.bindStatus) {
                                this.shouldUnderneath = !this.shouldUnderneath;
                                this.bindStatus = true;
                            }
                        } else {
                            this.bindStatus = false;
                        }

                        this.findPlacePos();
                        int places = 0;
                        if (this.doALittleTrolling) {
                            FindItemResult crystal = InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL});
                            if (crystal.found()) {
                                int i = 0;
                                Hand hand;
                                if (crystal.isOffhand()) {
                                    hand = Hand.OFF_HAND;
                                } else {
                                    hand = Hand.MAIN_HAND;
                                }

                                while(i != (Integer)this.iterations.get()) {
                                    this.DALTBlock = this.DALTBlock.add(this.DALTVec);
                                    ++i;
                                    if (BlockUtil.isReplaceable(this.DALTBlock) && CrystalUtils.autoTrapUtil(this.DALTBlock) && i > 1) {
                                        if ((Boolean)this.packet.get()) {
                                            PacketUtils.packetPlace(this.DALTBlock, InvUtils.findInHotbar((itemStack) -> {
                                                return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                                            }), (Boolean)this.rotate.get(), (Boolean)this.swing.get());
                                        } else {
                                            BlockUtils.place(this.DALTBlock, block, (Boolean)this.rotate.get(), 50);
                                        }

                                        ++places;
                                        this.placeTrollingCrystal(crystal, hand);
                                        break;
                                    }

                                    if ((BlockUtil.getBlock(this.DALTBlock).equals(Blocks.OBSIDIAN) || BlockUtil.getBlock(this.DALTBlock).equals(Blocks.BEDROCK)) && CrystalUtils.autoTrapUtil(this.DALTBlock)) {
                                        this.placeTrollingCrystal(crystal, hand);
                                        break;
                                    }

                                    if (!BlockUtil.isReplaceable(this.DALTBlock.up()) && i > 1) {
                                        if ((Boolean)this.notify.get()) {
                                            this.warning("can't place a trolling crystal.", new Object[0]);
                                        }
                                        break;
                                    }
                                }
                            }

                            this.doALittleTrolling = false;
                        }

                        Iterator var7;
                        BlockPos b;
                        if (!this.mainPositions.isEmpty()) {
                            var7 = this.mainPositions.iterator();

                            while(var7.hasNext()) {
                                b = (BlockPos)var7.next();
                                if (places <= (Integer)this.bpt.get() && b != null) {
                                    if ((Boolean)this.packet.get()) {
                                        PacketUtils.packetPlace(b, block, (Boolean)this.rotate.get(), (Boolean)this.swing.get());
                                    } else {
                                        BlockUtils.place(b, block, (Boolean)this.rotate.get(), 50);
                                    }

                                    ++places;
                                }
                            }
                        }

                        if (!this.underPositions.isEmpty()) {
                            var7 = this.underPositions.iterator();

                            while(var7.hasNext()) {
                                b = (BlockPos)var7.next();
                                if (places <= (Integer)this.bpt.get() && b != null) {
                                    if ((Boolean)this.packet.get()) {
                                        PacketUtils.packetPlace(b, block, (Boolean)this.rotate.get(), (Boolean)this.swing.get());
                                    } else {
                                        BlockUtils.place(b, block, (Boolean)this.rotate.get(), 50);
                                    }

                                    ++places;
                                }
                            }
                        }

                        if (!this.extraPositions.isEmpty()) {
                            var7 = this.extraPositions.iterator();

                            while(var7.hasNext()) {
                                b = (BlockPos)var7.next();
                                if (places <= (Integer)this.bpt.get() && b != null) {
                                    if ((Boolean)this.packet.get()) {
                                        PacketUtils.packetPlace(b, block, (Boolean)this.rotate.get(), (Boolean)this.swing.get());
                                    } else {
                                        BlockUtils.place(b, block, (Boolean)this.rotate.get(), 50);
                                    }

                                    ++places;
                                }
                            }
                        }

                        if ((Boolean)this.notify.get()) {
                            this.info("all positions placed.", new Object[0]);
                        }

                    }
                }
            }
        }
    }

    private void placeTrollingCrystal(FindItemResult crystal, Hand hand) {
        if ((Boolean)this.notify.get()) {
            this.info("placed trolling crystal", new Object[0]);
        }

        if (hand == Hand.MAIN_HAND) {
            InvUtils.swap(crystal.slot(), true);
        }

        this.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(hand, new BlockHitResult(Vec3dInfo.closestVec3d(this.DALTBlock), this.mc.player.getHorizontalFacing().getOpposite(), this.DALTBlock, true), 0));
        if (hand == Hand.MAIN_HAND) {
            InvUtils.swapBack();
        }

    }

    private void findPlacePos() {
        Iterator var1 = this.targets.iterator();

        while(var1.hasNext()) {
            PlayerEntity target = (PlayerEntity)var1.next();
            BlockPos pos = EntityUtil.playerPos(target);
            double yaw = (double)target.getYaw();
            if (target.isInSwimmingPose()) {
                this.addMain(pos.up());
            } else {
                this.addMain(pos.up().add(Direction.fromRotation(yaw).getVector()));
                this.addMain(pos.up(2));
                this.addMain(pos.up().add(Direction.fromRotation(yaw + 90.0D).getVector()));
                this.addMain(pos.up().add(Direction.fromRotation(yaw - 90.0D).getVector()));
                this.addMain(pos.up().add(Direction.fromRotation(yaw).getOpposite().getVector()));
            }

            this.addUnder(pos.down());
            if (this.shouldUnderneath) {
                this.addUnder(pos.add(Direction.fromRotation(yaw).getVector()));
                this.addUnder(pos.add(Direction.fromRotation(yaw + 90.0D).getVector()));
                this.addUnder(pos.add(Direction.fromRotation(yaw - 90.0D).getVector()));
                this.addUnder(pos.add(Direction.fromRotation(yaw).getOpposite().getVector()));
            }
        }

    }

    @EventHandler
    public void onBreakPacket(Receive event) {
        Packet var3 = event.packet;
        if (var3 instanceof BlockBreakingProgressS2CPacket) {
            BlockBreakingProgressS2CPacket packed = (BlockBreakingProgressS2CPacket)var3;
            BlockPos pos = packed.getPos();
            PlayerEntity breakingPlayer = (PlayerEntity)this.mc.world.getEntityById(packed.getEntityId());
            if (breakingPlayer != null) {
                BlockPos pPos = EntityUtil.playerPos(breakingPlayer);
                if (this.targets.contains(breakingPlayer) && packed.getProgress() >= (Integer)this.progress.get()) {
                    if (pos.equals(pPos.up().west())) {
                        this.doALittleTrolling = true;
                        this.DALTVec = new Vec3i(-1, 0, 0);
                    } else if (pos.equals(pPos.up().east())) {
                        this.doALittleTrolling = true;
                        this.DALTVec = new Vec3i(1, 0, 0);
                    } else if (pos.equals(pPos.up().north())) {
                        this.doALittleTrolling = true;
                        this.DALTVec = new Vec3i(0, 0, -1);
                    } else if (pos.equals(pPos.up().south())) {
                        this.doALittleTrolling = true;
                        this.DALTVec = new Vec3i(0, 0, 1);
                    }

                    if (this.doALittleTrolling) {
                        this.DALTBlock = breakingPlayer.getBlockPos();
                    }

                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get()) {
            Iterator var2 = this.mainPositions.iterator();

            BlockPos pos;
            while(var2.hasNext()) {
                pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

            var2 = this.underPositions.iterator();

            while(var2.hasNext()) {
                pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

            var2 = this.extraPositions.iterator();

            while(var2.hasNext()) {
                pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

            if (this.DALTBlock != null && (Boolean)this.renderTwo.get()) {
                event.renderer.box(this.DALTBlock, (Color)this.cideColor.get(), (Color)this.clineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

        }
    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() >= 600.0F && block.getHardness() > 0.0F;
    }

    private void addMain(BlockPos blockPos) {
        if (!this.mainPositions.contains(blockPos) && this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable() && this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent()) && BlockUtil.inPlaceRange(blockPos, BlockUtil.Origin.VANILLA, (Double)this.placeRange.get())) {
            this.mainPositions.add(blockPos);
        }

    }

    private void addUnder(BlockPos blockPos) {
        if (!this.underPositions.contains(blockPos) && this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable() && this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent()) && BlockUtil.inPlaceRange(blockPos, BlockUtil.Origin.VANILLA, (Double)this.placeRange.get())) {
            this.underPositions.add(blockPos);
        }

    }

    private void addExtra(BlockPos blockPos) {
        if (!this.extraPositions.contains(blockPos) && this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable() && this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent()) && BlockUtil.inPlaceRange(blockPos, BlockUtil.Origin.VANILLA, (Double)this.placeRange.get())) {
            this.extraPositions.add(blockPos);
        }

    }
}
