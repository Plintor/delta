package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixininterface.IClientPlayerInteractionManager;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.meteorclient.utils.world.Dir;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;

public class HoleFillerTwo extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgAdvanced;
    private final SettingGroup sgPause;
    private final SettingGroup sgRender;
    private final Setting<List<Block>> blocks;
    private final Setting<Double> horizontalPlaceRange;
    private final Setting<Double> verticalPlaceRange;
    private final Setting<Boolean> onlyAroundTargets;
    private final Setting<Double> horizontalTargetDistance;
    private final Setting<Double> verticalTargetDistance;
    private final Setting<Integer> maxBlocksPerTick;
    private final Setting<Boolean> doubles;
    private final Setting<Boolean> fillBoth;
    private final Setting<Boolean> allowHalf;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> swapBack;
    private final Setting<Boolean> placeRangeBypass;
    private final Setting<Boolean> sneakRangeBypass;
    private final Setting<Double> sneakActivationWindow;
    private final Setting<Boolean> ignoreCloseHoles;
    private final Setting<Boolean> ignoreSelfInHole;
    private final Setting<Double> horizontalIgnoreDistance;
    private final Setting<Double> verticalIgnoreDistance;
    private final Setting<Boolean> ignoreCloseFriends;
    private final Setting<Boolean> ignoreFriendInHole;
    private final Setting<Double> horizontalFriendDistance;
    private final Setting<Double> verticalFriendDistance;
    private final Setting<Boolean> ignoreOtherInHole;
    private final Setting<Boolean> eatPause;
    private final Setting<Boolean> drinkPause;
    private final Setting<Boolean> minePause;
    private final Setting<Boolean> renderSwing;
    private final Setting<Boolean> render;
    private final Setting<Integer> renderTicks;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Double> renderHeight;
    private final Setting<Double> shrinkSpeed;
    private final Setting<Boolean> topQuad;
    private final Setting<Boolean> bottomQuad;
    private final Setting<SettingColor> linesColorTop;
    private final Setting<SettingColor> linesColorBottom;
    private final Setting<SettingColor> sidesColorTop;
    private final Setting<SettingColor> sidesColorBottom;
    private final Pool<HoleFillerTwo.RenderBlock> renderBlockPool;
    private final List<HoleFillerTwo.RenderBlock> renderBlocks;
    private boolean shouldUnSneak;

    public HoleFillerTwo() {
        super(DeltaHack.Old, "hole-fillerV2", "Fills safe holes with obsidian using packets.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgAdvanced = this.settings.createGroup("Advanced");
        this.sgPause = this.settings.createGroup("Pause");
        this.sgRender = this.settings.createGroup("Render");
        this.blocks = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks")).description("The blocks to fill the holes with.")).defaultValue(new ArrayList<Block>() {
            {
                this.add(Blocks.ANCIENT_DEBRIS);
                this.add(Blocks.CRYING_OBSIDIAN);
                this.add(Blocks.ENDER_CHEST);
                this.add(Blocks.NETHERITE_BLOCK);
                this.add(Blocks.OBSIDIAN);
                this.add(Blocks.RESPAWN_ANCHOR);
            }
        })).build());
        this.horizontalPlaceRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("horizontal-place-range")).description("The horizontal radius in which blocks can be placed.")).defaultValue(3.0D).sliderMin(3.0D).sliderMax(5.0D).min(0.0D).max(10.0D).build());
        this.verticalPlaceRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("vertical-place-range")).description("The vertical radius in which blocks can be placed.")).defaultValue(3.25D).sliderRange(3.0D, 5.0D).range(0.0D, 10.0D).build());
        this.onlyAroundTargets = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-around-targets")).description("Only fills holes around targets.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("horizontal-target-distance")).description("The horizontal radius around a target in which holes are filled.")).defaultValue(1.5D).sliderMin(0.75D).sliderMax(2.0D).min(0.0D).max(10.0D);
        Setting var10003 = this.onlyAroundTargets;
        Objects.requireNonNull(var10003);
        this.horizontalTargetDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("vertical-target-distance")).description("The vertical radius around a target in which holes are filled.")).defaultValue(2.25D).sliderMin(1.5D).sliderMax(3.0D).min(0.0D).max(15.0D);
        var10003 = this.onlyAroundTargets;
        Objects.requireNonNull(var10003);
        this.verticalTargetDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.maxBlocksPerTick = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("max-bocks-per-tick")).description("The maximum amount of blocks placed in one tick.")).defaultValue(4)).sliderMin(3).sliderMax(5).min(1).noSlider().build());
        this.doubles = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("doubles")).description("Fills double holes.")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("fill-both")).description("Fills both blocks when a target comes close a double hole.")).defaultValue(true);
        var10003 = this.doubles;
        Objects.requireNonNull(var10003);
        this.fillBoth = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.allowHalf = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("allow-half")).description("Fills holes that are hard to get inside.")).defaultValue(false)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Faces the blocks being placed.")).defaultValue(false)).build());
        this.swapBack = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swap-back")).description("Swaps back to the previous slot after placing.")).defaultValue(true)).build());
        this.placeRangeBypass = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-range-bypass")).description("Interacts at the closest possible position to allow a maximal place range.")).defaultValue(true)).build());
        this.sneakRangeBypass = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("sneak-range-bypass")).description("Sneaks to lower your eye position to allow a little more vertical range.")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("sneak-activation-window")).description("From what range on to start sneaking when placing blocks.")).defaultValue(2.75D).sliderMin(1.5D).sliderMax(3.0D).min(0.0D).max(15.0D);
        var10003 = this.sneakRangeBypass;
        Objects.requireNonNull(var10003);
        this.sneakActivationWindow = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.ignoreCloseHoles = this.sgAdvanced.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-close-holes")).description("Ignores holes which are close to you.")).defaultValue(true)).build());
        var10001 = this.sgAdvanced;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-self-in-hole")).description("Ignores the holes around you when your in a safe-hole.")).defaultValue(true);
        var10003 = this.ignoreCloseHoles;
        Objects.requireNonNull(var10003);
        this.ignoreSelfInHole = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgAdvanced;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("horizontal-ignore-distance")).description("The horizontal radius around you in which holes aren't filled.")).defaultValue(1.0D).sliderMin(0.75D).sliderMax(1.5D).min(0.0D).max(5.0D);
        var10003 = this.ignoreCloseHoles;
        Objects.requireNonNull(var10003);
        this.horizontalIgnoreDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgAdvanced;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("vertical-ignore-distance")).description("The vertical radius around you in which holes aren't filled.")).defaultValue(1.25D).sliderMin(1.0D).sliderMax(1.5D).min(0.0D).max(10.0D);
        var10003 = this.ignoreCloseHoles;
        Objects.requireNonNull(var10003);
        this.verticalIgnoreDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.ignoreCloseFriends = this.sgAdvanced.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-close-to-friends")).description("Ignores holes which are close to your friends.")).defaultValue(true)).build());
        var10001 = this.sgAdvanced;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-friend-in-hole")).description("Ignores the holes around friends when they are in a safe-hole.")).defaultValue(true);
        var10003 = this.ignoreCloseFriends;
        Objects.requireNonNull(var10003);
        this.ignoreFriendInHole = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgAdvanced;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("horizontal-friend-distance")).description("The horizontal radius around your friends where holes aren't filled.")).defaultValue(1.0D).sliderMin(0.75D).sliderMax(1.5D).min(0.0D).max(5.0D);
        var10003 = this.ignoreCloseFriends;
        Objects.requireNonNull(var10003);
        this.horizontalFriendDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgAdvanced;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("vertical-friend-distance")).description("The vertical radius around your friends where holes aren't filled.")).defaultValue(1.5D).sliderMin(1.0D).sliderMax(2.0D).min(0.0D).max(10.0D);
        var10003 = this.ignoreCloseFriends;
        Objects.requireNonNull(var10003);
        this.verticalFriendDistance = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.ignoreOtherInHole = this.sgAdvanced.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-other-in-hole")).description("Ignores the holes around targets when they are in a safe-hole.")).defaultValue(true)).build());
        this.eatPause = this.sgPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-eat")).description("Pauses this module when your eating.")).defaultValue(true)).build());
        this.drinkPause = this.sgPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-drink")).description("Pauses this module when your drinking.")).defaultValue(true)).build());
        this.minePause = this.sgPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-mine")).description("Pauses this module when mining.")).defaultValue(true)).build());
        this.renderSwing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-swing")).description("Renders a hand-swing animation when you place a block.")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders the blocks being placed.")).defaultValue(true)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var2 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("ticks")).description("How many ticks it should take for a block to disappear.")).defaultValue(10)).min(1).sliderMin(1).sliderMax(15);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.renderTicks = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var2.visible(var10003::get)).noSlider().build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var3 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.shapeMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("height")).description("The height of rendering.")).defaultValue(0.75D).min(0.0D).sliderMin(0.15D).sliderMax(1.0D);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.renderHeight = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("shrink-speed")).description("How fast the hole shrinks per tick.")).defaultValue(0.1D).min(0.0D).sliderMin(0.0D).sliderMax(0.25D);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.shrinkSpeed = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("top-quad")).description("Whether to render a quad at the top of the hole.")).defaultValue(false);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.topQuad = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("bottom-quad")).description("Whether to render a quad at the bottom of the hole.")).defaultValue(true);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.bottomQuad = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.ColorSetting.Builder var4 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("lines-top")).description("The top color for the lines of the hole.")).defaultValue(new SettingColor(255, 0, 0, 15));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.linesColorTop = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var4.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var4 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("lines-bottom")).description("The bottom color for the lines of the hole.")).defaultValue(new SettingColor(255, 0, 0, 150));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.linesColorBottom = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var4.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var4 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("sides-top")).description("The top color for the sides of the hole.")).defaultValue(new SettingColor(255, 0, 0, 15));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.sidesColorTop = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var4.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var4 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("sides-bottom")).description("The bottom color for the sides of the hole.")).defaultValue(new SettingColor(255, 0, 0, 72));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.sidesColorBottom = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var4.visible(var10003::get)).build());
        this.renderBlockPool = new Pool(() -> {
            return new HoleFillerTwo.RenderBlock();
        });
        this.renderBlocks = new ArrayList();
    }

    public void onActivate() {
        this.shouldUnSneak = false;
        if (!this.renderBlocks.isEmpty()) {
            Iterator var1 = this.renderBlocks.iterator();

            while(var1.hasNext()) {
                HoleFillerTwo.RenderBlock block = (HoleFillerTwo.RenderBlock)var1.next();
                this.renderBlockPool.free(block);
            }

            this.renderBlocks.clear();
        }

    }

    public void onDeactivate() {
        if (!this.renderBlocks.isEmpty()) {
            Iterator var1 = this.renderBlocks.iterator();

            while(var1.hasNext()) {
                HoleFillerTwo.RenderBlock block = (HoleFillerTwo.RenderBlock)var1.next();
                this.renderBlockPool.free(block);
            }

            this.renderBlocks.clear();
        }

    }

    @EventHandler
    private void onPreTick(Pre event) {
        FindItemResult item = this.findInHotbar((stack) -> {
            Item patt15787$temp = stack.getItem();
            boolean var10000;
            if (patt15787$temp instanceof BlockItem) {
                BlockItem block = (BlockItem)patt15787$temp;
                if (((List)this.blocks.get()).contains(block.getBlock())) {
                    var10000 = true;
                    return var10000;
                }
            }

            var10000 = false;
            return var10000;
        });
        if (this.shouldUnSneak) {
            this.mc.player.setSneaking(false);
            this.mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(this.mc.player, Mode.RELEASE_SHIFT_KEY));
            this.shouldUnSneak = false;
        }

        if (item.found() && !this.shouldPause()) {
            List<HoleFillerTwo.Hole> holes = new ArrayList();
            boolean rotated = false;
            int pX = this.mc.player.getBlockX();
            int pY = this.mc.player.getBlockY();
            int pZ = this.mc.player.getBlockZ();
            int horizontal = (int)Math.floor((Double)this.horizontalPlaceRange.get());
            int vertical = (int)Math.floor((Double)this.verticalPlaceRange.get());

            int block;
            for(block = pX - horizontal; block <= pX + horizontal; ++block) {
                for(int z = pZ - horizontal; z <= pZ + horizontal; ++z) {
                    for(int y = Math.max(pY - vertical, this.mc.world.getBottomY() - 1); y <= Math.min(pY + vertical, this.mc.world.getTopY()); ++y) {
                        int dX = Math.abs(block - pX);
                        int dY = Math.abs(y - pY);
                        int dZ = Math.abs(z - pZ);
                        if ((double)dX <= (Double)this.horizontalPlaceRange.get() && (double)dY <= (Double)this.verticalPlaceRange.get() && (double)dZ <= (Double)this.horizontalPlaceRange.get()) {
                            BlockPos pos = new BlockPos(block, y, z);
                            if (this.isValidHole(pos, true) && this.isValidHole(pos.up(), false) && this.canPlace(pos)) {
                                int air = 0;
                                int surr = 0;
                                BlockPos second = null;
                                Direction excludeDir = null;
                                CardinalDirection[] var21 = CardinalDirection.values();
                                int var22 = var21.length;

                                for(int var23 = 0; var23 < var22; ++var23) {
                                    CardinalDirection cardinal = var21[var23];
                                    Direction direction = cardinal.toDirection();
                                    if ((Boolean)this.doubles.get() && this.isValidHole(pos.offset(direction), true) && this.isValidHole(pos.offset(direction).up(), false) && this.canPlace(pos.offset(direction))) {
                                        int surrounded = 0;
                                        CardinalDirection[] var27 = CardinalDirection.values();
                                        int var28 = var27.length;

                                        for(int var29 = 0; var29 < var28; ++var29) {
                                            CardinalDirection dir = var27[var29];
                                            if (this.mc.world.getBlockState(pos.offset(direction).offset(dir.toDirection())).getBlock().getBlastResistance() >= 600.0F) {
                                                ++surrounded;
                                            }
                                        }

                                        if (surrounded == 3) {
                                            excludeDir = direction;
                                            second = pos.offset(direction);
                                            ++air;
                                        } else {
                                            air = 0;
                                        }
                                    } else if (this.mc.world.getBlockState(pos.offset(direction)).getBlock().getBlastResistance() >= 600.0F) {
                                        ++surr;
                                    }
                                }

                                if ((Boolean)this.doubles.get()) {
                                    if ((air != 1 || surr < 3 || (Boolean)this.allowHalf.get() && !this.isValidHole(pos.up(2), false) && (second == null || !this.isValidHole(second.up(2), false))) && (air != 0 || surr < 4 || !this.isValidHole(pos.up(2), false))) {
                                        continue;
                                    }
                                } else if (surr < 4 || !this.isValidHole(pos.up(2), false)) {
                                    continue;
                                }

                                holes.add(new HoleFillerTwo.Hole(pos, (Boolean)this.doubles.get() && excludeDir != null ? second : null, (Boolean)this.doubles.get() && second != null ? excludeDir : null));
                            }
                        }
                    }
                }
            }

            if (!holes.isEmpty()) {
                holes.sort(Comparator.comparingDouble((holex) -> {
                    return BlockUtil.distance(this.mc.player.getPos(), Vec3d.ofCenter(holex.pos1));
                }));
                block = 0;
                Iterator var31 = holes.iterator();

                do {
                    HoleFillerTwo.Hole hole;
                    boolean fill;
                    Vec3d eyes;
                    do {
                        do {
                            if (!var31.hasNext()) {
                                return;
                            }

                            hole = (HoleFillerTwo.Hole)var31.next();
                            fill = !(Boolean)this.onlyAroundTargets.get();
                            Iterator var34;
                            PlayerEntity player;
                            Vec3d pos;
                            if ((Boolean)this.onlyAroundTargets.get()) {
                                label413: {
                                    var34 = this.mc.world.getPlayers().iterator();

                                    do {
                                        do {
                                            do {
                                                do {
                                                    if (!var34.hasNext()) {
                                                        break label413;
                                                    }

                                                    player = (PlayerEntity)var34.next();
                                                    pos = player.getEyePos();
                                                } while(!(player instanceof FakePlayerEntity) && Friends.get().isFriend(player));
                                            } while(this.mc.player == player);
                                        } while((Boolean)this.ignoreOtherInHole.get() && (!(Boolean)this.ignoreOtherInHole.get() || this.isHole(player.getBlockPos())));
                                    } while((!hole.isDouble() || !(Boolean)this.doubles.get() || !(Boolean)this.fillBoth.get() || (!(BlockUtil.distanceXZ(Vec3d.ofCenter(hole.pos1), pos) <= (Double)this.horizontalTargetDistance.get()) || !(BlockUtil.distanceY((double)hole.pos1.getY() + 0.5D, pos.getY()) <= (Double)this.verticalTargetDistance.get())) && (!(BlockUtil.distanceXZ(Vec3d.ofCenter(hole.pos2), pos) <= (Double)this.horizontalTargetDistance.get()) || !(BlockUtil.distanceY((double)hole.pos2.getY() + 0.5D, pos.getY()) <= (Double)this.verticalTargetDistance.get()))) && (!(BlockUtil.distanceXZ(Vec3d.ofCenter(hole.pos1), pos) <= (Double)this.horizontalTargetDistance.get()) || !(BlockUtil.distanceY((double)hole.pos1.getY() + 0.5D, pos.getY()) <= (Double)this.verticalTargetDistance.get())));

                                    fill = true;
                                }
                            }

                            if ((Boolean)this.ignoreCloseFriends.get()) {
                                label414: {
                                    var34 = this.mc.world.getPlayers().iterator();

                                    do {
                                        do {
                                            do {
                                                do {
                                                    if (!var34.hasNext()) {
                                                        break label414;
                                                    }

                                                    player = (PlayerEntity)var34.next();
                                                } while(this.mc.player == player);
                                            } while(!Friends.get().isFriend(player));

                                            pos = player.getEyePos();
                                        } while((Boolean)this.ignoreFriendInHole.get() && (!(Boolean)this.ignoreFriendInHole.get() || this.isHole(player.getBlockPos())));
                                    } while((!hole.isDouble() || !(Boolean)this.doubles.get() || !(Boolean)this.fillBoth.get() || (!(BlockUtil.distanceXZ(pos, Vec3d.ofCenter(hole.pos1)) < (Double)this.horizontalFriendDistance.get()) || !(BlockUtil.distanceXZ(pos, Vec3d.ofCenter(hole.pos2)) < (Double)this.horizontalFriendDistance.get())) && (!(BlockUtil.distanceY(pos.getY(), (double)hole.pos1.getY() + 0.5D) < (Double)this.verticalFriendDistance.get()) || !(BlockUtil.distanceY(pos.getY(), (double)hole.pos2.getY() + 0.5D) < (Double)this.verticalFriendDistance.get()))) && !(BlockUtil.distanceXZ(pos, Vec3d.ofCenter(hole.pos1)) < (Double)this.horizontalFriendDistance.get()) && !(BlockUtil.distanceY(pos.getY(), (double)hole.pos1.getY() + 0.5D) < (Double)this.verticalFriendDistance.get()));

                                    fill = false;
                                }
                            }

                            eyes = this.mc.player.getEyePos();
                        } while(!fill);
                    } while((Boolean)this.ignoreCloseHoles.get() && (!(Boolean)this.ignoreCloseHoles.get() || !(Boolean)this.ignoreSelfInHole.get() || !this.isHole(this.mc.player.getBlockPos())) && (!(Boolean)this.ignoreCloseHoles.get() || (!hole.isDouble() || !(Boolean)this.doubles.get() || !(Boolean)this.fillBoth.get() || (!(BlockUtil.distanceXZ(eyes, Vec3d.ofCenter(hole.pos1)) >= (Double)this.horizontalIgnoreDistance.get()) || !(BlockUtil.distanceXZ(eyes, Vec3d.ofCenter(hole.pos2)) >= (Double)this.horizontalIgnoreDistance.get())) && (!(BlockUtil.distanceY(eyes.getY(), (double)hole.pos1.getY() + 0.5D) >= (Double)this.verticalIgnoreDistance.get()) || !(BlockUtil.distanceY(eyes.getY(), (double)hole.pos2.getY() + 0.5D) >= (Double)this.verticalIgnoreDistance.get()))) && (hole.isDouble() && (Boolean)this.doubles.get() && (Boolean)this.fillBoth.get() || !(BlockUtil.distanceXZ(eyes, Vec3d.ofCenter(hole.pos1)) >= (Double)this.horizontalIgnoreDistance.get()) && !(BlockUtil.distanceY(eyes.getY(), (double)hole.pos1.getY() + 0.5D) >= (Double)this.verticalIgnoreDistance.get()))));

                    if (hole.isDouble() && (Boolean)this.doubles.get() && (Boolean)this.fillBoth.get()) {
                        if (block < (Integer)this.maxBlocksPerTick.get()) {
                            this.place(hole.pos1, item, !rotated ? (Boolean)this.rotate.get() : false);
                            if (this.isRendered(hole.pos1)) {
                                this.renderBlocks.add(((HoleFillerTwo.RenderBlock)this.renderBlockPool.get()).set(hole.pos1, Dir.get(hole.direction)));
                            }

                            rotated = true;
                            ++block;
                        }

                        if (block < (Integer)this.maxBlocksPerTick.get()) {
                            this.place(hole.pos2, item, !rotated ? (Boolean)this.rotate.get() : false);
                            if (this.isRendered(hole.pos2)) {
                                this.renderBlocks.add(((HoleFillerTwo.RenderBlock)this.renderBlockPool.get()).set(hole.pos2, Dir.get(hole.direction.getOpposite())));
                            }

                            rotated = true;
                            ++block;
                        }
                    } else if (block < (Integer)this.maxBlocksPerTick.get()) {
                        this.place(hole.pos1, item, !rotated ? (Boolean)this.rotate.get() : false);
                        if (this.isRendered(hole.pos1)) {
                            this.renderBlocks.add(((HoleFillerTwo.RenderBlock)this.renderBlockPool.get()).set(hole.pos1, 0));
                        }

                        rotated = true;
                        ++block;
                    }
                } while(block <= (Integer)this.maxBlocksPerTick.get());
            }
        }

    }

    @EventHandler
    private void onPostTick(Post event) {
        this.renderBlocks.forEach(HoleFillerTwo.RenderBlock::tick);
        this.renderBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!this.renderBlocks.isEmpty()) {
            this.renderBlocks.sort(Comparator.comparingInt((block) -> {
                return -block.ticks;
            }));
            this.renderBlocks.forEach((block) -> {
                block.render(event, (ShapeMode)this.shapeMode.get());
            });
        }

    }

    private boolean isValidHole(BlockPos pos, boolean checkDown) {
        return this.mc.world.getBlockState(pos).getMaterial().isReplaceable() && (!checkDown || this.mc.world.getBlockState(pos.down()).getBlock().getBlastResistance() >= 600.0F && this.mc.world.getBlockState(pos.down()).getCollisionShape(this.mc.world, pos.down()) != null && !this.mc.world.getBlockState(pos.down()).getCollisionShape(this.mc.world, pos.down()).isEmpty()) && (this.mc.world.getBlockState(pos).getCollisionShape(this.mc.world, pos) == null || this.mc.world.getBlockState(pos).getCollisionShape(this.mc.world, pos).isEmpty());
    }

    private boolean shouldPause() {
        if ((Boolean)this.minePause.get() && this.mc.interactionManager.isBreakingBlock()) {
            return true;
        } else if (!(Boolean)this.eatPause.get() || !this.mc.player.isUsingItem() || !this.mc.player.getMainHandStack().getItem().isFood() && !this.mc.player.getOffHandStack().getItem().isFood()) {
            return (Boolean)this.drinkPause.get() && this.mc.player.isUsingItem() && (this.mc.player.getMainHandStack().getItem() instanceof PotionItem || this.mc.player.getOffHandStack().getItem() instanceof PotionItem);
        } else {
            return true;
        }
    }

    private boolean isRendered(BlockPos pos) {
        Iterator var2 = this.renderBlocks.iterator();

        HoleFillerTwo.RenderBlock block;
        do {
            if (!var2.hasNext()) {
                return true;
            }

            block = (HoleFillerTwo.RenderBlock)var2.next();
        } while(!block.pos.equals(pos));

        return false;
    }

    private boolean isHole(BlockPos pos) {
        if (this.isValidHole(pos, true) && this.isValidHole(pos.up(), false)) {
            int air = 0;
            int surr = 0;
            BlockPos second = null;
            CardinalDirection[] var5 = CardinalDirection.values();
            int var6 = var5.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                CardinalDirection cardinal = var5[var7];
                Direction direction = cardinal.toDirection();
                if ((Boolean)this.doubles.get() && this.isValidHole(pos.offset(direction), true) && this.isValidHole(pos.offset(direction).up(), false)) {
                    int surrounded = 0;
                    CardinalDirection[] var11 = CardinalDirection.values();
                    int var12 = var11.length;

                    for(int var13 = 0; var13 < var12; ++var13) {
                        CardinalDirection dir = var11[var13];
                        if (this.mc.world.getBlockState(pos.offset(direction).offset(dir.toDirection())).getBlock().getBlastResistance() >= 600.0F) {
                            ++surrounded;
                        }
                    }

                    if (surrounded == 3) {
                        second = pos.offset(direction);
                        ++air;
                    } else {
                        air = 0;
                    }
                } else if (this.mc.world.getBlockState(pos.offset(direction)).getBlock().getBlastResistance() >= 600.0F) {
                    ++surr;
                }
            }

            return (Boolean)this.doubles.get() ? air == 1 && surr >= 3 && (!(Boolean)this.allowHalf.get() || this.isValidHole(pos.up(2), false) || second != null && this.isValidHole(second.up(2), false)) || air == 0 && surr >= 4 && this.isValidHole(pos.up(2), false) : surr >= 4 && this.isValidHole(pos.up(2), false);
        } else {
            return false;
        }
    }

    private FindItemResult findInHotbar(Predicate<ItemStack> isGood) {
        if (isGood.test(this.mc.player.getOffHandStack())) {
            return new FindItemResult(45, this.mc.player.getOffHandStack().getCount());
        } else if (isGood.test(this.mc.player.getMainHandStack())) {
            return new FindItemResult(this.mc.player.getInventory().selectedSlot, this.mc.player.getMainHandStack().getCount());
        } else {
            int slot = -1;
            int count = 0;

            for(int i = 0; i <= 8; ++i) {
                ItemStack stack = this.mc.player.getInventory().getStack(i);
                if (isGood.test(stack)) {
                    if (slot == -1) {
                        slot = i;
                    }

                    count += stack.getCount();
                }
            }

            return new FindItemResult(slot, count);
        }
    }

    private void place(BlockPos pos, FindItemResult item, boolean rotate) {
        if (item.isOffhand()) {
            this.place(pos, Hand.OFF_HAND, this.mc.player.getInventory().selectedSlot, rotate);
        } else if (item.isHotbar()) {
            this.place(pos, Hand.MAIN_HAND, item.slot(), rotate);
        }

    }

    private void place(BlockPos pos, Hand hand, int slot, boolean rotate) {
        if ((slot >= 0 && slot <= 8 || slot == 45) && this.canPlace(pos)) {
            Vec3d hitPos = this.getHitPos(pos);
            Direction side = this.getSide(pos);
            BlockPos neighbour = this.getNeighbourPos(pos);
            boolean shouldSneak = !this.mc.player.isSneaking() && (Boolean)this.sneakRangeBypass.get() && this.mc.player.getEyeY() > hitPos.getY() + (Double)this.sneakActivationWindow.get();
            if (shouldSneak) {
                this.mc.player.setSneaking(true);
                this.mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(this.mc.player, Mode.PRESS_SHIFT_KEY));
                this.shouldUnSneak = true;
            }

            if (rotate) {
                Rotations.rotate(Rotations.getYaw(hitPos), Rotations.getPitch(hitPos), 0, () -> {
                    int prevSlot = this.mc.player.getInventory().selectedSlot;
                    this.mc.player.getInventory().selectedSlot = slot;
                    ((IClientPlayerInteractionManager)this.mc.interactionManager).syncSelected();
                    this.place(new BlockHitResult(hitPos, side, neighbour, false), hand);
                    if ((Boolean)this.swapBack.get()) {
                        this.mc.player.getInventory().selectedSlot = prevSlot;
                        ((IClientPlayerInteractionManager)this.mc.interactionManager).syncSelected();
                    }

                });
            } else {
                int prevSlot = this.mc.player.getInventory().selectedSlot;
                this.mc.player.getInventory().selectedSlot = slot;
                ((IClientPlayerInteractionManager)this.mc.interactionManager).syncSelected();
                this.place(new BlockHitResult(hitPos, side, neighbour, false), hand);
                if ((Boolean)this.swapBack.get()) {
                    this.mc.player.getInventory().selectedSlot = prevSlot;
                    ((IClientPlayerInteractionManager)this.mc.interactionManager).syncSelected();
                }
            }
        }

    }

    private void place(BlockHitResult result, Hand hand) {
        if (hand != null && result != null && this.mc.world.getWorldBorder().contains(result.getBlockPos()) && this.mc.player.getStackInHand(hand).getItem() instanceof BlockItem) {
            this.mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(hand, result, 0));
            Block block = ((BlockItem)this.mc.player.getStackInHand(hand).getItem()).getBlock();
            BlockSoundGroup group = block.getSoundGroup(block.getDefaultState());
            this.mc.getSoundManager().play(new PositionedSoundInstance(group.getPlaceSound(), SoundCategory.BLOCKS, (group.getVolume() + 1.0F) / 8.0F, group.getPitch() * 0.5F, Random.create(), result.getBlockPos()));
            if ((Boolean)this.renderSwing.get()) {
                this.mc.player.swingHand(hand);
            } else {
                this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
            }
        }

    }

    private Vec3d getHitPos(BlockPos pos) {
        Direction side = this.getPlaceSide(pos);
        Vec3d hitPos = new Vec3d((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D);
        if (side != null) {
            side = side.getOpposite();
            if (!(Boolean)this.placeRangeBypass.get()) {
                hitPos = hitPos.add(side.getOffsetX() == 0 ? 0.0D : (side.getOffsetX() > 0 ? 0.5D : -0.5D), side.getOffsetY() == 0 ? 0.0D : (side.getOffsetY() > 0 ? 0.5D : -0.5D), side.getOffsetZ() == 0 ? 0.0D : (side.getOffsetZ() > 0 ? 0.5D : -0.5D));
            }
        }

        if ((Boolean)this.placeRangeBypass.get()) {
            Vec3d target = this.mc.player.getEyePos();
            double x = MathHelper.clamp(target.getX(), (double)pos.getX(), (double)(pos.getX() + 1));
            double y = MathHelper.clamp(target.getY(), (double)pos.getY(), (double)(pos.getY() + 1));
            double z = MathHelper.clamp(target.getZ(), (double)pos.getZ(), (double)(pos.getZ() + 1));
            hitPos = new Vec3d(x, y, z);
        }

        return hitPos;
    }

    private BlockPos getNeighbourPos(BlockPos pos) {
        Direction side = this.getPlaceSide(pos);
        BlockPos neighbour;
        if (side == null) {
            neighbour = pos;
        } else {
            neighbour = pos.offset(side.getOpposite());
        }

        return neighbour;
    }

    private Direction getSide(BlockPos pos) {
        Direction side = this.getPlaceSide(pos);
        return side == null ? Direction.UP : side;
    }

    private boolean canPlace(BlockPos pos) {
        if (pos != null && this.mc.world != null && this.mc.world.getBottomY() <= pos.getY() && this.mc.world.getTopY() >= pos.getY()) {
            return this.mc.world.getBlockState(pos).getMaterial().isReplaceable() && this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), pos, ShapeContext.absent());
        } else {
            return false;
        }
    }

    private Direction getPlaceSide(BlockPos pos) {
        Direction[] var2 = Direction.values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Direction side = var2[var4];
            BlockPos neighbor = pos.offset(side);
            Direction opposite = side.getOpposite();
            BlockState state = this.mc.world.getBlockState(neighbor);
            if (!state.getMaterial().isReplaceable() && state.getFluidState().isEmpty() && !BlockUtil.isClickable(this.mc.world.getBlockState(pos.offset(side)).getBlock())) {
                return opposite;
            }
        }

        return null;
    }

    public class RenderBlock {
        public Mutable pos = new Mutable();
        public int exclude;
        public int ticks;
        private double height;
        private Color sidesTop;
        private Color sidesBottom;
        private Color linesTop;
        private Color linesBottom;

        public HoleFillerTwo.RenderBlock set(BlockPos pos, int exclude) {
            this.pos.set(pos);
            this.exclude = exclude;
            this.ticks = (Integer)HoleFillerTwo.this.renderTicks.get();
            this.sidesTop = new Color((Color)HoleFillerTwo.this.sidesColorTop.get());
            this.sidesBottom = new Color((Color)HoleFillerTwo.this.sidesColorBottom.get());
            this.linesTop = new Color((Color)HoleFillerTwo.this.linesColorTop.get());
            this.linesBottom = new Color((Color)HoleFillerTwo.this.linesColorBottom.get());
            this.height = (Double)HoleFillerTwo.this.renderHeight.get();
            return this;
        }

        public void tick() {
            --this.ticks;
            this.height = this.height - (Double)HoleFillerTwo.this.shrinkSpeed.get() < 0.0D ? 0.0D : this.height - (Double)HoleFillerTwo.this.shrinkSpeed.get();
        }

        public void render(Render3DEvent event, ShapeMode shapeMode) {
            Color prevSidesTop = this.sidesTop.copy();
            Color prevSidesBottom = this.sidesBottom.copy();
            Color prevLinesTop = this.linesTop.copy();
            Color prevLinesBottom = this.linesBottom.copy();
            Color var10000 = this.sidesTop;
            var10000.a = (int)((double)var10000.a * ((double)this.ticks / 8.0D));
            var10000 = this.sidesBottom;
            var10000.a = (int)((double)var10000.a * ((double)this.ticks / 8.0D));
            var10000 = this.linesTop;
            var10000.a = (int)((double)var10000.a * ((double)this.ticks / 8.0D));
            var10000 = this.linesBottom;
            var10000.a = (int)((double)var10000.a * ((double)this.ticks / 8.0D));
            int x = this.pos.getX();
            int y = this.pos.getY();
            int z = this.pos.getZ();
            if (shapeMode.lines()) {
                if (Dir.isNot(this.exclude, (byte)32) && Dir.isNot(this.exclude, (byte)8)) {
                    event.renderer.line((double)x, (double)y, (double)z, (double)x, (double)y + this.height, (double)z, this.sidesBottom, this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)32) && Dir.isNot(this.exclude, (byte)16)) {
                    event.renderer.line((double)x, (double)y, (double)(z + 1), (double)x, (double)y + this.height, (double)(z + 1), this.sidesBottom, this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)64) && Dir.isNot(this.exclude, (byte)8)) {
                    event.renderer.line((double)(x + 1), (double)y, (double)z, (double)(x + 1), (double)y + this.height, (double)z, this.sidesBottom, this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)64) && Dir.isNot(this.exclude, (byte)16)) {
                    event.renderer.line((double)(x + 1), (double)y, (double)(z + 1), (double)(x + 1), (double)y + this.height, (double)(z + 1), this.sidesBottom, this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)8)) {
                    event.renderer.line((double)x, (double)y, (double)z, (double)(x + 1), (double)y, (double)z, this.sidesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)8)) {
                    event.renderer.line((double)x, (double)y + this.height, (double)z, (double)(x + 1), (double)y + this.height, (double)z, this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)16)) {
                    event.renderer.line((double)x, (double)y, (double)(z + 1), (double)(x + 1), (double)y, (double)(z + 1), this.sidesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)16)) {
                    event.renderer.line((double)x, (double)y + this.height, (double)(z + 1), (double)(x + 1), (double)y + this.height, (double)(z + 1), this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)32)) {
                    event.renderer.line((double)x, (double)y, (double)z, (double)x, (double)y, (double)(z + 1), this.sidesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)32)) {
                    event.renderer.line((double)x, (double)y + this.height, (double)z, (double)x, (double)y + this.height, (double)(z + 1), this.sidesTop);
                }

                if (Dir.isNot(this.exclude, (byte)64)) {
                    event.renderer.line((double)(x + 1), (double)y, (double)z, (double)(x + 1), (double)y, (double)(z + 1), this.sidesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)64)) {
                    event.renderer.line((double)(x + 1), (double)y + this.height, (double)z, (double)(x + 1), (double)y + this.height, (double)(z + 1), this.sidesTop);
                }
            }

            if (shapeMode.sides()) {
                if (Dir.isNot(this.exclude, (byte)2) && (Boolean)HoleFillerTwo.this.topQuad.get()) {
                    event.renderer.quad((double)x, (double)y + this.height, (double)z, (double)x, (double)y + this.height, (double)(z + 1), (double)(x + 1), (double)y + this.height, (double)(z + 1), (double)(x + 1), (double)y + this.height, (double)z, this.linesTop);
                }

                if (Dir.isNot(this.exclude, (byte)4) && (Boolean)HoleFillerTwo.this.bottomQuad.get()) {
                    event.renderer.quad((double)x, (double)y, (double)z, (double)x, (double)y, (double)(z + 1), (double)(x + 1), (double)y, (double)(z + 1), (double)(x + 1), (double)y, (double)z, this.linesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)8)) {
                    event.renderer.gradientQuadVertical((double)x, (double)y, (double)z, (double)(x + 1), (double)y + this.height, (double)z, this.linesTop, this.linesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)16)) {
                    event.renderer.gradientQuadVertical((double)x, (double)y, (double)(z + 1), (double)(x + 1), (double)y + this.height, (double)(z + 1), this.linesTop, this.linesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)32)) {
                    event.renderer.gradientQuadVertical((double)x, (double)y, (double)z, (double)x, (double)y + this.height, (double)(z + 1), this.linesTop, this.linesBottom);
                }

                if (Dir.isNot(this.exclude, (byte)64)) {
                    event.renderer.gradientQuadVertical((double)(x + 1), (double)y, (double)z, (double)(x + 1), (double)y + this.height, (double)(z + 1), this.linesTop, this.linesBottom);
                }
            }

            this.sidesTop = prevSidesTop.copy();
            this.sidesBottom = prevSidesBottom.copy();
            this.linesTop = prevLinesTop.copy();
            this.linesBottom = prevLinesBottom.copy();
        }
    }

    private class Hole {
        public BlockPos pos1;
        public BlockPos pos2;
        public Direction direction;

        public Hole(BlockPos pos1, BlockPos pos2, Direction direction) {
            this.pos1 = pos1;
            this.pos2 = pos2;
            this.direction = direction;
        }

        public boolean isDouble() {
            return this.pos1 != null && this.pos2 != null && this.direction != null;
        }
    }
}
