package delta.modules.combat;

import delta.DeltaHack;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

public class ArmorMessages extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> durThreshold;
    private final Setting<Boolean> alertSelf;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> alertFriend;
    private final Setting<Integer> delay;
    private final List<String> messages;
    private final List<PlayerEntity> helmet;
    private final List<PlayerEntity> chestplate;
    private final List<PlayerEntity> pants;
    private final List<PlayerEntity> boots;
    private int messageI;
    private int timer;

    public ArmorMessages() {
        super(DeltaHack.Combat, "armor-alert", "Send alerts to people with low armor.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.durThreshold = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("durability-threshold")).description("The minimum durability to alert.")).defaultValue(20)).range(1, 99).sliderRange(1, 99).build());
        this.alertSelf = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("alert-self")).description("Whether to alert yourself.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("messages-to-yourself")).description("Amount of messages to yourself.")).defaultValue(1);
        Setting var10003 = this.alertSelf;
        Objects.requireNonNull(var10003);
        this.blocksPerTick = var10001.add(((Builder)var10002.visible(var10003::get)).range(1, 10).sliderRange(1, 5).build());
        this.alertFriend = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("alert-friend")).description("Whether to alert friend.")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        var10002 = ((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("The delay between messages in ticks.")).defaultValue(0)).min(0).sliderMax(200);
        var10003 = this.alertFriend;
        Objects.requireNonNull(var10003);
        this.delay = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.messages = new ArrayList();
        this.helmet = new ArrayList();
        this.chestplate = new ArrayList();
        this.pants = new ArrayList();
        this.boots = new ArrayList();
    }

    public void onActivate() {
        this.timer = 0;
        this.helmet.clear();
        this.chestplate.clear();
        this.pants.clear();
        this.boots.clear();
    }

    public void onDeactivate() {
        this.helmet.clear();
        this.chestplate.clear();
        this.pants.clear();
        this.boots.clear();
    }

    @EventHandler
    private void onTick(Post event) {
        Iterator var2 = this.mc.world.getPlayers().iterator();

        while(true) {
            while(var2.hasNext()) {
                PlayerEntity player = (PlayerEntity)var2.next();
                if (player == this.mc.player && (Boolean)this.alertSelf.get()) {
                    this.check(player);
                } else if (Friends.get().isFriend(player) && (Boolean)this.alertFriend.get()) {
                    this.check(player);
                }
            }

            if (!this.messages.isEmpty()) {
                if (this.timer <= 0) {
                    if (this.messageI >= this.messages.size()) {
                        this.messageI = 0;
                    }

                    int i = this.messageI++;

                    for(int j = 0; j < (Integer)this.blocksPerTick.get(); ++j) {
                        this.mc.player.sendChatMessage((String)this.messages.get(i), Text.literal((String)this.messages.get(i)));
                    }

                    this.messages.remove(i);
                    this.timer = (Integer)this.delay.get();
                } else {
                    --this.timer;
                }
            }

            return;
        }
    }

    public void check(PlayerEntity player) {
        Iterable<ItemStack> armorPieces = player.getArmorItems();
        Iterator var3 = armorPieces.iterator();

        while(var3.hasNext()) {
            ItemStack armorPiece = (ItemStack)var3.next();
            if (this.checkDur(armorPiece)) {
                if (armorPiece == player.getInventory().getArmorStack(3) && player.getInventory().getArmorStack(3) != null && !this.helmet.contains(player)) {
                    this.sendMsg("helmet", player);
                    this.helmet.add(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(2) && player.getInventory().getArmorStack(2) != null && !this.chestplate.contains(player)) {
                    if (this.mc.player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA) {
                        this.sendMsg("elytra", player);
                    } else {
                        this.sendMsg("chestplate", player);
                    }

                    this.chestplate.add(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(1) && player.getInventory().getArmorStack(1) != null && !this.pants.contains(player)) {
                    this.sendMsg("leggings", player);
                    this.pants.add(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(0) && player.getInventory().getArmorStack(0) != null && !this.boots.contains(player)) {
                    this.sendMsg("boots", player);
                    this.boots.add(player);
                }
            }

            if (!this.checkDur(armorPiece)) {
                if (armorPiece == player.getInventory().getArmorStack(3)) {
                    this.helmet.remove(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(2)) {
                    this.chestplate.remove(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(1)) {
                    this.pants.remove(player);
                }

                if (armorPiece == player.getInventory().getArmorStack(0)) {
                    this.boots.remove(player);
                }
            }
        }

    }

    private boolean checkDur(ItemStack i) {
        return (float)(i.getMaxDamage() - i.getDamage()) / (float)i.getMaxDamage() * 100.0F <= (float)(Integer)this.durThreshold.get();
    }

    private void sendMsg(String armor, PlayerEntity player) {
        String grammar;
        if (armor.endsWith("s")) {
            grammar = " are low!";
        } else {
            grammar = " is low!";
        }

        if (player == this.mc.player) {
            this.info(" Your " + armor + grammar, new Object[0]);
        } else {
            this.messages.add("/msg " + player.getEntityName() + " Your " + armor + grammar);
        }

    }
}
