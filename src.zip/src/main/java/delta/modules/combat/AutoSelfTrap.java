package delta.modules.combat;

import delta.DeltaHack;
import delta.util.PacketUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;

public class AutoSelfTrap extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> delay;
    private final Setting<Double> range;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> rotate;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> onlyMove;
    private final Setting<Boolean> onlyHole;
    private final Setting<Boolean> notify;
    private int timer;

    public AutoSelfTrap() {
        super(DeltaHack.Combat, "auto-self-trap", "Places obsidian above your head when someone approaches you");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Extra delay between block bursts. (0 = every tick)")).defaultValue(1)).sliderRange(0, 5).build());
        this.range = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("range")).description("enemy range")).defaultValue(1.0D).sliderRange(0.0D, 6.0D).build());
        this.packet = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("packet")).description("Packet block placing method.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when placing.")).defaultValue(false)).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("Which blocks used for placing.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.onlyMove = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-moving-targets")).description("-")).defaultValue(true)).build());
        this.onlyHole = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-hole")).description("-")).defaultValue(true)).build());
        this.notify = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("-")).defaultValue(false)).build());
    }

    public void onActivate() {
        this.timer = 0;
    }

    @EventHandler
    private void onTick(Pre event) {
        FindItemResult block = InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        });
        if (block.found() && !this.mc.player.isInSwimmingPose() && (!EntityUtil.isMonke(this.mc.player, false, BlockUtil.BlastResistantType.Any) || !(Boolean)this.onlyHole.get())) {
            boolean should = false;
            BlockPos bs = EntityUtil.playerPos(this.mc.player);
            Iterator var5 = EntityUtil.getTargetsInRange(10.0D).iterator();

            while(true) {
                PlayerEntity entity;
                do {
                    do {
                        do {
                            do {
                                if (!var5.hasNext()) {
                                    if (this.timer == 0) {
                                        if (!should) {
                                            return;
                                        }

                                        if (BlockUtil.isReplaceable(bs.up(2))) {
                                            if ((Boolean)this.packet.get()) {
                                                PacketUtils.packetPlace(bs.up(2), block, (Boolean)this.rotate.get(), false);
                                            } else {
                                                BlockUtils.place(bs.up(2), block, (Boolean)this.rotate.get(), 50);
                                            }
                                        }

                                        this.timer = (Integer)this.delay.get();
                                    } else {
                                        --this.timer;
                                    }

                                    return;
                                }

                                entity = (PlayerEntity)var5.next();
                            } while(!(BlockUtil.horizontalDistance(entity.getBlockPos(), bs) <= (Double)this.range.get()));
                        } while(!(entity.getY() > (double)bs.getY()));
                    } while(!(entity.getY() - (double)bs.getY() < (Double)this.range.get()));
                } while(entity.getVelocity().length() < 0.2D && (Boolean)this.onlyMove.get());

                should = true;
                if ((Boolean)this.notify.get()) {
                    this.warning("Noticed a player.", new Object[0]);
                }
            }
        } else {
            this.timer = (Integer)this.delay.get();
        }
    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() >= 600.0F && block.getHardness() > 0.0F;
    }
}
