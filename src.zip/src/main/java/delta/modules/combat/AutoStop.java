package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.Vec3dInfo;
import delta.utils.WorldUtils;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoStop extends Module {
    private final SettingGroup sgDefault;
    private final SettingGroup sgTarget;
    private final Setting<Double> actionRange;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> noResourcesDisable;
    private final Setting<AutoStop.PositionMode> mode;
    private final Setting<Integer> delay;
    private final Setting<Integer> predict;
    private final Setting<AutoStop.YMode> yMode;
    private final Setting<Boolean> preventJump;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> swing;
    private final Setting<Double> enemyRange;
    private final Setting<Boolean> noTargetDisable;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<SortPriority> tarPrio;
    private final Setting<Boolean> notify;
    private int timer;
    private PlayerEntity target;
    private FindItemResult fr;

    public AutoStop() {
        super(DeltaHack.Combat, "auto-stop", "Places blocks in front of the enemy to make them shit their pants.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgTarget = this.settings.createGroup("Targeting");
        this.actionRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("action-range")).description("The radius in which blocks get targeted.")).defaultValue(4.5D).min(0.0D).sliderMax(6.0D).build());
        this.blocks = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for surrounding.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.noResourcesDisable = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("no-resources-disable")).description("disabling when no blocks.")).defaultValue(true)).build());
        this.mode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("XZ-select-mode")).description("How to select the XZ coordinates of the block.")).defaultValue(AutoStop.PositionMode.VelocityVector)).build());
        this.delay = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("delay between block placement.")).defaultValue(1)).min(0).sliderMax(4).build());
        this.predict = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("predict-ticks")).description("don't touch this unless you know what you're doing.")).visible(() -> {
            return this.mode.get() == AutoStop.PositionMode.VelocityVector;
        })).defaultValue(13)).sliderRange(10, 20).range(0, 90).build());
        this.yMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("Y-select-mode")).description("How to select the Y coordinate of the block (Obsolete will become smart mode... someday)")).defaultValue(AutoStop.YMode.AgainstFace)).build());
        this.preventJump = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("prevent-jumping")).description("tries to prevent the target from jumping.")).defaultValue(true)).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates to the blocks you place server side.")).defaultValue(true)).build());
        this.swing = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when placing the blocks.")).defaultValue(true)).build());
        this.enemyRange = this.sgTarget.add(((Builder)((Builder)(new Builder()).name("enemy-range")).description("The radius in which entities get targeted.")).defaultValue(4.0D).min(0.0D).sliderMax(7.0D).build());
        this.noTargetDisable = this.sgTarget.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("no-targets-disable")).description("disabling when no target.")).defaultValue(false)).build());
        this.entities = this.sgTarget.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("entities")).description("Entities to stop.")).defaultValue(new Object2BooleanOpenHashMap(0))).onlyAttackable().build());
        this.tarPrio = this.sgTarget.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.ClosestAngle)).build());
        this.notify = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("Debug mode.")).defaultValue(false)).build());
    }

    public String getInfoString() {
        if (this.fr == null) {
            return "...";
        } else {
            return this.mc.player == null ? "..." : (this.fr.found() ? (this.target != null ? this.target.getEntityName() : "Awaiting for target...") : "Block not found!");
        }
    }

    @EventHandler
    public void onTick(Pre event) {
        if (this.timer < (Integer)this.delay.get()) {
            ++this.timer;
        } else {
            this.timer = 0;
            this.fr = InvUtils.findInHotbar((itemStack) -> {
                return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
            });
            if (!this.fr.found()) {
                if ((Boolean)this.noResourcesDisable.get()) {
                    this.toggle();
                }

            } else {
                List<Entity> targets = new ArrayList();
                TargetUtils.getList(targets, this::entityCheck, (SortPriority)this.tarPrio.get(), 1);
                if (targets.isEmpty()) {
                    if ((Boolean)this.noTargetDisable.get()) {
                        this.toggle();
                    }

                    this.target = null;
                } else {
                    Iterator var3 = targets.iterator();

                    while(true) {
                        while(var3.hasNext()) {
                            Entity entity = (Entity)var3.next();
                            Vec3d vel = new Vec3d(entity.getX() - entity.prevX, entity.getY() - entity.prevY, entity.getZ() - entity.prevZ);
                            PlayerEntity tar = (PlayerEntity)entity;
                            if ((Boolean)this.notify.get()) {
                                this.info(entity.getEntityName() + "'s velocity: " + vel, new Object[0]);
                            }

                            BlockPos a = null;
                            if ((Boolean)this.preventJump.get() && vel.getY() > 0.0D && !entity.isOnGround()) {
                                a = EntityUtil.playerPos(tar).up(2);
                            } else {
                                switch((AutoStop.PositionMode)this.mode.get()) {
                                    case EnemyFacing:
                                        a = EntityUtil.playerPos(tar).offset(entity.getHorizontalFacing(), (int)Math.round(Math.sqrt(vel.x * vel.x + vel.z * vel.z)) + 1);
                                        break;
                                    case VelocityVector:
                                        a = new BlockPos(Vec3dInfo.xzAdd(entity.getPos(), vel, (Integer)this.predict.get()));
                                }

                                if (this.yMode.get() == AutoStop.YMode.AgainstFace) {
                                    a = a.up();
                                }
                            }

                            if (BlockUtil.canPlace(a, true) && !(PlayerUtil.distanceFromEye(a) > (Double)this.actionRange.get())) {
                                this.target = tar;
                                if (WorldUtils.place(a, this.fr, (Boolean)this.rotate.get(), 80, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), false, true) && (Boolean)this.notify.get()) {
                                    this.info("placed at " + a, new Object[0]);
                                }
                            } else if ((Boolean)this.notify.get()) {
                                this.info("failed to place at " + a, new Object[0]);
                            }
                        }

                        return;
                    }
                }
            }
        }
    }

    private boolean entityCheck(Entity entity) {
        if (!entity.equals(this.mc.player) && !entity.equals(this.mc.cameraEntity)) {
            if ((!(entity instanceof LivingEntity) || !((LivingEntity)entity).isDead()) && entity.isAlive()) {
                if (PlayerUtil.distanceFromEye(entity) > (Double)this.enemyRange.get()) {
                    return false;
                } else if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType())) {
                    return false;
                } else if (entity instanceof PlayerEntity) {
                    return ((PlayerEntity)entity).isCreative() ? false : Friends.get().shouldAttack((PlayerEntity)entity);
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean blockFilter(Block block) {
        return block.getHardness() > 1.0F;
    }

    public static enum PositionMode {
        EnemyFacing,
        VelocityVector;

        // $FF: synthetic method
        private static AutoStop.PositionMode[] $values() {
            return new AutoStop.PositionMode[]{EnemyFacing, VelocityVector};
        }
    }

    public static enum YMode {
        AgainstFeet,
        AgainstFace,
        Obsolete;

        // $FF: synthetic method
        private static AutoStop.YMode[] $values() {
            return new AutoStop.YMode[]{AgainstFeet, AgainstFace, Obsolete};
        }
    }
}
