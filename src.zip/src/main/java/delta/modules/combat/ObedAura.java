package delta.modules.combat;

import com.google.common.util.concurrent.AtomicDouble;
import delta.DeltaHack;
import delta.util.BedUtils;
import delta.util.EntityInfo;
import delta.util.Task;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.Vec3dInfo;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BedItem;
import net.minecraft.item.Items;
import net.minecraft.block.BedBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.hit.BlockHitResult;

public class ObedAura extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgPredict;
    private final SettingGroup sgPVP;
    private final SettingGroup sgTrapBreaker;
    private final SettingGroup sgBurrowBreaker;
    private final SettingGroup sgStringBreaker;
    private final SettingGroup sgOther;
    private final SettingGroup sgBedRefill;
    private final SettingGroup sgRender;
    public final Setting<Integer> placeDelay;
    public final Setting<Double> placeRange;
    public final Setting<Double> minTargetDamage;
    public final Setting<Boolean> ignoreTerrain;
    public final Setting<Boolean> debug;
    public final Setting<Boolean> predict;
    public final Setting<Integer> predictIncrease;
    public final Setting<Boolean> predictCollision;
    private final Setting<Boolean> lay;
    private final Setting<Keybind> forceLay;
    public final Setting<Integer> allowedFails;
    private final Setting<Boolean> zeroTick;
    public final Setting<Boolean> tBreakerMain;
    private final Setting<ObedAura.MineMode> tBreakerMode;
    private final Setting<Boolean> tBreakerSwap;
    private final Setting<Boolean> tBreakerOnlySur;
    private final Setting<Boolean> tBreakerGround;
    public final Setting<Boolean> bBreakerMain;
    private final Setting<ObedAura.MineMode> bBreakerMode;
    private final Setting<Boolean> bBreakerSwap;
    private final Setting<Boolean> bBreakerOnlySur;
    private final Setting<Boolean> bBreakerGround;
    public final Setting<Boolean> sBreakerMain;
    private final Setting<ObedAura.MineMode> sBreakerMode;
    private final Setting<Boolean> sBreakerOnlySur;
    private final Setting<Boolean> sBreakerGround;
    private final Setting<Boolean> pauseOnUse;
    private final Setting<Boolean> hurtTime;
    private final Setting<Boolean> bedRefill;
    private final Setting<Integer> bedSlot;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    public static ExecutorService cached = Executors.newCachedThreadPool();
    AtomicDouble bestDamage;
    private BlockPos finalPos;
    int placeTicks;
    int countTicks;
    int failTimes;
    private CardinalDirection placeDirection;
    double offsetTargetDamage;
    boolean smartLay;
    BlockPos prevBreakPos;
    Boolean Boolean;
    private final Task breakTask;
    private final Task infoTask;
    private final Task stageTask;
    private final Task secondStageTask;
    private final List<BlockPos> strings;
    private final Pool<BedUtils.RenderText> renderTextPool;
    private final List<BedUtils.RenderText> renderTexts;
    private final Pool<BedUtils.RenderBlock> renderBlockPool;
    private final List<BedUtils.RenderBlock> renderBlocks;
    private final Pool<BedUtils.RenderBreak> renderBreakPool;
    private final List<BedUtils.RenderBreak> renderBreaks;

    public ObedAura() {
        super(DeltaHack.Autist, "obed-aura", "LMAO");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgPredict = this.settings.createGroup("Predict");
        this.sgPVP = this.settings.createGroup("PVP");
        this.sgTrapBreaker = this.settings.createGroup("Trap Breaker");
        this.sgBurrowBreaker = this.settings.createGroup("Burrow Breaker");
        this.sgStringBreaker = this.settings.createGroup("String Breaker");
        this.sgOther = this.settings.createGroup("Other");
        this.sgBedRefill = this.settings.createGroup("Bed Re-fill");
        this.sgRender = this.settings.createGroup("Render");
        this.placeDelay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("place-delay")).description("The delay between placing beds in ticks.")).defaultValue(10)).sliderRange(0, 20).build());
        this.placeRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("place-range")).description("The range at which beds can be placed.")).defaultValue(4.5D).sliderRange(1.0D, 7.0D).build());
        this.minTargetDamage = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-damage")).description("The minimum damage to inflict on your target.")).defaultValue(7.0D).range(0.0D, 36.0D).sliderMax(36.0D).build());
        this.ignoreTerrain = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-terrain")).description("Completely ignores terrain if it can be blown up by beds.")).defaultValue(true)).build());
        this.debug = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("debug")).description("Sends info in chat about calculation.")).defaultValue(false)).build());
        this.predict = this.sgPredict.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("predict-position")).description("Predicts target position.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgPredict;
        Builder var10002 = ((Builder)((Builder)((Builder)(new Builder()).name("predict-increase")).description("Increasing range from predicted position to target.")).defaultValue(2)).sliderRange(1, 4).min(1).max(4);
        Setting var10003 = this.predict;
        Objects.requireNonNull(var10003);
        this.predictIncrease = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgPredict;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("predict-collision")).description("Whether to consider collision when predicting.")).defaultValue(true);
        var10003 = this.predict;
        Objects.requireNonNull(var10003);
        this.predictCollision = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.lay = this.sgPVP.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-lay")).defaultValue(false)).build());
        this.forceLay = this.sgPVP.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("force-lay")).description("AutoLay starts work if the keybind is pressed. Useful agains player with bed instamine.")).defaultValue(Keybind.none())).build());
        var10001 = this.sgPVP;
        var10002 = ((Builder)((Builder)((Builder)(new Builder()).name("fail-times")).description("How much AutoLay fails can be dealt with.")).defaultValue(2)).sliderRange(0, 10).min(0).max(10);
        var10003 = this.lay;
        Objects.requireNonNull(var10003);
        this.allowedFails = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.zeroTick = this.sgPVP.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("zero-tick")).description("Tries to zero tick your target faster.")).defaultValue(true)).build());
        this.tBreakerMain = this.sgTrapBreaker.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("trap-breaker")).description("Breaks targets self trap and prevent re-trapping.")).defaultValue(false)).build());
        var10001 = this.sgTrapBreaker;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mine-method")).defaultValue(ObedAura.MineMode.Client);
        var10003 = this.tBreakerMain;
        Objects.requireNonNull(var10003);
        this.tBreakerMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgTrapBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-swap")).description("Automatically switches to pickaxe slot.")).defaultValue(true);
        var10003 = this.tBreakerMain;
        Objects.requireNonNull(var10003);
        this.tBreakerSwap = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgTrapBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("surround-only")).description("Works only while player is surrounded.")).defaultValue(true);
        var10003 = this.tBreakerMain;
        Objects.requireNonNull(var10003);
        this.tBreakerOnlySur = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgTrapBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only while player is standing on ground.")).defaultValue(true);
        var10003 = this.tBreakerMain;
        Objects.requireNonNull(var10003);
        this.tBreakerGround = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.bBreakerMain = this.sgBurrowBreaker.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("burrow-breaker")).description("Breaks targets burrow and prevent re-burrowing.")).defaultValue(false)).build());
        var10001 = this.sgBurrowBreaker;
        var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mine-method")).defaultValue(ObedAura.MineMode.Client);
        var10003 = this.bBreakerMain;
        Objects.requireNonNull(var10003);
        this.bBreakerMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgBurrowBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-swap")).description("Automatically switches to pickaxe slot.")).defaultValue(true);
        var10003 = this.bBreakerMain;
        Objects.requireNonNull(var10003);
        this.bBreakerSwap = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgBurrowBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("surround-only")).description("Works only while player is surrounded.")).defaultValue(true);
        var10003 = this.bBreakerMain;
        Objects.requireNonNull(var10003);
        this.bBreakerOnlySur = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgBurrowBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only while player is standing on ground.")).defaultValue(true);
        var10003 = this.bBreakerMain;
        Objects.requireNonNull(var10003);
        this.bBreakerGround = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.sBreakerMain = this.sgStringBreaker.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("string-breaker")).description("Breaks strings around target.")).defaultValue(false)).build());
        var10001 = this.sgStringBreaker;
        var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mine-method")).defaultValue(ObedAura.MineMode.Packet);
        var10003 = this.sBreakerMain;
        Objects.requireNonNull(var10003);
        this.sBreakerMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgStringBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("surround-only")).description("Works only while player is surrounded.")).defaultValue(true);
        var10003 = this.sBreakerMain;
        Objects.requireNonNull(var10003);
        this.sBreakerOnlySur = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgStringBreaker;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only while player is standing on ground.")).defaultValue(true);
        var10003 = this.sBreakerMain;
        Objects.requireNonNull(var10003);
        this.sBreakerGround = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.pauseOnUse = this.sgOther.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-use")).description("Pauses while using items.")).defaultValue(true)).build());
        this.hurtTime = this.sgOther.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("hurt-time")).description("Place only while target can recieve damage. Not recommended to use this.")).defaultValue(false)).build());
        this.bedRefill = this.sgBedRefill.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("bed-refill")).description("Moves beds into a selected hotbar slot.")).defaultValue(true)).build());
        var10001 = this.sgBedRefill;
        var10002 = ((Builder)((Builder)((Builder)(new Builder()).name("bed-slot")).description("The slot auto move moves beds to.")).defaultValue(7)).min(1).max(9).sliderMin(1).sliderMax(9);
        var10003 = this.bedRefill;
        Objects.requireNonNull(var10003);
        this.bedSlot = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders the block where it is placing a bed.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color for positions to be placed.")).defaultValue(new SettingColor(255, 0, 170, 10))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color for positions to be placed.")).defaultValue(new SettingColor(255, 0, 170, 90))).build());
        this.bestDamage = new AtomicDouble(0.0D);
        this.finalPos = null;
        this.breakTask = new Task();
        this.infoTask = new Task();
        this.stageTask = new Task();
        this.secondStageTask = new Task();
        this.strings = new ArrayList();
        this.renderTextPool = new Pool(BedUtils.RenderText::new);
        this.renderTexts = new ArrayList();
        this.renderBlockPool = new Pool(BedUtils.RenderBlock::new);
        this.renderBlocks = new ArrayList();
        this.renderBreakPool = new Pool(BedUtils.RenderBreak::new);
        this.renderBreaks = new ArrayList();
    }

    public void onActivate() {
        this.infoTask.reset();
        this.breakTask.reset();
        this.stageTask.reset();
        this.secondStageTask.reset();
        this.failTimes = -1;
        this.finalPos = null;
        this.placeDirection = null;
        this.smartLay = true;
        this.countTicks = (Integer)this.placeDelay.get();
        this.placeTicks = 0;
        this.bestDamage.set(0.0D);
        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderBlock renderBlock = (BedUtils.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        var1 = this.renderBreaks.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderBreak renderBreak = (BedUtils.RenderBreak)var1.next();
            this.renderBreakPool.free(renderBreak);
        }

        this.renderBreaks.clear();
        var1 = this.renderTexts.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderText renderText = (BedUtils.RenderText)var1.next();
            this.renderTextPool.free(renderText);
        }

        this.renderTexts.clear();
    }

    public void onDeactivate() {
        this.bestDamage.set(0.0D);
        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderBlock renderBlock = (BedUtils.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        var1 = this.renderBreaks.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderBreak renderBreak = (BedUtils.RenderBreak)var1.next();
            this.renderBreakPool.free(renderBreak);
        }

        this.renderBreaks.clear();
        var1 = this.renderTexts.iterator();

        while(var1.hasNext()) {
            BedUtils.RenderText renderText = (BedUtils.RenderText)var1.next();
            this.renderTextPool.free(renderText);
        }

        this.renderTexts.clear();
    }

    @EventHandler(
        priority = 1200
    )
    private void onTick(Pre event) {
        if (this.mc.world.getDimension().comp_648()) {
            this.toggle();
        }

        this.countTicks = (Integer)this.placeDelay.get();
        --this.placeTicks;
        this.renderBlocks.forEach(BedUtils.RenderBlock::tick);
        this.renderBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        this.renderBreaks.forEach(BedUtils.RenderBreak::tick);
        this.renderBreaks.removeIf((renderBreak) -> {
            return renderBreak.ticks <= 0;
        });
        this.renderTexts.forEach(BedUtils.RenderText::tick);
        this.renderTexts.removeIf((renderText) -> {
            return renderText.ticks <= 0;
        });
        if (!(Boolean)this.pauseOnUse.get() || !this.mc.player.isUsingItem()) {
            int i;
            if (((Boolean)this.lay.get() || ((Keybind)this.forceLay.get()).isPressed()) && EntityInfo.isSurrounded(this.mc.player) && EntityInfo.isNotFaceTrapped(this.mc.player)) {
                this.calculateHolePos();
                if (this.placeDirection != null && this.finalPos != null) {
                    i = (Integer)this.placeDelay.get() <= 9 ? 0 : (Integer)this.placeDelay.get() / 2;
                    if (this.failTimes >= (Integer)this.allowedFails.get() || this.smartLay) {
                        i = 0;
                    }

                    this.countTicks = (Integer)this.placeDelay.get() - i;
                    if (this.placeTicks <= 0) {
                        this.bedRefill();
                        this.doHolePlace();
                        this.placeTicks = this.countTicks;
                    }
                }

            } else {
                if (EntityInfo.isNotFaceTrapped(this.mc.player)) {
                    this.smartLay = true;
                    this.failTimes = -1;
                }

                boolean sHurt = this.mc.player.hurtTime == 0 || !(Boolean)this.hurtTime.get();
                if (EntityUtils.getTotalHealth(this.mc.player) <= 11.0F && (Boolean)this.zeroTick.get() && !EntityInfo.isSurrounded(this.mc.player)) {
                    i = (Integer)this.placeDelay.get() <= 9 ? 0 : (Integer)this.placeDelay.get() / 2;
                    this.countTicks = (Integer)this.placeDelay.get() - i;
                    sHurt = true;
                }

                cached.execute(this::calculatePos);
                if (this.placeTicks <= 0 && sHurt) {
                    if (this.finalPos == null || this.placeDirection == null) {
                        return;
                    }

                    this.bedRefill();
                    this.doPlace();
                    this.placeTicks = this.countTicks;
                }

            }
        }
    }

    @EventHandler
    private void onPreSlowTick(Pre event) {
        BlockPos trapBp;
        if ((Boolean)this.bBreakerMain.get() && (!(Boolean)this.bBreakerGround.get() || this.mc.player.isOnGround()) && (!(Boolean)this.bBreakerOnlySur.get() || EntityInfo.isSurrounded(this.mc.player)) && BedUtils.shouldBurrowBreak(this.mc.player)) {
            trapBp = this.mc.player.getBlockPos();
            this.infoTask.run(() -> {
                this.renderBreaks.add(((BedUtils.RenderBreak)this.renderBreakPool.get()).set(trapBp));
            });
            switch((ObedAura.MineMode)this.bBreakerMode.get()) {
                case Packet:
                    BedUtils.packetMine(trapBp, (Boolean)this.bBreakerSwap.get(), this.breakTask);
                    break;
                case Client:
                    BedUtils.normalMine(trapBp, (Boolean)this.bBreakerSwap.get());
            }

        } else {
            this.stageTask.run(() -> {
                this.infoTask.reset();
                this.breakTask.reset();
            });
            if ((Boolean)this.tBreakerMain.get() && (!(Boolean)this.tBreakerGround.get() || this.mc.player.isOnGround()) && (!(Boolean)this.tBreakerOnlySur.get() || EntityInfo.isSurrounded(this.mc.player)) && BedUtils.shouldTrapBreak(this.mc.player)) {
                trapBp = BedUtils.getTrapBlock(this.mc.player, 4.5D);
                this.infoTask.run(() -> {
                    this.renderBreaks.add(((BedUtils.RenderBreak)this.renderBreakPool.get()).set(trapBp));
                });
                switch((ObedAura.MineMode)this.tBreakerMode.get()) {
                    case Packet:
                        BedUtils.packetMine(trapBp, (Boolean)this.tBreakerSwap.get(), this.breakTask);
                        break;
                    case Client:
                        BedUtils.normalMine(trapBp, (Boolean)this.tBreakerSwap.get());
                }

            } else {
                this.secondStageTask.run(() -> {
                    this.infoTask.reset();
                    this.breakTask.reset();
                });
                if ((Boolean)this.sBreakerMain.get() && (!(Boolean)this.sBreakerGround.get() || this.mc.player.isOnGround()) && (!(Boolean)this.sBreakerOnlySur.get() || EntityInfo.isSurrounded(this.mc.player)) && BedUtils.shouldStringBreak(this.mc.player)) {
                    this.strings.clear();
                    CardinalDirection[] var2 = CardinalDirection.values();
                    int var3 = var2.length;

                    for(int var4 = 0; var4 < var3; ++var4) {
                        CardinalDirection d = var2[var4];
                        BlockPos cPos = this.mc.player.getBlockPos().up();
                        if (this.mc.world.getBlockState(cPos).getBlock().asItem().equals(Items.STRING) && this.mc.player.getPos().distanceTo(BlockUtil.getCenterVec3d(cPos)) < 4.5D) {
                            this.strings.add(cPos);
                        }

                        if (this.mc.world.getBlockState(cPos.offset(d.toDirection())).getBlock().asItem().equals(Items.STRING) && this.mc.player.getPos().distanceTo(BlockUtil.getCenterVec3d(cPos.offset(d.toDirection()))) < 4.5D) {
                            this.strings.add(cPos.offset(d.toDirection()));
                        }
                    }

                    if (!this.strings.isEmpty()) {
                        this.infoTask.run(() -> {
                        });
                        Iterator var7 = this.strings.iterator();

                        while(var7.hasNext()) {
                            BlockPos p = (BlockPos)var7.next();
                            this.renderTexts.add(((BedUtils.RenderText)this.renderTextPool.get()).set(p, "String"));
                            if (this.sBreakerMode.get() == ObedAura.MineMode.Packet) {
                                BedUtils.packetMine(p, false, this.breakTask);
                            } else {
                                BedUtils.normalMine(p, false);
                            }
                        }
                    }
                }

                this.secondStageTask.reset();
                this.stageTask.reset();
                this.infoTask.reset();
                this.breakTask.reset();
            }
        }
    }

    @EventHandler
    public void onBreakPacket(Receive event) {
        if ((Boolean)this.lay.get() && this.mc.world != null && this.mc.player != null && this.finalPos != null && this.placeDirection != null) {
            Packet var3 = event.packet;
            if (var3 instanceof BlockBreakingProgressS2CPacket) {
                BlockBreakingProgressS2CPacket packet = (BlockBreakingProgressS2CPacket)var3;
                BlockPos packetBp = packet.getPos();
                if (packetBp.equals(this.prevBreakPos) && packet.getProgress() > 0) {
                    return;
                }

                this.Boolean = BlockUtil.getBlock(packetBp) instanceof BedBlock;
                if (this.Boolean && packetBp.equals(this.finalPos)) {
                    this.smartLay = false;
                } else if (this.Boolean && packetBp.equals(this.finalPos.offset(this.placeDirection.toDirection()))) {
                    this.smartLay = false;
                }

                this.prevBreakPos = packetBp;
            }

        }
    }

    @EventHandler
    private void onRender3d(Render3DEvent event) {
        if ((Boolean)this.render.get()) {
            this.renderBlocks.sort(Comparator.comparingInt((o) -> {
                return -o.ticks;
            }));
            this.renderBlocks.forEach((renderBlock) -> {
                renderBlock.render(event, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get());
            });
            this.renderBreaks.sort(Comparator.comparingInt((o) -> {
                return -o.ticks;
            }));
            this.renderBreaks.forEach((renderBreak) -> {
                renderBreak.render(event, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get());
            });
        }
    }

    @EventHandler
    private void onRender2d(Render2DEvent event) {
        if ((Boolean)this.render.get()) {
            this.renderTexts.sort(Comparator.comparingInt((o) -> {
                return -o.ticks;
            }));
            this.renderTexts.forEach((renderText) -> {
                renderText.render(event, (Color)this.sideColor.get());
            });
        }
    }

    private void bedRefill() {
        if ((Boolean)this.bedRefill.get()) {
            FindItemResult bedItem = InvUtils.find((itemStack) -> {
                return itemStack.getItem() instanceof BedItem;
            });
            if (bedItem.found() && bedItem.slot() != (Integer)this.bedSlot.get() - 1) {
                InvUtils.move().from(bedItem.slot()).toHotbar((Integer)this.bedSlot.get() - 1);
                this.mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket((Integer)this.bedSlot.get() - 1));
            }
        }

    }

    private void doPlace() {
        FindItemResult bedItem = InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof BedItem;
        });

        assert bedItem.isHotbar();

        BlockHitResult placeResult = new BlockHitResult(Vec3dInfo.closestVec3d(this.finalPos), Direction.UP, this.finalPos, false);
        BlockHitResult breakResult = new BlockHitResult(Vec3dInfo.closestVec3d(this.finalPos), Direction.UP, this.finalPos, false);
        double var10000;
        switch(this.placeDirection) {
            case North:
                var10000 = 180.0D;
                break;
            case East:
                var10000 = -90.0D;
                break;
            case West:
                var10000 = 90.0D;
                break;
            case South:
                var10000 = 0.0D;
                break;
            default:
                throw new IncompatibleClassChangeError();
        }

        double y = var10000;
        double p = Rotations.getPitch(Vec3dInfo.closestVec3d(this.finalPos));
        Rotations.rotate(y, p, 1000000, () -> {
            int prevSlot = this.mc.player.getInventory().selectedSlot;
            InvUtils.swap(bedItem.slot(), false);
            this.mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, placeResult, 0));
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.OFF_HAND, breakResult);
            this.mc.player.getInventory().selectedSlot = prevSlot;
            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.OFF_HAND));
            this.renderBlocks.add(((BedUtils.RenderBlock)this.renderBlockPool.get()).set(this.finalPos, this.placeDirection));
            this.bestDamage.set(0.0D);
            this.finalPos = null;
            this.placeDirection = null;
        });
    }

    private void doHolePlace() {
        FindItemResult bedItem = InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof BedItem;
        });
        if (this.finalPos != null && bedItem.isHotbar()) {
            if (!(this.mc.world.getBlockState(this.finalPos).getBlock() instanceof BedBlock)) {
                ++this.failTimes;
            }

            BlockHitResult placeResult = new BlockHitResult(Vec3dInfo.closestVec3d(this.finalPos), Direction.UP, this.finalPos, false);
            BlockHitResult breakResult = new BlockHitResult(Vec3dInfo.closestVec3d(this.finalPos), Direction.UP, this.finalPos, false);
            double var10000;
            switch(this.placeDirection) {
                case North:
                    var10000 = 180.0D;
                    break;
                case East:
                    var10000 = -90.0D;
                    break;
                case West:
                    var10000 = 90.0D;
                    break;
                case South:
                    var10000 = 0.0D;
                    break;
                default:
                    throw new IncompatibleClassChangeError();
            }

            double y = var10000;
            double p = Rotations.getPitch(Vec3dInfo.closestVec3d(this.finalPos));
            Rotations.rotate(y, p, () -> {
                int prevSlot = this.mc.player.getInventory().selectedSlot;
                InvUtils.swap(bedItem.slot(), false);
                if (this.failTimes >= (Integer)this.allowedFails.get()) {
                    this.mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, placeResult, 0));
                    this.mc.interactionManager.interactBlock(this.mc.player, Hand.OFF_HAND, breakResult);
                } else {
                    this.mc.interactionManager.interactBlock(this.mc.player, Hand.OFF_HAND, breakResult);
                    this.mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, placeResult, 0));
                }

                this.mc.player.getInventory().selectedSlot = prevSlot;
                this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.OFF_HAND));
                this.renderBlocks.add(((BedUtils.RenderBlock)this.renderBlockPool.get()).set(this.finalPos, this.placeDirection));
                this.bestDamage.set(0.0D);
                this.finalPos = null;
                this.placeDirection = null;
            });
        }
    }

    private void calculateHolePos() {
        long startTime = System.currentTimeMillis();
        if ((Boolean)this.debug.get()) {
            this.info("thread started", new Object[0]);
        }

        BlockPos p = EntityUtil.playerPos(this.mc.player).up();
        double targetDMG = BedUtils.getDamage(this.mc.player, BlockUtil.getCenterVec3d(p), false, false, 0, true);
        if (BedUtils.canBed(p.north(), p) && BlockUtil.isWithinRange(p.north(), (Double)this.placeRange.get()) && targetDMG > (Double)this.minTargetDamage.get()) {
            this.finalPos = p.north();
            this.placeDirection = CardinalDirection.South;
        } else if (BedUtils.canBed(p.south(), p) && BlockUtil.isWithinRange(p.south(), (Double)this.placeRange.get()) && targetDMG > (Double)this.minTargetDamage.get()) {
            this.finalPos = p.south();
            this.placeDirection = CardinalDirection.North;
        } else if (BedUtils.canBed(p.east(), p) && BlockUtil.isWithinRange(p.east(), (Double)this.placeRange.get()) && targetDMG > (Double)this.minTargetDamage.get()) {
            this.finalPos = p.east();
            this.placeDirection = CardinalDirection.West;
        } else if (BedUtils.canBed(p.west(), p) && BlockUtil.isWithinRange(p.west(), (Double)this.placeRange.get()) && targetDMG > (Double)this.minTargetDamage.get()) {
            this.finalPos = p.west();
            this.placeDirection = CardinalDirection.East;
        }

        if ((Boolean)this.debug.get()) {
            this.info("thread shutdown in " + (System.currentTimeMillis() - startTime) + "ms", new Object[0]);
        }

    }

    private void calculatePos() {
        long startTime = System.currentTimeMillis();
        int radius = 2;
        ArrayList<BlockPos> sphere = new ArrayList(BedUtils.getTargetSphere(this.mc.player, radius, 3));
        CardinalDirection localDirection = null;
        BlockPos localPos = null;

        try {
            Iterator var7 = sphere.iterator();

            label58:
            while(true) {
                BlockPos p;
                do {
                    do {
                        do {
                            if (!var7.hasNext()) {
                                break label58;
                            }

                            p = (BlockPos)var7.next();
                            this.offsetTargetDamage = 0.0D;
                        } while(this.intersectsWithEntities(p));
                    } while(!Vec3dInfo.isWithinRange(BlockUtil.closestVec3d(p), (Double)this.placeRange.get()));
                } while(!this.mc.world.getBlockState(p).getMaterial().isReplaceable());

                CardinalDirection[] var9 = CardinalDirection.values();
                int var10 = var9.length;

                for(int var11 = 0; var11 < var10; ++var11) {
                    CardinalDirection d = var9[var11];
                    double targetDMG = BedUtils.getDamage(this.mc.player, BlockUtil.getCenterVec3d(p.offset(d.toDirection())), (Boolean)this.predict.get(), (Boolean)this.predictCollision.get(), (Integer)this.predictIncrease.get(), (Boolean)this.ignoreTerrain.get());
                    if (BedUtils.canBed(p, p.offset(d.toDirection())) && !(targetDMG < (Double)this.minTargetDamage.get())) {
                        this.offsetTargetDamage = targetDMG;
                        if (this.offsetTargetDamage > this.bestDamage.get()) {
                            this.bestDamage.set(this.offsetTargetDamage);
                            localDirection = d;
                            localPos = p.toImmutable();
                        }
                    }
                }
            }
        } catch (Exception var15) {
            var15.fillInStackTrace();
        }

        if (localPos != null) {
            this.finalPos = localPos;
            this.placeDirection = localDirection;
            if ((Boolean)this.debug.get()) {
                this.info("thread shutdown in " + (System.currentTimeMillis() - startTime) + "ms", new Object[0]);
            }

        }
    }

    private boolean intersectsWithEntities(BlockPos blockPos) {
        Box box = new Box((double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), (double)(blockPos.getX() + 1), (double)blockPos.getY() + 0.6D, (double)(blockPos.getZ() + 1));
        return EntityUtils.intersectsWithEntity(box, (entity) -> {
            return entity instanceof PlayerEntity || entity instanceof EndCrystalEntity || entity instanceof TntEntity;
        });
    }

    public static enum MineMode {
        Packet,
        Client;

        // $FF: synthetic method
        private static ObedAura.MineMode[] $values() {
            return new ObedAura.MineMode[]{Packet, Client};
        }
    }
}
