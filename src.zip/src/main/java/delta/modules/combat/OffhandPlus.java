package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.DamageUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;

public class OffhandPlus extends Module {
    private final SettingGroup sgDefault;
    public final Setting<OffhandPlus.Mode> mode;
    public final Setting<Boolean> antiDesync;
    private final Setting<Integer> delay;
    public final Setting<OffhandPlus.ChooseItem> item;
    private final SettingGroup sgDamage;
    public final Setting<OffhandPlus.CrystalDamage> damageCalc;
    private final Setting<Integer> crystalDamage;
    private final Setting<Integer> range;
    private final Setting<Integer> minHealth;
    public final Setting<Boolean> fall;
    private final Setting<Integer> fallDistance;
    public final Setting<Boolean> elytra;
    public boolean locked;
    private int ticks;

    public OffhandPlus() {
        super(DeltaHack.Combat, "offhand+", "Refill totems in the offhand slot.");
        this.sgDefault = this.settings.createGroup("Default");
        this.mode = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("mode")).description("Offhand mode")).defaultValue(OffhandPlus.Mode.AutoTotem)).build());
        this.antiDesync = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-desync")).description("Try to prevent inventory desync.")).defaultValue(true)).build());
        this.delay = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("The delay between totem move.")).defaultValue(0)).min(0).sliderMax(1).build());
        this.item = this.sgDefault.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("item")).description("Offhand item")).defaultValue(OffhandPlus.ChooseItem.EGApple)).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
        this.sgDamage = this.settings.createGroup("Damage");
        this.damageCalc = this.sgDamage.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("damage-calc")).description("The method of calculating the damage.")).defaultValue(OffhandPlus.CrystalDamage.Custom)).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
        this.crystalDamage = this.sgDamage.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("crystal-damage")).description("Damage from the crystal.")).defaultValue(10)).min(0).sliderMax(36).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand) && ((OffhandPlus.CrystalDamage)this.damageCalc.get()).equals(OffhandPlus.CrystalDamage.Custom);
        })).build());
        this.range = this.sgDamage.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("range")).description("Range to crystal.")).defaultValue(10)).min(0).sliderMax(36).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
        this.minHealth = this.sgDamage.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("min-health")).description("The minimum health at which the totem will be taken in offhand.")).defaultValue(7)).min(0).sliderMax(36).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
        this.fall = this.sgDamage.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("fall")).description("Take a totem when you fall.")).defaultValue(true)).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
        this.fallDistance = this.sgDamage.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fall-distance")).description("Distance.")).defaultValue(10)).min(0).sliderMax(36).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand) && (Boolean)this.fall.get();
        })).build());
        this.elytra = this.sgDamage.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("elytra")).description("Take a totem when you fly on elytra.")).defaultValue(true)).visible(() -> {
            return ((OffhandPlus.Mode)this.mode.get()).equals(OffhandPlus.Mode.Offhand);
        })).build());
    }

    @EventHandler(
        priority = 200
    )
    private void onTick(Pre event) {
        this.doIt();
    }

    @EventHandler(
        priority = 200
    )
    private void onTick(Post event) {
        this.doIt();
    }

    private void doIt() {
        if ((Boolean)this.antiDesync.get()) {
            this.mc.player.getInventory().updateItems();
        }

        switch((OffhandPlus.Mode)this.mode.get()) {
            case AutoTotem:
                this.doItemMove(Items.TOTEM_OF_UNDYING);
                break;
            case Offhand:
                if (this.isThereDangerousCrystal()) {
                    this.doItemMove(Items.TOTEM_OF_UNDYING);
                }

                if (this.isThereDangerousBlock()) {
                    this.doItemMove(Items.TOTEM_OF_UNDYING);
                } else if (this.mc.player.getHealth() <= (float)(Integer)this.minHealth.get()) {
                    this.doItemMove(Items.TOTEM_OF_UNDYING);
                } else if (!this.mc.player.isOnGround() && this.mc.player.fallDistance >= (float)(Integer)this.fallDistance.get() && (Boolean)this.fall.get()) {
                    this.doItemMove(Items.TOTEM_OF_UNDYING);
                } else if (this.mc.player.isFallFlying() && this.mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() instanceof ElytraItem && (Boolean)this.elytra.get()) {
                    this.doItemMove(Items.TOTEM_OF_UNDYING);
                } else {
                    this.doItemMove(((OffhandPlus.ChooseItem)this.item.get()).item);
                }
        }

    }

    private boolean isThereDangerousBlock() {
        AtomicBoolean isBed = new AtomicBoolean(false);
        BlockUtil.getSphere(EntityUtil.playerPos(this.mc.player), (Integer)this.range.get(), (Integer)this.range.get()).stream().filter((blockPos) -> {
            return !this.mc.world.getDimension().comp_648() && BlockUtil.getBlock(blockPos) instanceof BedBlock || !this.mc.world.getDimension().comp_648() && BlockUtil.getBlock(blockPos) == Blocks.RESPAWN_ANCHOR;
        }).forEach((blockPos) -> {
            switch((OffhandPlus.CrystalDamage)this.damageCalc.get()) {
                case Custom:
                    if (DamageUtils.bedDamage(this.mc.player, Utils.vec3d(blockPos)) > (double)(Integer)this.crystalDamage.get()) {
                        isBed.set(true);
                    }
                    break;
                case Lethal:
                    double health = (double)this.mc.player.getHealth();
                    if (DamageUtils.bedDamage(this.mc.player, Utils.vec3d(blockPos)) > health && health - DamageUtils.crystalDamage(this.mc.player, Utils.vec3d(blockPos)) < (double)(Integer)this.minHealth.get()) {
                        isBed.set(true);
                    }
            }

        });
        return isBed.get();
    }

    private boolean isThereDangerousCrystal() {
        ArrayList<EndCrystalEntity> crystals = new ArrayList();
        Iterator var2 = this.mc.world.getEntities().iterator();

        while(var2.hasNext()) {
            Entity entity = (Entity)var2.next();
            if (entity instanceof EndCrystalEntity && this.mc.player.distanceTo(entity) < (float)(Integer)this.range.get()) {
                crystals.add((EndCrystalEntity)entity);
            }
        }

        if (crystals.isEmpty()) {
            return false;
        } else {
            crystals.sort(Comparator.comparing((entityx) -> {
                return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), entityx.getBlockPos());
            }));
            var2 = crystals.iterator();

            while(var2.hasNext()) {
                EndCrystalEntity crystalEntity = (EndCrystalEntity)var2.next();
                switch((OffhandPlus.CrystalDamage)this.damageCalc.get()) {
                    case Custom:
                        if (DamageUtils.crystalDamage(this.mc.player, crystalEntity.getPos()) > (double)(Integer)this.crystalDamage.get()) {
                            return true;
                        }
                        break;
                    case Lethal:
                        double health = (double)this.mc.player.getHealth();
                        if (DamageUtils.crystalDamage(this.mc.player, crystalEntity.getPos()) > health && health - DamageUtils.crystalDamage(this.mc.player, crystalEntity.getPos()) < (double)(Integer)this.minHealth.get()) {
                            return true;
                        }
                }
            }

            return false;
        }
    }

    private void doItemMove(Item item) {
        FindItemResult result = InvUtils.find(new Item[]{item});
        int totems = result.count();
        this.locked = totems > 0;
        if (this.ticks >= (Integer)this.delay.get()) {
            if (this.mc.player.getOffHandStack().getItem() != item) {
                InvUtils.move().from(result.slot()).toOffhand();
            }

            this.ticks = 0;
        } else {
            ++this.ticks;
        }
    }

    public static enum Mode {
        AutoTotem,
        Offhand;

        // $FF: synthetic method
        private static OffhandPlus.Mode[] $values() {
            return new OffhandPlus.Mode[]{AutoTotem, Offhand};
        }
    }

    public static enum ChooseItem {
        Crystal(Items.END_CRYSTAL),
        EGApple(Items.ENCHANTED_GOLDEN_APPLE);

        public Item item;

        private ChooseItem(Item item) {
            this.item = item;
        }

        // $FF: synthetic method
        private static OffhandPlus.ChooseItem[] $values() {
            return new OffhandPlus.ChooseItem[]{Crystal, EGApple};
        }
    }

    public static enum CrystalDamage {
        Lethal,
        Custom;

        // $FF: synthetic method
        private static OffhandPlus.CrystalDamage[] $values() {
            return new OffhandPlus.CrystalDamage[]{Lethal, Custom};
        }
    }
}
