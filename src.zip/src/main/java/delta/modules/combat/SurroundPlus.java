package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.RenderUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ChorusFruitItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;

public class SurroundPlus extends Module {
    private final SettingGroup sgDefault;
    private final SettingGroup sgDisable;
    private final SettingGroup sgSafety;
    private final SettingGroup sgRender;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> center;
    private final Setting<Boolean> anchor;
    private final Setting<Boolean> centerTwo;
    private final Setting<Double> threshold;
    private final Setting<Boolean> ignoreEntities;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> notify;
    private final Setting<WorldUtils.SwitchMode> switchMode;
    private final Setting<WorldUtils.PlaceMode> placeMode;
    private final Setting<Boolean> jumpDisable;
    private final Setting<Boolean> tpDisable;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> nextSideColor;
    private final Setting<SettingColor> nextLineColor;
    private final Setting<Boolean> renderActive;
    private final Setting<SettingColor> cideColor;
    private final Setting<SettingColor> cideColor2;
    private final Setting<SettingColor> clineColor;
    private final Setting<SettingColor> clineColor2;
    private final Setting<Integer> width;
    private final Setting<Boolean> recursiveAntiRetard;
    private final Setting<Boolean> crystalBreaker;
    private final Setting<Boolean> alwaysBreak;
    private final Setting<Integer> breakDelay;
    private final Setting<Integer> ticksExisted;
    private final Setting<Boolean> placeObby;
    private final Setting<Boolean> useAutist;
    private final Setting<Boolean> useRetard;
    private final Setting<Boolean> antiFp;
    private final Setting<Double> antiFpHp;
    private final Setting<Boolean> pauseOnEat;
    private final Setting<Boolean> pauseOnChorus;
    private final Setting<Boolean> pauseOnBreak;
    private final Setting<Boolean> pauseOnDrink;
    private static final List<BlockPos> placePositions = new ArrayList();
    private int placingTimer;
    private int breakingTimer;

    public SurroundPlus() {
        super(DeltaHack.Combat, "surround+", "Surrounds you in blocks to prevent crystal explosions damage.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgDisable = this.settings.createGroup("Disable");
        this.sgSafety = this.settings.createGroup("Delta Safety");
        this.sgRender = this.settings.createGroup("Render");
        this.delay = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Extra delay between block bursts. (0 = every tick)")).defaultValue(1)).sliderRange(0, 5).build());
        this.blocksPerTick = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks-per-tick")).description("Amount of blocks to place in 1 tick.")).defaultValue(1)).min(1).sliderMax(4).build());
        this.center = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center")).description("Centers you when surrounding.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anchor")).description("Anchors you after centering to prevent you from obstructing placements.")).defaultValue(true);
        Setting var10003 = this.center;
        Objects.requireNonNull(var10003);
        this.anchor = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.centerTwo = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center-afterwards")).description("Centers you after surrounding (cycling)")).defaultValue(true)).build());
        this.threshold = this.sgDefault.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("center-threshold")).description("don't touch this unless you know what you're doing.")).defaultValue(0.31D).range(0.0D, 1.0D).sliderRange(0.3D, 0.5D).visible(() -> {
            return (Boolean)this.center.get() || (Boolean)this.centerTwo.get();
        })).build());
        this.ignoreEntities = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-entities")).description("Ignores visible entities/crystals and tries to place on top of it. Useful on high ping.")).defaultValue(true)).build());
        this.onlyOnGround = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Only places blocks when on ground.")).defaultValue(true)).build());
        this.blocks = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for surrounding.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates to the blocks you place server side.")).defaultValue(true)).build());
        this.notify = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("Notify if the anti crystal spotted anything.")).defaultValue(true)).build());
        this.switchMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("switch-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.SwitchMode.Both)).build());
        this.placeMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("place-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.PlaceMode.Both)).build());
        this.jumpDisable = this.sgDisable.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("jump-pause")).description("Pauses surround when your y coordinate increases.")).defaultValue(false)).build());
        this.tpDisable = this.sgDisable.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("tp-disable")).description("Disables surround when you teleport to another location.")).defaultValue(false)).build());
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when placing the blocks.")).defaultValue(false)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders a block overlay where the obsidian will be placed.")).defaultValue(true)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var1 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.shapeMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.ColorSetting.Builder var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 45, true));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.sideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255, true));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.lineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("next-side-color")).description("The side color of the next block to be placed.")).defaultValue(new SettingColor(227, 196, 245, 10));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.nextSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("next-line-color")).description("The line color of the next block to be placed.")).defaultValue(new SettingColor(227, 196, 245));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.nextLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        this.renderActive = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-active-blocks")).description("Renders a nice block overlay on the placed blocks.")).defaultValue(true)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("active-side-gradient-1")).description("The side color.")).defaultValue(new SettingColor(0, 0, 0, 30));
        var10003 = this.renderActive;
        Objects.requireNonNull(var10003);
        this.cideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("active-side-gradient-2")).description("The side color.")).defaultValue(new SettingColor(0, 0, 255, 10, true));
        var10003 = this.renderActive;
        Objects.requireNonNull(var10003);
        this.cideColor2 = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("active-line-gradient-1")).description("The line color.")).defaultValue(new SettingColor(255, 255, 255, 160));
        var10003 = this.renderActive;
        Objects.requireNonNull(var10003);
        this.clineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("active-line-gradient-2")).description("The line color.")).defaultValue(new SettingColor(0, 0, 0, 255));
        var10003 = this.renderActive;
        Objects.requireNonNull(var10003);
        this.clineColor2 = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgRender;
        Builder var3 = ((Builder)((Builder)(new Builder()).name("width")).defaultValue(1)).range(1, 5).sliderRange(1, 4);
        var10003 = this.renderActive;
        Objects.requireNonNull(var10003);
        this.width = var10001.add(((Builder)var3.visible(var10003::get)).build());
        this.recursiveAntiRetard = this.sgSafety.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("recursive-anti-retard-city")).description("Uses a different placing technique when players are at your penis sucking pos.")).defaultValue(true)).build());
        this.crystalBreaker = this.sgSafety.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-crystal")).description("Breaks dangerous crystals automatically.")).defaultValue(true)).build());
        this.alwaysBreak = this.sgSafety.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-always")).description("Breaks dangerous crystals automatically.")).defaultValue(true)).build());
        var10001 = this.sgSafety;
        var3 = ((Builder)((Builder)((Builder)(new Builder()).name("break-delay")).description("Tick delay for crystal breaker.")).defaultValue(1)).min(0).sliderMax(10);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.breakDelay = var10001.add(((Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgSafety;
        var3 = ((Builder)((Builder)((Builder)(new Builder()).name("crystal-age")).description("Amount of ticks a crystal needs to have existed for it to be attacked.")).defaultValue(1)).sliderRange(0, 10).min(0);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.ticksExisted = var10001.add(((Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgSafety;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-obby")).description("Places blocks on crystals.")).defaultValue(true);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.placeObby = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.useAutist = this.sgSafety.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("use-autist")).description("Whether should you place obby on \"knight\" positions")).visible(() -> {
            return (Boolean)this.crystalBreaker.get() && (Boolean)this.placeObby.get();
        })).defaultValue(true)).build());
        this.useRetard = this.sgSafety.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("retarded-diagonal")).description("Whether should you place obby on every fucking position possible and be a retard")).visible(() -> {
            return (Boolean)this.useAutist.get() && (Boolean)this.placeObby.get() && (Boolean)this.crystalBreaker.get();
        })).defaultValue(true)).build());
        var10001 = this.sgSafety;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-face-place")).description("Places blocks on crystals if they are face damaging you.")).defaultValue(true);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.antiFp = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.antiFpHp = this.sgSafety.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("anti-face-place-hp")).description("-")).defaultValue(10.0D).visible(() -> {
            return (Boolean)this.crystalBreaker.get() && (Boolean)this.antiFp.get();
        })).build());
        var10001 = this.sgSafety;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-eat")).description("Pause the work of anti crystal on eating food. (NOT RECOMMENDED TO USE.)")).defaultValue(true);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.pauseOnEat = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.pauseOnChorus = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("hard-pause-on-chorus")).description("Pause the work of surround ENTIRELY when eating chorus.")).defaultValue(false)).build());
        var10001 = this.sgSafety;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-break")).description("Pause the work of anti crystal on breaking block.")).defaultValue(true);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.pauseOnBreak = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSafety;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-drink")).description("Pause the work of anti crystal on drink.")).defaultValue(true);
        var10003 = this.crystalBreaker;
        Objects.requireNonNull(var10003);
        this.pauseOnDrink = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
    }

    public void onActivate() {
        if ((Boolean)this.center.get()) {
            PlayerUtil.centerTwo((Double)this.threshold.get());
        }

        this.placingTimer = 0;
        this.breakingTimer = 0;
    }

    @EventHandler(
        priority = 200
    )
    public void onPreTick(Pre event) {
        if (!(Boolean)this.pauseOnChorus.get() || !this.mc.player.isUsingItem() || !(this.mc.player.getMainHandStack().getItem() instanceof ChorusFruitItem)) {
            if (this.mc.player.prevY < this.mc.player.getY()) {
                if ((Boolean)this.jumpDisable.get()) {
                    return;
                }
            } else if ((Boolean)this.anchor.get()) {
                this.mc.player.setVelocity(0.0D, this.mc.player.getVelocity().getY(), 0.0D);
            }

            if (this.mc.player.isOnGround() || !(Boolean)this.onlyOnGround.get()) {
                int places = 0;
                if (this.placingTimer == 0) {
                    places = (Integer)this.blocksPerTick.get();
                    this.placingTimer = (Integer)this.delay.get();
                    this.addPositions();
                } else {
                    --this.placingTimer;
                }

                Iterator var3 = placePositions.iterator();

                while(var3.hasNext()) {
                    BlockPos pos = (BlockPos)var3.next();
                    if (places != 0 && pos != null) {
                        if ((Boolean)this.centerTwo.get()) {
                            PlayerUtil.centerTwo((Double)this.threshold.get());
                        }

                        if (WorldUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                        }), (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), !(Boolean)this.ignoreEntities.get(), true)) {
                            --places;
                        }
                    }
                }

                if (this.breakingTimer == 0) {
                    this.breakingTimer = (Integer)this.breakDelay.get();
                    if ((Boolean)this.crystalBreaker.get() && (!placePositions.isEmpty() || (Boolean)this.alwaysBreak.get())) {
                        this.antiCrystal();
                    }

                    if ((Boolean)this.crystalBreaker.get() && (Boolean)this.antiFp.get() && (double)this.mc.player.getHealth() <= (Double)this.antiFpHp.get()) {
                        this.antiFacePlace();
                    }
                } else {
                    --this.breakingTimer;
                }

            }
        }
    }

    private void antiCrystal() {
        if (!PlayerUtils.shouldPause((Boolean)this.pauseOnBreak.get(), (Boolean)this.pauseOnEat.get(), (Boolean)this.pauseOnDrink.get())) {
            BlockPos pPos = EntityUtil.playerPos(this.mc.player);
            Entity crystalEntity = null;
            BlockPos crystalPos = null;
            Iterator var4 = this.mc.world.getEntities().iterator();

            while(true) {
                while(true) {
                    Entity entity;
                    do {
                        do {
                            do {
                                if (!var4.hasNext()) {
                                    if (crystalEntity != null) {
                                        if ((Boolean)this.rotate.get()) {
                                            Rotations.rotate(Rotations.getYaw(crystalEntity), (double)this.mc.player.getPitch());
                                        }

                                        CrystalUtils.attackCrystal(crystalEntity, (Boolean)this.swing.get());
                                        if ((Boolean)this.placeObby.get() && CrystalUtils.isPosCrystal(crystalEntity, (Boolean)this.useAutist.get(), (Boolean)this.useRetard.get())) {
                                            crystalPos = crystalEntity.getBlockPos();
                                        }

                                        if ((Boolean)this.notify.get()) {
                                            this.info("Anti-Crystal Detected a crystal!", new Object[0]);
                                        }
                                    }

                                    if (crystalPos != null && (Boolean)this.placeObby.get()) {
                                        FindItemResult obi = InvUtils.findInHotbar((itemStack) -> {
                                            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                                        });
                                        WorldUtils.place(crystalPos, obi, (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), !(Boolean)this.ignoreEntities.get(), true);
                                    }

                                    return;
                                }

                                entity = (Entity)var4.next();
                            } while(entity.age < (Integer)this.ticksExisted.get());
                        } while(!(entity instanceof EndCrystalEntity));
                    } while(!CrystalUtils.doesCrystalInterfere(entity, pPos.west()) && !CrystalUtils.doesCrystalInterfere(entity, pPos.east()) && !CrystalUtils.doesCrystalInterfere(entity, pPos.north()) && !CrystalUtils.doesCrystalInterfere(entity, pPos.south()));

                    crystalEntity = entity;
                    Iterator var6 = this.mc.world.getEntities().iterator();

                    while(var6.hasNext()) {
                        Entity pEntity = (Entity)var6.next();
                        if (pEntity instanceof PlayerEntity && CrystalUtils.isSurrCrystal(crystalEntity, pEntity) && pEntity != this.mc.player) {
                            crystalEntity = null;
                            break;
                        }
                    }
                }
            }
        }
    }

    private void antiFacePlace() {
        Iterator var1 = this.mc.world.getEntities().iterator();

        while(var1.hasNext()) {
            Entity entity = (Entity)var1.next();
            if (entity instanceof EndCrystalEntity && CrystalUtils.isPosFacePlaceCrystal(entity) && !EntityUtil.isFaceSurrounded(this.mc.player, BlockUtil.BlastResistantType.Any)) {
                CrystalUtils.attackCrystal(entity, (Boolean)this.swing.get());
                FindItemResult obi = InvUtils.findInHotbar((itemStack) -> {
                    return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                });
                if (obi.found()) {
                    WorldUtils.place(entity.getBlockPos(), obi, (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), !(Boolean)this.ignoreEntities.get(), true);
                }
            }
        }

    }

    private void addPositions() {
        BlockPos pos = EntityUtil.playerPos(this.mc.player);
        Direction dir = this.mc.player.getHorizontalFacing();
        placePositions.clear();
        if ((double)pos.getY() - this.mc.player.getY() > 0.1D) {
            this.add(pos.down().west(), 0);
            this.add(pos.down().east(), 0);
            this.add(pos.down().north(), 0);
            this.add(pos.down().south(), 0);
        }

        this.add(pos.down(), 0);
        this.add(pos.offset(dir), 0);
        this.add(pos.offset(dir.getOpposite()), 0);
        dir = Direction.fromHorizontal(dir.getHorizontal() + 1);
        this.add(pos.offset(dir), 0);
        this.add(pos.offset(dir.getOpposite()), 0);
    }

    private void add(BlockPos pos, int depth) {
        if (depth <= 2 && !pos.equals(EntityUtil.playerPos(this.mc.player))) {
            if ((Boolean)this.recursiveAntiRetard.get() && EntityUtils.intersectsWithEntity(Box.from(Vec3d.of(pos)), (entity) -> {
                return !entity.isSpectator() && entity instanceof PlayerEntity && (entity != this.mc.player || !(Boolean)this.centerTwo.get());
            })) {
                this.add(pos.east(), depth + 1);
                this.add(pos.west(), depth + 1);
                this.add(pos.north(), depth + 1);
                this.add(pos.south(), depth + 1);
            } else {
                if (BlockUtil.canPlace(pos, !(Boolean)this.ignoreEntities.get()) && !placePositions.contains(pos)) {
                    placePositions.add(pos);
                }

            }
        }
    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() > 600.0F;
    }

    @EventHandler
    private void onSendPacket(Send event) {
        if (event.packet instanceof TeleportConfirmC2SPacket && (Boolean)this.tpDisable.get()) {
            this.toggle();
        }

    }

    @EventHandler(
        priority = 100
    )
    private void onRender(Render3DEvent event) {
        if (this.mc.player != null) {
            if ((Boolean)this.renderActive.get() && placePositions.isEmpty()) {
                Direction[] var2 = Direction.values();
                int var3 = var2.length;

                for(int var4 = 0; var4 < var3; ++var4) {
                    Direction dir = var2[var4];
                    if (dir != Direction.UP) {
                        BlockPos pos = EntityUtil.playerPos(this.mc.player).offset(dir);
                        if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Sides)) {
                            RenderUtil.S(event, pos, 0.99D, 0.0D, 0.01D, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                            RenderUtil.TAB(event, pos, 0.99D, 0.01D, true, true, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                            if ((Integer)this.width.get() == 2) {
                                RenderUtil.S(event, pos, 0.98D, 0.0D, 0.02D, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                                RenderUtil.TAB(event, pos, 0.98D, 0.02D, true, true, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                            }

                            if ((Integer)this.width.get() == 3) {
                                RenderUtil.S(event, pos, 0.97D, 0.0D, 0.03D, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                                RenderUtil.TAB(event, pos, 0.97D, 0.03D, true, true, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                            }

                            if ((Integer)this.width.get() == 4) {
                                RenderUtil.S(event, pos, 0.96D, 0.0D, 0.04D, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                                RenderUtil.TAB(event, pos, 0.96D, 0.04D, true, true, (Color)this.clineColor.get(), (Color)this.clineColor2.get());
                            }
                        }

                        if (!((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Lines)) {
                            RenderUtil.FS(event, pos, 0.0D, true, true, (Color)this.cideColor.get(), (Color)this.cideColor2.get());
                        }
                    }
                }
            }

            if ((Boolean)this.render.get()) {
                Iterator var7 = placePositions.iterator();

                while(var7.hasNext()) {
                    BlockPos pos = (BlockPos)var7.next();
                    if (pos.equals(placePositions.get(placePositions.size() - 1))) {
                        event.renderer.box(pos, (Color)this.nextSideColor.get(), (Color)this.nextLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    } else {
                        event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    }
                }

            }
        }
    }

    public String getInfoString() {
        return String.valueOf(placePositions.size());
    }
}
