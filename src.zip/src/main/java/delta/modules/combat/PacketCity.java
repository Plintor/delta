package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.RenderUtil;
import delta.utils.TimerUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.events.entity.player.BreakBlockEvent;
import meteordevelopment.meteorclient.events.entity.player.PlaceBlockEvent;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class PacketCity extends Module {
    private final SettingGroup sgDefault;
    private final Setting<Double> enemyRange;
    private final Setting<Double> cityRange;
    private final Setting<Boolean> holdPos;
    private final Setting<Boolean> rotate;
    private final SettingGroup sgMining;
    private final Setting<Boolean> instant;
    private final Setting<Boolean> bypass;
    private final Setting<Integer> tickDelay;
    private final Setting<Boolean> openestCity;
    private final Setting<Boolean> breakInterfering;
    private final Setting<Boolean> onIron;
    private final Setting<Boolean> breakBurrow;
    private final Setting<List<Block>> burrowBlocks;
    private final Setting<Boolean> ignoreYourOwnSurround;
    private final Setting<Boolean> ignoreFriendSurround;
    private final Setting<Boolean> ignoreBlocks;
    private final Setting<List<Block>> ignoreBlocksList;
    private final SettingGroup sgSwap;
    private final Setting<Keybind> ironPickaxe;
    public final Setting<Boolean> autoSwap;
    public final Setting<Double> swapDelay;
    private final SettingGroup sgSupport;
    private final Setting<Boolean> support;
    private final Setting<Boolean> crystal;
    private final Setting<Boolean> crystalSupport;
    private final Setting<PacketCity.PlacePriority> placePriority;
    private final Setting<Boolean> nearTheCity;
    private final Setting<Boolean> diagonal;
    private final Setting<Boolean> under;
    private final Setting<Boolean> up;
    private final Setting<PacketCity.PlaceMode> placeMode;
    private final Setting<Double> timer;
    private final Setting<Boolean> breakCrystal;
    private final Setting<Boolean> placeCrystalOnSurPos;
    private final SettingGroup sgToggleAndPause;
    private final Setting<Boolean> selfToggle;
    private final Setting<Boolean> stopPlacingOnEat;
    private final Setting<Boolean> stopPlacingOnDrink;
    private final Setting<Boolean> stopPlacingOnMine;
    private final SettingGroup sgRender;
    private final Setting<Boolean> render;
    private PlayerEntity target;
    private BlockPos holdCityPos;
    private BlockPos holdMinePos;
    private BlockPos crystalPos;
    private final TimerUtils instantTimer;
    private final TimerUtils swapTimer;
    private final TimerUtils packetTimer;
    private static BlockPos minePos;
    private Direction direction;
    private final Mutable blockPos;
    public static ArrayList<BlockPos> surround = new ArrayList<BlockPos>() {
        {
            this.add(new BlockPos(1, 0, 0));
            this.add(new BlockPos(-1, 0, 0));
            this.add(new BlockPos(0, 0, 1));
            this.add(new BlockPos(0, 0, -1));
        }
    };
    public static ArrayList<BlockPos> diagonalArray = new ArrayList<BlockPos>() {
        {
            this.add(new BlockPos(1, 0, 1));
            this.add(new BlockPos(1, 0, -1));
            this.add(new BlockPos(-1, 0, 1));
            this.add(new BlockPos(-1, 0, -1));
        }
    };

    public PacketCity() {
        super(DeltaHack.Combat, "packet-city", "Auto City+ but with packet mode only (useful when you can't be bothered to change Auto City settings)");
        this.sgDefault = this.settings.createGroup("Default");
        this.enemyRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("enemy-range")).description("The radius in which players get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.cityRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("city-range")).description("The radius in which city get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.holdPos = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("hold-city")).description("Hold city pos.")).defaultValue(false)).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Automatically rotates you towards the city block.")).defaultValue(false)).build());
        this.sgMining = this.settings.createGroup("Mining");
        this.instant = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("instant-break")).description("Instant break")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgMining;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("bypass-break")).description("Tries to circumvent the restrictions from the instant mine.")).defaultValue(false);
        Setting var10003 = this.instant;
        Objects.requireNonNull(var10003);
        this.bypass = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgMining;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-delay")).description("The delay between breaks.")).defaultValue(0)).min(0).sliderMax(20);
        var10003 = this.instant;
        Objects.requireNonNull(var10003);
        this.tickDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var1.visible(var10003::get)).build());
        this.openestCity = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("openest-city")).description("Selects the most convenient block for punching.")).defaultValue(true)).build());
        this.breakInterfering = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-interfering")).description("Breaks interfering blocks to break through the surround.")).defaultValue(true)).build());
        var10001 = this.sgMining;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("on-iron")).description("Breaks interfering blocks to break through the surround.")).defaultValue(false);
        var10003 = this.breakInterfering;
        Objects.requireNonNull(var10003);
        this.onIron = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.breakBurrow = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-burrow")).description("Breaks the burrow block first.")).defaultValue(true)).build());
        this.burrowBlocks = this.sgMining.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("burrow-blocks")).description("Blocks can be broken on burrow pos.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).build());
        this.ignoreYourOwnSurround = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-your-own-surround")).description("Ignore the block if your enemy has a common city.")).defaultValue(true)).build());
        this.ignoreFriendSurround = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-friend-surround")).description("Ignore the block if your enemy has a common city.")).defaultValue(true)).build());
        this.ignoreBlocks = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-blocks")).description("Do not break the surround if this block is selected in the list.")).defaultValue(true)).build());
        this.ignoreBlocksList = this.sgMining.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("ignore-block-list")).description("List of ignored blocks.")).defaultValue(Collections.singletonList(Blocks.STONE_BUTTON))).build());
        this.sgSwap = this.settings.createGroup("Swap");
        this.ironPickaxe = this.sgSwap.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("iron-pickaxe")).description("Change the pickaxe slot to an iron one when pressing the button.")).defaultValue(Keybind.none())).build());
        this.autoSwap = this.sgSwap.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("autoSwap")).description("Automatically picks up the pickaxe when breaking.")).defaultValue(true)).build());
        this.swapDelay = this.sgSwap.add(((Builder)((Builder)(new Builder()).name("swapDelay")).description("The delay between swap.")).defaultValue(0.0D).min(0.0D).sliderMax(10.0D).build());
        this.sgSupport = this.settings.createGroup("Support");
        this.support = this.sgSupport.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("support-place")).description("If there is no block below a city block it will place one before mining.")).defaultValue(true)).build());
        this.crystal = this.sgSupport.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("crystal-place")).description("Place crystals for punching the surround.")).defaultValue(true)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("crystal-support")).description("If there is no block below a crystal place block it will place one before placing.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.crystalSupport = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("place-priority")).description("Place priority")).defaultValue(PacketCity.PlacePriority.Consistently);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.placePriority = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("near-the-city")).description("Place crystals near the city.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.nearTheCity = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("diagonal")).description("Place crystals diagonally.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.diagonal = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("under")).description("Place crystals under city block.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.under = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("up")).description("Place crystals up city block.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.up = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.placeMode = this.sgSupport.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("crystal-place-mode")).description("Which way to place crystal")).defaultValue(PacketCity.PlaceMode.Progress)).visible(() -> {
            return (Boolean)this.crystal.get() && !(Boolean)this.instant.get();
        })).build());
        this.timer = this.sgSupport.add(((Builder)((Builder)((Builder)(new Builder()).name("timer")).description("The progress of breaking after which the crystal is placed.")).defaultValue(300.0D).min(0.0D).sliderMax(1000.0D).visible(() -> {
            return this.placeMode.get() == PacketCity.PlaceMode.Progress && (Boolean)this.crystal.get() && !(Boolean)this.instant.get();
        })).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-crystal")).description("Breaking the crystal for the explosion of item.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.breakCrystal = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgSupport;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("crystal-on-sur-pos")).description("Breaking the crystal for the explosion of item.")).defaultValue(true);
        var10003 = this.crystal;
        Objects.requireNonNull(var10003);
        this.placeCrystalOnSurPos = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.sgToggleAndPause = this.settings.createGroup("Toggle and Pause");
        this.selfToggle = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("self-toggle")).description("Automatically toggles off after activation.")).defaultValue(false)).build());
        this.stopPlacingOnEat = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-placing-on-eat")).description("Stop-placing-on-eat.")).defaultValue(false)).build());
        this.stopPlacingOnDrink = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-placing-on-drink")).description("Stop-placing-on-drink.")).defaultValue(false)).build());
        this.stopPlacingOnMine = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-placing-on-mine")).description("Stop-placing-on-mine.")).defaultValue(false)).build());
        this.sgRender = this.settings.createGroup("Render");
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders the current block being mined.")).defaultValue(true)).build());
        this.instantTimer = new TimerUtils();
        this.swapTimer = new TimerUtils();
        this.packetTimer = new TimerUtils();
        this.blockPos = new Mutable(0, -1, 0);
    }

    public void onDeactivate() {
        minePos = null;
        this.holdMinePos = null;
        this.holdCityPos = null;
    }

    public void onActivate() {
        if (((PacketCity.PlaceMode)this.placeMode.get()).equals(PacketCity.PlaceMode.Progress)) {
            this.packetTimer.reset();
        }

    }

    @EventHandler
    private void onBlockBreak(BreakBlockEvent event) {
        if (event.blockPos.equals(minePos)) {
            if (((PacketCity.PlaceMode)this.placeMode.get()).equals(PacketCity.PlaceMode.Progress)) {
                this.packetTimer.reset();
            }

            if ((Boolean)this.selfToggle.get()) {
                this.toggle();
            }
        }

    }

    @EventHandler
    private void onBlockPlace(PlaceBlockEvent event) {
        if (event.blockPos.equals(minePos) && ((PacketCity.PlaceMode)this.placeMode.get()).equals(PacketCity.PlaceMode.Progress)) {
            this.packetTimer.reset();
        }

    }

    @EventHandler
    private void onTick(Pre event) {
        if (!PlayerUtils.shouldPause((Boolean)this.stopPlacingOnMine.get(), (Boolean)this.stopPlacingOnEat.get(), (Boolean)this.stopPlacingOnDrink.get())) {
            this.target = TargetUtils.getPlayerTarget((Double)this.enemyRange.get(), SortPriority.LowestDistance);
            if (this.target != null) {
                BlockPos pPos = EntityUtil.playerPos(this.target);
                ArrayList<BlockPos> cityList = new ArrayList();
                ArrayList<BlockPos> mineList = new ArrayList();
                if ((Boolean)this.breakBurrow.get() && EntityUtil.isBurrowed(this.target) && ((List)this.burrowBlocks.get()).contains(BlockUtil.getBlock(pPos))) {
                    mineList.add(pPos);
                }

                Iterator var5 = surround.iterator();

                while(true) {
                    BlockPos pos;
                    do {
                        while(true) {
                            do {
                                do {
                                    do {
                                        do {
                                            if (!var5.hasNext()) {
                                                cityList.sort(Comparator.comparing((blockPos1) -> {
                                                    return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                }));
                                                if (cityList.isEmpty()) {
                                                    return;
                                                }

                                                if (minePos != this.holdCityPos && (Boolean)this.instant.get() && !(Boolean)this.bypass.get()) {
                                                    this.startInstant(this.holdCityPos);
                                                }

                                                if ((Boolean)this.openestCity.get()) {
                                                    cityList.sort(Comparator.comparing(this::getOpenPos));
                                                }

                                                if (this.holdCityPos == null) {
                                                    this.holdCityPos = (BlockPos)cityList.get(0);
                                                }

                                                if (!(Boolean)this.holdPos.get()) {
                                                    this.holdCityPos = (BlockPos)cityList.get(0);
                                                }

                                                if ((Boolean)this.breakInterfering.get()) {
                                                    if (this.getOpenPos(this.holdCityPos) == 3 && !mineList.contains(pPos)) {
                                                        mineList.addAll(this.getFullSurroundPos(this.holdCityPos));
                                                        mineList.sort(Comparator.comparing((blockPos1) -> {
                                                            return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                        }));
                                                        if (!mineList.isEmpty()) {
                                                            this.holdMinePos = (BlockPos)mineList.get(0);
                                                        }
                                                    } else {
                                                        this.holdMinePos = null;
                                                    }
                                                }

                                                if (((Keybind)this.ironPickaxe.get()).isPressed() && !(Boolean)this.onIron.get() && (Boolean)this.breakInterfering.get()) {
                                                    mineList.clear();
                                                    this.holdMinePos = null;
                                                }

                                                if (mineList.contains(pPos)) {
                                                    minePos = pPos;
                                                } else if (this.holdMinePos != null) {
                                                    minePos = this.holdMinePos;
                                                } else if (this.holdCityPos != null) {
                                                    minePos = this.holdCityPos;
                                                }

                                                Box box;
                                                if (BlockUtil.isAir(minePos) && (Boolean)this.placeCrystalOnSurPos.get()) {
                                                    box = new Box(minePos);
                                                    if ((Boolean)this.crystal.get() && !EntityUtils.intersectsWithEntity(box, (entity) -> {
                                                        return entity instanceof EndCrystalEntity || entity instanceof ItemEntity;
                                                    }) && minePos == this.holdCityPos) {
                                                        this.placeCrystal(minePos.down());
                                                        this.crystalPos = minePos;
                                                    }
                                                }

                                                if (!BlockUtil.isAir(minePos) && BlockUtils.canBreak(minePos)) {
                                                    if ((Boolean)this.support.get() && BlockUtil.isAir(minePos.down())) {
                                                        this.placeSupportBlock(minePos.down());
                                                    }

                                                    box = new Box(minePos);
                                                    if ((Boolean)this.crystal.get() && !EntityUtils.intersectsWithEntity(box, (entity) -> {
                                                        return entity instanceof EndCrystalEntity;
                                                    }) && minePos == this.holdCityPos) {
                                                        ArrayList<BlockPos> crystalList = new ArrayList();
                                                        if ((Boolean)this.nearTheCity.get()) {
                                                            switch((PacketCity.PlacePriority)this.placePriority.get()) {
                                                                case Consistently:
                                                                    crystalList = this.getCrystalPos(minePos);
                                                                    crystalList.sort(Comparator.comparing((blockPos1) -> {
                                                                        return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                                    }));
                                                                    break;
                                                                case Distance:
                                                                    crystalList.addAll(this.getCrystalPos(minePos));
                                                            }
                                                        }

                                                        if ((Boolean)this.diagonal.get()) {
                                                            switch((PacketCity.PlacePriority)this.placePriority.get()) {
                                                                case Consistently:
                                                                    if (crystalList.isEmpty()) {
                                                                        crystalList = this.getDiagonalCrystalPos(minePos);
                                                                        crystalList.sort(Comparator.comparing((blockPos1) -> {
                                                                            return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                                        }));
                                                                    }
                                                                    break;
                                                                case Distance:
                                                                    crystalList.addAll(this.getDiagonalCrystalPos(minePos));
                                                            }
                                                        }

                                                        if ((Boolean)this.under.get() && crystalList.isEmpty()) {
                                                            switch((PacketCity.PlacePriority)this.placePriority.get()) {
                                                                case Consistently:
                                                                    if (crystalList.isEmpty()) {
                                                                        crystalList = this.getUnderCrystalPos(minePos);
                                                                        crystalList.sort(Comparator.comparing((blockPos1) -> {
                                                                            return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                                        }));
                                                                    }
                                                                    break;
                                                                case Distance:
                                                                    crystalList.addAll(crystalList = this.getUnderCrystalPos(minePos));
                                                            }
                                                        }

                                                        if ((Boolean)this.up.get() && crystalList.isEmpty()) {
                                                            switch((PacketCity.PlacePriority)this.placePriority.get()) {
                                                                case Consistently:
                                                                    if (crystalList.isEmpty()) {
                                                                        crystalList = new ArrayList<BlockPos>() {
                                                                            {
                                                                                if (BlockUtil.isAir(PacketCity.minePos.up()) && (BlockUtil.getBlock(PacketCity.minePos) == Blocks.BEDROCK || BlockUtil.getBlock(PacketCity.minePos) == Blocks.OBSIDIAN) && BlockUtil.distance(new BlockPos(PacketCity.this.mc.player.getEyePos()), PacketCity.minePos.up()) <= (Double)PacketCity.this.cityRange.get()) {
                                                                                    Box box = new Box(PacketCity.minePos.up());
                                                                                    if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                                                                                        return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
                                                                                    })) {
                                                                                        this.add(PacketCity.minePos.up());
                                                                                    }
                                                                                }

                                                                            }
                                                                        };
                                                                    }
                                                                    break;
                                                                case Distance:
                                                                    crystalList.addAll(new ArrayList<BlockPos>() {
                                                                        {
                                                                            if (BlockUtil.isAir(PacketCity.minePos.up()) && (BlockUtil.getBlock(PacketCity.minePos) == Blocks.BEDROCK || BlockUtil.getBlock(PacketCity.minePos) == Blocks.OBSIDIAN) && BlockUtil.distance(new BlockPos(PacketCity.this.mc.player.getEyePos()), PacketCity.minePos.up()) <= (Double)PacketCity.this.cityRange.get()) {
                                                                                Box box = new Box(PacketCity.minePos.up());
                                                                                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                                                                                    return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
                                                                                })) {
                                                                                    this.add(PacketCity.minePos.up());
                                                                                }
                                                                            }

                                                                        }
                                                                    });
                                                            }
                                                        }

                                                        if (!crystalList.isEmpty()) {
                                                            if (((PacketCity.PlacePriority)this.placePriority.get()).equals(PacketCity.PlacePriority.Distance)) {
                                                                crystalList.sort(Comparator.comparing((blockPos1) -> {
                                                                    return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), blockPos1);
                                                                }));
                                                            }

                                                            if ((Boolean)this.crystalSupport.get() && BlockUtil.isAir(((BlockPos)crystalList.get(0)).down())) {
                                                                this.placeSupportBlock(((BlockPos)crystalList.get(0)).down());
                                                            }

                                                            if (((PacketCity.PlaceMode)this.placeMode.get()).equals(PacketCity.PlaceMode.Progress)) {
                                                                if ((Boolean)this.instant.get() || this.packetTimer.hasPassed((Double)this.timer.get() * 10.0D)) {
                                                                    this.placeCrystal(((BlockPos)crystalList.get(0)).down());
                                                                    this.crystalPos = (BlockPos)crystalList.get(0);
                                                                }
                                                            } else {
                                                                this.placeCrystal(((BlockPos)crystalList.get(0)).down());
                                                                this.crystalPos = (BlockPos)crystalList.get(0);
                                                            }
                                                        }
                                                    }

                                                    FindItemResult pickaxe = InvUtils.find((itemStack) -> {
                                                        return itemStack.getItem() == Items.DIAMOND_PICKAXE || itemStack.getItem() == Items.NETHERITE_PICKAXE;
                                                    });
                                                    if (((Keybind)this.ironPickaxe.get()).isPressed()) {
                                                        pickaxe = InvUtils.find((itemStack) -> {
                                                            return itemStack.getItem() == Items.IRON_PICKAXE;
                                                        });
                                                    }

                                                    int prev = this.mc.player.getInventory().selectedSlot;
                                                    if (!pickaxe.isHotbar()) {
                                                        if ((Boolean)this.selfToggle.get()) {
                                                            this.toggle();
                                                        }

                                                        return;
                                                    }

                                                    if (!this.swapTimer.hasPassed((Double)this.swapDelay.get() * 50.0D)) {
                                                        return;
                                                    }

                                                    if ((Boolean)this.autoSwap.get()) {
                                                        this.mc.player.getInventory().selectedSlot = pickaxe.slot();
                                                    }

                                                    this.swapTimer.reset();
                                                    if ((Boolean)this.instant.get()) {
                                                        if (this.instantTimer.hasPassed((double)((Integer)this.tickDelay.get() * 50))) {
                                                            if ((Boolean)this.bypass.get()) {
                                                                if (this.direction == null) {
                                                                    this.direction = Direction.UP;
                                                                }

                                                                this.mc.interactionManager.updateBlockBreakingProgress(minePos, this.direction);
                                                                this.mc.interactionManager.cancelBlockBreaking();
                                                            } else {
                                                                this.instantMine(minePos);
                                                            }

                                                            this.instantTimer.reset();
                                                        }
                                                    } else {
                                                        this.mine(minePos);
                                                        this.mc.player.getInventory().selectedSlot = prev;
                                                    }
                                                }

                                                return;
                                            }

                                            BlockPos b = (BlockPos)var5.next();
                                            pos = pPos.add(b);
                                        } while(!BlockUtils.canBreak(pos));
                                    } while(BlockUtil.isAir(pos));
                                } while(!(BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos) <= (Double)this.cityRange.get()));
                            } while((Boolean)this.ignoreYourOwnSurround.get() && EntityUtil.getSurroundPos(this.mc.player).contains(pos));

                            try {
                                if (!(Boolean)this.ignoreFriendSurround.get() || !EntityUtil.getSurroundPos((PlayerEntity)this.getFriendsInRange().get(0)).contains(pos)) {
                                    break;
                                }
                            } catch (IndexOutOfBoundsException var9) {
                                break;
                            }
                        }
                    } while((Boolean)this.ignoreBlocks.get() && ((List)this.ignoreBlocksList.get()).contains(BlockUtil.getBlock(pos)));

                    cityList.add(pos);
                }
            }
        }
    }

    @EventHandler
    private void onT(Post event) {
        if ((Boolean)this.breakCrystal.get() && this.target != null) {
            Iterator var2 = this.mc.world.getEntities().iterator();

            while(true) {
                Entity crystal;
                do {
                    do {
                        if (!var2.hasNext()) {
                            return;
                        }

                        crystal = (Entity)var2.next();
                    } while(!(crystal instanceof EndCrystalEntity));
                } while(!crystal.getBlockPos().equals(this.crystalPos));

                Iterator var4 = this.mc.world.getEntities().iterator();

                while(var4.hasNext()) {
                    Entity item = (Entity)var4.next();
                    if (item instanceof ItemEntity && item.getBlockPos().equals(this.holdCityPos)) {
                        this.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(crystal, this.mc.player.isSneaking()));
                    }
                }
            }
        }
    }

    @EventHandler
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        if ((Boolean)this.instant.get() && (Boolean)this.bypass.get()) {
            this.instantTimer.reset();
            this.direction = event.direction;
            this.blockPos.set(event.blockPos);
            this.cum();
            event.cancel();
        }

    }

    private void cum() {
        if (!this.wontMine()) {
            if (this.direction == null) {
                this.direction = Direction.UP;
            }

            if ((Boolean)this.rotate.get()) {
                Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                });
                Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, this.blockPos, this.direction));
                });
            } else {
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, this.blockPos, this.direction));
            }
        }

    }

    private boolean wontMine() {
        return this.blockPos.getY() == -1 || !BlockUtils.canBreak(this.blockPos);
    }

    private void placeCrystal(BlockPos pos) {
        if (this.mc.world.getBlockState(pos.up()).isAir()) {
            this.placePattern(pos);
        }

    }

    private void placePattern(BlockPos pos) {
        if (this.mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL) {
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.OFF_HAND, new BlockHitResult(this.mc.player.getPos(), Direction.UP, pos, true));
            this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        } else if (this.mc.player.getOffHandStack().getItem() != Items.END_CRYSTAL) {
            int prev = this.mc.player.getInventory().selectedSlot;
            FindItemResult crystalSlot = InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL});
            if (!crystalSlot.found()) {
                return;
            }

            this.mc.player.getInventory().selectedSlot = crystalSlot.slot();
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, new BlockHitResult(this.mc.player.getPos(), Direction.UP, pos, true));
            this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            this.mc.player.getInventory().selectedSlot = prev;
        }

    }

    private void placeSupportBlock(BlockPos pos) {
        BlockUtils.place(pos, InvUtils.findInHotbar(new Item[]{Items.OBSIDIAN}), (Boolean)this.rotate.get(), 0, true);
    }

    private void instantMine(BlockPos pos) {
        if (this.instantTimer.hasPassed((double)((Integer)this.tickDelay.get() * 50))) {
            if ((Boolean)this.rotate.get()) {
                Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), () -> {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.DOWN));
                });
            } else {
                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.DOWN));
            }

            this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            this.instantTimer.reset();
        }

    }

    private void startInstant(BlockPos pos) {
        if (pos != null) {
            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.DOWN));
        }

    }

    private void mine(BlockPos pos) {
        this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.DOWN));
        this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.DOWN));
    }

    private ArrayList<BlockPos> getFullSurroundPos(BlockPos pos) {
        ArrayList<BlockPos> pos1 = new ArrayList();
        CardinalDirection[] var3 = CardinalDirection.values();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            CardinalDirection direction = var3[var5];
            if (!BlockUtil.isAir(pos.offset(direction.toDirection())) && BlockUtils.canBreak(pos.offset(direction.toDirection())) && BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos.offset(direction.toDirection())) <= (Double)this.cityRange.get()) {
                Box box = new Box(pos.offset(direction.toDirection()));
                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                    return entity instanceof PlayerEntity || entity instanceof ItemEntity || entity instanceof TntEntity;
                })) {
                    pos1.add(pos.offset(direction.toDirection()));
                }
            }
        }

        return pos1;
    }

    private int getOpenPos(BlockPos pos) {
        int count = 0;
        CardinalDirection[] var3 = CardinalDirection.values();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            CardinalDirection direction = var3[var5];
            if (BlockUtil.isAir(pos.offset(direction.toDirection()))) {
                Box box = new Box(pos.offset(direction.toDirection()));
                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                    return entity instanceof PlayerEntity || entity instanceof TntEntity;
                })) {
                    ++count;
                }
            }
        }

        return 3 - count;
    }

    private ArrayList<BlockPos> getUnderCrystalPos(BlockPos pos) {
        ArrayList<BlockPos> list = new ArrayList();
        if (BlockUtil.isAir(pos.down()) && (BlockUtil.getBlock(pos.down(2)) == Blocks.BEDROCK || BlockUtil.getBlock(pos.down(2)) == Blocks.OBSIDIAN || BlockUtil.getBlock(pos.down(2)) == Blocks.AIR) && BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos.down()) <= (Double)this.cityRange.get()) {
            Box box = new Box(pos.down());
            if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
            })) {
                list.add(pos.down());
            }
        }

        CardinalDirection[] var8 = CardinalDirection.values();
        int var4 = var8.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            CardinalDirection direction = var8[var5];
            if (BlockUtil.isAir(pos.offset(direction.toDirection()).down()) && (BlockUtil.getBlock(pos.offset(direction.toDirection()).down(2)) == Blocks.BEDROCK || BlockUtil.getBlock(pos.offset(direction.toDirection()).down(2)) == Blocks.OBSIDIAN || BlockUtil.getBlock(pos.offset(direction.toDirection()).down(2)) == Blocks.AIR) && BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos.offset(direction.toDirection()).down()) <= (Double)this.cityRange.get()) {
                Box box = new Box(pos.offset(direction.toDirection()).down());
                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                    return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
                })) {
                    list.add(pos.offset(direction.toDirection()).down());
                }
            }
        }

        return list;
    }

    private ArrayList<BlockPos> getDiagonalCrystalPos(BlockPos pos) {
        ArrayList<BlockPos> list = new ArrayList();
        Iterator var3 = diagonalArray.iterator();

        while(true) {
            BlockPos newPos;
            do {
                do {
                    if (!var3.hasNext()) {
                        return list;
                    }

                    BlockPos p = (BlockPos)var3.next();
                    newPos = pos.add(p);
                } while(!BlockUtil.isAir(newPos));
            } while(BlockUtil.getBlock(newPos.down()) != Blocks.BEDROCK && BlockUtil.getBlock(newPos.down()) != Blocks.OBSIDIAN && BlockUtil.getBlock(newPos.down()) != Blocks.AIR);

            if (BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), newPos) <= (Double)this.cityRange.get()) {
                Box box = new Box(newPos);
                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                    return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
                })) {
                    list.add(newPos);
                }
            }
        }
    }

    private ArrayList<BlockPos> getCrystalPos(BlockPos pos) {
        ArrayList<BlockPos> list = new ArrayList();
        CardinalDirection[] var3 = CardinalDirection.values();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            CardinalDirection direction = var3[var5];
            if (BlockUtil.isAir(pos.offset(direction.toDirection())) && (BlockUtil.getBlock(pos.offset(direction.toDirection()).down()) == Blocks.BEDROCK || BlockUtil.getBlock(pos.offset(direction.toDirection()).down()) == Blocks.OBSIDIAN || BlockUtil.getBlock(pos.offset(direction.toDirection()).down()) == Blocks.AIR) && BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos.offset(direction.toDirection())) <= (Double)this.cityRange.get()) {
                Box box = new Box(pos.offset(direction.toDirection()));
                if (!EntityUtils.intersectsWithEntity(box, (entity) -> {
                    return entity instanceof PlayerEntity || entity instanceof TntEntity || entity instanceof EndCrystalEntity;
                })) {
                    list.add(pos.offset(direction.toDirection()));
                }
            }
        }

        return list;
    }

    private List<PlayerEntity> getFriendsInRange() {
        return (List)this.mc.world.getPlayers().stream().filter((e) -> {
            return e != this.mc.player;
        }).filter(LivingEntity::isAlive).filter((e) -> {
            return Friends.get().isFriend(e);
        }).filter((e) -> {
            return e.getHealth() > 0.0F;
        }).filter((e) -> {
            return (double)this.mc.player.distanceTo(e) < (Double)this.enemyRange.get();
        }).sorted(Comparator.comparing((e) -> {
            return this.mc.player.distanceTo(e);
        })).collect(Collectors.toList());
    }

    public static BlockPos getPos() {
        return minePos;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && minePos != null && !this.mc.world.getBlockState(minePos).isAir()) {
            RenderUtil.S(event, minePos, 0.99D, 0.0D, 0.01D, new Color(15, 255, 211), new Color(15, 255, 211));
            RenderUtil.TAB(event, minePos, 0.99D, 0.01D, true, true, new Color(15, 255, 211), new Color(15, 255, 211));
            RenderUtil.FS(event, minePos, 0.0D, true, true, new Color(15, 255, 211, 75), new Color(15, 211, 255, 70));
            if (BlockUtil.distance(EntityUtil.playerPos(this.mc.player), minePos) > 6.0D) {
                minePos = null;
            }
        }

    }

    public static enum PlacePriority {
        Consistently,
        Distance;

        // $FF: synthetic method
        private static PacketCity.PlacePriority[] $values() {
            return new PacketCity.PlacePriority[]{Consistently, Distance};
        }
    }

    public static enum PlaceMode {
        Default,
        Progress;

        // $FF: synthetic method
        private static PacketCity.PlaceMode[] $values() {
            return new PacketCity.PlaceMode[]{Default, Progress};
        }
    }
}
