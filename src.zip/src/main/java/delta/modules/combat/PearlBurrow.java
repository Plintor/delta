package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.WorldUtils;
import java.util.Iterator;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class PearlBurrow extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final Setting<Boolean> notify;
    private final Setting<Double> dist;
    private final Setting<Double> threshold;
    private final Setting<BlockUtil.BlastResistantType> type;
    private final Setting<PearlBurrow.BlockSortPriority> sort;
    private final Setting<Boolean> place;
    private final Setting<Integer> thrDel;
    private final Setting<Boolean> forceRotate;
    private final Setting<Boolean> doubles;
    private final Setting<Boolean> autoToggle;
    private final Setting<Boolean> rotateBack;
    private final Setting<Boolean> sit;
    private final Setting<Integer> del;
    private final Setting<Boolean> renderSearchPos;
    private final Setting<Boolean> renderPlacePos;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> nextSideColor;
    private final Setting<SettingColor> nextLineColor;
    private Direction dir;
    BlockPos bestPos;
    private PearlBurrow.Stage stage;
    private int timer;
    private float ogYaw;
    private float ogPitch;

    public PearlBurrow() {
        super(DeltaHack.Combat, "pearl-burrow+", "Pearl Burrow but rewrite");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("Render");
        this.notify = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("notify")).description("Notifies you about the work of the module.")).defaultValue(true)).build());
        this.dist = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("distance")).description("How far to aim into the block.")).defaultValue(0.3D).range(0.0D, 0.6D).sliderRange(0.2D, 0.5D).build());
        this.threshold = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("center-threshold")).description("don't touch this unless you know what you're doing.")).defaultValue(0.31D).range(0.0D, 1.0D).sliderRange(0.1D, 0.45D).build());
        this.type = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("block-type")).description("Throws a pearl only in this type of blast-proof blocks")).defaultValue(BlockUtil.BlastResistantType.AnyBlock)).build());
        this.sort = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("sort-priority")).description("Prioritized property of a block.")).defaultValue(PearlBurrow.BlockSortPriority.BlastResistance)).build());
        this.place = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("place")).description("Places a block to burrow into if none are found")).defaultValue(false)).build());
        this.thrDel = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay-after-placing")).description("Extra delay between placing blocks and throwing pearl.")).defaultValue(3)).range(0, 20).sliderRange(0, 5).build());
        SettingGroup var10001 = this.sgGeneral;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("place-rotate")).description("Rotates before placing blocks.")).defaultValue(true);
        Setting var10003 = this.place;
        Objects.requireNonNull(var10003);
        this.forceRotate = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.doubles = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("only-doubles")).description("Only burrows in double height burrows.")).defaultValue(true)).build());
        this.autoToggle = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("only-if-not-burrowed")).description("Throws a pearl only if the player is not burrowed already")).defaultValue(true)).build());
        this.rotateBack = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate-back")).description("Rotates back after throwing")).defaultValue(true)).build());
        this.sit = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("auto-sit")).description("Should Pearl Burrow use /sit command after pearl throw.")).defaultValue(true)).build());
        this.del = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Delay between different actions")).defaultValue(1)).min(0).build());
        this.renderSearchPos = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render-search-pos")).description("Should Pearl Burrow render the positions it's searching the blocks to burrow in.")).defaultValue(true)).build());
        this.renderPlacePos = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render-place-pos")).description("Should Pearl Burrow render the position it's placing the block to burrow into.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).visible(() -> {
            return (Boolean)this.renderSearchPos.get() || (Boolean)this.renderPlacePos.get() && (Boolean)this.place.get();
        })).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.ColorSetting.Builder var1 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks that you search through.")).defaultValue(new SettingColor(204, 0, 0, 45, true));
        var10003 = this.renderSearchPos;
        Objects.requireNonNull(var10003);
        this.sideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var1 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks that you search through.")).defaultValue(new SettingColor(204, 0, 0, 255, true));
        var10003 = this.renderSearchPos;
        Objects.requireNonNull(var10003);
        this.lineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var1.visible(var10003::get)).build());
        this.nextSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("next-side-color")).description("The side color of the next block to be placed.")).defaultValue(new SettingColor(227, 196, 245, 10))).visible(() -> {
            return (Boolean)this.renderPlacePos.get() && (Boolean)this.place.get();
        })).build());
        var10001 = this.sgRender;
        var1 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("next-line-color")).description("The line color of the next block to be placed.")).defaultValue(new SettingColor(227, 196, 245))).visible(() -> {
            return (Boolean)this.renderPlacePos.get() && (Boolean)this.place.get();
        });
        var10003 = this.renderSearchPos;
        Objects.requireNonNull(var10003);
        this.nextLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var1.visible(var10003::get)).build());
    }

    public void onActivate() {
        this.dir = null;
        this.bestPos = null;
        this.stage = PearlBurrow.Stage.BlockSearch;
        this.timer = 0;
        this.ogYaw = 0.0F;
        this.ogPitch = -90.0F;
    }

    @EventHandler
    public void onTick(Pre event) {
        assert this.mc.player != null;

        assert this.mc.interactionManager != null;

        assert this.mc.world != null;

        if (this.mc.options.sneakKey.isPressed()) {
            this.mc.options.sneakKey.setPressed(false);
        }

        this.mc.player.setSneaking(false);
        if (this.timer > 0) {
            --this.timer;
        } else {
            this.timer = (Integer)this.del.get();
            if (this.mc.player.isInSwimmingPose()) {
                if ((Boolean)this.notify.get()) {
                    this.error("You can not pearl-burrow while in prone.", new Object[0]);
                }

                this.toggle();
            } else {
                FindItemResult fP;
                BlockPos placePos;
                Iterator var4;
                switch(this.stage) {
                    case BlockSearch:
                        PlayerUtil.centerTwo((Double)this.threshold.get());
                        if ((Boolean)this.autoToggle.get() && EntityUtil.isBurrowed(this.mc.player)) {
                            if ((Boolean)this.notify.get()) {
                                this.error("Already burrowed.", new Object[0]);
                            }

                            this.toggle();
                            return;
                        }

                        if ((Boolean)this.notify.get()) {
                            this.info("Searching for block to burrow into...", new Object[0]);
                        }

                        for(var4 = EntityUtil.getSurroundPos(this.mc.player).iterator(); var4.hasNext(); this.bestPos = this.compare(this.bestPos, placePos)) {
                            placePos = (BlockPos)var4.next();
                        }

                        if ((Boolean)this.rotateBack.get()) {
                            this.ogYaw = this.mc.player.getYaw();
                            this.ogPitch = this.mc.player.getPitch();
                        }

                        if (this.bestPos == null) {
                            if ((Boolean)this.place.get()) {
                                if ((Boolean)this.notify.get()) {
                                    this.warning("Couldn't find a block to burrow into.", new Object[0]);
                                }

                                this.stage = PearlBurrow.Stage.Place;
                            } else {
                                if ((Boolean)this.notify.get()) {
                                    this.error("Couldn't find a block to burrow into.", new Object[0]);
                                }

                                this.toggle();
                            }
                        } else {
                            this.dir = Direction.fromRotation(Rotations.getYaw(this.bestPos));
                            this.stage = PearlBurrow.Stage.Throw;
                            this.mc.player.setYaw((float)Rotations.getYaw(this.bestPos));
                            this.mc.player.setPitch(this.pearlPitch());
                        }
                        break;
                    case Place:
                        PlayerUtil.centerTwo((Double)this.threshold.get());
                        this.bestPos = null;
                        var4 = EntityUtil.getSurroundPos(this.mc.player).iterator();

                        while(var4.hasNext()) {
                            placePos = (BlockPos)var4.next();
                            if (BlockUtil.isBlastResist(placePos, (BlockUtil.BlastResistantType)this.type.get()) && (!(Boolean)this.doubles.get() || BlockUtil.isBlastResist(placePos.up(), (BlockUtil.BlastResistantType)this.type.get()))) {
                                if ((Boolean)this.notify.get()) {
                                    this.info("Found a block to burrow into.", new Object[0]);
                                }

                                this.bestPos = placePos;
                                this.dir = Direction.fromRotation(Rotations.getYaw(this.bestPos));
                                this.mc.player.setPitch(this.pearlPitch());
                                this.mc.player.setYaw(this.dir.asRotation());
                                this.stage = PearlBurrow.Stage.Throw;
                                this.timer = (Integer)this.thrDel.get();
                                return;
                            }

                            if (BlockUtil.canPlace(placePos, true)) {
                                this.bestPos = placePos;
                            } else if ((Boolean)this.doubles.get() && BlockUtil.canPlace(placePos.up(), true)) {
                                this.bestPos = placePos.up();
                            }
                        }

                        if (this.bestPos == null) {
                            if ((Boolean)this.notify.get()) {
                                this.warning("Found no position to place the block. Burrowing in the direction you're looking at.", new Object[0]);
                            }

                            this.dir = this.mc.player.getHorizontalFacing();
                            this.bestPos = EntityUtil.playerPos(this.mc.player).add(this.dir.getVector());
                            this.mc.player.setPitch(this.pearlPitch());
                            this.mc.player.setYaw(this.dir.asRotation());
                            this.stage = PearlBurrow.Stage.Throw;
                            return;
                        }

                        fP = InvUtils.findInHotbar((itemStack) -> {
                            return BlockUtil.isBlastResist(Block.getBlockFromItem(itemStack.getItem()), (BlockUtil.BlastResistantType)this.type.get());
                        });
                        if (!fP.found()) {
                            if ((Boolean)this.notify.get()) {
                                this.error("Couldn't find a block to place.", new Object[0]);
                            }

                            this.toggle();
                            return;
                        }

                        WorldUtils.place(this.bestPos, fP, (Boolean)this.forceRotate.get(), 50, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, false, true, true);
                        if ((Boolean)this.notify.get()) {
                            this.info("Placed a block.", new Object[0]);
                        }
                        break;
                    case Throw:
                        fP = InvUtils.find(new Item[]{Items.ENDER_PEARL});
                        if (!fP.found()) {
                            if ((Boolean)this.notify.get()) {
                                this.error("Couldn't find a pearl.", new Object[0]);
                            }

                            this.toggle();
                            return;
                        }

                        this.mc.player.setSneaking(false);
                        if ((Boolean)this.notify.get()) {
                            this.info("Thrown a pearl.", new Object[0]);
                        }

                        if (fP.isHotbar()) {
                            InvUtils.swap(fP.slot(), true);
                        } else {
                            InvUtils.move().from(fP.slot()).to(this.mc.player.getInventory().selectedSlot);
                        }

                        if (this.mc.player.getMainHandStack().getItem() == Items.ENDER_PEARL) {
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                            if (fP.isHotbar()) {
                                InvUtils.swapBack();
                            } else {
                                InvUtils.move().from(fP.slot()).to(this.mc.player.getInventory().selectedSlot);
                            }

                            if ((Boolean)this.rotateBack.get()) {
                                this.stage = PearlBurrow.Stage.RotateBack;
                            } else if ((Boolean)this.sit.get()) {
                                this.stage = PearlBurrow.Stage.Sit;
                            } else {
                                if ((Boolean)this.notify.get()) {
                                    this.info("Toggling off...", new Object[0]);
                                }

                                this.toggle();
                            }
                        }
                        break;
                    case RotateBack:
                        this.mc.player.setYaw(this.ogYaw);
                        this.mc.player.setPitch(this.ogPitch);
                        if ((Boolean)this.sit.get()) {
                            this.stage = PearlBurrow.Stage.Sit;
                        } else {
                            this.toggle();
                        }
                        break;
                    case Sit:
                        PlayerUtil.sendPlayerMsg("/sit");
                        this.toggle();
                }

            }
        }
    }

    private BlockPos compare(BlockPos FiRst, BlockPos SeCon) {
        if (FiRst == null) {
            return SeCon;
        } else if (SeCon == null) {
            return FiRst;
        } else {
            if (!BlockUtil.isBlastResist(FiRst, (BlockUtil.BlastResistantType)this.type.get()) || BlockUtil.isReplaceable(FiRst) || (Boolean)this.doubles.get() && !BlockUtil.isBlastResist(FiRst.up(), (BlockUtil.BlastResistantType)this.type.get())) {
                FiRst = null;
            }

            if (!BlockUtil.isBlastResist(SeCon, (BlockUtil.BlastResistantType)this.type.get()) || BlockUtil.isReplaceable(SeCon) || (Boolean)this.doubles.get() && !BlockUtil.isBlastResist(SeCon.up(), (BlockUtil.BlastResistantType)this.type.get())) {
                SeCon = null;
            }

            if (FiRst == null) {
                return SeCon;
            } else if (SeCon == null) {
                return FiRst;
            } else {
                switch((PearlBurrow.BlockSortPriority)this.sort.get()) {
                    case Angle:
                        return this.angleSort(FiRst, SeCon);
                    case Hardness:
                        if (BlockUtil.getHardness(FiRst) > BlockUtil.getHardness(SeCon)) {
                            return FiRst;
                        } else {
                            if (BlockUtil.getHardness(FiRst) < BlockUtil.getHardness(SeCon)) {
                                return SeCon;
                            }

                            return this.angleSort(FiRst, SeCon);
                        }
                    case BlastResistance:
                        if (BlockUtil.getBlastResistance(FiRst) > BlockUtil.getBlastResistance(SeCon)) {
                            return FiRst;
                        } else {
                            if (BlockUtil.getBlastResistance(FiRst) < BlockUtil.getBlastResistance(SeCon)) {
                                return SeCon;
                            }

                            return this.angleSort(FiRst, SeCon);
                        }
                    default:
                        return null;
                }
            }
        }
    }

    private BlockPos angleSort(BlockPos FiRst, BlockPos SeCon) {
        return Math.abs(Rotations.getYaw(FiRst) - (double)this.mc.player.getYaw()) < Math.abs(Rotations.getYaw(SeCon) - (double)this.mc.player.getYaw()) ? FiRst : SeCon;
    }

    private float pearlPitch() {
        Direction dir = Direction.fromRotation(Rotations.getYaw(this.bestPos));
        return (float)Rotations.getPitch(Vec3d.ofBottomCenter(this.mc.player.getBlockPos()).add((double)dir.getVector().getX() * (Double)this.dist.get(), 0.0D, (double)dir.getVector().getZ() * (Double)this.dist.get()));
    }

    @EventHandler(
        priority = 100
    )
    private void onRender(Render3DEvent event) {
        if (this.stage == PearlBurrow.Stage.BlockSearch && (Boolean)this.renderSearchPos.get()) {
            Iterator var2 = EntityUtil.getSurroundPos(this.mc.player).iterator();

            while(var2.hasNext()) {
                BlockPos pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }
        }

        if (this.bestPos != null && (this.stage == PearlBurrow.Stage.Place || this.stage == PearlBurrow.Stage.Throw) && (Boolean)this.place.get() && (Boolean)this.renderPlacePos.get()) {
            event.renderer.box(this.bestPos, (Color)this.nextSideColor.get(), (Color)this.nextLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

    }

    public static enum BlockSortPriority {
        Angle,
        Hardness,
        BlastResistance;

        // $FF: synthetic method
        private static PearlBurrow.BlockSortPriority[] $values() {
            return new PearlBurrow.BlockSortPriority[]{Angle, Hardness, BlastResistance};
        }
    }

    public static enum Stage {
        BlockSearch,
        Place,
        Throw,
        RotateBack,
        Sit;

        // $FF: synthetic method
        private static PearlBurrow.Stage[] $values() {
            return new PearlBurrow.Stage[]{BlockSearch, Place, Throw, RotateBack, Sit};
        }
    }
}
