package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.InvUtil;
import delta.utils.RenderUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class SexTNT extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<SexTNT.tntPlaceMode> tntPlaceModeSetting;
    private final Setting<Integer> trapDelay;
    private final Setting<Integer> tntDelay;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> breakBurrow;
    private final Setting<Boolean> breakSelfTrap;
    private final Setting<Boolean> instant;
    private final Setting<Integer> delay;
    private final Setting<Boolean> onlyInHole;
    private final Setting<Boolean> rotate;
    private final SettingGroup sgRender;
    private final Setting<Boolean> render;
    private final Setting<SexTNT.RenderMode> renderMode;
    private final Setting<Integer> fadeTick;
    private final Setting<Boolean> alwaysRender;
    private final Setting<Boolean> swing;
    private final Setting<ShapeMode> tntShapeMode;
    private final Setting<SettingColor> tntSideColor;
    private final Setting<SettingColor> tntSideColor2;
    private final Setting<SettingColor> tntLineColor;
    private final Setting<SettingColor> tntLineColor2;
    private final Setting<ShapeMode> trapShapeMode;
    private final Setting<SettingColor> trapSideColor;
    private final Setting<SettingColor> trapSideColor2;
    private final Setting<SettingColor> trapLineColor;
    private final Setting<SettingColor> trapLineColor2;
    private final Setting<Integer> width;
    private final Pool<SexTNT.RenderBlock> renderTNTBlockPool;
    private final List<SexTNT.RenderBlock> renderTNTBlocks;
    private final Pool<SexTNT.RenderBlock> renderTrapBlockPool;
    private final List<SexTNT.RenderBlock> renderTrapBlocks;
    private final ArrayList<Vec3d> trap;
    private final ArrayList<Vec3d> surr;
    private int timer;
    private int ticks;
    private int i;

    public SexTNT() {
        super(DeltaHack.Autist, "Sex-TNT", "Cringe");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.tntPlaceModeSetting = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("tnt-place-mode")).description("How to select the player to target.")).defaultValue(SexTNT.tntPlaceMode.HEAD)).build());
        this.trapDelay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("trap-delay")).description("How many ticks between block placements.")).defaultValue(1)).build());
        this.tntDelay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("tnt-delay")).description("How many ticks between block placements.")).defaultValue(1)).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for surround.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).build());
        this.breakBurrow = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-burrow")).description("Break target's self-trap automatically.")).defaultValue(false)).build());
        this.breakSelfTrap = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-self-trap")).description("Break target's self-trap automatically.")).defaultValue(false)).build());
        this.instant = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("instant")).description("instant.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).defaultValue(0)).min(0).max(20).sliderMin(0).sliderMax(20);
        Setting var10003 = this.instant;
        Objects.requireNonNull(var10003);
        this.delay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        this.onlyInHole = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-hole")).description("Rotates towards blocks when placing.")).defaultValue(true)).visible(() -> {
            return ((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.HEAD);
        })).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates towards blocks when placing.")).defaultValue(true)).build());
        this.sgRender = this.settings.createGroup("Render");
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Render surround.")).defaultValue(false)).build());
        this.renderMode = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render-mode")).description("Which way to render surround.")).defaultValue(SexTNT.RenderMode.Fade)).build());
        this.fadeTick = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fade-tick")).description("The slot auto move moves beds to.")).defaultValue(8)).visible(() -> {
            return this.renderMode.get() == SexTNT.RenderMode.Fade;
        })).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("always")).description("Render surround blocks always.")).defaultValue(false);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.alwaysRender = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).visible(() -> {
            return this.renderMode.get() != SexTNT.RenderMode.Fade;
        })).build());
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Render swing.")).defaultValue(false)).build());
        this.tntShapeMode = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("tnt-shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.tntSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-side-color")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.tntSideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-side-color-2")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.tntLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.tntLineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("tnt-line-color-2")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.trapShapeMode = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("trap-shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.trapSideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-side-color")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.trapSideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-side-color-2")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.trapLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.trapLineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("trap-line-color-2")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.width = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).defaultValue(1)).min(1).max(5).sliderMin(1).sliderMax(4).build());
        this.renderTNTBlockPool = new Pool(SexTNT.RenderBlock::new);
        this.renderTNTBlocks = new ArrayList();
        this.renderTrapBlockPool = new Pool(SexTNT.RenderBlock::new);
        this.renderTrapBlocks = new ArrayList();
        this.trap = new ArrayList<Vec3d>() {
            {
                this.add(new Vec3d(0.0D, 3.0D, 0.0D));
                this.add(new Vec3d(1.0D, 2.0D, 0.0D));
                this.add(new Vec3d(-1.0D, 2.0D, 0.0D));
                this.add(new Vec3d(0.0D, 2.0D, 1.0D));
                this.add(new Vec3d(0.0D, 2.0D, -1.0D));
            }
        };
        this.surr = new ArrayList<Vec3d>() {
            {
                this.add(new Vec3d(0.0D, -1.0D, 0.0D));
                this.add(new Vec3d(1.0D, 0.0D, 0.0D));
                this.add(new Vec3d(-1.0D, 0.0D, 0.0D));
                this.add(new Vec3d(0.0D, 0.0D, 1.0D));
                this.add(new Vec3d(0.0D, 0.0D, -1.0D));
            }
        };
    }

    public void onDeactivate() {
        this.i = 0;
        Iterator var1 = this.renderTNTBlocks.iterator();

        SexTNT.RenderBlock renderBlock;
        while(var1.hasNext()) {
            renderBlock = (SexTNT.RenderBlock)var1.next();
            this.renderTNTBlockPool.free(renderBlock);
        }

        this.renderTNTBlocks.clear();
        var1 = this.renderTrapBlocks.iterator();

        while(var1.hasNext()) {
            renderBlock = (SexTNT.RenderBlock)var1.next();
            this.renderTrapBlockPool.free(renderBlock);
        }

        this.renderTrapBlocks.clear();
    }

    public void onActivate() {
        Iterator var1 = this.renderTNTBlocks.iterator();

        SexTNT.RenderBlock renderBlock;
        while(var1.hasNext()) {
            renderBlock = (SexTNT.RenderBlock)var1.next();
            this.renderTNTBlockPool.free(renderBlock);
        }

        this.renderTNTBlocks.clear();
        var1 = this.renderTrapBlocks.iterator();

        while(var1.hasNext()) {
            renderBlock = (SexTNT.RenderBlock)var1.next();
            this.renderTrapBlockPool.free(renderBlock);
        }

        this.renderTrapBlocks.clear();
    }

    @EventHandler
    private void onTick(Pre event) {
        BlockPos ppos = this.mc.player.getBlockPos();
        this.renderTNTBlocks.forEach(SexTNT.RenderBlock::tick);
        this.renderTNTBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        this.renderTrapBlocks.forEach(SexTNT.RenderBlock::tick);
        this.renderTrapBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        FindItemResult pick;
        if (BlockUtil.getBlock(ppos) != Blocks.AIR && BlockUtil.getBlock(ppos) != Blocks.TNT && (Boolean)this.breakBurrow.get()) {
            pick = InvUtil.findPick();
            if (pick.found()) {
                InvUtil.updateSlot(pick.slot());
                if (!(Boolean)this.instant.get()) {
                    BlockUtils.breakBlock(ppos.up(2), true);
                }

                if ((Boolean)this.instant.get()) {
                    if (this.i == 0) {
                        this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                        if ((Boolean)this.swing.get()) {
                            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                        }

                        ++this.i;
                    }

                    if (this.ticks >= (Integer)this.delay.get()) {
                        this.ticks = 0;
                        if ((Boolean)this.rotate.get()) {
                            Rotations.rotate(Rotations.getYaw(ppos.up(2)), Rotations.getPitch(ppos.up(2)), () -> {
                                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                            });
                        } else {
                            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                        }

                        if ((Boolean)this.swing.get()) {
                            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                        }
                    } else {
                        ++this.ticks;
                    }
                }

                return;
            }
        }

        if (BlockUtil.getBlock(ppos.up(2)) != Blocks.AIR && BlockUtil.getBlock(ppos.up(2)) != Blocks.TNT && (Boolean)this.breakSelfTrap.get()) {
            pick = InvUtil.findPick();
            if (pick.found()) {
                InvUtil.updateSlot(pick.slot());
                if (!(Boolean)this.instant.get()) {
                    BlockUtils.breakBlock(ppos.up(2), true);
                }

                if ((Boolean)this.instant.get()) {
                    if (this.i == 0) {
                        this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                        if ((Boolean)this.swing.get()) {
                            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                        }

                        ++this.i;
                    }

                    if (this.ticks >= (Integer)this.delay.get()) {
                        this.ticks = 0;
                        if ((Boolean)this.rotate.get()) {
                            Rotations.rotate(Rotations.getYaw(ppos.up(2)), Rotations.getPitch(ppos.up(2)), () -> {
                                this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                            });
                        } else {
                            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, ppos.up(2), Direction.UP));
                        }

                        if ((Boolean)this.swing.get()) {
                            this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                        }
                    } else {
                        ++this.ticks;
                    }
                }

                return;
            }
        }

        Vec3d b;
        BlockPos pos;
        Iterator var6;
        if (((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.HEAD) || ((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.MIX)) {
            if (((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.HEAD) && (Boolean)this.onlyInHole.get() && EntityUtil.isMonke(false, this.mc.player)) {
                return;
            }

            var6 = (new ArrayList(this.trap)).iterator();

            while(var6.hasNext()) {
                b = (Vec3d)var6.next();
                pos = ppos.add(b.x, b.y, b.z);
                if (this.mc.world.getBlockState(pos).isAir()) {
                    if (this.ticks >= (Integer)this.trapDelay.get()) {
                        BlockUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                        }), (Boolean)this.rotate.get(), 100, (Boolean)this.swing.get(), false);
                        this.renderTrapBlocks.add(((SexTNT.RenderBlock)this.renderTrapBlockPool.get()).set(pos, (Integer)this.fadeTick.get()));
                        this.ticks = 0;
                    } else {
                        ++this.ticks;
                    }
                }
            }

            if (this.isTrapped(this.mc.player)) {
                if (this.timer >= (Integer)this.tntDelay.get()) {
                    BlockUtils.place(this.mc.player.getBlockPos().up(2), InvUtils.findInHotbar(new Item[]{Items.TNT}), (Boolean)this.rotate.get(), 100, true);
                    this.renderTNTBlocks.add(((SexTNT.RenderBlock)this.renderTNTBlockPool.get()).set(this.mc.player.getBlockPos().up(2), (Integer)this.fadeTick.get()));
                    this.timer = 0;
                } else {
                    ++this.timer;
                }
            }

            if (BlockUtil.getBlock(this.mc.player.getBlockPos().up(2)) == Blocks.TNT) {
                this.flintAndSteel(this.mc.player.getBlockPos().up(2));
            }
        }

        if (((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.LEGS) || ((SexTNT.tntPlaceMode)this.tntPlaceModeSetting.get()).equals(SexTNT.tntPlaceMode.MIX)) {
            var6 = (new ArrayList(this.surr)).iterator();

            while(var6.hasNext()) {
                b = (Vec3d)var6.next();
                pos = ppos.add(b.x, b.y, b.z);
                if (this.mc.world.getBlockState(pos).isAir()) {
                    if (this.timer >= (Integer)this.tntDelay.get()) {
                        BlockUtils.place(pos, InvUtils.findInHotbar(new Item[]{Items.TNT}), (Boolean)this.rotate.get(), 100, true);
                        this.timer = 0;
                    } else {
                        ++this.timer;
                    }
                }

                if (BlockUtil.getBlock(pos) == Blocks.TNT) {
                    this.flintAndSteel(pos);
                }
            }
        }

    }

    private void flintAndSteel(BlockPos pos) {
        FindItemResult flint = InvUtils.findInHotbar(new Item[]{Items.FLINT_AND_STEEL});
        int fire = flint.slot();
        if (fire != -1) {
            this.mc.player.getInventory().selectedSlot = fire;
            this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, new BlockHitResult(this.mc.player.getPos(), Direction.UP, pos, true));
            if ((Boolean)this.swing.get()) {
                this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }

        }
    }

    private boolean isTrapped(LivingEntity entity) {
        return BlockUtil.getBlock(entity.getBlockPos().add(0, 3, 0)) != Blocks.AIR && BlockUtil.getBlock(entity.getBlockPos().add(1, 2, 0)) != Blocks.AIR && BlockUtil.getBlock(entity.getBlockPos().add(-1, 2, 0)) != Blocks.AIR && BlockUtil.getBlock(entity.getBlockPos().add(0, 2, 1)) != Blocks.AIR && BlockUtil.getBlock(entity.getBlockPos().add(0, 2, 1)) != Blocks.AIR;
    }

    @EventHandler(
        priority = -100
    )
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get()) {
            if (this.renderMode.get() == SexTNT.RenderMode.Fade) {
                this.renderTNTBlocks.sort(Comparator.comparingInt((o) -> {
                    return -o.ticks;
                }));
                this.renderTNTBlocks.forEach((renderBlock) -> {
                    renderBlock.render(event, (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
                });
                this.renderTrapBlocks.sort(Comparator.comparingInt((o) -> {
                    return -o.ticks;
                }));
                this.renderTrapBlocks.forEach((renderBlock) -> {
                    renderBlock.render(event, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
                });
            } else {
                if (this.mc.player == null) {
                    return;
                }

                BlockPos br = this.mc.player.getBlockPos();
                if (BlockUtil.getBlock(br.up(2)) == Blocks.AIR) {
                    this.renderD(event, br.up(2), (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
                }

                if ((Boolean)this.alwaysRender.get()) {
                    this.renderD(event, br.up(2), (Color)this.tntSideColor.get(), (Color)this.tntSideColor2.get(), (Color)this.tntLineColor.get(), (Color)this.tntLineColor2.get(), (ShapeMode)this.tntShapeMode.get(), (Integer)this.width.get());
                }

                Iterator var3 = (new ArrayList(this.trap)).iterator();

                while(var3.hasNext()) {
                    Vec3d b = (Vec3d)var3.next();
                    BlockPos bb = br.add(b.x, b.y, b.z);
                    if (BlockUtil.getBlock(bb) == Blocks.AIR) {
                        this.renderD(event, bb, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
                    }

                    if ((Boolean)this.alwaysRender.get()) {
                        this.renderD(event, bb, (Color)this.trapSideColor.get(), (Color)this.trapSideColor2.get(), (Color)this.trapLineColor.get(), (Color)this.trapLineColor2.get(), (ShapeMode)this.trapShapeMode.get(), (Integer)this.width.get());
                    }
                }
            }
        }

    }

    private void renderD(Render3DEvent event, BlockPos pos, Color side1, Color side2, Color line1, Color line2, ShapeMode shapeMode, int width) {
        if (shapeMode.equals(ShapeMode.Lines) || shapeMode.equals(ShapeMode.Both)) {
            RenderUtil.S(event, pos, 0.99D, 0.0D, 0.01D, line1, line2);
            RenderUtil.TAB(event, pos, 0.99D, 0.01D, true, true, line1, line2);
            if (width == 2) {
                RenderUtil.S(event, pos, 0.98D, 0.0D, 0.02D, line1, line2);
                RenderUtil.TAB(event, pos, 0.98D, 0.02D, true, true, line1, line2);
            }

            if (width == 3) {
                RenderUtil.S(event, pos, 0.97D, 0.0D, 0.03D, line1, line2);
                RenderUtil.TAB(event, pos, 0.97D, 0.03D, true, true, line1, line2);
            }

            if (width == 4) {
                RenderUtil.S(event, pos, 0.96D, 0.0D, 0.04D, line1, line2);
                RenderUtil.TAB(event, pos, 0.96D, 0.04D, true, true, line1, line2);
            }
        }

        if (shapeMode.equals(ShapeMode.Sides) || shapeMode.equals(ShapeMode.Both)) {
            RenderUtil.FS(event, pos, 0.0D, true, true, side1, side2);
        }

    }

    public static enum tntPlaceMode {
        HEAD,
        LEGS,
        MIX;

        // $FF: synthetic method
        private static SexTNT.tntPlaceMode[] $values() {
            return new SexTNT.tntPlaceMode[]{HEAD, LEGS, MIX};
        }
    }

    public static enum RenderMode {
        Fade,
        Default;

        // $FF: synthetic method
        private static SexTNT.RenderMode[] $values() {
            return new SexTNT.RenderMode[]{Fade, Default};
        }
    }

    public static class RenderBlock {
        public Mutable pos = new Mutable();
        public int ticks;

        public SexTNT.RenderBlock set(BlockPos blockPos, int ticks) {
            this.pos.set(blockPos);
            this.ticks = ticks;
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color side1, Color side2, Color line1, Color line2, ShapeMode shapeMode, int width) {
            int preSideA = side1.a;
            int preSideB = side2.a;
            int preLineA = line1.a;
            int preLineB = line2.a;
            side1.a = (int)((double)side1.a * ((double)this.ticks / 10.0D));
            side2.a = (int)((double)side2.a * ((double)this.ticks / 10.0D));
            line1.a = (int)((double)line1.a * ((double)this.ticks / 10.0D));
            line2.a = (int)((double)line2.a * ((double)this.ticks / 10.0D));
            if (shapeMode.equals(ShapeMode.Lines) || shapeMode.equals(ShapeMode.Both)) {
                RenderUtil.S(event, this.pos, 0.99D, 0.0D, 0.01D, line1, line2);
                RenderUtil.TAB(event, this.pos, 0.99D, 0.01D, true, true, line1, line2);
                if (width == 2) {
                    RenderUtil.S(event, this.pos, 0.98D, 0.0D, 0.02D, line1, line2);
                    RenderUtil.TAB(event, this.pos, 0.98D, 0.02D, true, true, line1, line2);
                }

                if (width == 3) {
                    RenderUtil.S(event, this.pos, 0.97D, 0.0D, 0.03D, line1, line2);
                    RenderUtil.TAB(event, this.pos, 0.97D, 0.03D, true, true, line1, line2);
                }

                if (width == 4) {
                    RenderUtil.S(event, this.pos, 0.96D, 0.0D, 0.04D, line1, line2);
                    RenderUtil.TAB(event, this.pos, 0.96D, 0.04D, true, true, line1, line2);
                }
            }

            if (shapeMode.equals(ShapeMode.Sides) || shapeMode.equals(ShapeMode.Both)) {
                RenderUtil.FS(event, this.pos, 0.0D, true, true, side1, side2);
            }

            side1.a = preSideA;
            side2.a = preSideB;
            line1.a = preLineA;
            line2.a = preLineB;
        }
    }
}
