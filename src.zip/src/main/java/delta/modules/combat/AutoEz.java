package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.PlayerUtil;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;

public class AutoEz extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgPops;
    private final SettingGroup sgKills;
    private final SettingGroup sgTargeting;
    private final Setting<Boolean> clearOnDeath;
    private final Setting<Boolean> message;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> randomMsg;
    private final Setting<Boolean> popMsg;
    private final Setting<String> popString;
    private final Setting<List<String>> popMessages;
    private final Setting<Integer> popDelay;
    private final Setting<Boolean> killMsg;
    private final Setting<String> killString;
    private final Setting<List<String>> killMessages;
    private final Setting<Integer> killDelay;
    private final Setting<Boolean> checkTargets;
    private final Setting<Double> range;
    private final Random random;
    private HashMap<UUID, Integer> kills;
    private HashMap<UUID, Integer> pops;
    private int allKills;
    private int killTimer;
    private int popTimer;

    public AutoEz() {
        super(DeltaHack.Autist, "auto-ez", "Send a chat message after killing or poping a player.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgPops = this.settings.createGroup("Pops");
        this.sgKills = this.settings.createGroup("Kills");
        this.sgTargeting = this.settings.createGroup("Targeting");
        this.clearOnDeath = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("clear-on-death")).description("Resets your scores on death.")).defaultValue(true)).build());
        this.message = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("message")).description("Sends messages in the chat when you kill or pop players.")).defaultValue(true)).build());
        this.notify = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("notify")).description("Sends client-side messages with your kill and pop streak after you kill players.")).defaultValue(false)).build());
        this.randomMsg = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("random")).description("Sends random messages every kill or pop.")).defaultValue(true)).build());
        this.popMsg = this.sgPops.add(((Builder)((Builder)((Builder)(new Builder()).name("pop")).description("Sends a messages everytime you pop a player.")).defaultValue(true)).build());
        this.popString = this.sgPops.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("pop-message")).description("The message to send when you poped a player.")).defaultValue("ez pop {player}")).visible(() -> {
            return (Boolean)this.popMsg.get() && !(Boolean)this.randomMsg.get();
        })).build());
        this.popMessages = this.sgPops.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("pop-messages")).description("The random messages to send when you poped a player.")).defaultValue(List.of("{player} stop coping so bad", "{pops} pops on {player} already!"))).visible(() -> {
            return (Boolean)this.popMsg.get() && (Boolean)this.randomMsg.get();
        })).build());
        SettingGroup var10001 = this.sgPops;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("pop-delay")).description("How long to wait in ticks before sending a pop message again.")).defaultValue(15)).min(0);
        Setting var10003 = this.popMsg;
        Objects.requireNonNull(var10003);
        this.popDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        this.killMsg = this.sgKills.add(((Builder)((Builder)((Builder)(new Builder()).name("kill")).description("Sends a messages everytime you kill a player.")).defaultValue(true)).build());
        this.killString = this.sgKills.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("kill-message")).description("The message to send when you killed someone.")).defaultValue("killed {player}")).visible(() -> {
            return (Boolean)this.killMsg.get() && !(Boolean)this.randomMsg.get();
        })).build());
        this.killMessages = this.sgKills.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("kill-messages")).description("The random messages to send when you kill someone.")).defaultValue(List.of("ezzz {player}! Delta Hack on top!", "{player} ☠"))).visible(() -> {
            return (Boolean)this.killMsg.get() && (Boolean)this.randomMsg.get();
        })).build());
        var10001 = this.sgKills;
        var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("kill-delay")).description("How long to wait in ticks before sending a kill message again.")).defaultValue(5)).min(0);
        var10003 = this.killMsg;
        Objects.requireNonNull(var10003);
        this.killDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        this.checkTargets = this.sgTargeting.add(((Builder)((Builder)((Builder)(new Builder()).name("check-targets")).description("Checks if the player is targeted in any module.")).defaultValue(true)).build());
        this.range = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("range")).description("The range a player has to be in with to detect a pop.")).defaultValue(7.0D).min(0.0D).max(50.0D).build());
        this.random = new Random();
    }

    public void onActivate() {
        this.kills = new HashMap();
        this.pops = new HashMap();
        this.allKills = 0;
        this.killTimer = 0;
        this.popTimer = 0;
    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        Packet var3 = event.packet;
        if (var3 instanceof EntityStatusS2CPacket) {
            EntityStatusS2CPacket packet = (EntityStatusS2CPacket)var3;
            if (packet.getStatus() != 35 && packet.getStatus() != 3) {
                return;
            }

            if (packet.getStatus() == 3 && packet.getEntity(this.mc.world) == this.mc.player && (Boolean)this.clearOnDeath.get()) {
                this.onActivate();
            }

            Entity entity = packet.getEntity(this.mc.world);
            if (!this.check(entity, (Double)this.range.get(), true)) {
                return;
            }

            if (packet.getStatus() == 35) {
                this.pops.putIfAbsent(entity.getUuid(), 0);
                this.pops.replace(entity.getUuid(), (Integer)this.pops.get(entity.getUuid()) + 1);
                if ((Boolean)this.popMsg.get() && (this.popTimer >= (Integer)this.popDelay.get() || (Integer)this.popDelay.get() == 0)) {
                    this.sendPopMsg((PlayerEntity)entity);
                    this.popTimer = 0;
                    return;
                }
            }

            if (packet.getStatus() == 3) {
                this.kills.putIfAbsent(entity.getUuid(), 0);
                this.kills.replace(entity.getUuid(), (Integer)this.kills.get(entity.getUuid()) + 1);
                ++this.allKills;
                if ((Boolean)this.killMsg.get() && (this.killTimer >= (Integer)this.killDelay.get() || (Integer)this.killDelay.get() == 0)) {
                    this.sendKillMsg((PlayerEntity)entity);
                    this.pops.replace(entity.getUuid(), 0);
                    this.killTimer = 0;
                }
            }
        }

    }

    @EventHandler
    private void onPostTick(Post event) {
        ++this.killTimer;
        ++this.popTimer;
        if (this.mc != null && this.mc.world != null) {
            Iterator var2 = (new HashSet(this.pops.keySet())).iterator();

            while(var2.hasNext()) {
                UUID uuid = (UUID)var2.next();
                if (this.mc.world.getPlayerByUuid(uuid) == null) {
                    this.pops.replace(uuid, 0);
                }
            }
        }

    }

    private void sendPopMsg(PlayerEntity player) {
        PlayerUtil.sendPlayerMsg(this.apply(player, (Boolean)this.randomMsg.get() && !((List)this.popMessages.get()).isEmpty() ? (((List)this.popMessages.get()).size() > 1 ? (String)((List)this.popMessages.get()).get(this.random.nextInt(((List)this.popMessages.get()).size())) : (String)((List)this.popMessages.get()).get(0)) : (String)this.popString.get()));
    }

    private void sendKillMsg(PlayerEntity player) {
        if ((Boolean)this.message.get()) {
            PlayerUtil.sendPlayerMsg(this.apply(player, (Boolean)this.randomMsg.get() && !((List)this.killMessages.get()).isEmpty() ? (((List)this.killMessages.get()).size() > 1 ? (String)((List)this.killMessages.get()).get(this.random.nextInt(((List)this.killMessages.get()).size())) : (String)((List)this.killMessages.get()).get(0)) : (String)this.killString.get()));
        }

        int pop = this.pops.get(player.getUuid()) == null ? 0 : (Integer)this.pops.get(player.getUuid());
        int kill = this.kills.get(player.getUuid()) == null ? 0 : (Integer)this.kills.get(player.getUuid());
        if ((Boolean)this.notify.get()) {
            String var10001 = player.getGameProfile().getName();
            this.info("Poped " + var10001 + " " + pop + (pop == 1 ? " time" : " times") + " and killed him " + kill + (kill == 1 ? " time." : " times."), new Object[0]);
        }

    }

    private String apply(PlayerEntity player, String message) {
        String string = message.replace("{player}", player.getGameProfile().getName());
        string = string.replace("{online}", String.valueOf(this.mc.getNetworkHandler() != null ? this.mc.getNetworkHandler().getPlayerList().size() : 0));
        string = string.replace("{pops}", String.valueOf(this.pops.get(player.getUuid())));
        string = string.replace("{playerkills}", String.valueOf(this.kills.get(player.getUuid())));
        string = string.replace("{kills}", String.valueOf(this.allKills));
        return string;
    }

    private boolean check(Entity entity, double range, boolean shouldCheckTargets) {
        if (entity instanceof PlayerEntity && entity != this.mc.player && !Friends.get().isFriend((PlayerEntity)entity) && !(distance(this.mc.player.getPos(), entity.getPos()) > range)) {
            if ((Boolean)this.checkTargets.get() && shouldCheckTargets) {
                boolean target = true;
                Iterator var6 = Modules.get().getAll().iterator();

                while(var6.hasNext()) {
                    Module module = (Module)var6.next();
                    if (module.getInfoString() != null && module.getInfoString().contains(((PlayerEntity)entity).getGameProfile().getName())) {
                        target = false;
                        break;
                    }
                }

                return !target;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public static double distance(Vec3d vec1, Vec3d vec2) {
        double dX = vec2.x - vec1.x;
        double dY = vec2.y - vec1.y;
        double dZ = vec2.z - vec1.z;
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }
}
