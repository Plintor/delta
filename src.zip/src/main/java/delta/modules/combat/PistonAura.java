package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.util.PistonUtils;
import delta.utils.BlockUtil;
import delta.utils.DamageUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.RenderUtil;
import delta.utils.TimerUtils;
import delta.utils.WorldUtils;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.hit.BlockHitResult;

public class PistonAura extends Module {
    private final SettingGroup sgTargeting;
    private final SettingGroup sgPosition;
    private final SettingGroup sgFunc;
    private final SettingGroup sgDefault;
    private final SettingGroup sgRender;
    private final Setting<Boolean> selfMode;
    private final Setting<Double> enemyRange;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<SortPriority> priority;
    private final Setting<Double> minDamage;
    private final Setting<Double> minHealth;
    private final Setting<Boolean> pauseOnEat;
    private final Setting<Double> actionRadius;
    private final Setting<Boolean> breakInterfering;
    private final Setting<Boolean> breakCrystals;
    private final Setting<Boolean> deactivateNearestPosition;
    private final Setting<Boolean> useLevers;
    private final Setting<Boolean> autoSwap;
    private final Setting<Boolean> zeroTickDelay;
    private final Setting<Integer> pistonDelay;
    private final Setting<Integer> crystalDelay;
    private final Setting<Integer> cBreakDelay;
    private final Setting<Integer> activateDelay;
    private final Setting<Integer> deactivateDelay;
    private final Setting<Integer> breakDelay;
    public final Setting<Boolean> targetPopInvincibility;
    public final Setting<Integer> targetPopInvincibilityTime;
    private final Setting<Boolean> support;
    private final Setting<Boolean> one;
    private final Setting<Boolean> cSupport;
    private final Setting<Boolean> airPlace;
    private final Setting<Integer> supportDelay;
    private final Setting<Boolean> facePlace;
    private final Setting<Boolean> noTargetDisable;
    private final Setting<Boolean> noResourcesDisable;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> rotateTwo;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> straight;
    private final Setting<Boolean> upo;
    private final Setting<Boolean> faraway;
    private final Setting<Boolean> side;
    private final Setting<Boolean> upper;
    private final Setting<Integer> up;
    private final Setting<Boolean> pistonPush;
    private final Setting<Boolean> surCrystal;
    private final Setting<Boolean> swapBack;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> sideColor2;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> lineColor2;
    private final Setting<Integer> width;
    private final Setting<Boolean> renderProgress;
    private final Setting<Double> progressTextScale;
    private final Setting<SettingColor> textColor;
    private final Setting<SettingColor> crystalSideColor;
    private final Setting<SettingColor> crystalLineColor;
    private final Setting<SettingColor> inactiveCrystalSideColor;
    private final Setting<SettingColor> inactiveCrystalLineColor;
    private final Setting<SettingColor> pistonSideColor;
    private final Setting<SettingColor> pistonLineColor;
    private final Setting<SettingColor> inactivePistonSideColor;
    private final Setting<SettingColor> inactivePistonLineColor;
    private final Setting<SettingColor> buttonSideColor;
    private final Setting<SettingColor> buttonLineColor;
    private final Setting<SettingColor> inactiveButtonSideColor;
    private final Setting<SettingColor> inactiveButtonLineColor;
    private static PistonAura.Action action;
    private static final List<Entity> targets;
    private final TimerUtils targetPoppedTimer;
    private static Entity target;
    private static Entity cEntity;
    private static int timer;
    private static PistonUtils.PosDirPair leverPPos;
    private static FindItemResult leverItem;
    private static BlockPos interferePos;
    private static BlockPos supportPos;
    private static BlockPos cSupportPos;
    private static BlockPos activePos;
    private static BlockPos leverPos;
    private static BlockPos breakPos;
    private static BlockPos cPos;
    private static PistonUtils.PresumePiston pistonPos;
    private final Vec3 vec32;
    private final Vec3 vec3;

    public PistonAura() {
        super(DeltaHack.Combat, "piston-aura", "pushes crystals into the enemy using pistons and deals damage beyond fatal");
        this.sgTargeting = this.settings.createGroup("Targeting");
        this.sgPosition = this.settings.createGroup("Positioning");
        this.sgFunc = this.settings.createGroup("Functionality");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("Render");
        this.selfMode = this.sgTargeting.add(((Builder)((Builder)((Builder)(new Builder()).name("piston-yourself")).description("Sex piston.")).defaultValue(false)).build());
        this.enemyRange = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("enemy-range")).description("The radius in which entities get targeted.")).defaultValue(10.0D).min(0.0D).sliderMax(10.0D).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.entities = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("entities")).description("Entities to attack.")).defaultValue(new Object2BooleanOpenHashMap(0))).onlyAttackable().visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.priority = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("priority")).description("How to filter targets within range.")).defaultValue(SortPriority.ClosestAngle)).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.minDamage = this.sgDefault.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-damage")).description("-")).defaultValue(6.0D).min(0.0D).sliderMax(10.0D).max(36.0D).build());
        this.minHealth = this.sgDefault.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("min-health")).description("The minimum HP of the player required for the module to work.")).defaultValue(6.0D).min(0.0D).sliderMax(20.0D).max(36.0D).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.pauseOnEat = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("pause-on-eat")).description("Pauses Piston Aura if player is eating.")).defaultValue(true)).build());
        this.actionRadius = this.sgFunc.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("action-range")).description("The max distance from player in which to perform actions.")).defaultValue(4.4D).min(0.0D).sliderMax(6.0D).build());
        this.breakInterfering = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("break-interfering")).description("automatically breaks interfering blocks when no positions are found.")).defaultValue(true)).build());
        this.breakCrystals = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("break-interfering-crystal")).description("automatically breaks interfering crystals.")).defaultValue(false)).build());
        this.deactivateNearestPosition = this.sgFunc.add(((Builder)((Builder)(new Builder()).name("deactivate-nearest-piston")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgFunc;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("use-levers")).description("Use levers as activator blocks.")).defaultValue(true);
        Setting var10003 = this.deactivateNearestPosition;
        Objects.requireNonNull(var10003);
        this.useLevers = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.autoSwap = this.sgFunc.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("auto-swap")).description("Automatically puts redstone blocks or levers into hotbar when needed.")).defaultValue(true)).visible(() -> {
            return (Boolean)this.deactivateNearestPosition.get() && (Boolean)this.useLevers.get();
        })).build());
        this.zeroTickDelay = this.sgFunc.add(((Builder)((Builder)(new Builder()).name("zero-tick-delay")).defaultValue(false)).build());
        this.pistonDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("piston-delay")).defaultValue(0)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.crystalDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("place-crystal-delay")).defaultValue(0)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.cBreakDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-crystal-delay")).defaultValue(0)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.activateDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("activate-delay")).defaultValue(0)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.deactivateDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("deactivate-delay")).defaultValue(1)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.breakDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("break-delay")).defaultValue(2)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get();
        })).build());
        this.targetPopInvincibility = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("target-pop-invincibility")).description("Tries to pause all actions when your enemy just popped.")).defaultValue(false)).build());
        var10001 = this.sgFunc;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var1 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("target-pop-time")).description("How many milliseconds to consider for target-pop invincibility")).defaultValue(200)).sliderRange(1, 1000);
        var10003 = this.targetPopInvincibility;
        Objects.requireNonNull(var10003);
        this.targetPopInvincibilityTime = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var1.visible(var10003::get)).build());
        this.support = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("support")).description("Automatically supports the piston.")).defaultValue(false)).build());
        this.one = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("only-one-piston")).description("Only use one piston pos at a time. Slows down the PA a lot but conserves pistons.")).defaultValue(true)).build());
        this.cSupport = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("support-crystal")).description("Automatically supports the crystal.")).defaultValue(true)).build());
        var10001 = this.sgFunc;
        var10002 = (Builder)((Builder)((Builder)(new Builder()).name("air-place")).description("Places blocks mid air.")).defaultValue(true);
        var10003 = this.cSupport;
        Objects.requireNonNull(var10003);
        this.airPlace = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.supportDelay = this.sgFunc.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("support-delay")).defaultValue(2)).range(0, 20).sliderRange(0, 10).visible(() -> {
            return !(Boolean)this.zeroTickDelay.get() && (Boolean)this.support.get();
        })).build());
        this.facePlace = this.sgFunc.add(((Builder)((Builder)((Builder)(new Builder()).name("face-place-compatibility")).description("doesn't place pistons when the damage to target is already good.")).defaultValue(true)).build());
        this.noTargetDisable = this.sgDefault.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("no-targets-disable")).description("disabling when no target.")).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).defaultValue(false)).build());
        this.noResourcesDisable = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("no-resources-disable")).description("disabling when no resources.")).defaultValue(false)).build());
        this.rotate = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("Rotates to the blocks you place server side.")).defaultValue(true)).build());
        this.rotateTwo = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate-client")).description("Rotates client-side to place pistons more precisely.")).defaultValue(true)).build());
        this.swing = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("swing")).description("Renders client-side swinging when placing the blocks.")).defaultValue(false)).build());
        this.straight = this.sgPosition.add(((Builder)((Builder)((Builder)(new Builder()).name("straight-piston-pos")).description("Uses piston positions that are in a straight line with crystal.")).defaultValue(true)).build());
        this.upo = this.sgPosition.add(((Builder)((Builder)((Builder)(new Builder()).name("up-piston-pos")).description("Uses piston positions that have the same X and Z as the crystal pos.")).defaultValue(false)).build());
        this.faraway = this.sgPosition.add(((Builder)((Builder)((Builder)(new Builder()).name("far-away")).description("Uses piston positions that are one block more far away from the crystal.")).defaultValue(true)).build());
        this.side = this.sgPosition.add(((Builder)((Builder)((Builder)(new Builder()).name("side")).description("Uses piston positions that are one block to the side from the crystal.")).defaultValue(true)).build());
        this.upper = this.sgPosition.add(((Builder)((Builder)((Builder)(new Builder()).name("upper-piston-pos")).description("Uses piston positions that are one block up from the crystal.")).defaultValue(true)).build());
        this.up = this.sgPosition.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("max-height")).description("Maximum height above the target's feet.")).defaultValue(3)).sliderRange(1, 3).range(1, 6).build());
        this.pistonPush = this.sgPosition.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("piston-push-yourself")).description("Use positions that can possibly push you out of surround.")).defaultValue(false)).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.surCrystal = this.sgPosition.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("place-surround-break-crystals")).description("Use crystal positions that your surround can possibly surround break you.")).defaultValue(false)).visible(() -> {
            return !(Boolean)this.selfMode.get();
        })).build());
        this.swapBack = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("silent-switch")).description("Switches back after using items.")).defaultValue(false)).build());
        this.notify = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("notify")).description("Notifies you about what's going on.")).defaultValue(false)).build());
        this.render = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render")).description("Renders the current block being mined.")).defaultValue(true)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.shapeMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.ColorSetting.Builder var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.sideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).description("The side color.")).defaultValue(new SettingColor(255, 255, 211, 75))).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color-2");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.sideColor2 = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).description("The side color.")).defaultValue(new SettingColor(150, 150, 120, 60))).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.lineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).description("The line color.")).defaultValue(new SettingColor(255, 255, 211))).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color-2");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.lineColor2 = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).description("The line color.")).defaultValue(new SettingColor(150, 150, 150))).build());
        var10001 = this.sgRender;
        var1 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).range(1, 5).defaultValue(1)).sliderRange(1, 4);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.width = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var10002 = (Builder)((Builder)(new Builder()).name("render-progress")).description("Renders the current block being mined.");
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.renderProgress = var10001.add(((Builder)((Builder)var10002.visible(var10003::get)).defaultValue(true)).build());
        var10001 = this.sgRender;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var4 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("text-scale")).description("How big the damage text should be.")).defaultValue(1.25D).min(1.0D).sliderMax(4.0D);
        var10003 = this.renderProgress;
        Objects.requireNonNull(var10003);
        this.progressTextScale = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var4.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("text-color")).description("The text color.")).defaultValue(new SettingColor(15, 255, 211));
        var10003 = this.renderProgress;
        Objects.requireNonNull(var10003);
        this.textColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("crystal-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(240, 240, 230, 45, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.crystalSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("crystal-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(255, 255, 255, 255, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.crystalLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-crystal-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(240, 240, 230, 10, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactiveCrystalSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-crystal-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(255, 255, 255, 40, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactiveCrystalLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("piston-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(126, 185, 255, 45, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.pistonSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("piston-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(126, 185, 255, 255, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.pistonLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-piston-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(126, 185, 255, 10, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactivePistonSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-piston-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(126, 185, 255, 40, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactivePistonLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("activator-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(240, 52, 42, 45, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.buttonSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("activator-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(250, 18, 32, 255, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.buttonLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-activator-side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(240, 52, 42, 10, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactiveButtonSideColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = (meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("inactive-activator-line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(250, 18, 32, 40, false));
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.inactiveButtonLineColor = var10001.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)var3.visible(var10003::get)).build());
        this.targetPoppedTimer = new TimerUtils();
        this.vec32 = new Vec3();
        this.vec3 = new Vec3();
    }

    public void onActivate() {
        this.targetPoppedTimer.reset();
        timer = 0;
    }

    @EventHandler(
        priority = 150
    )
    public void onPreTick(Pre event) {
        if (!(Boolean)this.straight.get()) {
            this.info("Gay LGBT?", new Object[0]);
            this.warning("Gay LGBT?", new Object[0]);
            this.error("Gay LGBT?", new Object[0]);
        }

        if ((Boolean)this.selfMode.get()) {
            target = this.mc.player;
        } else {
            TargetUtils.getList(targets, this::entityCheck, (SortPriority)this.priority.get(), 1);
            if (!this.targetPoppedTimer.passedMillis((long)(Integer)this.targetPopInvincibilityTime.get())) {
                return;
            }

            if (targets.isEmpty()) {
                if ((Boolean)this.noTargetDisable.get() && !(Boolean)this.selfMode.get()) {
                    this.toggle();
                }

                target = null;
                return;
            }

            target = (Entity)targets.get(0);
        }

        FindItemResult crystal = InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL});
        FindItemResult piston = InvUtils.findInHotbar(new Item[]{Items.PISTON});
        FindItemResult redstone = InvUtils.findInHotbar(new Item[]{Items.REDSTONE_BLOCK});
        leverItem = InvUtils.find(new Item[]{Items.LEVER});
        if (!piston.found()) {
            piston = InvUtils.findInHotbar(new Item[]{Items.STICKY_PISTON});
        }

        if ((!((double)this.mc.player.getHealth() < (Double)this.minHealth.get()) || (Boolean)this.selfMode.get()) && (!(Boolean)this.pauseOnEat.get() || !this.mc.player.isUsingItem() || !this.mc.player.getInventory().getMainHandStack().getItem().isFood())) {
            ++timer;
            FindItemResult supportItem = InvUtils.findInHotbar((itemStack) -> {
                return itemStack.getItem() instanceof BlockItem && itemStack.getItem() != Items.REDSTONE_BLOCK && itemStack.getItem() != Items.PISTON && itemStack.getItem() != Items.OBSIDIAN;
            });
            FindItemResult obsidian = InvUtils.findInHotbar(new Item[]{Items.OBSIDIAN});
            this.calculateStage(redstone.slot(), supportItem.slot(), obsidian.slot());
            if (action == PistonAura.Action.Rotate && !(Boolean)this.swapBack.get() && piston.found()) {
                InvUtils.swap(piston.slot(), false);
            }

            if (action == PistonAura.Action.PlaceRedstone) {
                if (redstone.found()) {
                    if (!(Boolean)this.swapBack.get()) {
                        InvUtils.swap(redstone.slot(), false);
                    }
                } else if ((Boolean)this.autoSwap.get() && leverItem.found()) {
                    FindItemResult fr = InvUtils.find(new Item[]{Items.REDSTONE_BLOCK});
                    if (fr.found()) {
                        InvUtils.move().from(fr.slot()).to(leverItem.slot());
                        redstone = InvUtils.findInHotbar(new Item[]{Items.REDSTONE_BLOCK});
                    }
                }
            }

            if (action != PistonAura.Action.BreakInterfering) {
                interferePos = null;
            } else {
                if ((Boolean)this.notify.get()) {
                    this.warning("Breaking interfering block at position " + interferePos.toString(), new Object[0]);
                }

                BlockUtil.mineBlock(interferePos, (Boolean)this.swing.get(), (Boolean)this.rotate.get());
            }

            if (action != PistonAura.Action.BreakActivator) {
                breakPos = null;
                if (timer > this.getDelay()) {
                    timer = 0;
                    if (action != PistonAura.Action.BreakingCrystal) {
                        cEntity = null;
                    } else {
                        if (!cEntity.isAlive()) {
                            return;
                        }

                        if ((Boolean)this.notify.get()) {
                            this.warning("Breaking crystal.", new Object[0]);
                        }

                        if ((Boolean)this.notify.get()) {
                            this.info(cEntity.getBlockPos().toString(), new Object[0]);
                        }

                        if ((Boolean)this.rotate.get()) {
                            Rotations.rotate(Rotations.getYaw(cEntity), (double)this.mc.player.getPitch());
                        }

                        CrystalUtils.attackCrystal(cEntity, (Boolean)this.swing.get());
                    }

                    if (action != PistonAura.Action.PlaceCrystal) {
                        cPos = null;
                    } else {
                        if (!crystal.found()) {
                            if ((Boolean)this.noResourcesDisable.get()) {
                                this.toggle();
                            }

                            return;
                        }

                        CrystalUtils.placeCrystal(crystal, cPos, (Boolean)this.swing.get(), (Boolean)this.swapBack.get());
                        if ((Boolean)this.notify.get()) {
                            this.info("Placing crystal.", new Object[0]);
                        }
                    }

                    if (action != PistonAura.Action.PlaceRedstone) {
                        activePos = null;
                    } else {
                        WorldUtils.place(activePos, redstone, (Boolean)this.rotate.get(), 80, false, (Boolean)this.swing.get(), false, true);
                        if ((Boolean)this.notify.get()) {
                            this.info("Placing activator at position " + activePos.toString(), new Object[0]);
                        }
                    }

                    if (action != PistonAura.Action.ToggleLever) {
                        leverPos = null;
                    } else {
                        this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofBottomCenter(leverPos), Direction.UP, leverPos, false));
                        if ((Boolean)this.notify.get()) {
                            this.info("Toggling the lever at position " + leverPos.toString(), new Object[0]);
                        }
                    }

                    if (action != PistonAura.Action.PlaceLever) {
                        leverPPos = null;
                    } else {
                        float pitch = leverPPos.dir().equals(Direction.UP) ? -90.0F : (leverPPos.dir().equals(Direction.DOWN) ? 90.0F : 0.0F);
                        if ((Boolean)this.rotateTwo.get()) {
                            this.mc.player.setYaw(leverPPos.dir().asRotation());
                            this.mc.player.setPitch(pitch);
                        } else {
                            Rotations.rotate((double)leverPPos.dir().asRotation(), (double)pitch);
                        }

                        WorldUtils.place(leverPPos.pos(), leverItem, false, 80, false, (Boolean)this.swing.get(), false, true);
                        if ((Boolean)this.notify.get()) {
                            this.info("Placing lever at position " + leverPPos.pos().toString(), new Object[0]);
                        }
                    }

                    if (action != PistonAura.Action.Support) {
                        supportPos = null;
                    } else {
                        WorldUtils.place(supportPos, supportItem, (Boolean)this.rotate.get(), 80, false, (Boolean)this.swing.get(), false, true);
                    }

                    if (action != PistonAura.Action.SupportCrystal) {
                        cSupportPos = null;
                    } else {
                        WorldUtils.place(cSupportPos, obsidian, (Boolean)this.rotate.get(), 80, false, (Boolean)this.swing.get(), false, true);
                    }

                    if (action == PistonAura.Action.Rotate) {
                        this.penis();
                    } else if (action == PistonAura.Action.PlacePiston) {
                        if (!piston.found()) {
                            if ((Boolean)this.noResourcesDisable.get()) {
                                this.toggle();
                            }

                            return;
                        }

                        if ((Boolean)this.notify.get()) {
                            this.info("Placing piston.", new Object[0]);
                        }

                        BlockUtils.place(pistonPos.getPos(), piston, false, 100, true);
                    } else {
                        pistonPos = null;
                    }

                } else {
                    if (action == PistonAura.Action.Rotate) {
                        this.penis();
                    }

                }
            } else {
                if (timer > (Integer)this.deactivateDelay.get()) {
                    BlockUtil.mineBlock(breakPos, (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                    if ((Boolean)this.notify.get()) {
                        this.info("Mining the piston activator at position " + breakPos.toString(), new Object[0]);
                    }
                }

            }
        }
    }

    private void penis() {
        if ((Boolean)this.notify.get()) {
            this.info("Rotating to direction: " + pistonPos.getRotateDir().toString(), new Object[0]);
        }

        if ((Boolean)this.rotateTwo.get()) {
            this.mc.player.setYaw(pistonPos.getRotateDir().asRotation());
            this.mc.player.setPitch(0.0F);
        } else {
            Rotations.rotate((double)pistonPos.getRotateDir().asRotation(), 0.0D);
        }

    }

    private int getDelay() {
        if ((Boolean)this.zeroTickDelay.get()) {
            return 0;
        } else {
            switch(action) {
                case PlacePiston:
                    return 0;
                case Rotate:
                    return (Integer)this.pistonDelay.get();
                case Support:
                case SupportCrystal:
                    return (Integer)this.supportDelay.get();
                case PlaceCrystal:
                    return (Integer)this.crystalDelay.get();
                case PlaceRedstone:
                case PlaceLever:
                    return (Integer)this.activateDelay.get();
                case ToggleLever:
                    return (Integer)this.deactivateDelay.get();
                case BreakingCrystal:
                    return (Integer)this.cBreakDelay.get();
                case BreakInterfering:
                    return (Integer)this.breakDelay.get();
                default:
                    return 0;
            }
        }
    }

    public String getInfoString() {
        return target != null ? (target instanceof PlayerEntity ? target.getEntityName() : target.getName().getString()) + " " + action.name() + " " + timer : "Awaiting for target...";
    }

    private void calculateStage(int red, int sup, int obi) {
        if (action == PistonAura.Action.Rotate && timer >= (Integer)this.pistonDelay.get()) {
            action = PistonAura.Action.PlacePiston;
        } else {
            action = PistonAura.Action.None;
            Entity var6 = target;
            BlockPos pPos;
            BlockPos interfere;
            int j;
            if (!(var6 instanceof PlayerEntity)) {
                pPos = target.getBlockPos();
            } else {
                label252: {
                    PlayerEntity player = (PlayerEntity)var6;
                    pPos = EntityUtil.playerPos(player);
                    Iterator var12 = this.mc.world.getEntities().iterator();

                    Entity entity;
                    do {
                        do {
                            do {
                                if (!var12.hasNext()) {
                                    if ((Boolean)this.facePlace.get()) {
                                        for(int i = 0; i <= 4; ++i) {
                                            for(j = 0; j < 4; ++j) {
                                                interfere = pPos.add(Direction.fromHorizontal(j).getVector()).up(i);
                                                if ((double)DamageUtil.crystalDamage(player, Vec3d.ofBottomCenter(interfere), (Double)this.actionRadius.get() + 2.0D) >= (Double)this.minDamage.get() && CrystalUtils.canPlace(interfere, (Double)this.actionRadius.get(), true)) {
                                                    action = PistonAura.Action.PlaceCrystal;
                                                    cPos = interfere;
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                    break label252;
                                }

                                entity = (Entity)var12.next();
                            } while(!(entity instanceof EndCrystalEntity));
                        } while(!((double)DamageUtil.crystalDamage(player, entity.getPos(), (Double)this.actionRadius.get() + 2.0D) >= (Double)this.minDamage.get()));
                    } while(CrystalUtils.isSurrCrystal(entity, target) && !(Boolean)this.facePlace.get());

                    if ((Boolean)this.notify.get()) {
                        this.info("Found a crystal to break.", new Object[0]);
                    }

                    action = PistonAura.Action.BreakingCrystal;
                    cEntity = entity;
                    return;
                }
            }

            for(int i = 1; i <= 5; ++i) {
                if ((Boolean)this.notify.get()) {
                    this.info("Checking on level " + i + "...", new Object[0]);
                }

                if (BlockUtil.isBlastResist(pPos.up(i - 1))) {
                    return;
                }

                List<PistonUtils.PresumePiston> pistons = PistonUtils.getPresumablePistons(pPos.up(i), (Boolean)this.faraway.get(), (Boolean)this.side.get(), (Boolean)this.upper.get(), (Boolean)this.straight.get(), (Boolean)this.upo.get());
                Iterator var16 = pistons.iterator();

                while(var16.hasNext()) {
                    PistonUtils.PresumePiston piston = (PistonUtils.PresumePiston)var16.next();
                    BlockPos lever = piston.getLeverPos();
                    BlockPos a;
                    if ((Boolean)this.deactivateNearestPosition.get()) {
                        if (PistonUtils.isPiston(piston.getPos())) {
                            a = piston.getRedstoneBlock();
                            if (a != null) {
                                action = PistonAura.Action.BreakActivator;
                                breakPos = a;
                                return;
                            }
                        }

                        if (lever != null && piston.isActivated()) {
                            action = PistonAura.Action.ToggleLever;
                            leverPos = lever;
                            return;
                        }
                    }

                    if (piston.shouldSupportCrystal(pPos) && (Boolean)this.cSupport.get()) {
                        if ((Boolean)this.airPlace.get()) {
                            action = PistonAura.Action.SupportCrystal;
                            cSupportPos = piston.getCrystalPos().down();
                            return;
                        }

                        if (target.isOnGround()) {
                            a = PistonUtils.getRecursiveSupportBlock(piston.getCrystalPos(), (Double)this.actionRadius.get());
                            if (a != null) {
                                if (a.equals(piston.getCrystalPos().down()) && obi != -1) {
                                    action = PistonAura.Action.SupportCrystal;
                                    cSupportPos = a;
                                    return;
                                }

                                if (sup != -1) {
                                    action = PistonAura.Action.Support;
                                    supportPos = a;
                                    return;
                                }

                                if (obi != -1) {
                                    action = PistonAura.Action.SupportCrystal;
                                    cSupportPos = a;
                                    return;
                                }
                            }
                        }
                    }

                    if (piston.isReadyCrystal((Double)this.actionRadius.get()) && !piston.isActivated()) {
                        if ((Boolean)this.useLevers.get()) {
                            if (lever != null) {
                                action = PistonAura.Action.ToggleLever;
                                leverPos = lever;
                                return;
                            }

                            if ((piston.shouldUseLever() || red == -1 && !(Boolean)this.autoSwap.get()) && leverItem.found()) {
                                if (!leverItem.isHotbar() && red != -1 && (Boolean)this.autoSwap.get()) {
                                    InvUtils.move().from(leverItem.slot()).to(red);
                                    leverItem = InvUtils.findInHotbar(new Item[]{Items.LEVER});
                                }

                                List<PistonUtils.PosDirPair> pos = piston.getLeverPlacePair();
                                if (!pos.isEmpty() && !(PlayerUtil.distanceFromEye(((PistonUtils.PosDirPair)pos.get(0)).pos()) > (Double)this.actionRadius.get())) {
                                    action = PistonAura.Action.PlaceLever;
                                    leverPPos = (PistonUtils.PosDirPair)pos.get(0);
                                    return;
                                }
                            }
                        }

                        action = PistonAura.Action.PlaceRedstone;
                        activePos = (BlockPos)piston.getRedstonePos((Double)this.actionRadius.get()).get(0);
                        return;
                    }

                    if (piston.isReadyPiston((Double)this.actionRadius.get(), (Boolean)this.pistonPush.get())) {
                        if (piston.getRedstoneBlock() == null) {
                            action = PistonAura.Action.PlaceCrystal;
                            cPos = piston.getCrystalPos();
                            return;
                        }
                    } else {
                        if ((Boolean)this.one.get() && piston.isReady((Double)this.actionRadius.get())) {
                            return;
                        }

                        if (piston.isPlaceable((Double)this.actionRadius.get(), (Boolean)this.pistonPush.get(), (Boolean)this.surCrystal.get(), (Boolean)this.useLevers.get())) {
                            if (piston.isSupported() || !piston.isSupportable || !(Boolean)this.support.get()) {
                                action = PistonAura.Action.Rotate;
                                pistonPos = piston;
                                return;
                            }

                            if (sup != -1) {
                                supportPos = PistonUtils.getRecursiveSupportBlock(piston.getPos().down(), (Double)this.actionRadius.get());
                                if (supportPos != null) {
                                    action = PistonAura.Action.Support;
                                    return;
                                }
                            }
                        } else if ((Boolean)this.breakCrystals.get()) {
                            Entity e = piston.getInterferingCrystal((Double)this.actionRadius.get());
                            if (e != null) {
                                action = PistonAura.Action.BreakingCrystal;
                                cEntity = e;
                            }
                        }
                    }
                }

                if ((Boolean)this.notify.get()) {
                    this.warning("Couldn't find a piston pos on level " + i, new Object[0]);
                }

                if (i == (Integer)this.up.get()) {
                    if ((Boolean)this.breakInterfering.get()) {
                        for(j = 1; j <= (Integer)this.up.get(); ++j) {
                            interfere = ((PistonUtils.PresumePiston)PistonUtils.getPresumablePistons(pPos.up(j), (Boolean)this.faraway.get(), (Boolean)this.side.get(), (Boolean)this.upper.get(), (Boolean)this.straight.get(), (Boolean)this.upo.get()).get(0)).getInterferingBlock((Double)this.actionRadius.get());
                            if (interfere != null) {
                                if (interferePos == null || BlockUtil.isReplaceable(interferePos)) {
                                    interferePos = interfere;
                                }

                                action = PistonAura.Action.BreakInterfering;
                                break;
                            }
                        }
                    }

                    return;
                }
            }

        }
    }

    @EventHandler
    private void onFinishUsingItem(FinishUsingItemEvent event) {
        if (event.itemStack.getItem().isFood()) {
            timer = -1;
        }

    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        if (target != null) {
            Packet var3 = event.packet;
            if (var3 instanceof EntityStatusS2CPacket) {
                EntityStatusS2CPacket p = (EntityStatusS2CPacket)var3;
                if (p.getStatus() == 35) {
                    if (p.getEntity(this.mc.world).equals(target) && (Boolean)this.targetPopInvincibility.get()) {
                        this.targetPoppedTimer.reset();
                    }

                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get()) {
            BlockPos pepis = null;
            if (interferePos != null) {
                pepis = interferePos;
            } else if (breakPos != null) {
                pepis = breakPos;
            }

            if (pepis != null) {
                if (this.shapeMode.get() != ShapeMode.Sides) {
                    for(int i = 1; i <= 4; ++i) {
                        if ((Integer)this.width.get() == i) {
                            RenderUtil.S(event, pepis, (double)(1.0F - (float)i / 100.0F), 0.0D, (double)((float)i / 100.0F), (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                            RenderUtil.TAB(event, pepis, (double)(1.0F - (float)i / 100.0F), (double)((float)i / 100.0F), true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                        }
                    }
                }

                if (this.shapeMode.get() != ShapeMode.Lines) {
                    RenderUtil.FS(event, pepis, 0.0D, true, true, (Color)this.sideColor.get(), (Color)this.sideColor2.get());
                }
            }

            if (pistonPos != null) {
                List<BlockPos> poss = pistonPos.getRedstonePos((Double)this.actionRadius.get());
                if (poss.isEmpty()) {
                    return;
                }

                BlockPos pos = (BlockPos)poss.get(0);
                if (action != PistonAura.Action.Rotate && action != PistonAura.Action.PlacePiston) {
                    event.renderer.box(pistonPos.getPos(), (Color)this.inactivePistonSideColor.get(), (Color)this.inactivePistonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    if (action == PistonAura.Action.PlaceCrystal) {
                        event.renderer.box(pistonPos.getCrystalPos(), (Color)this.crystalSideColor.get(), (Color)this.crystalLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                        event.renderer.box(pos, (Color)this.inactiveButtonSideColor.get(), (Color)this.inactiveButtonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    } else if (action == PistonAura.Action.PlaceRedstone) {
                        event.renderer.box(pistonPos.getCrystalPos(), (Color)this.inactiveCrystalSideColor.get(), (Color)this.inactiveCrystalLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                        event.renderer.box(pos, (Color)this.buttonSideColor.get(), (Color)this.buttonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    } else {
                        event.renderer.box(pistonPos.getCrystalPos(), (Color)this.inactiveCrystalSideColor.get(), (Color)this.inactiveCrystalLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                        event.renderer.box(pos, (Color)this.inactiveButtonSideColor.get(), (Color)this.inactiveButtonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    }
                } else {
                    event.renderer.box(pistonPos.getPos(), (Color)this.pistonSideColor.get(), (Color)this.pistonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    event.renderer.box(pistonPos.getCrystalPos(), (Color)this.inactiveCrystalSideColor.get(), (Color)this.inactiveCrystalLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                    event.renderer.box(pos, (Color)this.inactiveButtonSideColor.get(), (Color)this.inactiveButtonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
                }
            }

        }
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if ((Boolean)this.render.get()) {
            BlockPos pepis = null;
            if (interferePos != null) {
                pepis = interferePos;
            } else if (breakPos != null) {
                pepis = breakPos;
            }

            if ((Boolean)this.renderProgress.get() && pepis != null && target != null) {
                this.vec3.set((double)pepis.getX() + 0.5D, (double)pepis.getY() + 0.5D, (double)pepis.getZ() + 0.5D);
                this.vec32.set((double)pepis.getX() + 0.5D, (double)pepis.getY() + 0.8D, (double)pepis.getZ() + 0.5D);
                float ownBreakingStage = ((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress();
                String text;
                double w;
                if (NametagUtils.to2D(this.vec32, (Double)this.progressTextScale.get())) {
                    NametagUtils.begin(this.vec32);
                    TextRenderer.get().begin(1.0D, true, true);
                    text = target.getEntityName();
                    w = TextRenderer.get().getWidth(text) / 2.0D;
                    TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                    TextRenderer.get().end();
                    NametagUtils.end();
                }

                if (NametagUtils.to2D(this.vec3, (Double)this.progressTextScale.get())) {
                    NametagUtils.begin(this.vec3);
                    TextRenderer.get().begin(1.0D, false, true);
                    Object[] var10001 = new Object[]{ownBreakingStage * 100.0F};
                    text = String.format("%.2f", var10001) + "%";
                    w = TextRenderer.get().getWidth(text) / 2.0D;
                    TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                    TextRenderer.get().end();
                    NametagUtils.end();
                }

            }
        }
    }

    private boolean entityCheck(Entity entity) {
        if (!entity.equals(this.mc.player) && !entity.equals(this.mc.cameraEntity)) {
            if ((!(entity instanceof LivingEntity) || !((LivingEntity)entity).isDead()) && entity.isAlive()) {
                if (PlayerUtil.distanceFromEye(entity) > (Double)this.enemyRange.get()) {
                    return false;
                } else if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType())) {
                    return false;
                } else if (entity instanceof PlayerEntity) {
                    return ((PlayerEntity)entity).isCreative() ? false : Friends.get().shouldAttack((PlayerEntity)entity);
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    static {
        action = PistonAura.Action.None;
        targets = new ArrayList();
    }

    public static enum Action {
        Rotate,
        Support,
        PlaceLever,
        PlacePiston,
        ToggleLever,
        PlaceCrystal,
        PlaceRedstone,
        SupportCrystal,
        BreakActivator,
        BreakingCrystal,
        BreakInterfering,
        None;

        // $FF: synthetic method
        private static PistonAura.Action[] $values() {
            return new PistonAura.Action[]{Rotate, Support, PlaceLever, PlacePiston, ToggleLever, PlaceCrystal, PlaceRedstone, SupportCrystal, BreakActivator, BreakingCrystal, BreakInterfering, None};
        }
    }
}
