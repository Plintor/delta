package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.util.PacketUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.item.ChorusFruitItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.block.ShapeContext;

public class SelfTrapPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgMisc;
    private final SettingGroup sgAntiCity;
    private final SettingGroup sgRender;
    private final Setting<Integer> delay;
    private final Setting<Integer> bpt;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> rotate;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> downPlace;
    private final Setting<Boolean> antiFacePlace;
    private final Setting<Boolean> jumpOnTNT;
    private final Setting<Boolean> antiCev;
    private final Setting<Boolean> antiCevTwo;
    private final Setting<Boolean> keep;
    private final Setting<Boolean> antiObed;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> onlyHole;
    private final Setting<Boolean> disableOnTp;
    private final Setting<Boolean> pauseOnUse;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private static final List<BlockPos> placePositions = new ArrayList();
    private boolean shouldUnPress;
    private boolean shouldAntiCevUp;
    private boolean shouldAntiCevNorth;
    private boolean shouldAntiCevSouth;
    private boolean shouldAntiCevWest;
    private boolean shouldAntiCevEast;
    private int timer;

    public SelfTrapPlus() {
        super(DeltaHack.Combat, "self-trap+", "Places obsidian above your head.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgMisc = this.settings.createGroup("Misc");
        this.sgAntiCity = this.settings.createGroup("Delta Safety");
        this.sgRender = this.settings.createGroup("Render");
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Extra delay between block bursts. (0 = every tick)")).defaultValue(1)).sliderRange(0, 5).build());
        this.bpt = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks-per-tick")).description("How many blocks can be placed per one tick.")).defaultValue(1)).sliderMin(1).sliderMax(5).build());
        this.packet = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("packet")).description("Packet block placing method.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when placing.")).defaultValue(false)).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("Which blocks used for placing.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.downPlace = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-down")).description("Places everything one block down if you're in prone")).defaultValue(true)).build());
        this.antiFacePlace = this.sgAntiCity.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-face-place")).description("Breaks crystals that don't let you place your selftrap.")).defaultValue(true)).build());
        this.jumpOnTNT = this.sgAntiCity.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("jump-on-tnt")).description("Automatically jumps to trick TNT aura")).defaultValue(true)).build());
        this.antiCev = this.sgAntiCity.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-cev")).description("Places on 2 blocks on top of your head when needed.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgAntiCity;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-cev-two")).description("Places on 4 blocks on side-tops of your head when needed.")).defaultValue(true);
        Setting var10003 = this.antiCev;
        Objects.requireNonNull(var10003);
        this.antiCevTwo = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgAntiCity;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("keep-placing")).description("Force-keeps positions in the place block list")).defaultValue(true);
        var10003 = this.antiCev;
        Objects.requireNonNull(var10003);
        this.keep = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.antiObed = this.sgAntiCity.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-bed")).description("Places a button when in the nether.")).defaultValue(true)).build());
        this.onlyOnGround = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only when you standing on blocks.")).defaultValue(true)).build());
        this.onlyHole = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-in-hole")).description("-")).defaultValue(true)).build());
        this.disableOnTp = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("disable-on-chorus")).description("Automatically disables when you eat a chorus.")).defaultValue(true)).build());
        this.pauseOnUse = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-on-use")).description("Pauses self-trap if player is using item.")).defaultValue(false)).build());
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Client side hand-swing")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders a block overlay where the obsidian will be placed.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
        this.shouldUnPress = false;
        this.shouldAntiCevUp = false;
        this.shouldAntiCevNorth = false;
        this.shouldAntiCevSouth = false;
        this.shouldAntiCevWest = false;
        this.shouldAntiCevEast = false;
    }

    public void onActivate() {
        this.timer = 0;
        placePositions.clear();
        this.shouldAntiCevUp = false;
        this.shouldAntiCevNorth = false;
        this.shouldAntiCevSouth = false;
        this.shouldAntiCevWest = false;
        this.shouldAntiCevEast = false;
    }

    @EventHandler
    private void onTick(Pre event) {
        FindItemResult block = InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        });
        placePositions.clear();
        if (!(Boolean)this.onlyOnGround.get() || this.mc.player.isOnGround()) {
            if (!(Boolean)this.pauseOnUse.get() || !this.mc.player.isUsingItem()) {
                if (block.found()) {
                    this.findPlacePos();
                    this.antiEntity(block);
                    int places = 0;
                    if (this.timer == 0) {
                        places = (Integer)this.bpt.get();
                        if (EntityUtil.isMonke(this.mc.player, false, BlockUtil.BlastResistantType.AnyBlock) && (Boolean)this.onlyHole.get()) {
                            return;
                        }

                        this.timer = (Integer)this.delay.get();
                    } else {
                        --this.timer;
                    }

                    if (!placePositions.isEmpty()) {
                        Iterator var4 = placePositions.iterator();

                        BlockPos b;
                        while(var4.hasNext()) {
                            b = (BlockPos)var4.next();
                            if (places != 0 && b != null) {
                                if ((Boolean)this.packet.get()) {
                                    PacketUtils.packetPlace(b, block, (Boolean)this.rotate.get(), (Boolean)this.swing.get());
                                } else {
                                    BlockUtils.place(b, block, (Boolean)this.rotate.get(), 50);
                                }

                                --places;
                            }
                        }

                        FindItemResult button = InvUtils.findInHotbar((itemStack) -> {
                            return Block.getBlockFromItem(itemStack.getItem()) instanceof AbstractButtonBlock;
                        });
                        b = EntityUtil.playerPos(this.mc.player).up();
                        if (places != 0 && button.found() && !this.mc.world.getDimension().comp_648() && (Boolean)this.antiObed.get() && BlockUtil.isReplaceable(b)) {
                            BlockUtils.place(b, button, (Boolean)this.rotate.get(), 50, (Boolean)this.swing.get(), false, true);
                        }

                    }
                }
            }
        }
    }

    private void antiEntity(FindItemResult block) {
        Iterator var2 = this.mc.world.getEntities().iterator();

        while(var2.hasNext()) {
            Entity entity = (Entity)var2.next();
            if ((Boolean)this.antiFacePlace.get() && !placePositions.isEmpty() && entity instanceof EndCrystalEntity && CrystalUtils.isPosFacePlaceCrystal(entity)) {
                this.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, this.mc.player.isSneaking()));
            }

            if (entity.getBlockPos().equals(EntityUtil.playerPos(this.mc.player).up(2)) && entity instanceof TntEntity && (Boolean)this.jumpOnTNT.get()) {
                this.shouldUnPress = !this.mc.options.jumpKey.isPressed();
                this.mc.options.jumpKey.setPressed(true);
            } else if (this.shouldUnPress) {
                this.mc.options.jumpKey.setPressed(false);
            }

            if (entity instanceof EndCrystalEntity && (Boolean)this.antiCev.get()) {
                BlockPos tPos = EntityUtil.playerPos(this.mc.player).up(2);
                BlockPos ce = entity.getBlockPos();
                if (ce.equals(tPos.up())) {
                    this.breakCrystal(entity, block);
                    if ((Boolean)this.keep.get()) {
                        this.shouldAntiCevUp = true;
                    }
                }

                if ((Boolean)this.antiCevTwo.get()) {
                    if (ce.equals(tPos.west())) {
                        this.breakCrystal(entity, block);
                        if ((Boolean)this.keep.get()) {
                            this.shouldAntiCevWest = true;
                        }
                    }

                    if (ce.equals(tPos.east())) {
                        this.breakCrystal(entity, block);
                        if ((Boolean)this.keep.get()) {
                            this.shouldAntiCevEast = true;
                        }
                    }

                    if (ce.equals(tPos.north())) {
                        this.breakCrystal(entity, block);
                        if ((Boolean)this.keep.get()) {
                            this.shouldAntiCevNorth = true;
                        }
                    }

                    if (ce.equals(tPos.south())) {
                        this.breakCrystal(entity, block);
                        if ((Boolean)this.keep.get()) {
                            this.shouldAntiCevSouth = true;
                        }
                    }
                }
            }
        }

    }

    @EventHandler
    private void onFinishUsingItem(FinishUsingItemEvent event) {
        if (event.itemStack.getItem() instanceof ChorusFruitItem && (Boolean)this.disableOnTp.get()) {
            this.toggle();
        }

    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && !placePositions.isEmpty()) {
            Iterator var2 = placePositions.iterator();

            while(var2.hasNext()) {
                BlockPos pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

        }
    }

    private void findPlacePos() {
        placePositions.clear();
        BlockPos pos = EntityUtil.playerPos(this.mc.player);
        if (this.mc.player.isInSwimmingPose() && (Boolean)this.downPlace.get()) {
            pos = pos.down();
        }

        this.add(pos.add(0, 2, 0));
        this.add(pos.add(1, 1, 0));
        this.add(pos.add(-1, 1, 0));
        this.add(pos.add(0, 1, 1));
        this.add(pos.add(0, 1, -1));
        pos = pos.up(2);
        if (this.shouldAntiCevUp) {
            this.add(pos.up());
        }

        if (this.shouldAntiCevNorth) {
            this.add(pos.north());
        }

        if (this.shouldAntiCevSouth) {
            this.add(pos.south());
        }

        if (this.shouldAntiCevWest) {
            this.add(pos.west());
        }

        if (this.shouldAntiCevEast) {
            this.add(pos.east());
        }

    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() >= 600.0F && block.getHardness() > 0.0F;
    }

    private void add(BlockPos blockPos) {
        if (!placePositions.contains(blockPos) && BlockUtil.isReplaceable(blockPos) && (this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent()) || (Boolean)this.antiFacePlace.get())) {
            placePositions.add(blockPos);
        }

    }

    private void breakCrystal(Entity entity, FindItemResult block) {
        this.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, this.mc.player.isSneaking()));
        this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        BlockUtils.place(entity.getBlockPos(), block, (Boolean)this.rotate.get(), 50);
    }
}
