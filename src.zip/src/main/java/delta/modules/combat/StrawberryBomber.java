package delta.modules.combat;

import delta.DeltaHack;
import delta.modules.ModuleExtended;
import delta.util.CrystalUtils;
import delta.utils.BlockUtil;
import delta.utils.DamageUtil;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class StrawberryBomber extends ModuleExtended {
    private final Setting<Double> targetRange = this.setting("target-range", "the max distance from the user to search for targets.", 15.0D, this.getGroup(), 5.0D, 20.0D, 5.0D, 15.0D);
    private final Setting<Double> range = this.setting("range", "the max distance from the user to search for crystal pos.", 4.5D, this.getGroup(), 0.0D, 10.0D, 2.0D, 5.0D);
    private final Setting<Double> radius = this.setting("radius", "the max distance from the enemy to search for crystal pos.", 6.0D, this.getGroup(), 3.0D, 10.0D, 4.0D, 6.0D);
    private final Setting<Integer> delayPl = this.setting("place-delay", "the amount of ticks to wait since the last crystal place to place another.", 1, this.getGroup("Delays"), 0, 10, 0, 10);
    private final Setting<Integer> delayBr = this.setting("break-delay", "the amount of ticks to wait since the last crystal break to break another.", 1, this.getGroup("Delays"), 0, 10, 0, 10);
    private final Setting<Boolean> fastBreak = this.setting("fast-break", "be able to break and place at the same time.", true, this.getGroup("Delays"));
    private final Setting<Double> minDmg = this.setting("min-place-damage", "The minimal damage to the enemy to place crystals.", 6.0D, this.getGroup(), 3.0D, 36.0D, 4.0D, 8.0D);
    private final Setting<Boolean> ignoreTerrain = this.setting("ignore-terrain", "Ignore blocks if they can be blown up by crystals.", true, this.getGroup());
    private final Setting<Boolean> support = this.setting("support", "Place obsidian to support the crystals.", true, this.getGroup());
    private final Setting<Boolean> ratio = this.setting("use-damage-ratio", "Ignore self damage if the enemyDmg/selfDmg ratio fits and the crystal doesn't suicide you", true, this.getGroup());
    private final Setting<Double> maxDmg = this.setting("min-place-damage", "The max damage to self to place and break crystals.", 3.0D, this.getGroup(), 3.0D, 10.0D, 4.0D, 6.0D);
    private final Setting<Double> ratioDmg = this.setting("ratio", "the minimal enemyDmg/selfDmg ratio to use", 2.0D, this.getGroup(), 1.0D, 10.0D, 1.0D, 3.0D);
    public final List<PlayerEntity> targets = new ArrayList();
    private int bTimer;
    private int pTimer;

    public StrawberryBomber() {
        super(DeltaHack.Combat, "strawberry-bomb+", "DOES NOT WORK YET. THIS IS A TEST.");
    }

    public void onActivate() {
        this.bTimer = 0;
        this.pTimer = 0;
        this.targets.clear();
    }

    @EventHandler
    public void onTick(Pre event) {
        Vec3d pos = this.mc.player.getPos();
        this.targets.clear();
        Iterator var3 = this.mc.world.getPlayers().iterator();

        while(var3.hasNext()) {
            PlayerEntity pl = (PlayerEntity)var3.next();
            if (!pl.getAbilities().creativeMode && pl != this.mc.player && !(BlockUtil.distance(pos, pl.getPos()) > (Double)this.targetRange.get()) && !pl.isDead() && pl.isAlive() && Friends.get().shouldAttack(pl)) {
                this.targets.add(pl);
            }
        }

        if (!this.targets.isEmpty()) {
            if (this.pTimer == 0) {
                this.tryPlace(pos, EntityUtil.playerPos(this.mc.player));
                this.pTimer = (Integer)this.delayPl.get();
            } else {
                --this.pTimer;
            }

        }
    }

    private void tryPlace(Vec3d pos, BlockPos bPos) {
        double r = (Double)this.range.get();
        int ir = (int)Math.floor(r);

        for(int x = ir; x > -ir; --x) {
            for(int y = ir; y > -ir; --y) {
                for(int z = ir; z > -ir; --z) {
                    new StrawberryBomber.Crystal(bPos.add(x, y, z), pos);
                }
            }
        }

    }

    private class Crystal {
        public final BlockPos pos;
        public boolean placeable;
        public boolean needSupport;
        public double damage;

        public Crystal(BlockPos crystal, Vec3d player) {
            this.pos = crystal;
            int place = CrystalUtils.strawberryUtil(crystal, true);
            if (place == 0) {
                this.placeable = false;
            } else {
                if (place == 1) {
                    if (!(Boolean)StrawberryBomber.this.support.get()) {
                        this.placeable = false;
                        return;
                    }

                    this.needSupport = true;
                } else {
                    this.needSupport = false;
                }

                Vec3d che = Vec3d.ofBottomCenter(crystal);
                if (player.distanceTo(che) > (Double)StrawberryBomber.this.range.get()) {
                    this.placeable = false;
                } else {
                    double self = (double)DamageUtil.crystalDamage(StrawberryBomber.this.mc.player, che, true, 10.0D, (Boolean)StrawberryBomber.this.ignoreTerrain.get(), false);
                    if (self > (Double)StrawberryBomber.this.maxDmg.get() && !(Boolean)StrawberryBomber.this.ratio.get()) {
                        this.placeable = false;
                    } else {
                        double dmg = 0.0D;

                        PlayerEntity t;
                        for(Iterator var10 = StrawberryBomber.this.targets.iterator(); var10.hasNext(); dmg += (double)DamageUtil.crystalDamage(t, che, true, (Double)StrawberryBomber.this.radius.get(), (Boolean)StrawberryBomber.this.ignoreTerrain.get(), false)) {
                            t = (PlayerEntity)var10.next();
                        }

                    }
                }
            }
        }
    }
}
