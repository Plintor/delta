package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.InvUtil;
import delta.utils.RenderUtil;
import delta.utils.TimerUtils;
import delta.utils.WorldUtils;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class FeetTroll extends Module {
    private final SettingGroup sgDefault;
    private final Setting<Double> enemyRange;
    private final Setting<SortPriority> priority;
    private final Setting<Double> cityRange;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> notify;
    private final SettingGroup sgMining;
    private final Setting<FeetTroll.MineMode> mineMode;
    private final Setting<Boolean> breakInterfering;
    private final Setting<List<Block>> placeBlocksList;
    private final SettingGroup sgSwap;
    public final Setting<Boolean> autoSwap;
    private final Setting<FeetTroll.SwapMode> swapMode;
    public final Setting<Double> swapDelay;
    private final SettingGroup sgToggleAndPause;
    private final Setting<Boolean> stopPlacingOnEat;
    private final Setting<Boolean> stopPlacingOnDrink;
    private final SettingGroup sgRender;
    private final Setting<FeetTroll.Swing> swing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> sideColor2;
    private final Setting<SettingColor> lineColor;
    private final Setting<SettingColor> lineColor2;
    private final Setting<Integer> width;
    private final Setting<Boolean> renderProgress;
    private final Setting<Double> progressTextScale;
    private final Setting<SettingColor> textColor;
    private PlayerEntity target;
    private final TimerUtils swapTimer;
    private static BlockPos minePos;
    private final Vec3 vec3;
    private final Vec3 vec32;

    public FeetTroll() {
        super(DeltaHack.Old, "auto-feet-troll", "Automatically trolls the target by mining the block they're standing on and replacing it with a non-full one.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.enemyRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("enemy-range")).description("The radius in which players get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.priority = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.ClosestAngle)).build());
        this.cityRange = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("city-range")).description("The radius in which city get targeted.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Automatically rotates you towards the city block.")).defaultValue(false)).build());
        this.notify = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("Notifies you about the work of the module.")).defaultValue(false)).build());
        this.sgMining = this.settings.createGroup("Mining");
        this.mineMode = this.sgMining.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mining")).description("Block breaking method")).defaultValue(FeetTroll.MineMode.Packet)).build());
        this.breakInterfering = this.sgMining.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("break-interfering")).description("Breaks interfering blocks to break through the surround.")).defaultValue(true)).build());
        this.placeBlocksList = this.sgMining.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("place-block-list")).description("List of blocks to place to troll the opponent.")).defaultValue(Collections.singletonList(Blocks.ENDER_CHEST))).build());
        this.sgSwap = this.settings.createGroup("Swap");
        this.autoSwap = this.sgSwap.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("autoSwap")).description("Automatically picks up the pickaxe when breaking.")).defaultValue(true)).build());
        this.swapMode = this.sgSwap.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("swap-mode")).description("Which way to swap.")).defaultValue(FeetTroll.SwapMode.Normal)).build());
        this.swapDelay = this.sgSwap.add(((Builder)((Builder)(new Builder()).name("swapDelay")).description("The delay between swap.")).defaultValue(0.0D).min(0.0D).sliderMax(10.0D).build());
        this.sgToggleAndPause = this.settings.createGroup("Toggle and Pause");
        this.stopPlacingOnEat = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-placing-on-eat")).description("Stop-placing-on-eat.")).defaultValue(false)).build());
        this.stopPlacingOnDrink = this.sgToggleAndPause.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-placing-on-drink")).description("Stop-placing-on-drink.")).defaultValue(false)).build());
        this.sgRender = this.settings.createGroup("Render");
        this.swing = this.sgMining.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("swing")).description("Block breaking method")).defaultValue(FeetTroll.Swing.PACKET)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders the current block being mined.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.sideColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color-2")).description("The side color.")).defaultValue(new SettingColor(15, 255, 211, 75))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.lineColor2 = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color-2")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.width = this.sgRender.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("width")).defaultValue(1)).min(1).max(5).sliderMin(1).sliderMax(4).build());
        this.renderProgress = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-progress")).description("Renders the current block being mined.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgRender;
        Builder var10002 = ((Builder)((Builder)(new Builder()).name("text-scale")).description("How big the damage text should be.")).defaultValue(1.25D).min(1.0D).sliderMax(4.0D);
        Setting var10003 = this.renderProgress;
        Objects.requireNonNull(var10003);
        this.progressTextScale = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.textColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("text-color")).description("The line color.")).defaultValue(new SettingColor(15, 255, 211))).build());
        this.swapTimer = new TimerUtils();
        this.vec3 = new Vec3();
        this.vec32 = new Vec3();
    }

    public void onDeactivate() {
        this.target = null;
    }

    @EventHandler
    private void onTick(Pre event) {
        if (!PlayerUtils.shouldPause(false, (Boolean)this.stopPlacingOnEat.get(), (Boolean)this.stopPlacingOnDrink.get())) {
            this.target = TargetUtils.getPlayerTarget((Double)this.enemyRange.get(), (SortPriority)this.priority.get());
            FindItemResult block = InvUtils.findInHotbar((itemStack) -> {
                return ((List)this.placeBlocksList.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
            });
            if (this.target != null && block.found()) {
                BlockPos pPos = this.target.getBlockPos();
                if (this.target.isOnGround()) {
                    if (((List)this.placeBlocksList.get()).contains(BlockUtil.getBlock(pPos))) {
                        return;
                    }

                    if (!BlockUtil.isBreakable(EntityUtil.playerPos(this.target).down())) {
                        return;
                    }

                    FindItemResult pickaxe = InvUtil.findPick();
                    int prev = this.mc.player.getInventory().selectedSlot;
                    if (!pickaxe.isHotbar()) {
                        this.toggle();
                    }

                    if (!this.swapTimer.hasPassed((Double)this.swapDelay.get() * 50.0D)) {
                        return;
                    }

                    if ((Boolean)this.autoSwap.get()) {
                        this.mc.player.getInventory().selectedSlot = pickaxe.slot();
                    }

                    this.swapTimer.reset();
                    boolean isTargetMonke = false;

                    BlockPos pos;
                    for(Iterator var7 = EntityUtil.getSurroundPos(this.target).iterator(); var7.hasNext(); minePos = this.bestPos(pos, minePos)) {
                        pos = (BlockPos)var7.next();
                        pos = pos.down();
                        if (BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), pos) <= (Double)this.cityRange.get()) {
                            pos = null;
                        }

                        if (pos != null && BlockUtil.isAir(pos)) {
                            isTargetMonke = true;
                        }
                    }

                    if (!(Boolean)this.breakInterfering.get() || isTargetMonke) {
                        minePos = pPos.down();
                    }

                    if (minePos != null) {
                        this.mine(minePos);
                    }

                    if (this.swapMode.get() == FeetTroll.SwapMode.Silent) {
                        this.mc.player.getInventory().selectedSlot = prev;
                    }
                } else {
                    WorldUtils.place(pPos, block, (Boolean)this.rotate.get(), 80, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, this.swing.get() == FeetTroll.Swing.FULL, false, true);
                }

            }
        }
    }

    private BlockPos bestPos(BlockPos FiRst, BlockPos SeCon) {
        if (FiRst == null) {
            return SeCon;
        } else if (SeCon == null) {
            return FiRst;
        } else {
            return BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), FiRst) < BlockUtil.distance(new BlockPos(this.mc.player.getEyePos()), SeCon) ? FiRst : SeCon;
        }
    }

    private void mine(BlockPos pos) {
        if (((FeetTroll.MineMode)this.mineMode.get()).equals(FeetTroll.MineMode.Vanilla)) {
            BlockUtils.breakBlock(pos, this.swing.get() == FeetTroll.Swing.FULL || this.swing.get() == FeetTroll.Swing.PACKET);
        } else {
            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.DOWN));
            if (this.swing.get() == FeetTroll.Swing.FULL) {
                this.mc.player.swingHand(Hand.MAIN_HAND);
            }

            if (this.swing.get() == FeetTroll.Swing.PACKET) {
                this.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }

            this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.DOWN));
        }

    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && minePos != null && !this.mc.world.getBlockState(minePos).isAir()) {
            if (((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Lines) || ((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Both)) {
                RenderUtil.S(event, minePos, 0.99D, 0.0D, 0.01D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                RenderUtil.TAB(event, minePos, 0.99D, 0.01D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                if ((Integer)this.width.get() == 2) {
                    RenderUtil.S(event, minePos, 0.98D, 0.0D, 0.02D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, minePos, 0.98D, 0.02D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }

                if ((Integer)this.width.get() == 3) {
                    RenderUtil.S(event, minePos, 0.97D, 0.0D, 0.03D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, minePos, 0.97D, 0.03D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }

                if ((Integer)this.width.get() == 4) {
                    RenderUtil.S(event, minePos, 0.96D, 0.0D, 0.04D, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                    RenderUtil.TAB(event, minePos, 0.96D, 0.04D, true, true, (Color)this.lineColor.get(), (Color)this.lineColor2.get());
                }
            }

            if (((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Sides) || ((ShapeMode)this.shapeMode.get()).equals(ShapeMode.Both)) {
                RenderUtil.FS(event, minePos, 0.0D, true, true, (Color)this.sideColor.get(), (Color)this.sideColor2.get());
            }

            if (BlockUtil.distance(EntityUtil.playerPos(this.mc.player), minePos) > 6.0D) {
                minePos = null;
            }
        }

    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if ((Boolean)this.render.get() && (Boolean)this.renderProgress.get()) {
            if (this.target != null && minePos != null && !this.mc.world.getBlockState(minePos).isAir() && ((FeetTroll.MineMode)this.mineMode.get()).equals(FeetTroll.MineMode.Vanilla)) {
                this.vec3.set((double)minePos.getX() + 0.5D, (double)minePos.getY() + 0.5D, (double)minePos.getZ() + 0.5D);
                this.vec32.set((double)minePos.getX() + 0.5D, (double)minePos.getY() + 0.8D, (double)minePos.getZ() + 0.5D);
                float ownBreakingStage = ((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress();
                String text;
                double w;
                if (NametagUtils.to2D(this.vec32, (Double)this.progressTextScale.get())) {
                    NametagUtils.begin(this.vec32);
                    TextRenderer.get().begin(1.0D, true, true);
                    text = this.target.getEntityName();
                    w = TextRenderer.get().getWidth(text) / 2.0D;
                    TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                    TextRenderer.get().end();
                    NametagUtils.end();
                }

                if (NametagUtils.to2D(this.vec3, (Double)this.progressTextScale.get())) {
                    NametagUtils.begin(this.vec3);
                    TextRenderer.get().begin(1.0D, false, true);
                    Object[] var10001 = new Object[]{ownBreakingStage * 100.0F};
                    text = String.format("%.2f", var10001) + "%";
                    w = TextRenderer.get().getWidth(text) / 2.0D;
                    TextRenderer.get().render(text, -w, 0.0D, (Color)this.textColor.get(), true);
                    TextRenderer.get().end();
                    NametagUtils.end();
                }
            }

        }
    }

    public static enum MineMode {
        Vanilla,
        Packet;

        // $FF: synthetic method
        private static FeetTroll.MineMode[] $values() {
            return new FeetTroll.MineMode[]{Vanilla, Packet};
        }
    }

    public static enum SwapMode {
        Normal,
        Silent;

        // $FF: synthetic method
        private static FeetTroll.SwapMode[] $values() {
            return new FeetTroll.SwapMode[]{Normal, Silent};
        }
    }

    public static enum Swing {
        FULL,
        PACKET,
        NONE;

        // $FF: synthetic method
        private static FeetTroll.Swing[] $values() {
            return new FeetTroll.Swing[]{FULL, PACKET, NONE};
        }
    }
}
