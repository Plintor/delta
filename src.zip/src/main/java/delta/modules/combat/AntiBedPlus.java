package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.WorldUtils;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.TrapdoorBlock;

public class AntiBedPlus extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> toggle;
    private final Setting<Integer> delay;
    private final Setting<Boolean> swingHand;
    private final Setting<Boolean> rotate;
    private int timer;

    public AntiBedPlus() {
        super(DeltaHack.Combat, "anti-bed+", "Protects you from bed aura (retard edition)");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.toggle = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("toggle")).description("Toggle off if beds work in the current dimension.")).defaultValue(true)).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Delay in ticks between actions.")).defaultValue(0)).build());
        this.swingHand = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("swing-hand")).description("Swing hand client side.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("-")).defaultValue(false)).build());
    }

    public void onActivate() {
        this.timer = 0;
    }

    @EventHandler
    private void onTickPre(Pre event) {
        if (this.mc.world.getDimension().comp_648()) {
            if ((Boolean)this.toggle.get()) {
                this.toggle();
            }

        } else if (this.timer != 0) {
            --this.timer;
        } else {
            this.timer = (Integer)this.delay.get();
            FindItemResult trapdoor = InvUtils.findInHotbar((itemStack) -> {
                return Block.getBlockFromItem(itemStack.getItem()) instanceof TrapdoorBlock;
            });
            FindItemResult button = InvUtils.findInHotbar((itemStack) -> {
                return Block.getBlockFromItem(itemStack.getItem()) instanceof AbstractButtonBlock;
            });
            FindItemResult web = InvUtils.findInHotbar(new Item[]{Items.COBWEB});
            FindItemResult string = InvUtils.findInHotbar(new Item[]{Items.STRING});
            if (trapdoor.found()) {
                this.placeBlocks(trapdoor);
            }

            if (button.found()) {
                this.placeBlocks(button);
            } else if (web.found()) {
                this.placeBlocks(web);
            } else if (string.found()) {
                this.placeBlocks(string);
            }

        }
    }

    private void placeBlocks(FindItemResult item) {
        BlockPos pos = EntityUtil.playerPos(this.mc.player);
        if (BlockUtil.isReplaceable(pos) && !BlockUtil.isReplaceable(pos.down())) {
            Rotations.rotate((double)this.mc.player.getYaw(), 90.0D);
            WorldUtils.place(pos, item, (Boolean)this.rotate.get(), 0, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swingHand.get(), false, true);
        } else if (BlockUtil.isReplaceable(pos.up()) && !BlockUtil.isReplaceable(pos.up(2))) {
            Rotations.rotate((double)this.mc.player.getYaw(), -90.0D);
            WorldUtils.place(pos.up(), item, (Boolean)this.rotate.get(), 0, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Up, (Boolean)this.swingHand.get(), false, true);
        }

    }
}
