package delta.modules.combat;

import delta.DeltaHack;
import delta.modules.ModuleExtended;
import delta.util.CrystalUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.PistonBlock;
import net.minecraft.util.math.MathHelper;

public class PistonPush extends ModuleExtended {
    private final Setting<Integer> delay = this.setting("delay", "the amount of ticks to wait since the rotation to place piston.", 1, this.getGroup(), 0, 10, 0, 10);
    private final Setting<Double> range = this.setting("action-range", "the range in which you can place blocks.", 4.4D, this.getGroup(), 0.0D, 6.0D, 2.0D, 5.0D);
    private final Setting<Double> radius = this.setting("radius", "the range in which you detect enemies.", 6.0D, this.getGroup(), 0.0D, 10.0D, 2.0D, 15.0D);
    private final Setting<SortPriority> priority;
    private final Setting<PistonPush.SortPrio> priority2;
    private final Setting<PistonPush.Priority> priority3;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> disable1;
    private final Setting<Boolean> disable2;
    private final Setting<Boolean> disable3;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> autoBreak;
    private final Setting<Boolean> autoCev;
    private final Setting<Double> breakingProgress;
    private final Setting<Boolean> rotate;
    private int timer;
    private static boolean cevIng;
    private static PlayerEntity target;

    public PistonPush() {
        super(DeltaHack.Combat, "piston-pusher", "pushes the enemy out of their hole with pistons and redstone blocks.");
        this.priority = this.setting("target-priority", "how to filter targets within given range.", SortPriority.ClosestAngle, this.getGroup());
        this.priority2 = this.setting("piston-priority", "how to filter available piston positions", PistonPush.SortPrio.HighestDistance, this.getGroup());
        this.priority3 = this.setting("place-priority", "what to place first when possible.", PistonPush.Priority.Piston, this.getGroup());
        this.swing = this.setting("render-swing", "self explanatory.", true, this.getGroup());
        this.disable1 = this.setting("toggle-on-no-target", "self explanatory.", true, this.getGroup());
        this.disable2 = this.setting("toggle-on-no-resources", "self explanatory.", true, this.getGroup());
        this.disable3 = this.setting("auto-toggle", "turns off the module after you've piston'd your enemy", true, this.getGroup());
        this.notify = this.setting("notify", "notifies you about the module's work.", true, this.getGroup());
        this.autoBreak = this.setting("auto-break", "automatically breaks interfering blocks if possible.", true, this.getGroup("Auto Break"));
        SettingGroup var10005 = this.getGroup("Auto Break");
        Setting var10006 = this.autoBreak;
        Objects.requireNonNull(var10006);
        this.autoCev = this.setting("auto-cev", "Crystals your enemy from above when possible.", true, var10005, var10006::get);
        this.breakingProgress = this.setting("breaking-progress", "-", 0.95D, this.getGroup("Auto Break"), 0.0D, 1.0D, 0.5D, 1.0D, () -> {
            return (Boolean)this.autoBreak.get() && (Boolean)this.autoCev.get();
        });
        var10005 = this.getGroup("Auto Break");
        var10006 = this.autoBreak;
        Objects.requireNonNull(var10006);
        this.rotate = this.setting("rotate", "rotates to the blocks being broken.", true, var10005, var10006::get);
        this.timer = 0;
    }

    @EventHandler(
        priority = 150
    )
    public void onPreTick(Pre event) {
        FindItemResult fP = InvUtils.findInHotbar((itemStack) -> {
            return Block.getBlockFromItem(itemStack.getItem()) instanceof PistonBlock;
        });
        FindItemResult fR = InvUtils.findInHotbar(new Item[]{Items.REDSTONE_BLOCK});
        if (fP.found() && fR.found()) {
            if (TargetUtils.isBadTarget(target, (Double)this.radius.get())) {
                target = TargetUtils.getPlayerTarget((Double)this.radius.get(), (SortPriority)this.priority.get());
            }

            if (TargetUtils.isBadTarget(target, (Double)this.radius.get())) {
                if ((Boolean)this.disable1.get()) {
                    this.toggle();
                }

                if ((Boolean)this.notify.get()) {
                    this.error("No target!", new Object[0]);
                }

            } else if (EntityUtil.isMonke(target, true, BlockUtil.BlastResistantType.Any) && !EntityUtil.isBurrowed(target)) {
                if ((Boolean)this.disable3.get()) {
                    this.toggle();
                }

                if ((Boolean)this.notify.get()) {
                    this.warning("Target not in hole!", new Object[0]);
                }

            } else {
                BlockPos pos = EntityUtil.playerPos(target);
                if ((double)target.getEyeHeight(target.getPose()) < 1.4D) {
                    if ((Boolean)this.notify.get()) {
                        this.warning("Target in a non-pistonable pose!", new Object[0]);
                    }

                    if ((Boolean)this.autoBreak.get() && BlockUtil.isBreakable(pos.up())) {
                        BlockUtil.mineBlock(pos.up(), (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                    } else if ((Boolean)this.disable3.get()) {
                        this.toggle();
                    }

                } else {
                    if (!BlockUtil.isReplaceable(pos.up(2))) {
                        if (!(Boolean)this.autoBreak.get()) {
                            if ((Boolean)this.disable3.get()) {
                                this.toggle();
                            }

                            if ((Boolean)this.notify.get()) {
                                this.error("Target will not be pushed by piston because of self-trap!", new Object[0]);
                            }

                            return;
                        }

                        if (!cevIng) {
                            if ((Boolean)this.notify.get()) {
                                this.warning("Target will not be pushed by piston because of self-trap!", new Object[0]);
                            }

                            if (!BlockUtil.isBreakable(pos.up(2))) {
                                if ((Boolean)this.notify.get()) {
                                    this.error("Can't mine the block!", new Object[0]);
                                }

                                if ((Boolean)this.disable3.get()) {
                                    this.toggle();
                                }

                                return;
                            }

                            if ((Boolean)this.notify.get()) {
                                this.info("Mining...", new Object[0]);
                            }

                            cevIng = true;
                        }
                    } else {
                        cevIng = false;
                    }

                    if (cevIng) {
                        BlockUtil.mineBlock(pos.up(2), (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                        if ((Boolean)this.autoCev.get() && (double)((ClientPlayerInteractionManagerAccessor)this.mc.interactionManager).getBreakingProgress() >= (Double)this.breakingProgress.get() && CrystalUtils.canPlace(pos.up(3), (Double)this.range.get(), true)) {
                            CrystalUtils.placeCrystal(InvUtils.findInHotbar(new Item[]{Items.END_CRYSTAL}), pos.up(3), (Boolean)this.swing.get(), true);
                        }

                    } else {
                        List<PistonPush.PresumePush> pushable = new ArrayList();
                        List<PistonPush.PresumePush> city = new ArrayList();

                        for(int i = 0; i < 4; ++i) {
                            PistonPush.PresumePush p = new PistonPush.PresumePush(pos.up(), Direction.fromHorizontal(i));
                            if (p.isPistonAble()) {
                                pushable.add(p);
                            } else if (p.interferingPos != null && (Boolean)this.autoBreak.get() && PlayerUtil.distanceFromEye(p.interferingPos) < (Double)this.range.get()) {
                                city.add(p);
                            }
                        }

                        if (pushable.isEmpty()) {
                            if (city.isEmpty()) {
                                if ((Boolean)this.notify.get()) {
                                    this.error("couldn't find a pushable position!", new Object[0]);
                                }

                                if ((Boolean)this.disable3.get()) {
                                    this.toggle();
                                }
                            } else {
                                if ((Boolean)this.notify.get()) {
                                    this.warning("couldn't find a pushable position!", new Object[0]);
                                    this.info("mining...", new Object[0]);
                                }

                                city.sort(Comparator.comparingDouble(this::sortUtil));
                                BlockUtil.mineBlock(((PistonPush.PresumePush)city.get(0)).interferingPos, (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                            }
                        } else {
                            city.clear();
                            pushable.sort(Comparator.comparingDouble(this::sortUtil));
                            PistonPush.PresumePush a = (PistonPush.PresumePush)pushable.get(0);
                            pushable.clear();
                            if (a.activated && a.pistonEd) {
                                Block b = BlockUtil.getBlock(a.pos);
                                if (b != Blocks.PISTON_HEAD && b != Blocks.MOVING_PISTON) {
                                    BlockUtil.mineBlock(a.piston, (Boolean)this.swing.get(), false);
                                }
                            }

                            if (this.priority3.get() == PistonPush.Priority.Piston) {
                                if (this.placePiston(a, fP)) {
                                    return;
                                }

                                if (!a.activated) {
                                    this.placeRedstone(a.activatorPos, fR);
                                }
                            } else if (a.activated) {
                                this.placePiston(a, fP);
                            } else {
                                this.placeRedstone(a.activatorPos, fR);
                            }
                        }

                    }
                }
            }
        } else {
            if ((Boolean)this.notify.get()) {
                this.error("No resources!", new Object[0]);
            }

            if ((Boolean)this.disable2.get()) {
                this.toggle();
            }

        }
    }

    private void placeRedstone(BlockPos activatorPos, FindItemResult fR) {
        Rotations.rotate(Rotations.getYaw(activatorPos), Rotations.getPitch(activatorPos));
        if ((Boolean)this.notify.get()) {
            this.info("Placing redstone!", new Object[0]);
        }

        WorldUtils.place(activatorPos, fR, true, (Boolean)this.swing.get());
    }

    private boolean placePiston(PistonPush.PresumePush a, FindItemResult fP) {
        if (a.pistonEd) {
            return false;
        } else if (this.mc.player.getHorizontalFacing() != a.d.getOpposite()) {
            float y = a.d.getOpposite().asRotation();
            y = (float)MathHelper.clamp(Rotations.getYaw(a.piston), (double)(y - 40.0F), (double)(y + 40.0F));
            this.mc.player.setYaw(y);
            this.mc.player.setPitch(0.0F);
            Rotations.rotate((double)y, 0.0D, 100, (Runnable)null);
            return true;
        } else {
            ++this.timer;
            if (this.timer < (Integer)this.delay.get()) {
                return true;
            } else {
                this.timer = 0;
                if ((Boolean)this.notify.get()) {
                    this.info("Placing piston!", new Object[0]);
                }

                WorldUtils.place(a.piston, fP, false, (Boolean)this.swing.get());
                return true;
            }
        }
    }

    public double sortUtil(PistonPush.PresumePush pres) {
        return PlayerUtil.distanceFromEye(pres.pos) * (double)(this.priority2.get() == PistonPush.SortPrio.LowestDistance ? 1 : -1);
    }

    public String getInfoString() {
        return target != null ? target.getEntityName() : "Awaiting for target...";
    }

    public static enum SortPrio {
        LowestDistance,
        HighestDistance;

        // $FF: synthetic method
        private static PistonPush.SortPrio[] $values() {
            return new PistonPush.SortPrio[]{LowestDistance, HighestDistance};
        }
    }

    public static enum Priority {
        Piston,
        Activator;

        // $FF: synthetic method
        private static PistonPush.Priority[] $values() {
            return new PistonPush.Priority[]{Piston, Activator};
        }
    }

    private class PresumePush {
        final BlockPos pos;
        final Direction d;
        BlockPos interferingPos = null;
        BlockPos activatorPos = null;
        boolean activated = false;
        boolean pistonEd = false;
        BlockPos piston = null;

        public PresumePush(BlockPos target, Direction dir) {
            this.pos = target;
            this.d = dir;
        }

        public boolean isPistonAble() {
            BlockPos check = this.pos.offset(this.d);
            this.piston = this.pos.offset(this.d.getOpposite());
            if (PlayerUtil.distanceFromEye(this.piston) > (Double)PistonPush.this.range.get()) {
                return false;
            } else {
                if (BlockUtil.getBlock(this.piston) instanceof PistonBlock) {
                    this.pistonEd = true;
                } else if (!BlockUtil.canPlace(this.piston, true)) {
                    if ((Boolean)PistonPush.this.autoBreak.get() && BlockUtil.isBreakable(this.piston)) {
                        this.interferingPos = this.piston;
                    }

                    return false;
                }

                this.getActivators();
                if (!this.activated && (this.activatorPos == null || PlayerUtil.distanceFromEye(this.activatorPos) > (Double)PistonPush.this.range.get())) {
                    return false;
                } else if (!BlockUtil.isReplaceable(check)) {
                    if ((Boolean)PistonPush.this.autoBreak.get() && BlockUtil.isBreakable(check)) {
                        this.interferingPos = check;
                    }

                    return false;
                } else if (!BlockUtil.isReplaceable(check.up())) {
                    if ((Boolean)PistonPush.this.autoBreak.get() && BlockUtil.isBreakable(check.up())) {
                        this.interferingPos = check.up();
                    }

                    return false;
                } else {
                    return true;
                }
            }
        }

        private void getActivators() {
            List<BlockPos> a = new ArrayList();
            List<BlockPos> b = new ArrayList();
            Direction[] var3 = Direction.values();
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                Direction dir0 = var3[var5];
                if (dir0 != this.d) {
                    BlockPos c = this.piston.offset(dir0);
                    if (BlockUtil.getBlock(c).equals(Blocks.REDSTONE_BLOCK)) {
                        this.activated = true;
                        return;
                    }

                    if (BlockUtil.canPlace(c, true)) {
                        a.add(c);
                    } else if ((Boolean)PistonPush.this.autoBreak.get() && BlockUtil.isBreakable(c)) {
                        b.add(c);
                    }
                }
            }

            if (a.isEmpty()) {
                if (!b.isEmpty()) {
                    b.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                    this.interferingPos = (BlockPos)b.get(0);
                }

                this.activatorPos = null;
            } else {
                a.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                this.activatorPos = (BlockPos)a.get(0);
            }

        }
    }
}
