package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.PlayerUtil;
import java.util.Iterator;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class AntiGhostBlock extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> range;
    private final Setting<Integer> delay;
    private final Setting<Integer> attempts;
    private final Setting<Integer> retryDelay;
    private final Setting<Boolean> packet;
    private final Setting<Integer> checksPerTick;
    private int timer;
    private int attempt;
    private int waitTimer;
    private BlockPos prevPos;
    private boolean shouldWait;
    private int cpt;

    public AntiGhostBlock() {
        super(DeltaHack.Old, "anti-ghost-block", "Automatically detects glitching blocks.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.range = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("range")).description("Range for block checking")).defaultValue(3.0D).range(1.0D, 6.0D).sliderRange(1.0D, 3.0D).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Delay in ticks")).defaultValue(1)).range(1, 20).sliderRange(1, 5).build());
        this.attempts = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("attempts")).description("Amount of attempts to break one position in a row")).defaultValue(3)).range(1, 10).sliderRange(1, 5).build());
        this.retryDelay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("retry-delay")).description("Delay after a certain amount of attempts made in ticks")).defaultValue(4)).range(1, 20).sliderRange(1, 5).build());
        this.packet = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("packet")).description("Sends extra break packets to the server.")).defaultValue(false)).build());
        this.checksPerTick = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("checks-per-tick")).description("max checks per tick")).defaultValue(2)).range(1, 5).sliderRange(1, 5).build());
    }

    public void onActivate() {
        this.timer = (Integer)this.delay.get();
        this.cpt = 0;
        this.attempt = 0;
        this.waitTimer = 0;
        this.shouldWait = false;
    }

    @EventHandler
    public void onTick(Pre event) {
        if (this.shouldWait) {
            ++this.waitTimer;
            if (this.waitTimer == (Integer)this.retryDelay.get()) {
                this.shouldWait = false;
                this.waitTimer = 0;
            }
        }

        if (this.timer < (Integer)this.delay.get()) {
            ++this.timer;
        } else {
            this.timer = 0;
            this.cpt = (Integer)this.checksPerTick.get();
        }

        Iterator var2 = this.mc.world.getEntities().iterator();

        while(var2.hasNext()) {
            Entity entity = (Entity)var2.next();
            if (this.cpt == 0) {
                return;
            }

            if (entity instanceof EndCrystalEntity && BlockUtil.isBreakable(entity.getBlockPos()) && !(PlayerUtil.distanceFromEye(entity) > (Double)this.range.get())) {
                --this.cpt;
                BlockPos s = entity.getBlockPos();
                if (s == this.prevPos) {
                    ++this.attempt;
                } else {
                    this.prevPos = s;
                    this.attempt = 0;
                }

                if (this.attempt == (Integer)this.attempts.get()) {
                    this.shouldWait = true;
                }

                this.doCheck(s);
            }
        }

    }

    private void doCheck(BlockPos pos) {
        ClientPlayNetworkHandler conn = this.mc.getNetworkHandler();
        if (conn != null) {
            if ((Boolean)this.packet.get()) {
                conn.sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.UP));
                conn.sendPacket(new PlayerActionC2SPacket(Action.ABORT_DESTROY_BLOCK, pos, Direction.UP));
            }

            BlockUtils.breakBlock(pos, false);
        }
    }
}
