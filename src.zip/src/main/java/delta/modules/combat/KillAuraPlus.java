package delta.modules.combat;

import baritone.api.BaritoneAPI;
import delta.DeltaHack;
import delta.utils.PlayerUtil;
import delta.utils.TimerUtils;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BannerItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.world.GameMode;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.entity.Tameable;

public class KillAuraPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTargeting;
    private final SettingGroup sgDelay;
    private final Setting<KillAuraPlus.Weapon> weapon;
    private final Setting<Boolean> autoSwitch;
    private final Setting<Boolean> onlyOnClick;
    private final Setting<KillAuraPlus.RotationMode> rotation;
    private final Setting<KillAuraPlus.RotateTo> rotateTo;
    private final Setting<Boolean> ghostSwing;
    private final Setting<Boolean> pauseOnCombat;
    private final Setting<Boolean> ignorePassive;
    private final Setting<Boolean> ignoreTamed;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<Double> range;
    private final Setting<Double> wallsRange;
    private final Setting<SortPriority> priority;
    private final Setting<Integer> maxTargets;
    private final Setting<Boolean> babies;
    private final Setting<Boolean> nametagged;
    private final Setting<Boolean> killFriends;
    private final Setting<Keybind> FFBind;
    private final Setting<Boolean> raidFarm;
    private final Setting<KillAuraPlus.DelayMode> delayMode;
    private final Setting<Integer> hitDelay;
    private final Setting<Boolean> TPSSync;
    private final Setting<Boolean> lagPause;
    private final Setting<Integer> switchDelay;
    private final List<Entity> targets;
    private int hitDelayTimer;
    private int switchTimer;
    private final TimerUtils fixedHitTimer;
    private boolean wasPathing;

    public KillAuraPlus() {
        super(DeltaHack.Combat, "kill-aura+", "Kill Aura with various improvements.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTargeting = this.settings.createGroup("Targeting");
        this.sgDelay = this.settings.createGroup("Delay");
        this.weapon = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("weapons")).description("Only attacks an entity when a specified item is in your hand.")).defaultValue(KillAuraPlus.Weapon.Any)).build());
        this.autoSwitch = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-switch")).description("Switches to your selected weapon when attacking the target.")).defaultValue(false)).build());
        this.onlyOnClick = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-click")).description("Only attacks when hold left click.")).defaultValue(false)).build());
        this.rotation = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("Determines when you should rotate towards the target.")).defaultValue(KillAuraPlus.RotationMode.None)).build());
        this.rotateTo = this.sgGeneral.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("rotate-to")).description("Where to rotate to when you are hitting the target.")).defaultValue(KillAuraPlus.RotateTo.Body)).visible(() -> {
            return this.rotation.get() != KillAuraPlus.RotationMode.None;
        })).build());
        this.ghostSwing = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ghost-swing")).description("Hides your hand swing server side.")).defaultValue(false)).build());
        this.pauseOnCombat = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("pause-baritone")).description("Freezes Baritone temporarily until you are finished attacking the entity.")).defaultValue(true)).build());
        this.ignorePassive = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-passive")).description("Will only attack sometimes passive mobs if they are targeting you.")).defaultValue(true)).build());
        this.ignoreTamed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-tamed")).description("Will avoid attacking mobs you tamed.")).defaultValue(false)).build());
        this.entities = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("entities")).description("Entities to attack.")).defaultValue(new Object2BooleanOpenHashMap(0))).onlyAttackable().build());
        this.range = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("range")).description("The maximum range the entity can be to attack it.")).defaultValue(4.5D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D).build());
        this.wallsRange = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("walls-range")).description("The maximum range the entity can be attacked through walls.")).defaultValue(4.5D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D).build());
        this.priority = this.sgTargeting.add(((Builder)((Builder)((Builder)(new Builder()).name("priority")).description("How to filter targets within range.")).defaultValue(SortPriority.ClosestAngle)).build());
        this.maxTargets = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("targets")).description("How many entities to target at once.")).defaultValue(1)).range(1, 5).sliderRange(1, 5).build());
        this.babies = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("babies")).description("Whether or not to attack baby variants of the entity.")).defaultValue(true)).build());
        this.nametagged = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("nametagged")).description("Whether or not to attack mobs with a name tag.")).defaultValue(false)).build());
        this.killFriends = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("friendly-fire")).description("Whether or not to attack friends.")).defaultValue(false)).build());
        this.FFBind = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("force-friendly-fire")).description("Force find for friendly fire")).defaultValue(Keybind.none())).visible(() -> {
            return !(Boolean)this.killFriends.get();
        })).build());
        this.raidFarm = this.sgTargeting.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-vindicator-captains")).description("Whether or not to attack vindicator captains.")).defaultValue(false)).build());
        this.delayMode = this.sgDelay.add(((Builder)((Builder)((Builder)(new Builder()).name("delay-mode")).description("PositionMode to use for the delay to attack.")).defaultValue(KillAuraPlus.DelayMode.Custom)).build());
        this.hitDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("hit-delay")).description("How fast you hit the entity in ticks.")).defaultValue(11)).min(0).sliderMax(60).visible(() -> {
            return this.delayMode.get() == KillAuraPlus.DelayMode.Custom;
        })).build());
        this.TPSSync = this.sgDelay.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("TPS-sync")).description("Tries to sync attack delay with the server's TPS.")).defaultValue(true)).visible(() -> {
            return this.delayMode.get() != KillAuraPlus.DelayMode.Vanilla;
        })).build());
        this.lagPause = this.sgDelay.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("lag-pause")).description("Whether to pause if the server is not responding.")).defaultValue(true)).build());
        this.switchDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("switch-delay")).description("How many ticks to wait before hitting an entity after switching hotbar slots.")).defaultValue(0)).min(0).sliderMax(10).build());
        this.targets = new ArrayList();
        this.fixedHitTimer = new TimerUtils();
    }

    public void onDeactivate() {
        this.hitDelayTimer = 0;
        this.targets.clear();
    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.mc.player.isAlive() && PlayerUtils.getGameMode() != GameMode.SPECTATOR) {
            float timeSinceLastTick = TickRate.INSTANCE.getTimeSinceLastTick();
            if (!(timeSinceLastTick >= 1.0F) || !(Boolean)this.lagPause.get()) {
                TargetUtils.getList(this.targets, this::entityCheck, (SortPriority)this.priority.get(), (Integer)this.maxTargets.get());
                if (this.targets.isEmpty()) {
                    if (this.wasPathing) {
                        BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("resume");
                        this.wasPathing = false;
                    }

                } else {
                    if ((Boolean)this.pauseOnCombat.get() && BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing() && !this.wasPathing) {
                        BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("pause");
                        this.wasPathing = true;
                    }

                    Entity primary = (Entity)this.targets.get(0);
                    if (this.rotation.get() == KillAuraPlus.RotationMode.Always) {
                        this.rotate(primary, (Runnable)null);
                    }

                    if (!(Boolean)this.onlyOnClick.get() || this.mc.options.attackKey.isPressed()) {
                        if ((Boolean)this.autoSwitch.get()) {
                            FindItemResult weaponResult = InvUtils.findInHotbar((itemStack) -> {
                                Item item = itemStack.getItem();
                                boolean var10000;
                                switch((KillAuraPlus.Weapon)this.weapon.get()) {
                                    case Axe:
                                        var10000 = item instanceof AxeItem;
                                        break;
                                    case Sword:
                                        var10000 = item instanceof SwordItem;
                                        break;
                                    case Both:
                                        var10000 = item instanceof AxeItem || item instanceof SwordItem;
                                        break;
                                    default:
                                        var10000 = true;
                                }

                                return var10000;
                            });
                            InvUtils.swap(weaponResult.slot(), false);
                        }

                        if (this.itemInHand()) {
                            if (this.delayCheck()) {
                                this.targets.forEach(this::attack);
                            }

                        }
                    }
                }
            }
        }
    }

    @EventHandler
    private void onSendPacket(Send event) {
        if (event.packet instanceof UpdateSelectedSlotC2SPacket) {
            this.switchTimer = (Integer)this.switchDelay.get();
        }

        if (event.packet instanceof HandSwingC2SPacket && (Boolean)this.ghostSwing.get()) {
            event.cancel();
        }

    }

    private boolean entityCheck(Entity entity) {
        if (!entity.equals(this.mc.player) && !entity.equals(this.mc.cameraEntity)) {
            if ((!(entity instanceof LivingEntity) || !((LivingEntity)entity).isDead()) && entity.isAlive()) {
                if (PlayerUtil.distanceFromEye(entity) > (Double)this.range.get()) {
                    return false;
                } else if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType())) {
                    return false;
                } else if (!(Boolean)this.nametagged.get() && entity.hasCustomName()) {
                    return false;
                } else if (!PlayerUtils.canSeeEntity(entity) && PlayerUtil.distanceFromEye(entity) > (Double)this.wallsRange.get()) {
                    return false;
                } else {
                    if ((Boolean)this.ignoreTamed.get() && entity instanceof Tameable) {
                        Tameable tameable = (Tameable)entity;
                        if (tameable.getOwnerUuid() != null && tameable.getOwnerUuid().equals(this.mc.player.getUuid())) {
                            return false;
                        }
                    }

                    if ((Boolean)this.ignorePassive.get()) {
                        if (entity instanceof EndermanEntity) {
                            EndermanEntity enderman = (EndermanEntity)entity;
                            if (!enderman.isAngryAt(this.mc.player)) {
                                return false;
                            }
                        }

                        if (entity instanceof ZombifiedPiglinEntity) {
                            ZombifiedPiglinEntity piglin = (ZombifiedPiglinEntity)entity;
                            if (!piglin.isAngryAt(this.mc.player)) {
                                return false;
                            }
                        }

                        if (entity instanceof WolfEntity) {
                            WolfEntity wolf = (WolfEntity)entity;
                            if (!wolf.isAttacking()) {
                                return false;
                            }
                        }
                    }

                    if (entity instanceof PlayerEntity) {
                        PlayerEntity x = (PlayerEntity)entity;
                        if (x.isCreative()) {
                            return false;
                        }

                        if (!Friends.get().shouldAttack(x) && !(Boolean)this.killFriends.get() && !((Keybind)this.FFBind.get()).isPressed()) {
                            return false;
                        }
                    }

                    if ((Boolean)this.raidFarm.get() && entity instanceof VindicatorEntity) {
                        VindicatorEntity x = (VindicatorEntity)entity;
                        Iterator var3 = x.getArmorItems().iterator();

                        while(var3.hasNext()) {
                            ItemStack s = (ItemStack)var3.next();
                            if (s.getItem() instanceof BannerItem) {
                                return false;
                            }
                        }
                    }

                    return !(entity instanceof AnimalEntity) || (Boolean)this.babies.get() || !((AnimalEntity)entity).isBaby();
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean delayCheck() {
        if (this.switchTimer > 0) {
            --this.switchTimer;
            return false;
        } else {
            switch((KillAuraPlus.DelayMode)this.delayMode.get()) {
                case Vanilla:
                    return this.mc.player.getAttackCooldownProgress(0.5F) >= 1.0F;
                case Custom:
                    if (this.hitDelayTimer > 0) {
                        --this.hitDelayTimer;
                        return false;
                    }

                    this.hitDelayTimer = (int)((double)(Integer)this.hitDelay.get() / TimerUtils.getTPSMatch((Boolean)this.TPSSync.get()));
                    return true;
                case Fixed:
                    if (this.fixedHitTimer.passedMillis((long)((double)this.fixedDelay() / TimerUtils.getTPSMatch((Boolean)this.TPSSync.get())))) {
                        return true;
                    }
                default:
                    return false;
            }
        }
    }

    private void attack(Entity target) {
        if (this.rotation.get() == KillAuraPlus.RotationMode.OnHit) {
            this.rotate(target, () -> {
                this.hitEntity(target);
            });
        } else {
            this.hitEntity(target);
        }

    }

    private void hitEntity(Entity target) {
        this.mc.interactionManager.attackEntity(this.mc.player, target);
        this.mc.player.swingHand(Hand.MAIN_HAND);
        this.fixedHitTimer.reset();
    }

    private void rotate(Entity target, Runnable callback) {
        double var10000 = Rotations.getYaw(target);
        Target var10002;
        switch((KillAuraPlus.RotateTo)this.rotateTo.get()) {
            case Head:
                var10002 = Target.Head;
                break;
            case Body:
                var10002 = Target.Body;
                break;
            case Feet:
                var10002 = Target.Feet;
                break;
            default:
                throw new IncompatibleClassChangeError();
        }

        Rotations.rotate(var10000, Rotations.getPitch(target, var10002), callback);
    }

    private boolean itemInHand() {
        boolean var10000;
        switch((KillAuraPlus.Weapon)this.weapon.get()) {
            case Axe:
                var10000 = this.mc.player.getMainHandStack().getItem() instanceof AxeItem;
                break;
            case Sword:
                var10000 = this.mc.player.getMainHandStack().getItem() instanceof SwordItem;
                break;
            case Both:
                var10000 = this.mc.player.getMainHandStack().getItem() instanceof AxeItem || this.mc.player.getMainHandStack().getItem() instanceof SwordItem;
                break;
            default:
                var10000 = true;
        }

        return var10000;
    }

    private long fixedDelay() {
        Item activeItem = this.mc.player.getMainHandStack().getItem();
        if (activeItem instanceof SwordItem) {
            return 625L;
        } else if (activeItem instanceof TridentItem) {
            return 909L;
        } else if (activeItem instanceof PickaxeItem) {
            return 833L;
        } else if (!(activeItem instanceof ShovelItem) && activeItem != Items.GOLDEN_AXE && activeItem != Items.DIAMOND_AXE && activeItem != Items.NETHERITE_AXE && activeItem != Items.WOODEN_HOE && activeItem != Items.GOLDEN_HOE) {
            if (activeItem != Items.WOODEN_AXE && activeItem != Items.STONE_AXE) {
                if (activeItem == Items.IRON_AXE) {
                    return 1111L;
                } else if (activeItem == Items.STONE_HOE) {
                    return 500L;
                } else {
                    return activeItem == Items.IRON_HOE ? 333L : 250L;
                }
            } else {
                return 1250L;
            }
        } else {
            return 1000L;
        }
    }

    public Entity getTarget() {
        return !this.targets.isEmpty() ? (Entity)this.targets.get(0) : null;
    }

    public String getInfoString() {
        if (!this.targets.isEmpty()) {
            Entity targetFirst = (Entity)this.targets.get(0);
            return targetFirst instanceof PlayerEntity ? targetFirst.getEntityName() : targetFirst.getType().getName().getString();
        } else {
            return null;
        }
    }

    public static enum Weapon {
        Sword,
        Axe,
        Both,
        Any;

        // $FF: synthetic method
        private static KillAuraPlus.Weapon[] $values() {
            return new KillAuraPlus.Weapon[]{Sword, Axe, Both, Any};
        }
    }

    public static enum RotationMode {
        Always,
        OnHit,
        None;

        // $FF: synthetic method
        private static KillAuraPlus.RotationMode[] $values() {
            return new KillAuraPlus.RotationMode[]{Always, OnHit, None};
        }
    }

    public static enum RotateTo {
        Head,
        Body,
        Feet;

        // $FF: synthetic method
        private static KillAuraPlus.RotateTo[] $values() {
            return new KillAuraPlus.RotateTo[]{Head, Body, Feet};
        }
    }

    public static enum DelayMode {
        Vanilla,
        Fixed,
        Custom;

        // $FF: synthetic method
        private static KillAuraPlus.DelayMode[] $values() {
            return new KillAuraPlus.DelayMode[]{Vanilla, Fixed, Custom};
        }
    }
}
