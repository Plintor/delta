package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BedBlock;
import net.minecraft.util.math.BlockPos;

public class AntiLay extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> toggle;
    private final Setting<Boolean> swingHand;
    private final Setting<Boolean> rotate;

    public AntiLay() {
        super(DeltaHack.Combat, "anti-bed-lay", "Protects you from getting forced to enter laying state to slow down the enemy's bed aura");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.toggle = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("toggle")).description("Toggle off if beds work in the current dimension.")).defaultValue(true)).build());
        this.swingHand = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("swing-hand")).description("Swing hand client side.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("-")).defaultValue(false)).build());
    }

    @EventHandler
    private void onTickPre(Pre event) {
        if (this.mc.world.getDimension().comp_648()) {
            if ((Boolean)this.toggle.get()) {
                this.toggle();
            }

        } else {
            BlockPos breakPos = EntityUtil.playerPos(this.mc.player);
            if (!(BlockUtil.getBlock(breakPos) instanceof BedBlock)) {
                breakPos = breakPos.up();
                if (!(BlockUtil.getBlock(breakPos) instanceof BedBlock)) {
                    breakPos = null;
                }
            }

            if (breakPos != null) {
                if ((Boolean)this.rotate.get()) {
                    Rotations.rotate(Rotations.getYaw(breakPos), Rotations.getPitch(breakPos));
                }

                BlockUtil.breakAT(breakPos, (Boolean)this.swingHand.get(), (Boolean)this.rotate.get());
            }

        }
    }
}
