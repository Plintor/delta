package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.InvUtil;
import java.util.Iterator;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Sent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.mixininterface.IExplosion;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.world.explosion.Explosion.DestructionType;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen.CreativeScreenHandler;

public class AutoTotemPlus extends Module {
    public static AutoTotemPlus instance;
    private final SettingGroup sgGeneral;
    private final Setting<AutoTotemPlus.Versions> version;
    private final Setting<Boolean> closeScreen;
    private final Setting<Integer> delay;
    private final Setting<Boolean> antiGapDisease;
    private final Setting<Boolean> tryHard;
    private final Setting<Integer> hardDelay;
    private static final double cry_damage = 85.0D;
    private static final Explosion explosion;
    private boolean should_override_totem;
    private int selected_slot;
    private int delay_ticks_left;
    private int try_hard_ticks_left;

    public AutoTotemPlus() {
        super(DeltaHack.Combat, "auto-totem+", "Automatically puts totems.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.version = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("mode")).defaultValue(AutoTotemPlus.Versions.one_dot_17)).build());
        this.closeScreen = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("close-screen-on-pop")).description("Closes any screen handler while putting totem in offhand.")).defaultValue(false)).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("action-delay")).defaultValue(0)).build());
        this.antiGapDisease = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("stop-eating-on-action")).visible(() -> {
            return this.version.get() == AutoTotemPlus.Versions.one_dot_12;
        })).defaultValue(true)).build());
        this.tryHard = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("totem-spam")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("spam-delay");
        Setting var10003 = this.tryHard;
        Objects.requireNonNull(var10003);
        this.hardDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).defaultValue(0)).build());
        this.selected_slot = 0;
        this.delay_ticks_left = 0;
        this.try_hard_ticks_left = 0;
        instance = this;
    }

    @EventHandler
    private void tick(Pre event) {
        if (this.delay_ticks_left > 0) {
            --this.delay_ticks_left;
        } else if (!(this.mc.player.currentScreenHandler instanceof CreativeScreenHandler)) {
            if (Offhand.instance.isActive() && this.SmartCheck()) {
                if (!(this.mc.currentScreen instanceof HandledScreen) && this.mc.player.currentScreenHandler instanceof PlayerScreenHandler) {
                    Offhand.instance.tick();
                }

            } else {
                ItemStack offhand_stack = this.mc.player.getInventory().getStack(40);
                ItemStack cursor_stack = this.mc.player.currentScreenHandler.getCursorStack();
                boolean is_holding_totem = cursor_stack.getItem() == Items.TOTEM_OF_UNDYING;
                boolean is_totem_in_offhand = offhand_stack.getItem() == Items.TOTEM_OF_UNDYING;
                boolean can_click_offhand = this.mc.player.currentScreenHandler instanceof PlayerScreenHandler;
                if ((Boolean)this.tryHard.get() && (!isClassic() || !(this.mc.currentScreen instanceof HandledScreen))) {
                    if (this.try_hard_ticks_left > 0) {
                        --this.try_hard_ticks_left;
                    } else {
                        this.try_hard_ticks_left = (Integer)this.hardDelay.get();
                        this.should_override_totem = true;
                    }
                }

                if (!is_totem_in_offhand || this.should_override_totem) {
                    int totem_id = this.GetTotemId();
                    if (totem_id != -1 || is_holding_totem) {
                        if (is_holding_totem && can_click_offhand) {
                            InvUtil.Click(45);
                        } else {
                            if (!can_click_offhand) {
                                if (isClassic()) {
                                    ItemStack mainhand_stack = this.mc.player.getInventory().getStack(this.selected_slot);
                                    if (mainhand_stack.getItem() == Items.TOTEM_OF_UNDYING) {
                                        this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
                                        this.mc.player.setStackInHand(Hand.OFF_HAND, this.mc.player.getInventory().getStack(this.selected_slot));
                                        this.mc.player.getInventory().setStack(this.selected_slot, offhand_stack);
                                        this.mc.player.clearActiveItem();
                                        return;
                                    }

                                    if (is_holding_totem) {
                                        InvUtil.Click(InvUtil.GetFirstHotbarSlotId() + this.selected_slot);
                                    }

                                    this.should_override_totem = false;
                                } else if (totem_id == -1) {
                                    Iterator var10 = this.mc.player.currentScreenHandler.slots.iterator();

                                    Slot slot;
                                    do {
                                        if (!var10.hasNext()) {
                                            InvUtil.Click(InvUtil.GetFirstHotbarSlotId() + this.selected_slot);
                                            return;
                                        }

                                        slot = (Slot)var10.next();
                                    } while(!slot.getStack().isEmpty());

                                    InvUtil.Click(slot.id);
                                    return;
                                }
                            }

                            InvUtil.Move(totem_id);
                            this.should_override_totem = !is_totem_in_offhand && this.ShouldOverrideTotem();
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    private void onPacketSent(Sent event) {
        if (event.packet instanceof ClickSlotC2SPacket) {
            this.delay_ticks_left = (Integer)this.delay.get();
            if (isClassic() && (Boolean)this.antiGapDisease.get()) {
                this.mc.interactionManager.stopUsingItem(this.mc.player);
            }
        } else {
            Packet var4 = event.packet;
            if (var4 instanceof PlayerActionC2SPacket) {
                PlayerActionC2SPacket packet = (PlayerActionC2SPacket)var4;
                if (packet.getAction() == Action.SWAP_ITEM_WITH_OFFHAND) {
                    this.delay_ticks_left = (Integer)this.delay.get();
                }
            } else {
                var4 = event.packet;
                if (var4 instanceof UpdateSelectedSlotC2SPacket) {
                    UpdateSelectedSlotC2SPacket packet = (UpdateSelectedSlotC2SPacket)var4;
                    this.selected_slot = packet.getSelectedSlot();
                }
            }
        }

    }

    @EventHandler
    private void onPacketReceived(Receive event) {
        Packet var4 = event.packet;
        if (var4 instanceof EntityStatusS2CPacket) {
            EntityStatusS2CPacket packet = (EntityStatusS2CPacket)var4;
            if (packet.getStatus() != 35 || packet.getEntity(this.mc.world) != this.mc.player) {
                return;
            }

            if (this.mc.player.currentScreenHandler instanceof PlayerScreenHandler) {
                return;
            }

            if ((Boolean)this.closeScreen.get()) {
                this.mc.player.closeHandledScreen();
            }

            ItemStack mainhand_stack = this.mc.player.getInventory().getStack(this.selected_slot);
            if (mainhand_stack.getItem() == Items.TOTEM_OF_UNDYING) {
                mainhand_stack.decrement(1);
                return;
            }

            ItemStack offhand_stack = this.mc.player.getOffHandStack();
            if (offhand_stack.getItem() == Items.TOTEM_OF_UNDYING) {
                offhand_stack.decrement(1);
            }
        } else {
            var4 = event.packet;
            if (var4 instanceof UpdateSelectedSlotS2CPacket) {
                UpdateSelectedSlotS2CPacket packet = (UpdateSelectedSlotS2CPacket)var4;
                this.selected_slot = packet.getSlot();
            }
        }

    }

    public void onActivate() {
        this.should_override_totem = true;
        this.selected_slot = this.mc.player.getInventory().selectedSlot;
    }

    public static boolean isClassic() {
        return instance.version.get() == AutoTotemPlus.Versions.one_dot_12;
    }

    private int GetTotemId() {
        int hotbar_start = InvUtil.GetFirstHotbarSlotId();

        int i;
        for(i = hotbar_start; i < hotbar_start + 9; ++i) {
            if (this.mc.player.currentScreenHandler.getSlot(i).getStack().getItem() == Items.TOTEM_OF_UNDYING) {
                return i;
            }
        }

        for(i = 0; i < hotbar_start; ++i) {
            if (this.mc.player.currentScreenHandler.getSlot(i).getStack().getItem() == Items.TOTEM_OF_UNDYING) {
                return i;
            }
        }

        return -1;
    }

    private boolean ShouldOverrideTotem() {
        return this.version.get() != AutoTotemPlus.Versions.one_dot_17 || !(this.mc.player.currentScreenHandler instanceof PlayerScreenHandler) && this.version.get() == AutoTotemPlus.Versions.one_dot_17;
    }

    private boolean SmartCheck() {
        if (this.mc.player.isFallFlying()) {
            return false;
        } else if (this.GetLatency() >= 125L) {
            return false;
        } else {
            float health = this.GetHealth();
            if (Offhand.instance.cfg_mode.get() == Offhand.OffhandMode.normal) {
                return health >= (float)(Integer)Offhand.instance.cfg_min_health.get();
            } else if (health < 10.0F) {
                return false;
            } else if (this.mc.player.fallDistance > 3.0F && (double)health - (double)this.mc.player.fallDistance * 0.5D <= 2.0D) {
                return false;
            } else {
                double resistance_coefficient = 1.0D;
                StatusEffectInstance resistance_effect = this.mc.player.getStatusEffect(StatusEffects.RESISTANCE);
                if (resistance_effect != null) {
                    resistance_coefficient -= (double)(resistance_effect.getAmplifier() + 1) * 0.2D;
                    if (resistance_coefficient <= 0.0D) {
                        return true;
                    }
                }

                double damage = 85.0D;
                switch(this.mc.world.getDifficulty()) {
                    case EASY:
                        damage = damage * 0.5D + 1.0D;
                        break;
                    case HARD:
                        damage *= 1.5D;
                }

                damage *= resistance_coefficient;
                EntityAttributeInstance attribute_instance = this.mc.player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
                float f = 2.0F + (float)attribute_instance.getValue() / 4.0F;
                float g = (float)MathHelper.clamp((double)((float)this.mc.player.getArmor()) - damage / (double)f, (double)((float)this.mc.player.getArmor() * 0.2F), 20.0D);
                damage *= (double)(1.0F - g / 25.0F);
                ((IExplosion)explosion).set(this.mc.player.getPos(), 6.0F, false);
                int protLevel = EnchantmentHelper.getProtectionAmount(this.mc.player.getArmorItems(), DamageSource.explosion(explosion));
                if (protLevel > 20) {
                    protLevel = 20;
                }

                damage *= 1.0D - (double)protLevel / 25.0D;
                return (double)health - damage > 2.0D;
            }
        }
    }

    private float GetHealth() {
        float health = this.mc.player.getHealth();
        if (this.mc.player.getStatusEffect(StatusEffects.ABSORPTION) != null) {
            health += this.mc.player.getAbsorptionAmount();
        }

        return health;
    }

    private long GetLatency() {
        PlayerListEntry playerListEntry = this.mc.player.networkHandler.getPlayerListEntry(this.mc.player.getUuid());
        return playerListEntry != null ? (long)playerListEntry.getLatency() : 0L;
    }

    static {
        explosion = new Explosion((World)null, (Entity)null, 0.0D, 0.0D, 0.0D, 6.0F, false, DestructionType.DESTROY);
    }

    public static enum Versions {
        one_dot_12("classic"),
        one_dot_16("1.16.5"),
        one_dot_17("1.17+");

        final String name;

        private Versions(String name) {
            this.name = name;
        }

        public String toString() {
            return this.name;
        }

        // $FF: synthetic method
        private static AutoTotemPlus.Versions[] $values() {
            return new AutoTotemPlus.Versions[]{one_dot_12, one_dot_16, one_dot_17};
        }
    }
}
