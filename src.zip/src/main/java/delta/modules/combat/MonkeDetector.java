package delta.modules.combat;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.TimerUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

public class MonkeDetector extends Module {
    private final SettingGroup sgDefault;
    private final SettingGroup sgBurrow;
    private final SettingGroup sgWebbed;
    private final SettingGroup sgGreenHole;
    private final SettingGroup sgButton;
    private final SettingGroup sgAutist;
    private final Setting<Double> range;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Boolean> message;
    private final Setting<Integer> delay;
    private final Setting<Boolean> mutualMonkeIgnore;
    private final Setting<Boolean> renderBurrowed;
    private final Setting<Boolean> doubleHeightBurrow;
    private final Setting<BlockUtil.BlastResistantType> burrowType;
    private final Setting<List<String>> burrowMessages;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Setting<Boolean> renderWebbed;
    private final Setting<List<String>> webMessages;
    private final Setting<SettingColor> webSideColor;
    private final Setting<SettingColor> webLineColor;
    private final Setting<Boolean> renderHole;
    private final Setting<List<String>> holeMessages;
    private final Setting<SettingColor> holeSideColor;
    private final Setting<SettingColor> holeLineColor;
    private final Setting<Boolean> renderButtoned;
    private final Setting<List<String>> buttonMessages;
    private final Setting<SettingColor> buttonSideColor;
    private final Setting<SettingColor> buttonLineColor;
    private final Setting<Boolean> renderAutist;
    private final Setting<Boolean> selfTrap;
    private final Setting<Boolean> antiCevTwo;
    private final Setting<BlockUtil.BlastResistantType> autistType;
    private final Setting<List<String>> autistMessages;
    private final Setting<SettingColor> autistSideColor;
    private final Setting<SettingColor> autistLineColor;
    private final Setting<Boolean> messageByNickname;
    private final Setting<List<String>> nicknames;
    private final Setting<List<String>> insults;
    private final TimerUtils pepisTimer;
    private final List<BlockPos> burrowPositions;
    private final List<BlockPos> webPositions;
    private final List<BlockPos> ghPositions;
    private final List<BlockPos> buttonPositions;
    private final List<BlockPos> autistPositions;

    public MonkeDetector() {
        super(DeltaHack.Combat, "monke-detector", "Displays monkes in your visual range as well as sends mocking messages.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgBurrow = this.settings.createGroup("Burrowed");
        this.sgWebbed = this.settings.createGroup("Webbed");
        this.sgGreenHole = this.settings.createGroup("GreenHole");
        this.sgButton = this.settings.createGroup("Button Anti Bedded");
        this.sgAutist = this.settings.createGroup("Using Russian+ Surround");
        this.range = this.sgDefault.add(((Builder)((Builder)(new Builder()).name("range")).description("The radius in which to detect the targets.")).defaultValue(5.0D).min(0.0D).sliderMax(10.0D).build());
        this.shapeMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.message = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("message")).description("Will send a message if the player is a monke.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("message-delay")).description("How long to wait in ticks before sending a message again.")).defaultValue(100)).sliderRange(0, 200).min(0);
        Setting var10003 = this.message;
        Objects.requireNonNull(var10003);
        this.delay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("mutual-monke-ignore")).description("Will not send a message if you are a monke.")).defaultValue(true);
        var10003 = this.message;
        Objects.requireNonNull(var10003);
        this.mutualMonkeIgnore = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.renderBurrowed = this.sgBurrow.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-burrow")).description("Will render if the target is burrowed.")).defaultValue(true)).build());
        this.doubleHeightBurrow = this.sgBurrow.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("double-height")).description("Will only render if the target is burrowed in tho blocks in height.")).defaultValue(true)).build());
        var10001 = this.sgBurrow;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("block-type")).description("What type of burrow to detect.")).defaultValue(BlockUtil.BlastResistantType.AnyBlock);
        var10003 = this.renderBurrowed;
        Objects.requireNonNull(var10003);
        this.burrowType = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        this.burrowMessages = this.sgBurrow.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("burrow-messages")).description("The random messages to send when someone is in a burrow.")).defaultValue(List.of("{player} Joseph Lee Burrow (born December 10, 1996) is an American football quarterback for the Cincinnati Bengals.", "{player} lmao suffocate in there idiot"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.renderBurrowed.get();
        })).build());
        this.sideColor = this.sgBurrow.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("burrow-side-color")).description("The side color of the rendering.")).defaultValue(new SettingColor(230, 0, 255, 5))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Lines && (Boolean)this.renderBurrowed.get();
        })).build());
        this.lineColor = this.sgBurrow.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("burrow-line-color")).description("The line color of the rendering.")).defaultValue(new SettingColor(250, 0, 255, 255))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.renderBurrowed.get();
        })).build());
        this.renderWebbed = this.sgWebbed.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-webbed")).description("Will render if the target is webbed.")).defaultValue(true)).build());
        this.webMessages = this.sgWebbed.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("web-messages")).description("The random messages to send when someone is in a web.")).defaultValue(List.of("{player} get out of the fucking web you spider", "{player} no criticals?"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.renderWebbed.get();
        })).build());
        this.webSideColor = this.sgWebbed.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("web-side-color")).description("The side color of the rendering for webs.")).defaultValue(new SettingColor(240, 250, 65, 35))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Lines && (Boolean)this.renderWebbed.get();
        })).build());
        this.webLineColor = this.sgWebbed.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("web-line-color")).description("The line color of the rendering for webs.")).defaultValue(new SettingColor(0, 0, 0, 0))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.renderWebbed.get();
        })).build());
        this.renderHole = this.sgGreenHole.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-green-hole")).description("Will render if the target is in a green hole.")).defaultValue(true)).build());
        this.holeMessages = this.sgGreenHole.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("hole-messages")).description("The random messages to send when someone is in an unbreakable hole.")).defaultValue(List.of("{player} nice green hole you got there", ":clown: -> {player}", "Leave the green hole challenge passed to {player}", "The Green Banana Hole is a blue hole 80 km (50 mi) off the coast southwest of Sarasota, Florida."))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.renderHole.get();
        })).build());
        this.holeSideColor = this.sgGreenHole.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("hole-side-color")).description("The side color of the rendering for green holes.")).defaultValue(new SettingColor(10, 250, 150, 20))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Lines && (Boolean)this.renderHole.get();
        })).build());
        this.holeLineColor = this.sgGreenHole.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("hole-line-color")).description("The line color of the rendering for green holes.")).defaultValue(new SettingColor(10, 250, 150, 255))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.renderHole.get();
        })).build());
        this.renderButtoned = this.sgButton.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-buttoned")).description("Will render if the target is buttoned to prevent you from placing beds in their face.")).defaultValue(true)).build());
        this.buttonMessages = this.sgButton.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("button-messages")).description("The random messages to send when someone is using buttons.")).defaultValue(List.of("{player} you afraid of beds?", "{player} got the laziest bed protection in history of minecraft", "anybody teach {player} bed PvP :skull:"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.renderButtoned.get();
        })).build());
        this.buttonSideColor = this.sgButton.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("button-side-color")).description("The side color of the rendering for buttons.")).defaultValue(new SettingColor(250, 191, 10, 20))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Lines && (Boolean)this.renderButtoned.get();
        })).build());
        this.buttonLineColor = this.sgButton.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("button-line-color")).description("The line color of the rendering for buttons.")).defaultValue(new SettingColor(248, 111, 0, 255))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.renderButtoned.get();
        })).build());
        this.renderAutist = this.sgAutist.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-autist")).description("Will render if the target is using russian+ surround.")).defaultValue(true)).build());
        var10001 = this.sgAutist;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-cev")).description("Will only render if the target is self trapped with anti cev.")).defaultValue(false);
        var10003 = this.renderAutist;
        Objects.requireNonNull(var10003);
        this.selfTrap = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.antiCevTwo = this.sgAutist.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-cev-two")).description("Will only render if the target is also self trapped in a way that you can't cev nor piston it.")).defaultValue(false)).visible(() -> {
            return (Boolean)this.selfTrap.get() && (Boolean)this.renderAutist.get();
        })).build());
        var10001 = this.sgAutist;
        var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("block-type")).description("What type of autist surround to detect.")).defaultValue(BlockUtil.BlastResistantType.Any);
        var10003 = this.renderAutist;
        Objects.requireNonNull(var10003);
        this.autistType = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        this.autistMessages = this.sgAutist.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("autist-messages")).description("The random messages to send when someone is in a russian+ surround.")).defaultValue(List.of("{player} so how the fuck do i city you"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.renderAutist.get();
        })).build());
        this.autistSideColor = this.sgAutist.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("autist-side-color")).description("The side color of the rendering.")).defaultValue(new SettingColor(255, 0, 0, 37))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Lines && (Boolean)this.renderBurrowed.get();
        })).build());
        this.autistLineColor = this.sgAutist.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("autist-line-color")).description("The line color of the rendering.")).defaultValue(new SettingColor(250, 0, 255, 0))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.renderBurrowed.get();
        })).build());
        var10001 = this.sgDefault;
        var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("message-by-nickname")).description("Will mock players if they match one of the nicknames in the list.")).defaultValue(true);
        var10003 = this.message;
        Objects.requireNonNull(var10003);
        this.messageByNickname = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.nicknames = this.sgDefault.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("nicknames")).description("The nicknames of monke players.")).defaultValue(List.of("tesak", "Indra", "ReapeRxGoD", "A_Gawr_Gura_A", "IPv4address", "_Spw_"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.messageByNickname.get();
        })).build());
        this.insults = this.sgDefault.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("insults")).description("The list of random messages to send to monke players.")).defaultValue(List.of("{player} fuck my cat. {player} cum on my cat. {player} put my dick anywhere near my cat. {player} done anything weird with my cats.", "{player} look at you.. alone.. no bitches. staring at your phone wit 0 notifications", "Прежде всего, надо знать, что само понятие {player} в малолетней зоне относится только к петухам, опущенкам и прочей нечисти.", "A journey of a thousand miles begins with fucking {player}'s mom", "{player} is a registered sex offender. Learn more about Minecraft's new safety policy at https://www.minecraft.net/en-us/eula", "\"None of us would be here without cum\" - (c) {player}", "{player} is a casual 13 year old from \"russia\"", "{player} <- smelly dick hammer"))).visible(() -> {
            return (Boolean)this.message.get() && (Boolean)this.messageByNickname.get();
        })).build());
        this.pepisTimer = new TimerUtils();
        this.burrowPositions = new ArrayList();
        this.webPositions = new ArrayList();
        this.ghPositions = new ArrayList();
        this.buttonPositions = new ArrayList();
        this.autistPositions = new ArrayList();
    }

    public void onActivate() {
        this.pepisTimer.reset();
    }

    @EventHandler
    private void onTick(Post event) {
        assert this.mc.player != null;

        this.burrowPositions.clear();
        this.webPositions.clear();
        this.ghPositions.clear();
        this.burrowPositions.clear();
        this.autistPositions.clear();
        Random rand = new Random();
        List<String> nickname = new ArrayList();
        Iterator var4 = ((List)this.nicknames.get()).iterator();

        while(var4.hasNext()) {
            String string = (String)var4.next();
            nickname.add(string.toLowerCase());
        }

        List<PlayerEntity> monkes = EntityUtil.getTargetsInRange((Double)this.range.get());
        Collections.shuffle(monkes);
        Iterator var8 = monkes.iterator();

        while(true) {
            PlayerEntity monke;
            do {
                do {
                    do {
                        do {
                            if (!var8.hasNext()) {
                                return;
                            }

                            monke = (PlayerEntity)var8.next();
                            if (nickname.contains(monke.getGameProfile().getName().toLowerCase()) && (Boolean)this.messageByNickname.get() && (Boolean)this.message.get()) {
                                this.sendMsg((String)((List)this.insults.get()).get(rand.nextInt(((List)this.insults.get()).size())), monke);
                            }

                            if (EntityUtil.isBurrowed(monke, (BlockUtil.BlastResistantType)this.burrowType.get(), (Boolean)this.doubleHeightBurrow.get()) && (Boolean)this.renderBurrowed.get() && monke.getVelocity().horizontalLength() <= 6.0D) {
                                this.burrowPositions.add(EntityUtil.playerPos(monke));
                                if ((Boolean)this.message.get() && (!EntityUtil.isBurrowed(this.mc.player) || !(Boolean)this.mutualMonkeIgnore.get())) {
                                    this.sendMsg((String)((List)this.burrowMessages.get()).get(rand.nextInt(((List)this.burrowMessages.get()).size())), monke);
                                }
                            }

                            if (EntityUtil.isWebbed(monke) && (Boolean)this.renderWebbed.get()) {
                                this.webPositions.add(EntityUtil.playerPos(monke));
                                if ((Boolean)this.message.get() && (!EntityUtil.isWebbed(this.mc.player) || !(Boolean)this.mutualMonkeIgnore.get())) {
                                    this.sendMsg((String)((List)this.webMessages.get()).get(rand.nextInt(((List)this.webMessages.get()).size())), monke);
                                }
                            }

                            if (EntityUtil.isSurrounded(monke, BlockUtil.BlastResistantType.Unbreakable) && monke.isOnGround() && (Boolean)this.renderHole.get()) {
                                this.ghPositions.add(EntityUtil.playerPos(monke));
                                if ((Boolean)this.message.get() && (!EntityUtil.isSurrounded(this.mc.player, BlockUtil.BlastResistantType.Unbreakable) || !(Boolean)this.mutualMonkeIgnore.get())) {
                                    this.sendMsg((String)((List)this.holeMessages.get()).get(rand.nextInt(((List)this.holeMessages.get()).size())), monke);
                                }
                            }

                            if (EntityUtil.isButtoned(monke) && (Boolean)this.renderButtoned.get()) {
                                this.buttonPositions.add(EntityUtil.playerPos(monke).up());
                                if ((Boolean)this.message.get() && (!EntityUtil.isButtoned(this.mc.player) || !(Boolean)this.mutualMonkeIgnore.get())) {
                                    this.sendMsg((String)((List)this.buttonMessages.get()).get(rand.nextInt(((List)this.buttonMessages.get()).size())), monke);
                                }
                            }
                        } while(!EntityUtil.isAutist(monke, (Boolean)this.selfTrap.get(), (Boolean)this.antiCevTwo.get(), (BlockUtil.BlastResistantType)this.autistType.get()));
                    } while(!(Boolean)this.renderAutist.get());

                    this.autistPositions.addAll(EntityUtil.getAutistPos(monke, (Boolean)this.selfTrap.get(), (Boolean)this.antiCevTwo.get()));
                } while(!(Boolean)this.message.get());
            } while(EntityUtil.isAutist(this.mc.player, false, false, BlockUtil.BlastResistantType.Any) && (Boolean)this.mutualMonkeIgnore.get());

            this.sendMsg((String)((List)this.autistMessages.get()).get(rand.nextInt(((List)this.autistMessages.get()).size())), monke);
        }
    }

    private void sendMsg(String msg, PlayerEntity player) {
        if (this.pepisTimer.passedMillis((long)(Integer)this.delay.get())) {
            PlayerUtil.sendPlayerMsg(msg.replace("{player}", player.getGameProfile().getName()));
            this.pepisTimer.reset();
        }

    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Iterator var2 = this.ghPositions.iterator();

        BlockPos pos;
        while(var2.hasNext()) {
            pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.holeSideColor.get(), (Color)this.holeLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

        var2 = this.webPositions.iterator();

        while(var2.hasNext()) {
            pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.webSideColor.get(), (Color)this.webLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

        var2 = this.burrowPositions.iterator();

        while(var2.hasNext()) {
            pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

        var2 = this.autistPositions.iterator();

        while(var2.hasNext()) {
            pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.autistSideColor.get(), (Color)this.autistLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

        var2 = this.buttonPositions.iterator();

        while(var2.hasNext()) {
            pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.buttonSideColor.get(), (Color)this.buttonLineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

    }
}
