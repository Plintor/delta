package delta.modules.combat;

import delta.DeltaHack;
import delta.util.CrystalUtils;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;

public class Cuboid extends Module {
    private final SettingGroup sgDefault;
    private final SettingGroup sgDisable;
    private final SettingGroup sgSafety;
    private final SettingGroup sgRender;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> center;
    private final Setting<Double> threshold;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> rotate;
    private final Setting<WorldUtils.SwitchMode> switchMode;
    private final Setting<WorldUtils.PlaceMode> placeMode;
    private final Setting<Boolean> tpDisable;
    private final Setting<Boolean> swing;
    private final Setting<Integer> ticksExisted;
    private static final List<BlockPos> surroundPositions = new ArrayList();
    private static final List<BlockPos> selfTrapPositions = new ArrayList();
    private static final List<BlockPos> extraPositions = new ArrayList();
    private int placingTimer;

    public Cuboid() {
        super(DeltaHack.Old, "pyramid-surround", "Autist pvp.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.sgDisable = this.settings.createGroup("Disable");
        this.sgSafety = this.settings.createGroup("Delta Safety");
        this.sgRender = this.settings.createGroup("Render");
        this.delay = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Extra delay between block bursts. (0 = every tick)")).defaultValue(1)).sliderRange(0, 5).build());
        this.blocksPerTick = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks-per-tick")).description("Amount of blocks to place in 1 tick.")).defaultValue(1)).min(1).sliderMax(4).build());
        this.center = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center")).description("Centers you when surrounding.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgDefault;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("center-threshold")).description("don't touch this unless you know what you're doing.")).defaultValue(0.31D).range(0.0D, 1.0D).sliderRange(0.3D, 0.5D);
        Setting var10003 = this.center;
        Objects.requireNonNull(var10003);
        this.threshold = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.blocks = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for surrounding.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).filter(this::blockFilter).build());
        this.rotate = this.sgDefault.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates to the blocks you place server side.")).defaultValue(true)).build());
        this.switchMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("switch-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.SwitchMode.Both)).build());
        this.placeMode = this.sgDefault.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("place-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.PlaceMode.Both)).build());
        this.tpDisable = this.sgDisable.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("tp-disable")).description("Disables surround when you teleport to another location.")).defaultValue(false)).build());
        this.swing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when placing the blocks.")).defaultValue(false)).build());
        this.ticksExisted = this.sgSafety.add(((Builder)((Builder)((Builder)(new Builder()).name("crystal-age")).description("Amount of ticks a crystal needs to have existed for it to be attacked.")).defaultValue(1)).sliderRange(0, 10).min(0).build());
    }

    public void onActivate() {
        if ((Boolean)this.center.get()) {
            PlayerUtil.centerTwo((Double)this.threshold.get());
        }

        this.placingTimer = 0;
    }

    @EventHandler(
        priority = 200
    )
    public void onPreTick(Pre event) {
        int places = 0;
        if (this.placingTimer == 0) {
            places = (Integer)this.blocksPerTick.get();
            this.placingTimer = (Integer)this.delay.get();
            this.addPositions();
        } else {
            --this.placingTimer;
        }

        Iterator var3 = surroundPositions.iterator();

        BlockPos pos;
        Iterator var5;
        Entity entity;
        while(var3.hasNext()) {
            pos = (BlockPos)var3.next();
            if (places == 0) {
                return;
            }

            var5 = this.mc.world.getEntities().iterator();

            while(var5.hasNext()) {
                entity = (Entity)var5.next();
                if (entity instanceof EndCrystalEntity && CrystalUtils.doesCrystalInterfere(entity, pos)) {
                    CrystalUtils.attackCrystal(entity, (Boolean)this.swing.get());
                }
            }

            if (pos != null && WorldUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
            }), (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), true, true)) {
                --places;
            }
        }

        var3 = selfTrapPositions.iterator();

        while(var3.hasNext()) {
            pos = (BlockPos)var3.next();
            if (places == 0) {
                return;
            }

            var5 = this.mc.world.getEntities().iterator();

            while(var5.hasNext()) {
                entity = (Entity)var5.next();
                if (entity instanceof EndCrystalEntity && CrystalUtils.doesCrystalInterfere(entity, pos) && entity.age >= (Integer)this.ticksExisted.get()) {
                    CrystalUtils.attackCrystal(entity, (Boolean)this.swing.get());
                }
            }

            if (pos != null && WorldUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
            }), (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), true, true)) {
                --places;
            }
        }

        var3 = extraPositions.iterator();

        while(var3.hasNext()) {
            pos = (BlockPos)var3.next();
            if (places == 0) {
                return;
            }

            var5 = this.mc.world.getEntities().iterator();

            while(var5.hasNext()) {
                entity = (Entity)var5.next();
                if (entity instanceof EndCrystalEntity && CrystalUtils.doesCrystalInterfere(entity, pos) && entity.age >= (Integer)this.ticksExisted.get()) {
                    CrystalUtils.attackCrystal(entity, (Boolean)this.swing.get());
                }
            }

            if (pos != null && WorldUtils.place(pos, InvUtils.findInHotbar((itemStack) -> {
                return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
            }), (Boolean)this.rotate.get(), 80, (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), false, WorldUtils.AirPlaceDirection.Down, (Boolean)this.swing.get(), true, true)) {
                --places;
            }
        }

    }

    private void addPositions() {
        BlockPos pos = EntityUtil.playerPos(this.mc.player);
        Direction dir = this.mc.player.getHorizontalFacing();
        surroundPositions.clear();
        selfTrapPositions.clear();
        extraPositions.clear();
        this.add(pos.down());
        this.add(pos.offset(dir));
        this.add(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() - 1))));
        this.add(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() + 1))));
        this.add(pos.offset(dir.getOpposite()));
        this.addExtra(pos.south(2));
        this.addExtra(pos.north(2));
        this.addExtra(pos.west(2));
        this.addExtra(pos.east(2));
        this.addExtra(pos.east().north());
        this.addExtra(pos.west().north());
        this.addExtra(pos.east().south());
        this.addExtra(pos.west().south());
        pos = pos.up();
        this.addSelf(pos.offset(dir));
        this.addSelf(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() - 1))));
        this.addSelf(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() + 1))));
        this.addSelf(pos.offset(dir.getOpposite()));
        this.addSelf(pos.up());
        pos = pos.up();
        this.addExtra(pos.offset(dir));
        this.addExtra(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() - 1))));
        this.addExtra(pos.offset(Direction.fromRotation((double)(dir.getHorizontal() + 1))));
        this.addExtra(pos.offset(dir.getOpposite()));
        this.addExtra(pos.up());
    }

    private void add(BlockPos blockPos) {
        if (!surroundPositions.contains(blockPos) && BlockUtil.canPlace(blockPos, false)) {
            selfTrapPositions.add(blockPos);
        }

    }

    private void addSelf(BlockPos blockPos) {
        if (!selfTrapPositions.contains(blockPos) && BlockUtil.canPlace(blockPos, false)) {
            selfTrapPositions.add(blockPos);
        }

    }

    private void addExtra(BlockPos blockPos) {
        if (!extraPositions.contains(blockPos) && BlockUtil.canPlace(blockPos, false)) {
            extraPositions.add(blockPos);
        }

    }

    private boolean blockFilter(Block block) {
        return block.getBlastResistance() > 600.0F;
    }

    @EventHandler
    private void onSendPacket(Send event) {
        if (event.packet instanceof TeleportConfirmC2SPacket && (Boolean)this.tpDisable.get()) {
            this.toggle();
        }

    }
}
