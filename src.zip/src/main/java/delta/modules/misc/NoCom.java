package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.io.OutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.Flight;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.util.math.MathHelper;

public class NoCom extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgMovement;
    private final Setting<NoCom.CoordinateMode> mode;
    private final Setting<Keybind> pauseBind;
    private final Setting<NoCom.MoveMode> move;
    private final Setting<Integer> airDelay;
    private final Setting<Integer> groundDelay;
    private final Setting<Boolean> teleport;
    private final Setting<Integer> tpDistance;
    private final Setting<Boolean> boost;
    private final Setting<Double> boostSpeed;
    private final Setting<Boolean> jump;
    private final Setting<Boolean> dodgeObstacles;
    private final Setting<Double> bHopOffset;
    private final Setting<NoCom.SpiralDirection> direction;
    private final Setting<Integer> rad;
    private final Setting<Double> dist;
    private final Setting<String> token;
    private final Setting<Boolean> log;
    private final Setting<Boolean> notify;
    private int centX;
    private int centZ;
    private int stage;
    private int ticksSinceBoosting;
    private int airTicks;
    private int groundTicks;
    private boolean shouldUnPress;
    private boolean shouldForwardFly;
    private boolean shouldToggleOffFly;
    private boolean shouldUpFly;
    private boolean shouldDownFly;
    private boolean antiSpamClickPause;
    private boolean shouldPause;
    private NoCom.SpiralDirection dir;
    private Flight flight;

    public NoCom() {
        super(DeltaHack.Misc, "noCom-spiral-player-finder", "Finds players by going in a quadratic spiral.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgMovement = this.settings.createGroup("Movement");
        this.mode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("start-mode")).description("What mode to use to select the starting point of the spiral. (doesn't work yet)")).defaultValue(NoCom.CoordinateMode.Central)).build());
        this.pauseBind = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("pause-bind")).description("Pressing this button toggles the module's work")).defaultValue(Keybind.none())).build());
        this.move = this.sgMovement.add(((Builder)((Builder)((Builder)(new Builder()).name("move-mode")).description("What mode to use for spiral. (eFly doesn't work yet)")).defaultValue(NoCom.MoveMode.Baritone)).build());
        this.airDelay = this.sgMovement.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("air-delay")).description("the delay (in ticks) to open elytras after being in air")).sliderRange(3, 20).defaultValue(4)).range(0, 40).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly;
        })).build());
        this.groundDelay = this.sgMovement.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("ground-delay")).description("the delay (in ticks) to jump after you landed.")).sliderRange(3, 20).defaultValue(4)).range(1, 20).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly;
        })).build());
        this.teleport = this.sgMovement.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("tp-up")).description("Teleport up when reaching ground")).defaultValue(true)).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly;
        })).build());
        this.tpDistance = this.sgMovement.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("tp-distance")).description("The distance you teleport up.")).defaultValue(10)).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly && (Boolean)this.teleport.get();
        })).range(1, 150).sliderRange(1, 20).build());
        this.boost = this.sgMovement.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("boost")).description("Boost when reaching ground")).defaultValue(true)).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly;
        })).build());
        this.boostSpeed = this.sgMovement.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("boost-speed")).description("The speed you boost at")).range(1.0D, 10.0D).defaultValue(4.0D).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly && (Boolean)this.boost.get();
        })).build());
        this.jump = this.sgMovement.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("jump-up")).description("Jump up when reaching ground")).defaultValue(true)).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly;
        })).build());
        this.dodgeObstacles = this.sgMovement.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("dodge-obstacles")).description("Dodge obstacles when flying.")).defaultValue(true)).visible(() -> {
            return this.move.get() == NoCom.MoveMode.Fly;
        })).build());
        this.bHopOffset = this.sgMovement.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("ground-offset")).description("The height above ground to trigger the maneuver(maneuvers)")).defaultValue(0.9D).range(0.0D, 2.0D).sliderRange(0.5D, 1.0D).visible(() -> {
            return this.move.get() == NoCom.MoveMode.eFly && ((Boolean)this.teleport.get() || (Boolean)this.jump.get() || (Boolean)this.boost.get());
        })).build());
        this.direction = this.sgGeneral.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("default-direction")).description("What default direction to use for spiral.")).defaultValue(NoCom.SpiralDirection.XPlus)).visible(() -> {
            return this.mode.get() != NoCom.CoordinateMode.Positional;
        })).build());
        this.rad = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("radius")).description("the gap (in chunks) between the spiral's lines (5-7 is recommended for spawn area, around 8 is recommended when searching for coordinates outside the spawn area)")).sliderRange(3, 16).defaultValue(4)).range(3, 16).build());
        this.dist = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("distance")).description("the distance (in blocks) between the spiral's edge and player pos to turn around.")).sliderRange(5.0D, 20.0D).defaultValue(4.0D).range(5.0D, 50.0D).build());
        this.token = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("webHook-token")).description("the link to the webhook to send the coords of the player from.")).defaultValue("")).build());
        this.log = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("log-off-on-player-found")).description("log off if you found a player who's not in your friends list")).defaultValue(true)).build());
        this.notify = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("debug")).description("notify you about what the fuck is going on")).defaultValue(false)).build());
        this.centZ = 0;
        this.stage = 1;
        this.shouldToggleOffFly = true;
    }

    @EventHandler
    public void onTick(Pre event) {
        if (((Keybind)this.pauseBind.get()).isPressed()) {
            if (!this.antiSpamClickPause) {
                this.mc.options.forwardKey.setPressed(false);
                this.mc.options.sprintKey.setPressed(false);
                Input.setKeyState(this.mc.options.forwardKey, false);
                Input.setKeyState(this.mc.options.sprintKey, false);
                this.shouldPause = !this.shouldPause;
                if ((Boolean)this.notify.get()) {
                    this.info("Pause bind pressed.", new Object[0]);
                }

                this.antiSpamClickPause = true;
            }
        } else {
            this.antiSpamClickPause = false;
        }

        if (!this.shouldPause) {
            boolean newArm = BlockUtil.distanceXZ(this.mc.player.getPos(), new Vec3d((double)this.centX, 0.0D, (double)this.centZ)) <= (Double)this.dist.get() || this.stage == 0;
            if (newArm) {
                this.makeSpiralArm();
            }

            float alpha = this.getXZAngle(this.mc.player.getPos().getX(), (double)this.centX, this.mc.player.getPos().getZ(), (double)this.centZ);
            if (this.shouldUnPress) {
                this.mc.options.jumpKey.setPressed(false);
                Input.setKeyState(this.mc.options.jumpKey, false);
                this.shouldUnPress = false;
            }

            switch((NoCom.MoveMode)this.move.get()) {
                case Baritone:
                    this.mc.options.forwardKey.setPressed(true);
                    this.mc.options.sprintKey.setPressed(true);
                    Input.setKeyState(this.mc.options.forwardKey, true);
                    Input.setKeyState(this.mc.options.sprintKey, true);
                    if (newArm) {
                        this.mc.player.sendChatMessage("#goto " + this.centX + " " + this.centZ, (Text)null);
                        if ((Boolean)this.notify.get()) {
                            this.info("Baritone command sent", new Object[0]);
                        }
                    }
                    break;
                case Fly:
                    this.setYawAngle(alpha);
                    if (!this.flight.isActive()) {
                        this.flight.toggle();
                    }

                    double hSpeed = PlayerUtil.horizontalSpeed();
                    if ((Boolean)this.notify.get()) {
                        this.info("Horizontal speed: " + hSpeed, new Object[0]);
                    }

                    if (PlayerUtil.horizontalSpeed() < 0.03D) {
                        if ((Boolean)this.notify.get()) {
                            this.warning("You are moving suspiciously slow.", new Object[0]);
                        }

                        if ((Boolean)this.dodgeObstacles.get()) {
                            if (!this.shouldUpFly) {
                                if (!this.shouldDownFly) {
                                    this.shouldUpFly = true;
                                }
                            } else {
                                this.info(String.valueOf(this.mc.player.getVelocity().getY()), new Object[0]);
                            }
                        }
                    } else {
                        this.shouldDownFly = false;
                        this.shouldUpFly = false;
                    }

                    if (this.shouldUpFly) {
                        Input.setKeyState(this.mc.options.jumpKey, true);
                        this.mc.options.jumpKey.setPressed(true);
                    } else {
                        Input.setKeyState(this.mc.options.jumpKey, false);
                        this.mc.options.jumpKey.setPressed(false);
                    }

                    if (this.shouldDownFly) {
                        this.info("Shit", new Object[0]);
                        Input.setKeyState(this.mc.options.sneakKey, true);
                        this.mc.options.sneakKey.setPressed(true);
                    } else {
                        Input.setKeyState(this.mc.options.sneakKey, false);
                        this.mc.options.sneakKey.setPressed(false);
                    }

                    if (this.shouldForwardFly) {
                        this.mc.options.forwardKey.setPressed(true);
                        Input.setKeyState(this.mc.options.forwardKey, true);
                    } else {
                        this.mc.options.forwardKey.setPressed(false);
                        Input.setKeyState(this.mc.options.forwardKey, false);
                    }
                    break;
                case eFly:
                    this.setYawAngle(alpha);
                    this.mc.options.forwardKey.setPressed(true);
                    Input.setKeyState(this.mc.options.forwardKey, true);
                    if (this.airTicks >= (Integer)this.airDelay.get() && this.mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA && !this.mc.player.isFallFlying()) {
                        this.shouldUnPress = !this.mc.options.jumpKey.isPressed();
                        PlayerUtil.openElytras();
                        if ((Boolean)this.notify.get()) {
                            this.info("InAir, opening elytra...", new Object[0]);
                        }
                    }

                    if (this.groundTicks >= (Integer)this.groundDelay.get()) {
                        this.mc.player.jump();
                        if ((Boolean)this.notify.get()) {
                            this.info("OnGround, jumping...", new Object[0]);
                        }

                        this.groundTicks = 0;
                    }

                    if (PlayerUtil.isElytraFlying()) {
                        if (BlockUtil.isFullBlock(this.mc.player.getBlockPos().add(0.0D, -(Double)this.bHopOffset.get(), 0.0D)) || PlayerUtil.horizontalSpeed() < 0.02D) {
                            if ((Boolean)this.teleport.get()) {
                                PlayerUtil.teleportVec(Vec3d.ofBottomCenter(this.mc.player.getBlockPos().up((Integer)this.tpDistance.get())));
                            }

                            if ((Boolean)this.jump.get()) {
                                this.mc.player.jump();
                            }

                            if ((Boolean)this.boost.get()) {
                                if (this.ticksSinceBoosting > (Integer)this.tpDistance.get() / 10) {
                                    this.mc.player.addVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getYaw()))) * (Double)this.boostSpeed.get(), 0.0D, (double)MathHelper.cos((float)Math.toRadians((double)this.mc.player.getYaw())) * (Double)this.boostSpeed.get());
                                    this.ticksSinceBoosting = 0;
                                } else {
                                    ++this.ticksSinceBoosting;
                                    if ((Boolean)this.notify.get()) {
                                        this.warning("You are boosting suspiciously fast.", new Object[0]);
                                    }
                                }
                            }
                        }

                        if ((Boolean)this.notify.get()) {
                            this.info("Horizontal speed: " + PlayerUtil.horizontalSpeed(), new Object[0]);
                        }
                    } else if (this.mc.player.isOnGround()) {
                        this.airTicks = 0;
                        ++this.groundTicks;
                    } else {
                        ++this.airTicks;
                        this.groundTicks = 0;
                    }
            }

        }
    }

    public void onActivate() {
        if (this.move.get() == NoCom.MoveMode.Fly) {
            this.flight = (Flight)Modules.get().get(Flight.class);
            if (this.flight == null) {
                this.flight = new Flight();
                this.shouldToggleOffFly = true;
            } else {
                this.shouldToggleOffFly = false;
            }
        }

        this.shouldUnPress = false;
        this.shouldForwardFly = true;
        this.shouldUpFly = false;
        this.shouldDownFly = false;
        this.shouldPause = false;
        this.antiSpamClickPause = false;
        this.ticksSinceBoosting = 0;
        this.airTicks = 0;
        this.groundTicks = 0;
        switch((NoCom.CoordinateMode)this.mode.get()) {
            case Central:
                if (this.direction.get() != NoCom.SpiralDirection.Smart) {
                    this.dir = (NoCom.SpiralDirection)this.direction.get();
                } else {
                    float pY = this.mc.player.getYaw();
                    if ((Boolean)this.notify.get()) {
                        this.info("Player yaw rotation: " + pY, new Object[0]);
                    }

                    if (this.mc.player.getHorizontalFacing() == Direction.EAST) {
                        this.dir = NoCom.SpiralDirection.XPlus;
                    }

                    if (this.mc.player.getHorizontalFacing() == Direction.WEST) {
                        this.dir = NoCom.SpiralDirection.XMinus;
                    }

                    if (this.mc.player.getHorizontalFacing() == Direction.SOUTH) {
                        this.dir = NoCom.SpiralDirection.ZPlus;
                    }

                    if (this.mc.player.getHorizontalFacing() == Direction.NORTH) {
                        this.dir = NoCom.SpiralDirection.ZMinus;
                    }
                }

                this.centX = EntityUtil.playerPos(this.mc.player).getX();
                this.centZ = EntityUtil.playerPos(this.mc.player).getZ();
                break;
            case Positional:
                this.dir = NoCom.SpiralDirection.ZPlus;
                byte targetStage;
                if (EntityUtil.playerPos(this.mc.player).getX() > 0) {
                    if (EntityUtil.playerPos(this.mc.player).getZ() > 0) {
                        targetStage = 2;
                    } else {
                        targetStage = 1;
                    }
                } else if (EntityUtil.playerPos(this.mc.player).getZ() > 0) {
                    targetStage = 3;
                } else {
                    targetStage = 0;
                }

                double prevDistance = 2.147483647E9D;

                while(true) {
                    if (this.stage % 4 == targetStage) {
                        this.info(this.centX + " " + this.centZ, new Object[0]);
                        if (BlockUtil.distanceXZ(this.mc.player.getPos(), new Vec3d((double)this.centX, 0.0D, (double)this.centZ)) > prevDistance) {
                            this.mc.player.sendChatMessage("#goto " + this.centX + " " + this.centZ, (Text)null);
                            break;
                        }

                        prevDistance = BlockUtil.distanceXZ(this.mc.player.getPos(), new Vec3d((double)this.centX, 0.0D, (double)this.centZ));
                    }

                    this.makeSpiralArm();
                }
        }

    }

    public void onDeactivate() {
        if (this.move.get() == NoCom.MoveMode.Baritone) {
            this.mc.player.sendChatMessage("#c", (Text)null);
        }

        if ((Boolean)this.notify.get()) {
            this.error("Disabled, stopped", new Object[0]);
        }

        this.stage = 1;
        this.centX = 0;
        this.centZ = 0;
        this.mc.options.forwardKey.setPressed(false);
        this.mc.options.jumpKey.setPressed(false);
        this.mc.options.sneakKey.setPressed(false);
        this.mc.options.sprintKey.setPressed(false);
        Input.setKeyState(this.mc.options.forwardKey, false);
        Input.setKeyState(this.mc.options.jumpKey, false);
        Input.setKeyState(this.mc.options.sneakKey, false);
        Input.setKeyState(this.mc.options.sprintKey, false);
        if (this.shouldToggleOffFly && this.flight != null) {
            this.flight.toggle();
        }

    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (!((String)this.token.get()).equals("")) {
            if (!event.entity.equals(this.mc.player)) {
                if (event.entity instanceof PlayerEntity && this.mc.getCurrentServerEntry() != null) {
                    if (!Friends.get().isFriend((PlayerEntity)event.entity)) {
                        String var10000 = event.entity.getEntityName();
                        String jsonBrut = "{\"embeds\": [{\"title\": \"Found player " + var10000 + "\",\"description\": \"At " + event.entity.getBlockPos().getX() + "X, " + event.entity.getBlockPos().getZ() + "Z by " + this.mc.player.getEntityName() + " on " + this.mc.getCurrentServerEntry().address + "\",\"color\": 15258703}]}";

                        try {
                            URL url = new URL((String)this.token.get());
                            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
                            con.addRequestProperty("Content-Type", "application/json");
                            con.addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
                            con.setDoOutput(true);
                            con.setRequestMethod("POST");
                            OutputStream stream = con.getOutputStream();
                            stream.write(jsonBrut.getBytes());
                            stream.flush();
                            stream.close();
                            con.getInputStream().close();
                            con.disconnect();
                        } catch (Exception var6) {
                            var6.printStackTrace();
                        }

                        if ((Boolean)this.log.get()) {
                            this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(Text.literal("Player found!")));
                        }

                        this.toggle();
                    } else {
                        this.warning("Found a player but they are in your friends.", new Object[0]);
                    }
                }

            }
        }
    }

    private void makeSpiralArm() {
        int dirMultiplierX = 0;
        int dirMultiplierZ = 0;
        switch(this.dir) {
            case XMinus:
                dirMultiplierX = -1;
                this.dir = NoCom.SpiralDirection.ZMinus;
                break;
            case ZPlus:
                dirMultiplierZ = 1;
                this.dir = NoCom.SpiralDirection.XMinus;
                break;
            case XPlus:
                dirMultiplierX = 1;
                this.dir = NoCom.SpiralDirection.ZPlus;
                break;
            case ZMinus:
                dirMultiplierZ = -1;
                this.dir = NoCom.SpiralDirection.XPlus;
        }

        this.centX += (Integer)this.rad.get() * 16 * dirMultiplierX * this.stage;
        this.centZ += (Integer)this.rad.get() * 16 * dirMultiplierZ * this.stage;
        ++this.stage;
        if ((Boolean)this.notify.get()) {
            this.info("Made spiral arm", new Object[0]);
        }

    }

    private float getXZAngle(double x1Point, double x2Point, double z1Point, double z2Point) {
        return (float)Math.toDegrees(Math.atan2(x1Point - x2Point, z2Point - z1Point));
    }

    private void setYawAngle(float yawAngle) {
        this.mc.player.setYaw(yawAngle);
        this.mc.player.headYaw = yawAngle;
        this.mc.player.bodyYaw = yawAngle;
    }

    public static enum CoordinateMode {
        Central,
        Positional;

        // $FF: synthetic method
        private static NoCom.CoordinateMode[] $values() {
            return new NoCom.CoordinateMode[]{Central, Positional};
        }
    }

    public static enum MoveMode {
        Fly,
        eFly,
        Baritone;

        // $FF: synthetic method
        private static NoCom.MoveMode[] $values() {
            return new NoCom.MoveMode[]{Fly, eFly, Baritone};
        }
    }

    public static enum SpiralDirection {
        XPlus,
        XMinus,
        ZPlus,
        ZMinus,
        Smart;

        // $FF: synthetic method
        private static NoCom.SpiralDirection[] $values() {
            return new NoCom.SpiralDirection[]{XPlus, XMinus, ZPlus, ZMinus, Smart};
        }
    }
}
