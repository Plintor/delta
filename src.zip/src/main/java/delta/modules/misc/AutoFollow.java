package delta.modules.misc;

import delta.DeltaHack;
import java.util.Objects;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoFollow extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<AutoFollow.Mode> mode;
    private final Setting<Keybind> keybind;
    private final Setting<Boolean> onlyFriend;
    private final Setting<Boolean> onlyOther;
    private final Setting<Double> range;
    private final Setting<Boolean> ignoreRange;
    private final Setting<SortPriority> priority;
    private final Setting<Boolean> message;
    private final Setting<Boolean> dm;
    private final Setting<Boolean> pm;
    boolean isFollowing;
    String playerName;
    Entity playerEntity;
    boolean pressed;
    boolean alternate;

    public AutoFollow() {
        super(DeltaHack.Misc, "auto-Follow", "Follow another player in different ways.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.mode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("PositionMode")).description("The mode at which to follow the player.")).defaultValue(AutoFollow.Mode.BindClickFollow)).build());
        this.keybind = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("follow-keybind")).description("What key to press to start following someone.")).defaultValue(Keybind.fromKey(-1))).visible(() -> {
            return this.mode.get() == AutoFollow.Mode.BindClickFollow;
        })).build());
        this.onlyFriend = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-follow-friends")).description("Whether or not to only follow friends.")).defaultValue(false)).build());
        this.onlyOther = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("don't-follow-friends")).description("Whether or not to follow friends.")).defaultValue(false)).visible(() -> {
            return this.mode.get() != AutoFollow.Mode.FollowPlayer;
        })).build());
        this.range = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("Range")).description("The range in which it follows a random player.")).defaultValue(20.0D).min(0.0D).sliderMax(200.0D).visible(() -> {
            return this.mode.get() == AutoFollow.Mode.FollowPlayer;
        })).build());
        this.ignoreRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("keep-Following")).description("Follow the player even if they are out of range.")).defaultValue(false)).visible(() -> {
            return this.mode.get() == AutoFollow.Mode.FollowPlayer;
        })).build());
        this.priority = this.sgGeneral.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("target-priority")).description("How to select the player to target.")).defaultValue(SortPriority.LowestDistance)).visible(() -> {
            return this.mode.get() == AutoFollow.Mode.FollowPlayer;
        })).build());
        this.message = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("message")).description("Sends a message to the player when you start/stop following them.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("private-msg")).description("Sends a private chat msg to the person.")).defaultValue(false);
        Setting var10003 = this.message;
        Objects.requireNonNull(var10003);
        this.dm = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("public-msg")).description("Sends a public chat msg.")).defaultValue(false);
        var10003 = this.message;
        Objects.requireNonNull(var10003);
        this.pm = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.isFollowing = false;
        this.pressed = false;
        this.alternate = true;
    }

    @EventHandler
    private void onMouseButton(MouseButtonEvent event) {
        if (this.mode.get() == AutoFollow.Mode.MiddleClickToFollow) {
            if (event.action == KeyAction.Press && event.button == 2 && this.mc.currentScreen == null && this.mc.targetedEntity != null && this.mc.targetedEntity instanceof PlayerEntity) {
                if (!this.isFollowing) {
                    if (!Friends.get().isFriend((PlayerEntity)this.mc.targetedEntity) && (Boolean)this.onlyFriend.get()) {
                        return;
                    }

                    if (Friends.get().isFriend((PlayerEntity)this.mc.targetedEntity) && (Boolean)this.onlyOther.get()) {
                        return;
                    }

                    ClientPlayerEntity var10000 = this.mc.player;
                    String var10001 = (String)Config.get().prefix.get() + "baritone follow player " + this.mc.targetedEntity.getEntityName();
                    String var10002 = (String)Config.get().prefix.get();
                    var10000.sendChatMessage(var10001, Text.literal(var10002 + "baritone follow player " + this.mc.targetedEntity.getEntityName()));
                    this.playerName = this.mc.targetedEntity.getEntityName();
                    this.playerEntity = this.mc.targetedEntity;
                    if ((Boolean)this.message.get()) {
                        this.startMsg();
                    }

                    this.isFollowing = true;
                } else {
                    this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "baritone stop", Text.literal((String)Config.get().prefix.get() + "baritone stop"));
                    if ((Boolean)this.message.get()) {
                        this.endMsg();
                    }

                    this.playerName = null;
                    this.isFollowing = false;
                }
            } else if (event.action == KeyAction.Press && event.button == 2 && this.isFollowing) {
                this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "baritone stop", Text.literal((String)Config.get().prefix.get() + "baritone stop"));
                if ((Boolean)this.message.get()) {
                    this.endMsg();
                }

                this.playerName = null;
                this.isFollowing = false;
            }
        }

    }

    @EventHandler(
        priority = -100
    )
    private void onTick(Post event) {
        ClientPlayerEntity var10000;
        String var10001;
        String var10002;
        if (this.mode.get() == AutoFollow.Mode.BindClickFollow && this.keybind != null) {
            if (((Keybind)this.keybind.get()).isPressed() && !this.pressed && !this.alternate && this.isFollowing) {
                this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "baritone stop", Text.literal((String)Config.get().prefix.get() + "baritone stop"));
                if ((Boolean)this.message.get()) {
                    this.endMsg();
                }

                this.pressed = true;
                this.alternate = true;
                this.playerName = null;
                this.isFollowing = false;
            }

            if (!((Keybind)this.keybind.get()).isPressed()) {
                this.pressed = false;
            }

            if (((Keybind)this.keybind.get()).isPressed() && !this.pressed && this.alternate && this.mc.currentScreen == null && this.mc.targetedEntity != null && this.mc.targetedEntity instanceof PlayerEntity && !this.isFollowing) {
                if (!Friends.get().isFriend((PlayerEntity)this.mc.targetedEntity) && (Boolean)this.onlyFriend.get()) {
                    return;
                }

                if (Friends.get().isFriend((PlayerEntity)this.mc.targetedEntity) && (Boolean)this.onlyOther.get()) {
                    return;
                }

                var10000 = this.mc.player;
                var10001 = (String)Config.get().prefix.get() + "baritone follow player " + this.mc.targetedEntity.getEntityName();
                var10002 = (String)Config.get().prefix.get();
                var10000.sendChatMessage(var10001, Text.literal(var10002 + "baritone follow player " + this.mc.targetedEntity.getEntityName()));
                this.playerName = this.mc.targetedEntity.getEntityName();
                this.playerEntity = this.mc.targetedEntity;
                if ((Boolean)this.message.get()) {
                    this.startMsg();
                }

                this.pressed = true;
                this.alternate = false;
                this.isFollowing = true;
            }
        }

        if (this.mode.get() == AutoFollow.Mode.FollowPlayer) {
            if (!this.isFollowing) {
                this.playerEntity = TargetUtils.getPlayerTarget((Double)this.range.get(), (SortPriority)this.priority.get());
                if (this.playerEntity == null) {
                    return;
                }

                this.playerName = this.playerEntity.getEntityName();
                if (!Friends.get().isFriend((PlayerEntity)this.playerEntity) && (Boolean)this.onlyFriend.get()) {
                    return;
                }

                var10000 = this.mc.player;
                var10001 = (String)Config.get().prefix.get() + "baritone follow player " + this.playerName;
                var10002 = (String)Config.get().prefix.get();
                var10000.sendChatMessage(var10001, Text.literal(var10002 + "baritone follow player " + this.playerName));
                if ((Boolean)this.message.get()) {
                    this.startMsg();
                }

                this.isFollowing = true;
            }

            if (!this.playerEntity.isAlive() || (double)this.playerEntity.distanceTo(this.mc.player) > (Double)this.range.get() && !(Boolean)this.ignoreRange.get()) {
                if ((Boolean)this.message.get()) {
                    this.endMsg();
                }

                this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "baritone stop", Text.literal((String)Config.get().prefix.get() + "baritone stop"));
                this.playerEntity = null;
                this.playerName = null;
                this.isFollowing = false;
            }
        }

    }

    public void onDeactivate() {
        this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "baritone stop", Text.literal((String)Config.get().prefix.get() + "baritone stop"));
        this.playerEntity = null;
        this.playerName = null;
        this.isFollowing = false;
    }

    public void startMsg() {
        if ((Boolean)this.dm.get()) {
            this.mc.player.sendChatMessage("/msg " + this.playerName + " I am now following you using Banana+", Text.literal("/msg " + this.playerName + " I am now following you using Banana+"));
        }

        if ((Boolean)this.pm.get()) {
            this.mc.player.sendChatMessage("I am now following " + this.playerName + " using Banana+", Text.literal("I am now following " + this.playerName + " using Banana+"));
        }

    }

    public void endMsg() {
        if ((Boolean)this.dm.get()) {
            this.mc.player.sendChatMessage("/msg " + this.playerName + " I am no longer following you", Text.literal("/msg " + this.playerName + " I am no longer following you"));
        }

        if ((Boolean)this.pm.get()) {
            this.mc.player.sendChatMessage("I am no longer following " + this.playerName, Text.literal("I am no longer following " + this.playerName));
        }

    }

    public static enum Mode {
        MiddleClickToFollow,
        FollowPlayer,
        BindClickFollow;

        // $FF: synthetic method
        private static AutoFollow.Mode[] $values() {
            return new AutoFollow.Mode[]{MiddleClickToFollow, FollowPlayer, BindClickFollow};
        }
    }
}
