package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.PlayerUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.BlockPos.Mutable;

public class AutoKovchegPlace extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> range;
    private final Setting<Integer> delay;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> plantOnKelp;
    private final Pool<Mutable> kovchegPool;
    private final List<Mutable> kovchegBlockList;
    private int ticksWaited;

    public AutoKovchegPlace() {
        super(DeltaHack.Util, "auto-kovcheg-place", "Automatically places kelp");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.range = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("range")).description("Range for block placement and rendering")).defaultValue(3)).min(0).build());
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Delay in ticks between placing kelp")).defaultValue(0)).min(0).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Rotates towards the blocks being placed.")).defaultValue(true)).build());
        this.plantOnKelp = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("plant-on-kelp")).description("Should you place kelp on top of kelp")).defaultValue(true)).build());
        this.kovchegPool = new Pool(Mutable::new);
        this.kovchegBlockList = new ArrayList();
    }

    @EventHandler
    private void onTickPre(Pre event) {
        if ((Integer)this.delay.get() == 0 || this.ticksWaited >= (Integer)this.delay.get() - 1) {
            FindItemResult foundBlock = InvUtils.findInHotbar(new Item[]{Items.KELP});
            if (foundBlock.found()) {
                Iterator var3 = this.kovchegBlockList.iterator();

                while(var3.hasNext()) {
                    Mutable blockPos = (Mutable)var3.next();
                    this.kovchegPool.free(blockPos);
                }

                this.kovchegBlockList.clear();
                BlockIterator.register((Integer)this.range.get(), (Integer)this.range.get(), (blockPosx, blockState) -> {
                    if (!(PlayerUtil.distanceFromEye(blockPosx) > (double)(Integer)this.range.get())) {
                        if (blockState.isOf(Blocks.WATER) && blockState.getFluidState().getLevel() > 7 && (BlockUtil.isFullBlock(blockPosx.down()) || BlockUtil.getBlock(blockPosx.down()) == Blocks.KELP && (Boolean)this.plantOnKelp.get())) {
                            this.kovchegBlockList.add(((Mutable)this.kovchegPool.get()).set(blockPosx));
                        }

                    }
                });
            }
        }
    }

    @EventHandler
    private void onTickPost(Post event) {
        if ((Integer)this.delay.get() != 0 && this.ticksWaited < (Integer)this.delay.get() - 1) {
            ++this.ticksWaited;
        } else if (!this.kovchegBlockList.isEmpty()) {
            FindItemResult block = InvUtils.findInHotbar(new Item[]{Items.KELP});
            if (block.found()) {
                if ((Integer)this.delay.get() == 0) {
                    Iterator var3 = this.kovchegBlockList.iterator();

                    while(var3.hasNext()) {
                        BlockPos blockPos = (BlockPos)var3.next();
                        BlockUtils.place(blockPos, block, (Boolean)this.rotate.get(), -50, false);
                    }
                } else if (this.mc.player.getInventory().getStack(block.slot()).getItem().equals(Items.KELP)) {
                    Mutable selectedBlockPos = (Mutable)this.kovchegBlockList.get(0);
                    selectedBlockPos.set((Vec3i)this.kovchegBlockList.get((new Random()).nextInt(this.kovchegBlockList.size())));
                    BlockUtils.place(selectedBlockPos, block, (Boolean)this.rotate.get(), -50, false);
                } else {
                    BlockUtils.place((BlockPos)this.kovchegBlockList.get(0), block, (Boolean)this.rotate.get(), -50, false);
                }

                this.ticksWaited = 0;
            }
        }
    }
}
