package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;

public class AutoLogPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgLogMessages;
    private final Setting<AutoLogPlus.LogMode> logMode;
    private final Setting<String> kickCommand;
    private final Setting<Boolean> lagCheck;
    private final Setting<Double> tickTime;
    private final Setting<AutoLogPlus.TriggerMode> triggerMode;
    private final Setting<Boolean> visualRange;
    private final Setting<Integer> health;
    private final Setting<Boolean> smart;
    private final Setting<Boolean> noTotemsOnly;
    private final Setting<Integer> totemsCount;
    private final Setting<Boolean> toggleOff;
    private final Setting<Boolean> ignoreIfNaked;
    private final Setting<Boolean> logMessagesActive;
    private final Setting<Boolean> showNearbyPlayers;
    private final Setting<Boolean> ignoreFriends;
    String logMessage;
    List<String> nearbyPlayers;
    AutoReconnect autoReconnect;
    boolean autoRecActive;
    private final AutoLogPlus.StaticListener staticListener;

    public AutoLogPlus() {
        super(DeltaHack.Misc, "auto-log+", "Logs you off of the server when you're fucked");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgLogMessages = this.settings.createGroup("Log Messages");
        this.logMode = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("log-mode")).defaultValue(AutoLogPlus.LogMode.Quit)).build());
        this.kickCommand = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("kick-command")).visible(() -> {
            return this.logMode.get() == AutoLogPlus.LogMode.Kick;
        })).defaultValue("/calc")).build());
        this.lagCheck = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("lag-mode")).description("Disconnects when no answer from the server.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.DoubleSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("last-tick-time")).description("Time after the last tick.")).defaultValue(6.0D).range(0.0D, 40.0D).sliderMax(40.0D);
        Setting var10003 = this.lagCheck;
        Objects.requireNonNull(var10003);
        this.tickTime = var10001.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)var10002.visible(var10003::get)).build());
        this.triggerMode = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("trigger-mode")).defaultValue(AutoLogPlus.TriggerMode.Health)).build());
        this.visualRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("log-off-on-visual-range")).description("Asked to be made by Touch My Sword.")).defaultValue(false)).build());
        this.health = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("health")).description("Automatically disconnects when health is lower or equal to this value.")).defaultValue(6)).range(0, 20).sliderMax(20).visible(() -> {
            return this.triggerMode.get() == AutoLogPlus.TriggerMode.Health;
        })).build());
        this.smart = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("smart")).description("Disconnects when you're about to take enough damage to die.")).defaultValue(true)).visible(() -> {
            return this.triggerMode.get() == AutoLogPlus.TriggerMode.Health;
        })).build());
        this.noTotemsOnly = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-no-totems")).description("Health mode works if no totems only.")).defaultValue(true)).visible(() -> {
            return this.triggerMode.get() == AutoLogPlus.TriggerMode.Health;
        })).build());
        this.totemsCount = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("totems-count")).description("Disconnects when totems count is lower or equal this value.")).defaultValue(2)).range(0, 9999).sliderRange(0, 37).visible(() -> {
            return this.triggerMode.get() == AutoLogPlus.TriggerMode.Totems;
        })).build());
        this.toggleOff = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-off")).description("Disables Auto Log after usage.")).defaultValue(true)).build());
        this.ignoreIfNaked = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-if-naked")).description("Not use Auto Log if you are a monke.")).defaultValue(true)).build());
        this.logMessagesActive = this.sgLogMessages.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("log-messages")).description("Show log information after quit.")).defaultValue(true)).build());
        var10001 = this.sgLogMessages;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("show-nearby-players")).defaultValue(true);
        var10003 = this.logMessagesActive;
        Objects.requireNonNull(var10003);
        this.showNearbyPlayers = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).build());
        this.ignoreFriends = this.sgLogMessages.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-friends")).defaultValue(true)).visible(() -> {
            return (Boolean)this.showNearbyPlayers.get() && (Boolean)this.logMessagesActive.get();
        })).build());
        this.logMessage = "";
        this.nearbyPlayers = new ArrayList();
        this.autoReconnect = (AutoReconnect)Modules.get().get(AutoReconnect.class);
        this.autoRecActive = false;
        this.staticListener = new AutoLogPlus.StaticListener();
    }

    @EventHandler
    private void onTick(Post event) {
        if (this.mc.player != null && this.mc.world != null) {
            if (this.isActive()) {
                if (!this.mc.player.isCreative() && !this.mc.player.isSpectator()) {
                    int playerHealth = (int)this.mc.player.getHealth();
                    if (!(Boolean)this.ignoreIfNaked.get() || !EntityUtil.isNaked(this.mc.player)) {
                        if ((Boolean)this.showNearbyPlayers.get()) {
                            this.nearbyPlayers.clear();
                            Iterator var3 = this.mc.world.getPlayers().iterator();

                            label75:
                            while(true) {
                                PlayerEntity player;
                                do {
                                    do {
                                        do {
                                            if (!var3.hasNext()) {
                                                break label75;
                                            }

                                            player = (PlayerEntity)var3.next();
                                        } while(player == this.mc.player);
                                    } while(player.distanceTo(this.mc.player) > 30.0F);
                                } while((Boolean)this.ignoreFriends.get() && Friends.get().isFriend(player));

                                this.nearbyPlayers.add(player.getName().getString());
                            }
                        }

                        double lastTick = (double)TickRate.INSTANCE.getTimeSinceLastTick();
                        if ((Boolean)this.lagCheck.get() && lastTick >= (Double)this.tickTime.get()) {
                            this.log("§7§lServer was lagged." + this.conNearbyPlayers());
                        } else {
                            switch((AutoLogPlus.TriggerMode)this.triggerMode.get()) {
                                case Health:
                                    if (!(Boolean)this.noTotemsOnly.get() || InvUtils.find(new Item[]{Items.TOTEM_OF_UNDYING}).slot() == -1) {
                                        if ((Boolean)this.smart.get()) {
                                            if ((double)((float)playerHealth + this.mc.player.getAbsorptionAmount()) - PlayerUtils.possibleHealthReductions() < (double)(Integer)this.health.get()) {
                                                this.log("§c§lHealth going lower. Hp left: §r§l§n" + playerHealth + this.conNearbyPlayers());
                                            }
                                        } else if (playerHealth <= (Integer)this.health.get()) {
                                            this.log("§c§lHealth was lower than §r§l§n" + this.health.get() + "§r§4§l. Left: §r§l§n" + playerHealth + this.conNearbyPlayers());
                                        }
                                    }
                                    break;
                                case Totems:
                                    int totems = InvUtils.find(new Item[]{Items.TOTEM_OF_UNDYING}).count();
                                    if (totems <= (Integer)this.totemsCount.get()) {
                                        this.log("§6§lTotems left: §r§l§n" + totems + this.conNearbyPlayers());
                                    }
                            }

                        }
                    }
                }
            }
        }
    }

    public void log(String message) {
        if (this.mc.player != null) {
            this.logMessage = message;
            this.autoRecActive = this.autoReconnect.isActive();
            if (this.autoRecActive) {
                this.autoReconnect.toggle();
            }

            switch((AutoLogPlus.LogMode)this.logMode.get()) {
                case Kick:
                    this.mc.player.sendCommand((String)this.kickCommand.get());
                    break;
                case Quit:
                    this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(Text.of("")));
            }

            MeteorClient.EVENT_BUS.subscribe(this.staticListener);
        }
    }

    private String conNearbyPlayers() {
        return (Boolean)this.showNearbyPlayers.get() && !this.nearbyPlayers.isEmpty() ? "§r\n\n§b§lNearby players:§r\n" + this.nearbyPlayers + "." : "";
    }

    private void setScreen() {
        if (this.mc.currentScreen instanceof DisconnectedScreen) {
            if ((Boolean)this.logMessagesActive.get()) {
                this.mc.setScreen(new DisconnectedScreen(new TitleScreen(), Text.of("§9§lTriggered AutoLog"), Text.of(this.logMessage)));
            } else {
                this.mc.setScreen(new TitleScreen());
            }

        }
    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        if (this.triggerMode.get() == AutoLogPlus.TriggerMode.Pop) {
            Packet var3 = event.packet;
            if (var3 instanceof EntityStatusS2CPacket) {
                EntityStatusS2CPacket p = (EntityStatusS2CPacket)var3;
                if (p.getStatus() == 35 && p.getEntity(this.mc.world).equals(this.mc.player)) {
                    this.log("§6§lYou popped!");
                }

            }
        }
    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (!event.entity.getUuid().equals(this.mc.player.getUuid()) && (Boolean)this.visualRange.get()) {
            Entity var3 = event.entity;
            if (var3 instanceof PlayerEntity) {
                PlayerEntity as = (PlayerEntity)var3;
                if (!Friends.get().isFriend(as) && !(event.entity instanceof FakePlayerEntity)) {
                    this.log("§6§lWarning! §r§l§n" + as.getGameProfile().getName() + "§r§4§l entered your visual range!");
                }
            }
        }

    }

    public static enum LogMode {
        Kick,
        Quit;

        // $FF: synthetic method
        private static AutoLogPlus.LogMode[] $values() {
            return new AutoLogPlus.LogMode[]{Kick, Quit};
        }
    }

    public static enum TriggerMode {
        Health,
        Totems,
        Pop;

        // $FF: synthetic method
        private static AutoLogPlus.TriggerMode[] $values() {
            return new AutoLogPlus.TriggerMode[]{Health, Totems, Pop};
        }
    }

    private class StaticListener {
        @EventHandler
        private void statusUpdater(Post event) {
            if (!Utils.canUpdate() && AutoLogPlus.this.isActive()) {
                AutoLogPlus.this.setScreen();
                if (AutoLogPlus.this.autoRecActive && !AutoLogPlus.this.autoReconnect.isActive()) {
                    AutoLogPlus.this.autoReconnect.toggle();
                }

                AutoLogPlus.this.logMessage = "";
                if ((Boolean)AutoLogPlus.this.toggleOff.get()) {
                    AutoLogPlus.this.toggle();
                }

                MeteorClient.EVENT_BUS.unsubscribe(AutoLogPlus.this.staticListener);
            } else {
                MeteorClient.EVENT_BUS.unsubscribe(AutoLogPlus.this.staticListener);
            }

        }
    }
}
