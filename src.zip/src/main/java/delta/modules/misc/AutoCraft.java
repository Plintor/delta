package delta.modules.misc;

import delta.DeltaHack;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ItemListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.item.Item;
import net.minecraft.recipe.Recipe;
import net.minecraft.client.gui.screen.recipebook.RecipeResultCollection;

public class AutoCraft extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<List<Item>> items;
    private final Setting<Integer> delay;
    private final Setting<Boolean> antiDesync;
    private final Setting<Boolean> craftAll;
    private final Setting<Boolean> drop;
    private int timer;

    public AutoCraft() {
        super(DeltaHack.Misc, "auto-craft", "Automatically crafts items.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.items = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("items")).description("Items you want to get crafted.")).defaultValue(List.of())).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Delay. Simply just delay in whatever the fuck this module does")).range(0, 10).sliderRange(0, 10).defaultValue(0)).build());
        this.antiDesync = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("anti-desync")).description("Try to prevent inventory de-synchronization.")).defaultValue(false)).build());
        this.craftAll = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("craft-all")).description("Crafts maximum possible amount amount per craft (shift-clicking)")).defaultValue(false)).build());
        this.drop = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("drop")).description("Automatically drops crafted items (useful for when not enough inventory space)")).defaultValue(false)).build());
        this.timer = 0;
    }

    @EventHandler
    private void onTick(Post event) {
        if (this.mc.interactionManager != null) {
            if (!((List)this.items.get()).isEmpty()) {
                ScreenHandler var3 = this.mc.player.currentScreenHandler;
                if (var3 instanceof CraftingScreenHandler) {
                    CraftingScreenHandler currentScreenHandler = (CraftingScreenHandler)var3;
                    if ((Boolean)this.antiDesync.get()) {
                        this.mc.player.getInventory().updateItems();
                    }

                    if (this.timer < (Integer)this.delay.get()) {
                        ++this.timer;
                    } else {
                        this.timer = 0;
                        List<Item> itemList = (List)this.items.get();
                        List<RecipeResultCollection> recipeResultCollectionList = this.mc.player.getRecipeBook().getOrderedResults();
                        Iterator var5 = recipeResultCollectionList.iterator();

                        while(var5.hasNext()) {
                            RecipeResultCollection recipeResultCollection = (RecipeResultCollection)var5.next();
                            Iterator var7 = recipeResultCollection.getRecipes(true).iterator();

                            while(var7.hasNext()) {
                                Recipe<?> recipe = (Recipe)var7.next();
                                if (itemList.contains(recipe.getOutput().getItem())) {
                                    this.mc.interactionManager.clickRecipe(currentScreenHandler.syncId, recipe, (Boolean)this.craftAll.get());
                                    this.mc.interactionManager.clickSlot(currentScreenHandler.syncId, 0, 1, (Boolean)this.drop.get() ? SlotActionType.THROW : SlotActionType.QUICK_MOVE, this.mc.player);
                                }
                            }
                        }

                    }
                }
            }
        }
    }
}
