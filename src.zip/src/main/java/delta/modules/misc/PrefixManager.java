package delta.modules.misc;

import delta.DeltaHack;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.util.Formatting;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextColor;

public class PrefixManager extends Module {
    private final SettingGroup sgDelta;
    private final SettingGroup sgMeteor;
    private final Setting<String> deltaPrefix;
    private final Setting<SettingColor> deltaColor;
    private final Setting<PrefixManager.Format> deltaFormatting;
    private final Setting<Boolean> deltaFormatBrackets;
    private final Setting<String> deltaLeftBracket;
    private final Setting<String> deltaRightBracket;
    private final Setting<PrefixManager.PrefixMode> prefixMode;
    private final Setting<String> meteorPrefix;
    private final Setting<SettingColor> meteorColor;
    private final Setting<PrefixManager.Format> meteorFormatting;
    private final Setting<Boolean> meteorFormatBrackets;
    private final Setting<String> meteorLeftBracket;
    private final Setting<String> meteorRightBracket;
    private final Setting<SettingColor> meteorLeftColor;
    private final Setting<SettingColor> meteorRightColor;

    public PrefixManager() {
        super(DeltaHack.Misc, "prefix-manager", "Allows you to customize prefixes used by Meteor.");
        this.sgDelta = this.settings.createGroup("Delta");
        this.sgMeteor = this.settings.createGroup("Meteor");
        this.deltaPrefix = this.sgDelta.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("delta-prefix")).description("What prefix to use for Delta modules.")).defaultValue("Delta")).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.deltaColor = this.sgDelta.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("prefix-color")).description("Color display for the prefix.")).defaultValue(new SettingColor(100, 78, 172, 255))).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.deltaFormatting = this.sgDelta.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("prefix-format")).description("What type of minecraft formatting should be applied to the prefix.")).defaultValue(PrefixManager.Format.Normal)).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.deltaFormatBrackets = this.sgDelta.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("format-brackets")).description("Whether the formatting should apply to the brackets as well.")).visible(() -> {
            return this.deltaFormatting.get() != PrefixManager.Format.Normal;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).defaultValue(true)).build());
        this.deltaLeftBracket = this.sgDelta.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("left-bracket")).description("What to be displayed as left bracket for the prefix.")).defaultValue("[")).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.deltaRightBracket = this.sgDelta.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("right-bracket")).description("What to be displayed as right bracket for the prefix.")).defaultValue("]")).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.prefixMode = this.sgMeteor.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("prefix-mode")).description("What prefix to use for Meteor modules.")).defaultValue(PrefixManager.PrefixMode.Default)).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorPrefix = this.sgMeteor.add(((Builder)((Builder)((Builder)((Builder)((Builder)(new Builder()).name("meteor-prefix")).description("What to use as meteor prefix text")).defaultValue("Motor")).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorColor = this.sgMeteor.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("prefix-color")).description("Color display for the meteor prefix")).defaultValue(new SettingColor(142, 60, 222, 255))).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorFormatting = this.sgMeteor.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("prefix-format")).description("What type of minecraft formatting should be applied to the prefix.")).defaultValue(PrefixManager.Format.Normal)).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorFormatBrackets = this.sgDelta.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("format-brackets")).description("Whether the formatting should apply to the brackets as well.")).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom && this.meteorFormatting.get() != PrefixManager.Format.Normal;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).defaultValue(true)).build());
        this.meteorLeftBracket = this.sgMeteor.add(((Builder)((Builder)((Builder)((Builder)((Builder)(new Builder()).name("left-bracket")).description("What to be displayed as left bracket for the meteor prefix")).defaultValue("[")).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorRightBracket = this.sgMeteor.add(((Builder)((Builder)((Builder)((Builder)((Builder)(new Builder()).name("right-bracket")).description("What to be displayed as right bracket for the meteor prefix")).defaultValue("]")).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorLeftColor = this.sgMeteor.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("left-color")).description("Color display for the left bracket")).defaultValue(new SettingColor(150, 150, 150, 255))).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
        this.meteorRightColor = this.sgMeteor.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("right-color")).description("Color display for the right bracket")).defaultValue(new SettingColor(150, 150, 150, 255))).visible(() -> {
            return this.prefixMode.get() == PrefixManager.PrefixMode.Custom;
        })).onChanged((cope) -> {
            this.setPrefixes();
        })).build());
    }

    public void onActivate() {
        this.setPrefixes();
    }

    public void onDeactivate() {
        meteordevelopment.meteorclient.utils.player.ChatUtils.unregisterCustomPrefix("modules.modules");
        meteordevelopment.meteorclient.utils.player.ChatUtils.unregisterCustomPrefix("meteordevelopment");
    }

    public void setPrefixes() {
        if (this.isActive()) {
            meteordevelopment.meteorclient.utils.player.ChatUtils.registerCustomPrefix("delta.modules", this::getDeltaPrefix);
            switch((PrefixManager.PrefixMode)this.prefixMode.get()) {
                case Delta:
                    meteordevelopment.meteorclient.utils.player.ChatUtils.registerCustomPrefix("meteordevelopment", this::getDeltaPrefix);
                    break;
                case Custom:
                    meteordevelopment.meteorclient.utils.player.ChatUtils.registerCustomPrefix("meteordevelopment", this::getMeteorPrefix);
                    break;
                case Default:
                    meteordevelopment.meteorclient.utils.player.ChatUtils.unregisterCustomPrefix("meteordevelopment");
            }
        }

    }

    private Formatting getFormat(PrefixManager.Format format) {
        Formatting var10000;
        switch(format) {
            case Normal:
                var10000 = null;
                break;
            case Heavy:
                var10000 = Formatting.BOLD;
                break;
            case Italic:
                var10000 = Formatting.ITALIC;
                break;
            case Underline:
                var10000 = Formatting.UNDERLINE;
                break;
            case Cursed:
                var10000 = Formatting.OBFUSCATED;
                break;
            case Crossed:
                var10000 = Formatting.STRIKETHROUGH;
                break;
            default:
                throw new IncompatibleClassChangeError();
        }

        return var10000;
    }

    public Text getDeltaPrefix() {
        MutableText logo = Text.literal((String)this.deltaPrefix.get());
        MutableText left = Text.literal((String)this.deltaLeftBracket.get());
        MutableText right = Text.literal((String)this.deltaRightBracket.get());
        MutableText prefix = Text.literal("");
        if (this.deltaFormatting.get() != PrefixManager.Format.Normal) {
            logo.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.deltaFormatting.get())));
        }

        logo.setStyle(logo.getStyle().withColor(TextColor.fromRgb(((SettingColor)this.deltaColor.get()).getPacked())));
        if (this.deltaFormatting.get() != PrefixManager.Format.Normal && (Boolean)this.deltaFormatBrackets.get()) {
            left.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.deltaFormatting.get())));
        }

        if (this.deltaFormatting.get() != PrefixManager.Format.Normal && (Boolean)this.deltaFormatBrackets.get()) {
            right.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.deltaFormatting.get())));
        }

        left.setStyle(left.getStyle());
        right.setStyle(right.getStyle());
        prefix.append(left);
        prefix.append(logo);
        prefix.append(right);
        prefix.append(" ");
        return prefix;
    }

    public Text getMeteorPrefix() {
        MutableText logo = Text.literal((String)this.meteorPrefix.get());
        MutableText left = Text.literal((String)this.meteorLeftBracket.get());
        MutableText right = Text.literal((String)this.meteorRightBracket.get());
        MutableText prefix = Text.literal("");
        if (this.meteorFormatting.get() != PrefixManager.Format.Normal) {
            logo.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.meteorFormatting.get())));
        }

        logo.setStyle(logo.getStyle().withColor(TextColor.fromRgb(((SettingColor)this.meteorColor.get()).getPacked())));
        if (this.meteorFormatting.get() != PrefixManager.Format.Normal && (Boolean)this.meteorFormatBrackets.get()) {
            left.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.deltaFormatting.get())));
        }

        if (this.meteorFormatting.get() != PrefixManager.Format.Normal && (Boolean)this.meteorFormatBrackets.get()) {
            right.setStyle(Style.EMPTY.withFormatting(this.getFormat((PrefixManager.Format)this.deltaFormatting.get())));
        }

        left.setStyle(left.getStyle().withColor(TextColor.fromRgb(((SettingColor)this.meteorLeftColor.get()).getPacked())));
        right.setStyle(right.getStyle().withColor(TextColor.fromRgb(((SettingColor)this.meteorRightColor.get()).getPacked())));
        prefix.append(left);
        prefix.append(logo);
        prefix.append(right);
        prefix.append(" ");
        return prefix;
    }

    public static enum Format {
        Normal,
        Heavy,
        Italic,
        Underline,
        Crossed,
        Cursed;

        // $FF: synthetic method
        private static PrefixManager.Format[] $values() {
            return new PrefixManager.Format[]{Normal, Heavy, Italic, Underline, Crossed, Cursed};
        }
    }

    public static enum PrefixMode {
        Delta,
        Custom,
        Default;

        // $FF: synthetic method
        private static PrefixManager.PrefixMode[] $values() {
            return new PrefixManager.PrefixMode[]{Delta, Custom, Default};
        }
    }
}
