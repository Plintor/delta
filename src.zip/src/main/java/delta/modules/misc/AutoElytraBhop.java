package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.PlayerUtil;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class AutoElytraBhop extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> bhopOffset;
    private final Setting<Boolean> teleport;
    private final Setting<Integer> tpDistance;
    private final Setting<Boolean> boost;
    private final Setting<Double> boostSpeed;
    private final Setting<Boolean> jump;
    private final Setting<Boolean> debug;

    public AutoElytraBhop() {
        super(DeltaHack.Misc, "auto-elytra-bhop", "Lets you bhop with elytras");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.bhopOffset = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("ground-offset")).description("The height above ground to trigger the hop")).defaultValue(0.9D).range(0.0D, 2.0D).sliderRange(0.5D, 1.0D).build());
        this.teleport = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("tp-up")).description("Teleport up when reaching ground")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("tp-distance")).description("The distance you teleport up.")).defaultValue(10);
        Setting var10003 = this.teleport;
        Objects.requireNonNull(var10003);
        this.tpDistance = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).range(1, 150).sliderRange(1, 100).build());
        this.boost = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("boost")).description("Boost when reaching ground")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        Builder var1 = ((Builder)((Builder)(new Builder()).name("boost-speed")).description("The speed you boost at")).range(1.0D, 10.0D);
        var10003 = this.boost;
        Objects.requireNonNull(var10003);
        this.boostSpeed = var10001.add(((Builder)var1.visible(var10003::get)).defaultValue(4.0D).build());
        this.jump = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("jump-up")).description("Jump up when reaching ground")).defaultValue(true)).build());
        this.debug = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("debug")).description("Tells you what block triggered the jump.")).defaultValue(false)).build());
    }

    @EventHandler(
        priority = -200
    )
    private void onTick(Pre event) {
        BlockPos underneathBlock = this.mc.player.getBlockPos().add(0.0D, -(Double)this.bhopOffset.get(), 0.0D);
        if (PlayerUtil.isElytraFlying() && BlockUtil.isFullBlock(underneathBlock)) {
            if ((Boolean)this.boost.get()) {
                this.mc.player.setVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getYaw()))) * (Double)this.boostSpeed.get(), (double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getPitch()))) * (Double)this.boostSpeed.get(), (double)MathHelper.cos((float)Math.toRadians((double)this.mc.player.getYaw())) * (Double)this.boostSpeed.get());
            }

            if ((Boolean)this.jump.get()) {
                this.mc.player.jump();
            }

            if ((Boolean)this.teleport.get()) {
                PlayerUtil.teleportVec(Vec3d.ofBottomCenter(this.mc.player.getBlockPos().up((Integer)this.tpDistance.get())));
            }

            if ((Boolean)this.debug.get()) {
                this.info(BlockUtil.getBlock(underneathBlock).toString(), new Object[0]);
            }
        }

    }
}
