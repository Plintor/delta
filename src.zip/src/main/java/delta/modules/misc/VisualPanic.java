package delta.modules.misc;

import delta.DeltaHack;
import java.util.Objects;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.ESP;
import meteordevelopment.meteorclient.systems.modules.render.Fullbright;
import meteordevelopment.meteorclient.systems.modules.render.HandView;
import meteordevelopment.meteorclient.systems.modules.render.Nametags;
import meteordevelopment.meteorclient.systems.modules.render.NoRender;
import meteordevelopment.meteorclient.systems.modules.render.StorageESP;
import meteordevelopment.meteorclient.systems.modules.render.Tracers;
import net.minecraft.text.Text;

public class VisualPanic extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> fov;
    private final Setting<Integer> penis;
    private boolean enabledNoRender;
    private boolean enabledNoRenderTwo;
    private boolean enabledTracers;
    private boolean enabledFullBright;
    private boolean enabledNames;
    private boolean enabledESP;
    private boolean enabledStorageESP;
    private boolean enabledKovchegESP;
    private boolean enabledHand;
    private boolean enabledHandPlus;

    public VisualPanic() {
        super(DeltaHack.Autist, "visual-panic", "Disables all render modules.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.fov = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("change-FOV")).description("changes your FOV to a certain value.")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("change-FOV")).description("-");
        Setting var10003 = this.fov;
        Objects.requireNonNull(var10003);
        this.penis = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).sliderRange(30, 110).defaultValue(100)).range(30, 110).build());
    }

    public void onActivate() {
        if ((Boolean)this.fov.get()) {
            this.mc.player.sendChatMessage((String)Config.get().prefix.get() + "fov " + this.penis.get(), (Text)null);
        }

        if (((NoRender)Modules.get().get(NoRender.class)).isActive()) {
            ((NoRender)Modules.get().get(NoRender.class)).toggle();
            this.enabledNoRender = true;
        }

        if (((NoRenderTwo)Modules.get().get(NoRenderTwo.class)).isActive()) {
            ((NoRenderTwo)Modules.get().get(NoRenderTwo.class)).toggle();
            this.enabledNoRenderTwo = true;
        }

        if (((Tracers)Modules.get().get(Tracers.class)).isActive()) {
            ((Tracers)Modules.get().get(Tracers.class)).toggle();
            this.enabledTracers = true;
        }

        if (((ESP)Modules.get().get(ESP.class)).isActive()) {
            ((ESP)Modules.get().get(ESP.class)).toggle();
            this.enabledESP = true;
        }

        if (((StorageESP)Modules.get().get(StorageESP.class)).isActive()) {
            ((StorageESP)Modules.get().get(StorageESP.class)).toggle();
            this.enabledStorageESP = true;
        }

        if (((KovchegEsp)Modules.get().get(KovchegEsp.class)).isActive()) {
            ((KovchegEsp)Modules.get().get(KovchegEsp.class)).toggle();
            this.enabledKovchegESP = true;
        }

        if (((HandView)Modules.get().get(HandView.class)).isActive()) {
            ((HandView)Modules.get().get(HandView.class)).toggle();
            this.enabledHand = true;
        }

        if (((HandViewPlus)Modules.get().get(HandViewPlus.class)).isActive()) {
            ((HandViewPlus)Modules.get().get(HandViewPlus.class)).toggle();
            this.enabledHandPlus = true;
        }

        if (((Fullbright)Modules.get().get(Fullbright.class)).isActive()) {
            ((Fullbright)Modules.get().get(Fullbright.class)).toggle();
            this.enabledFullBright = true;
        }

        if (((Nametags)Modules.get().get(Nametags.class)).isActive()) {
            ((Nametags)Modules.get().get(Nametags.class)).toggle();
            this.enabledNames = true;
        }

    }

    public void onDeactivate() {
        if (!((NoRender)Modules.get().get(NoRender.class)).isActive() && this.enabledNoRender) {
            ((NoRender)Modules.get().get(NoRender.class)).toggle();
        }

        if (!((NoRenderTwo)Modules.get().get(NoRenderTwo.class)).isActive() && this.enabledNoRenderTwo) {
            ((NoRenderTwo)Modules.get().get(NoRenderTwo.class)).toggle();
        }

        if (!((Tracers)Modules.get().get(Tracers.class)).isActive() && this.enabledTracers) {
            ((Tracers)Modules.get().get(Tracers.class)).toggle();
        }

        if (!((ESP)Modules.get().get(ESP.class)).isActive() && this.enabledESP) {
            ((ESP)Modules.get().get(ESP.class)).toggle();
        }

        if (!((StorageESP)Modules.get().get(StorageESP.class)).isActive() && this.enabledStorageESP) {
            ((StorageESP)Modules.get().get(StorageESP.class)).toggle();
        }

        if (!((KovchegEsp)Modules.get().get(KovchegEsp.class)).isActive() && this.enabledKovchegESP) {
            ((KovchegEsp)Modules.get().get(KovchegEsp.class)).toggle();
        }

        if (!((HandView)Modules.get().get(HandView.class)).isActive() && this.enabledHand) {
            ((HandView)Modules.get().get(HandView.class)).toggle();
        }

        if (!((HandViewPlus)Modules.get().get(HandViewPlus.class)).isActive() && this.enabledHandPlus) {
            ((HandViewPlus)Modules.get().get(HandViewPlus.class)).toggle();
        }

        if (!((Fullbright)Modules.get().get(Fullbright.class)).isActive() && this.enabledFullBright) {
            ((Fullbright)Modules.get().get(Fullbright.class)).toggle();
        }

        if (!((Nametags)Modules.get().get(Nametags.class)).isActive() && this.enabledNames) {
            ((Nametags)Modules.get().get(Nametags.class)).toggle();
        }

    }
}
