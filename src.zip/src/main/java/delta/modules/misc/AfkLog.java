package delta.modules.misc;

import delta.DeltaHack;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.Dimension;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;

public class AfkLog extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Dimension> dimension;
    private final Setting<Integer> xCoords;
    private final Setting<Integer> zCoords;
    private final Setting<Integer> radius;
    private final Setting<Boolean> toggleAutoReconnect;
    private final Setting<Boolean> autoToggle;

    public AfkLog() {
        super(DeltaHack.Misc, "afk-log", "Logs out when you are at a certain coords for afk travelling.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.dimension = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("dimension")).description("Dimension for the coords.")).defaultValue(Dimension.Nether)).build());
        this.xCoords = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("x-coords")).description("The X coords it should log you out.")).defaultValue(1000)).range(-29999872, 29999872).sliderRange(-29999872, 29999872).noSlider().build());
        this.zCoords = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("z-coords")).description("The z coords it should log you out.")).defaultValue(1000)).range(-29999872, 29999872).sliderRange(-29999872, 29999872).noSlider().build());
        this.radius = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("radius")).description("The radius of coords from the exact coords it will log you out.")).defaultValue(64)).min(0).sliderRange(0, 256).build());
        this.toggleAutoReconnect = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("prevent-reconnect")).description("Turns off auto reconnect when disconnecting.")).defaultValue(true)).build());
        this.autoToggle = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-toggle")).description("Turns itself off when disconnecting.")).defaultValue(true)).build());
    }

    @EventHandler
    private void onTick(Post event) {
        if (this.xCoordsMatch() && this.zCoordsMatch() && PlayerUtils.getDimension() == this.dimension.get()) {
            if ((Boolean)this.toggleAutoReconnect.get() && Modules.get().isActive(AutoReconnect.class)) {
                ((AutoReconnect)Modules.get().get(AutoReconnect.class)).toggle();
            }

            if ((Boolean)this.autoToggle.get()) {
                this.toggle();
            }

            this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(Text.literal("AfkLog Arrived at destination.")));
        }

    }

    private boolean xCoordsMatch() {
        return this.mc.player.getX() <= (double)((Integer)this.xCoords.get() + (Integer)this.radius.get()) && this.mc.player.getX() >= (double)((Integer)this.xCoords.get() - (Integer)this.radius.get());
    }

    private boolean zCoordsMatch() {
        return this.mc.player.getZ() <= (double)((Integer)this.zCoords.get() + (Integer)this.radius.get()) && this.mc.player.getZ() >= (double)((Integer)this.zCoords.get() - (Integer)this.radius.get());
    }
}
