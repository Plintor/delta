package delta.modules.misc;

import delta.DeltaHack;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Quaternion;
import net.minecraft.util.Hand;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.client.util.math.MatrixStack;

public class HandViewPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgMainhand;
    private final SettingGroup sgOffhand;
    private final Setting<Boolean> noSwing;
    private final Setting<Double> scale;
    private final Setting<Integer> speedX;
    private final Setting<Integer> speedY;
    private final Setting<Integer> speedZ;
    private final Setting<Integer> offspeedX;
    private final Setting<Integer> offspeedY;
    private final Setting<Integer> offspeedZ;
    private float nextRotationX;
    private float nextRotationY;
    private float nextRotationZ;

    public HandViewPlus() {
        super(DeltaHack.Misc, "hand-view+", "Tweaks for main and off hands.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgMainhand = this.settings.createGroup("Main Hand");
        this.sgOffhand = this.settings.createGroup("Off Hand");
        this.noSwing = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("no-swing")).description("Preventing client-side swing animation.")).defaultValue(false)).build());
        this.scale = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("scale")).description("The scale of your hands.")).defaultValue(1.0D).sliderMax(5.0D).build());
        this.speedX = this.sgMainhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("x-animation")).description("The speed of X orientation of your main hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.speedY = this.sgMainhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("y-animation")).description("The speed of Y orientation of your main hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.speedZ = this.sgMainhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("z-animation")).description("The speed of Z orientation of your main hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.offspeedX = this.sgOffhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("x-animation")).description("The speed of X orientation of your off hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.offspeedY = this.sgOffhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("y-animation")).description("The speed of Y orientation of your off hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.offspeedZ = this.sgOffhand.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("z-animation")).description("The speed of Z orientation of your off hand.")).defaultValue(0)).sliderMin(-100).sliderMax(100).build());
        this.nextRotationX = 0.0F;
        this.nextRotationY = 0.0F;
        this.nextRotationZ = 0.0F;
    }

    public void transform(MatrixStack matrices, Hand hand) {
        if (this.isActive()) {
            float defRotation = 0.0F;
            matrices.scale(((Double)this.scale.get()).floatValue(), ((Double)this.scale.get()).floatValue(), ((Double)this.scale.get()).floatValue());
            float finalRotationZ;
            if (hand == Hand.MAIN_HAND) {
                if (!((Integer)this.speedX.get()).equals(0)) {
                    finalRotationZ = this.nextRotationX++ / (float)(Integer)this.speedX.get();
                    matrices.multiply(Quaternion.fromEulerXyz(finalRotationZ, defRotation, defRotation));
                }

                if (!((Integer)this.speedY.get()).equals(0)) {
                    finalRotationZ = this.nextRotationY++ / (float)(Integer)this.speedY.get();
                    matrices.multiply(Quaternion.fromEulerXyz(defRotation, finalRotationZ, defRotation));
                }

                if (!((Integer)this.speedZ.get()).equals(0)) {
                    finalRotationZ = this.nextRotationZ++ / (float)(Integer)this.speedZ.get();
                    matrices.multiply(Quaternion.fromEulerXyz(defRotation, defRotation, finalRotationZ));
                }
            } else {
                if (!((Integer)this.offspeedX.get()).equals(0)) {
                    finalRotationZ = this.nextRotationX++ / (float)(Integer)this.offspeedX.get();
                    matrices.multiply(Quaternion.fromEulerXyz(finalRotationZ, defRotation, defRotation));
                }

                if (!((Integer)this.offspeedY.get()).equals(0)) {
                    finalRotationZ = this.nextRotationY++ / (float)(Integer)this.offspeedY.get();
                    matrices.multiply(Quaternion.fromEulerXyz(defRotation, finalRotationZ, defRotation));
                }

                if (!((Integer)this.offspeedZ.get()).equals(0)) {
                    finalRotationZ = this.nextRotationZ++ / (float)(Integer)this.offspeedZ.get();
                    matrices.multiply(Quaternion.fromEulerXyz(defRotation, defRotation, finalRotationZ));
                }
            }

        }
    }

    @EventHandler
    private void onPacketSend(Send event) {
        if ((Boolean)this.noSwing.get() && event.packet instanceof HandSwingC2SPacket) {
            this.mc.player.handSwinging = false;
        }

    }

    @EventHandler
    private void onPacketRecieve(Receive event) {
        if ((Boolean)this.noSwing.get() && event.packet instanceof HandSwingC2SPacket) {
            this.mc.player.handSwinging = false;
        }

    }
}
