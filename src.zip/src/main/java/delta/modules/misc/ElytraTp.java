package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.PlayerUtil;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.KeybindSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class ElytraTp extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Keybind> tpBind;
    private final Setting<Keybind> downBind;
    private final Setting<Keybind> boostBind;
    private final Setting<Boolean> allowSpam;
    private final Setting<Double> boostSpeed;
    private final Setting<Double> tpDistance;
    private final Setting<Boolean> throughBlocks;
    private final Setting<Boolean> elytraOnly;
    private boolean antiSpamClick;
    private boolean antiSpamClickBoost;

    public ElytraTp() {
        super(DeltaHack.Autist, "elytra-click-tp", "Teleports you up in the air");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.tpBind = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("TP-bind")).description("Teleports you when this button is pressed")).defaultValue(Keybind.none())).build());
        this.downBind = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("TP-bind (down)")).description("Teleports you down")).defaultValue(Keybind.fromKey(264))).build());
        this.boostBind = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("boost-bind")).description("Teleports you when this button is pressed")).defaultValue(Keybind.fromButton(3))).build());
        this.allowSpam = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("allow-spam")).description("Teleports you each tick the button is pressed")).defaultValue(false)).build());
        this.boostSpeed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("boost-speed")).description("The speed you boost at")).range(1.0D, 10.0D).defaultValue(7.0D).build());
        this.tpDistance = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("TP-distance")).description("The distance you teleport")).defaultValue(100.0D).min(1.0D).sliderMax(200.0D).build());
        this.throughBlocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("through-blocks")).description("Allows you to teleport through blocks")).defaultValue(true)).build());
        this.elytraOnly = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("elytra-only")).description("Only use on elytra flying")).defaultValue(true)).build());
        this.antiSpamClick = false;
        this.antiSpamClickBoost = true;
    }

    @EventHandler
    private void onTick(Post event) {
        double distance = (Double)this.tpDistance.get();
        if (this.mc.options.sneakKey.isPressed() && !this.mc.options.sneakKey.matchesKey(((Keybind)this.tpBind.get()).getValue(), -1)) {
            this.antiSpamClick = false;
            this.antiSpamClickBoost = false;
        } else if (PlayerUtil.isElytraFlying() || !(Boolean)this.elytraOnly.get()) {
            Vec3d position = this.mc.player.getCameraPosVec(this.mc.getTickDelta());
            Vec3d rotation = new Vec3d(0.0D, ((Keybind)this.downBind.get()).isPressed() ? -1.0D : 1.0D, 0.0D);
            Vec3d vec3d3 = position.add(rotation.x * distance, rotation.y * distance, rotation.z * distance);
            if ((Boolean)this.throughBlocks.get()) {
                position = vec3d3;

                for(int i = 0; (double)i < distance; ++i) {
                    position = position.subtract(rotation);
                    Block block = this.mc.world.getBlockState(new BlockPos(position)).getBlock();
                    if (block == Blocks.AIR || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR) {
                        break;
                    }
                }
            }

            BlockHitResult hit = this.mc.player.world.raycast(new RaycastContext(position, vec3d3, ShapeType.OUTLINE, FluidHandling.ANY, this.mc.player));
            BlockPos pos = hit.getBlockPos();
            Direction dir = Direction.UP;
            if (pos != null) {
                if (((Keybind)this.tpBind.get()).isPressed() && this.mc.currentScreen == null && (!this.antiSpamClick || (Boolean)this.allowSpam.get())) {
                    this.antiSpamClick = true;
                    Vec3d tpPos = Vec3d.ofBottomCenter(pos.offset(dir, 1));
                    PlayerUtil.teleportVec(tpPos);
                } else if (!((Keybind)this.tpBind.get()).isPressed()) {
                    this.antiSpamClick = false;
                }

                if (((Keybind)this.boostBind.get()).isPressed() && !this.antiSpamClickBoost) {
                    this.antiSpamClickBoost = true;
                    this.mc.player.setVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getYaw()))) * (Double)this.boostSpeed.get(), (double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getPitch()))) * (Double)this.boostSpeed.get(), (double)MathHelper.cos((float)Math.toRadians((double)this.mc.player.getYaw())) * (Double)this.boostSpeed.get());
                } else if (!((Keybind)this.boostBind.get()).isPressed()) {
                    this.antiSpamClickBoost = false;
                }
            }

        }
    }
}
