package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.EntityUtil;
import delta.utils.WorldUtils;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;

public class KillEffects extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> range;
    private final Setting<Boolean> avoidSelf;

    public KillEffects() {
        super(DeltaHack.Misc, "kill-effects", "Spawns a lightning where a player dies.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.range = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("range")).description("How far away the lightning is allowed to spawn from you.")).defaultValue(16)).sliderRange(0, 256).build());
        this.avoidSelf = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("avoid-self")).description("Will not render your own deaths.")).defaultValue(true)).build());
    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        if (EntityUtil.isDeathPacket(event)) {
            Entity player = EntityUtil.deadEntity;
            if (player == this.mc.player && (Boolean)this.avoidSelf.get()) {
                return;
            }

            if (this.mc.player.distanceTo(player) > (float)(Integer)this.range.get()) {
                return;
            }

            double playerX = player.getX();
            double playerY = player.getY();
            double playerZ = player.getZ();
            WorldUtils.spawnLightning(playerX, playerY, playerZ);
        }

    }
}
