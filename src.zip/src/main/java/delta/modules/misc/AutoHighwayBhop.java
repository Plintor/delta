package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class AutoHighwayBhop extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> bhopOffset;
    private final Setting<Boolean> boost;
    private final Setting<Double> boostSpeed;
    private final Setting<Boolean> penis;
    private final Setting<Boolean> jump;

    public AutoHighwayBhop() {
        super(DeltaHack.Util, "auto-highway-bhop", "Module for GULAG highway navigation");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.bhopOffset = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("ground-offset")).description("The height above ground to trigger the hop")).defaultValue(0.9D).range(0.0D, 2.0D).sliderRange(0.5D, 1.0D).build());
        this.boost = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("boost")).description("Boost when reaching ground")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        Builder var10002 = ((Builder)((Builder)(new Builder()).name("boost-speed")).description("The speed you boost at")).range(1.0D, 10.0D);
        Setting var10003 = this.boost;
        Objects.requireNonNull(var10003);
        this.boostSpeed = var10001.add(((Builder)var10002.visible(var10003::get)).defaultValue(4.0D).build());
        this.penis = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("penis")).description("Jump up when ")).defaultValue(false)).build());
        this.jump = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("jump-up")).description("Jump up when reaching ground")).defaultValue(true)).build());
    }

    @EventHandler(
        priority = -200
    )
    private void onTick(Pre event) {
        if (PlayerUtil.isElytraFlying()) {
            BlockPos a = EntityUtil.playerPos(this.mc.player);
            if ((Boolean)this.penis.get() && !BlockUtil.isReplaceable(a.add(0.0D, -(Double)this.bhopOffset.get(), 0.0D)) || (!BlockUtil.isReplaceable(a.north()) || !BlockUtil.isReplaceable(a.south()) || !BlockUtil.isReplaceable(a.east()) || !BlockUtil.isReplaceable(a.west())) && !BlockUtil.isReplaceable(a.up())) {
                if ((Boolean)this.boost.get()) {
                    this.mc.player.setVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getYaw()))) * (Double)this.boostSpeed.get(), (double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getPitch()))) * (Double)this.boostSpeed.get(), (double)MathHelper.cos((float)Math.toRadians((double)this.mc.player.getYaw())) * (Double)this.boostSpeed.get());
                }

                if ((Boolean)this.jump.get()) {
                    this.mc.player.jump();
                }
            }
        }

    }
}
