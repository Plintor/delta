package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.PlayerUtil;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

public class ElytraFighter extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> takeoff;
    private final Setting<Integer> delFly;
    private final Setting<ElytraFighter.EFlyMode> mode;
    private final Setting<Boolean> autoBucket;
    private final Setting<Integer> del;
    private final Setting<Double> speed;
    boolean boosting;
    boolean shouldUnpress;
    int delay;
    int flyTicks;
    float nat_pitch;

    public ElytraFighter() {
        super(DeltaHack.Misc, "elytra-hypersonic-fighter", "A smooth, nice efly based on Bedtrap's E+");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.takeoff = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("take-off")).defaultValue(false)).build());
        this.delFly = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("get-control-delay")).defaultValue(0)).range(0, 10).build());
        this.mode = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mode")).defaultValue(ElytraFighter.EFlyMode.Acceleration)).build());
        this.autoBucket = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("auto-bucket")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("auto-bucket-delay");
        Setting var10003 = this.autoBucket;
        Objects.requireNonNull(var10003);
        this.del = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).defaultValue(3)).range(0, 10).build());
        this.speed = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("factor")).defaultValue(1.0D).sliderMax(10.0D).range(0.0D, 40.0D).build());
    }

    public void onActivate() {
        this.delay = (Integer)this.del.get();
        this.boosting = false;
        this.flyTicks = 0;
        if ((Boolean)this.autoBucket.get() && this.mc.player.isOnGround()) {
            this.nat_pitch = this.mc.player.getPitch();
            this.mc.player.setPitch(90.0F);
            InvUtils.swap(InvUtils.findInHotbar((itemStack) -> {
                return itemStack.getItem() == Items.LAVA_BUCKET;
            }).slot(), true);
            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
        }

    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.shouldUnpress) {
            this.mc.options.jumpKey.setPressed(false);
            Input.setKeyState(this.mc.options.jumpKey, false);
            this.shouldUnpress = false;
        }

        if (this.delay == 0 && this.mc.player.isOnGround() && (Boolean)this.autoBucket.get()) {
            InvUtils.swap(InvUtils.findInHotbar((itemStack) -> {
                return itemStack.getItem() == Items.BUCKET;
            }).slot(), false);
            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
            InvUtils.swapBack();
            this.mc.player.setPitch(this.nat_pitch);
        }

        --this.delay;
        if (!this.mc.player.isFallFlying()) {
            this.flyTicks = 0;
            if ((Boolean)this.takeoff.get() && !this.mc.player.isOnGround() && this.mc.options.jumpKey.isPressed()) {
                if (!this.mc.options.jumpKey.isPressed()) {
                    this.shouldUnpress = true;
                }

                PlayerUtil.openElytras();
            }

        } else {
            if (this.mc.player.getAbilities().flying) {
                this.mc.player.getAbilities().flying = false;
            }

            if (this.flyTicks >= (Integer)this.delFly.get()) {
                if (this.mc.options.leftKey.isPressed()) {
                    this.decideVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)(this.mc.player.getYaw() - 90.0F)))) * (Double)this.speed.get() / 10.0D, 0.0D, (double)MathHelper.cos((float)Math.toRadians((double)(this.mc.player.getYaw() - 90.0F))) * (Double)this.speed.get() / 10.0D);
                }

                if (this.mc.options.rightKey.isPressed()) {
                    this.decideVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)(this.mc.player.getYaw() + 90.0F)))) * (Double)this.speed.get() / 10.0D, 0.0D, (double)MathHelper.cos((float)Math.toRadians((double)(this.mc.player.getYaw() + 90.0F))) * (Double)this.speed.get() / 10.0D);
                }

                if (this.mc.options.forwardKey.isPressed()) {
                    this.decideVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getYaw()))) * (Double)this.speed.get() / 10.0D, (double)(-MathHelper.sin((float)Math.toRadians((double)this.mc.player.getPitch()))) * (Double)this.speed.get() / 10.0D, (double)MathHelper.cos((float)Math.toRadians((double)this.mc.player.getYaw())) * (Double)this.speed.get() / 10.0D);
                }

                if (this.mc.options.jumpKey.isPressed()) {
                    this.decideVelocity(0.0D, (Double)this.speed.get() / 15.0D, 0.0D);
                }

                if (this.mc.options.sneakKey.isPressed()) {
                    this.decideVelocity(0.0D, -(Double)this.speed.get() / 15.0D, 0.0D);
                }

                if (this.mc.options.backKey.isPressed()) {
                    if (this.mode.get() == ElytraFighter.EFlyMode.Acceleration) {
                        PlayerUtil.stopPlayer();
                    } else {
                        this.mc.player.addVelocity((double)(-MathHelper.sin((float)Math.toRadians((double)(this.mc.player.getYaw() + 180.0F)))) * (Double)this.speed.get() / 10.0D, 0.0D, (double)MathHelper.cos((float)Math.toRadians((double)(this.mc.player.getYaw() + 180.0F))) * (Double)this.speed.get() / 10.0D);
                    }
                }
            } else {
                ++this.flyTicks;
            }

        }
    }

    private void decideVelocity(double deltaX, double deltaY, double deltaZ) {
        if (this.mode.get() == ElytraFighter.EFlyMode.Acceleration) {
            this.mc.player.addVelocity(deltaX, deltaY, deltaZ);
        } else if (this.mode.get() == ElytraFighter.EFlyMode.Velocity) {
            this.mc.player.setVelocity(deltaX * 2.0D, deltaY * 2.0D, deltaZ * 2.0D);
        }

    }

    public static enum EFlyMode {
        Acceleration,
        Velocity;

        // $FF: synthetic method
        private static ElytraFighter.EFlyMode[] $values() {
            return new ElytraFighter.EFlyMode[]{Acceleration, Velocity};
        }
    }
}
