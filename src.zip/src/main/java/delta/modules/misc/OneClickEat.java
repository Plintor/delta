package delta.modules.misc;

import delta.DeltaHack;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.entity.player.StoppedUsingItemEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ItemListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.DonkeyEntity;
import net.minecraft.entity.passive.HorseEntity;
import net.minecraft.entity.passive.MuleEntity;
import net.minecraft.entity.mob.SkeletonHorseEntity;
import net.minecraft.entity.mob.ZombieHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BannerItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BoatItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.MinecartItem;
import net.minecraft.item.PotionItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.entity.passive.StriderEntity;
import net.minecraft.item.GoatHornItem;
import net.minecraft.util.hit.HitResult.Type;

public class OneClickEat extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<List<Item>> foodList;
    private final Setting<Boolean> usePotions;
    private final Setting<Boolean> onlyGround;
    private boolean isUsing;
    private boolean pressed;
    private Item currentItem;

    public OneClickEat() {
        super(DeltaHack.Misc, "one-click-eat", "Allows you to eat a consumable with one click.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.foodList = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("white-list")).description("Which items you can one click eat.")).filter(Item::isFood).build());
        this.usePotions = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("use-potions")).description("Allows you to also use potions.")).defaultValue(false)).build());
        this.onlyGround = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Only allows you to one click eat on ground.")).defaultValue(false)).build());
    }

    private boolean isPotato() {
        return this.mc.player.getMainHandStack().getItem() == Items.POTATO || this.mc.player.getOffHandStack().getItem() == Items.POTATO;
    }

    private boolean isCarrot() {
        return this.mc.player.getMainHandStack().getItem() == Items.CARROT || this.mc.player.getOffHandStack().getItem() == Items.CARROT;
    }

    private boolean canEatFull() {
        return this.mc.player.getMainHandStack().getItem() == Items.ENCHANTED_GOLDEN_APPLE || this.mc.player.getOffHandStack().getItem() == Items.ENCHANTED_GOLDEN_APPLE || this.mc.player.getMainHandStack().getItem() == Items.GOLDEN_APPLE || this.mc.player.getOffHandStack().getItem() == Items.GOLDEN_APPLE || this.mc.player.getMainHandStack().getItem() == Items.CHORUS_FRUIT || this.mc.player.getOffHandStack().getItem() == Items.CHORUS_FRUIT || this.mc.player.getMainHandStack().getItem() == Items.HONEY_BOTTLE || this.mc.player.getOffHandStack().getItem() == Items.HONEY_BOTTLE || this.mc.player.getMainHandStack().getItem() == Items.MILK_BUCKET || this.mc.player.getOffHandStack().getItem() == Items.MILK_BUCKET || this.mc.player.getMainHandStack().getItem() == Items.SUSPICIOUS_STEW || this.mc.player.getOffHandStack().getItem() == Items.SUSPICIOUS_STEW;
    }

    private boolean canPlantBerry(BlockPos pos) {
        return (this.mc.player.getMainHandStack().getItem() == Items.GLOW_BERRIES || this.mc.player.getOffHandStack().getItem() == Items.GLOW_BERRIES) && !this.mc.world.getBlockState(pos).isOf(Blocks.AIR) || (this.mc.player.getMainHandStack().getItem() == Items.SWEET_BERRIES || this.mc.player.getOffHandStack().getItem() == Items.SWEET_BERRIES) && (this.mc.world.getBlockState(pos).isOf(Blocks.GRASS_BLOCK) || this.mc.world.getBlockState(pos).isOf(Blocks.DIRT) || this.mc.world.getBlockState(pos).isOf(Blocks.PODZOL) || this.mc.world.getBlockState(pos).isOf(Blocks.COARSE_DIRT) || this.mc.world.getBlockState(pos).isOf(Blocks.FARMLAND));
    }

    private boolean isGround(BlockPos pos) {
        return this.mc.player.getMainHandStack().getItem() instanceof BlockItem && !this.mc.world.getBlockState(pos).isOf(Blocks.AIR);
    }

    private boolean isFarmland(BlockPos pos) {
        return this.mc.world.getBlockState(pos).isOf(Blocks.FARMLAND);
    }

    private boolean mainHandFull() {
        return this.mc.player.getMainHandStack().getItem() == Items.TRIDENT || this.mc.player.getMainHandStack().getItem() == Items.BOW || this.mc.player.getMainHandStack().getItem() == Items.CROSSBOW || this.mc.player.getMainHandStack().getItem() instanceof GoatHornItem || this.mc.player.getMainHandStack().getItem() == Items.EXPERIENCE_BOTTLE || this.mc.player.getMainHandStack().getItem() instanceof BucketItem || this.mc.player.getMainHandStack().getItem() == Items.WRITABLE_BOOK || this.mc.player.getMainHandStack().getItem() == Items.WRITTEN_BOOK || this.mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET || this.mc.player.getMainHandStack().getItem() == Items.LEAD || this.mc.player.getMainHandStack().getItem() == Items.NAME_TAG || this.mc.player.getMainHandStack().getItem() instanceof BoatItem || this.mc.player.getMainHandStack().getItem() instanceof MinecartItem || this.mc.player.getMainHandStack().getItem() == Items.SADDLE || this.mc.player.getMainHandStack().getItem() == Items.ARMOR_STAND || this.mc.player.getMainHandStack().getItem() == Items.SHIELD || this.mc.player.getMainHandStack().getItem() == Items.SHEARS || this.mc.player.getMainHandStack().getItem() == Items.ITEM_FRAME || this.mc.player.getMainHandStack().getItem() instanceof BannerItem || this.mc.player.getMainHandStack().getItem() == Items.PAINTING || this.mc.player.getMainHandStack().getItem() == Items.SPYGLASS || this.mc.player.getMainHandStack().getItem() == Items.FISHING_ROD || this.mc.player.getMainHandStack().getItem() == Items.FLINT_AND_STEEL || this.mc.player.getMainHandStack().getItem() instanceof SpawnEggItem || this.mc.player.getMainHandStack().getItem() == Items.TURTLE_EGG;
    }

    private boolean canChangeBlock(BlockPos pos) {
        return (this.mc.world.getBlockState(pos).isOf(Blocks.GRASS_BLOCK) || this.mc.world.getBlockState(pos).isOf(Blocks.DIRT) || this.mc.world.getBlockState(pos).isOf(Blocks.PODZOL)) && (this.mc.player.getMainHandStack().getItem() instanceof ShovelItem || this.mc.player.getOffHandStack().getItem() instanceof ShovelItem) || (this.mc.world.getBlockState(pos).isOf(Blocks.ACACIA_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.BIRCH_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.DARK_OAK_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.JUNGLE_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.MANGROVE_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.OAK_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.SPRUCE_LOG) || this.mc.world.getBlockState(pos).isOf(Blocks.ACACIA_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.BIRCH_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.DARK_OAK_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.JUNGLE_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.MANGROVE_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.OAK_WOOD) || this.mc.world.getBlockState(pos).isOf(Blocks.SPRUCE_WOOD)) && (this.mc.player.getMainHandStack().getItem() instanceof AxeItem || this.mc.player.getOffHandStack().getItem() instanceof AxeItem);
    }

    private boolean isRideable(Entity hit) {
        return hit instanceof MinecartEntity || hit instanceof BoatEntity || hit instanceof HorseEntity || hit instanceof DonkeyEntity || hit instanceof MuleEntity || hit instanceof SkeletonHorseEntity || hit instanceof ZombieHorseEntity || hit instanceof PigEntity || hit instanceof StriderEntity;
    }

    private boolean canFeed(Entity hit) {
        return (hit instanceof HorseEntity || hit instanceof DonkeyEntity || hit instanceof MuleEntity) && (this.mc.player.getMainHandStack().getItem() == Items.APPLE || this.mc.player.getOffHandStack().getItem() == Items.APPLE || this.mc.player.getMainHandStack().getItem() == Items.ENCHANTED_GOLDEN_APPLE || this.mc.player.getOffHandStack().getItem() == Items.ENCHANTED_GOLDEN_APPLE || this.mc.player.getMainHandStack().getItem() == Items.GOLDEN_APPLE || this.mc.player.getOffHandStack().getItem() == Items.GOLDEN_APPLE || this.mc.player.getMainHandStack().getItem() == Items.GOLDEN_CARROT || this.mc.player.getOffHandStack().getItem() == Items.GOLDEN_CARROT) || hit instanceof PigEntity && (this.mc.player.getMainHandStack().getItem() == Items.BEETROOT || this.mc.player.getOffHandStack().getItem() == Items.BEETROOT || this.mc.player.getMainHandStack().getItem() == Items.CARROT || this.mc.player.getOffHandStack().getItem() == Items.CARROT || this.mc.player.getMainHandStack().getItem() == Items.POTATO || this.mc.player.getOffHandStack().getItem() == Items.POTATO);
    }

    private boolean canPlaceCrystal(BlockPos pos) {
        return (this.mc.world.getBlockState(pos).isOf(Blocks.OBSIDIAN) || this.mc.world.getBlockState(pos).isOf(Blocks.BEDROCK)) && this.mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL;
    }

    private boolean isPlayer(Entity hit) {
        return hit instanceof PlayerEntity;
    }

    @EventHandler
    private void onTick(Pre event) {
        assert this.mc.player != null;

        assert this.mc.world != null;

        if (!(Boolean)this.onlyGround.get() || this.mc.player.isOnGround()) {
            if (!this.mc.options.useKey.isPressed()) {
                this.pressed = false;
            }

            if (this.mc.options.useKey.isPressed() && !this.isUsing && !this.pressed) {
                this.pressed = true;
                if (this.mc.crosshairTarget.getType() == Type.BLOCK) {
                    if (BlockUtils.isClickable(this.mc.world.getBlockState(((BlockHitResult)this.mc.crosshairTarget).getBlockPos()).getBlock())) {
                        return;
                    }

                    if (this.canPlantBerry(((BlockHitResult)this.mc.crosshairTarget).getBlockPos())) {
                        return;
                    }

                    if ((this.isPotato() || this.isCarrot()) && this.isFarmland(((BlockHitResult)this.mc.crosshairTarget).getBlockPos())) {
                        return;
                    }
                }

                if (this.mc.crosshairTarget.getType() == Type.ENTITY && (this.isRideable(((EntityHitResult)this.mc.crosshairTarget).getEntity()) || this.canFeed(((EntityHitResult)this.mc.crosshairTarget).getEntity()))) {
                    return;
                }

                if (!this.mc.player.getHungerManager().isNotFull() && !this.canEatFull()) {
                    return;
                }

                if (((List)this.foodList.get()).contains(this.mc.player.getMainHandStack().getItem()) || (Boolean)this.usePotions.get() && this.mc.player.getMainHandStack().getItem() instanceof PotionItem) {
                    this.eat();
                } else if ((((List)this.foodList.get()).contains(this.mc.player.getOffHandStack().getItem()) || (Boolean)this.usePotions.get() && this.mc.player.getOffHandStack().getItem() instanceof PotionItem) && !this.mainHandFull()) {
                    if (this.mc.crosshairTarget.getType() == Type.BLOCK) {
                        if (this.isGround(((BlockHitResult)this.mc.crosshairTarget).getBlockPos())) {
                            return;
                        }

                        if (this.canChangeBlock(((BlockHitResult)this.mc.crosshairTarget).getBlockPos())) {
                            return;
                        }

                        if (this.canPlaceCrystal(((BlockHitResult)this.mc.crosshairTarget).getBlockPos())) {
                            return;
                        }
                    }

                    if (this.mc.player.getOffHandStack().getItem() != this.currentItem) {
                        this.stopIfUsing();
                    }

                    this.eat();
                }
            }

            if (this.isUsing) {
                this.mc.options.useKey.setPressed(true);
            }

        }
    }

    private void eat() {
        this.mc.options.useKey.setPressed(true);
        this.isUsing = true;
    }

    public void onDeactivate() {
        this.stopIfUsing();
    }

    @EventHandler
    private void onPacketSend(Send event) {
        if (event.packet instanceof UpdateSelectedSlotC2SPacket) {
            this.stopIfUsing();
        }

    }

    @EventHandler
    private void onFinishUsingItem(FinishUsingItemEvent event) {
        this.stopIfUsing();
    }

    @EventHandler
    private void onStoppedUsingItem(StoppedUsingItemEvent event) {
        this.stopIfUsing();
    }

    private void stopIfUsing() {
        if (this.isUsing) {
            this.mc.options.useKey.setPressed(false);
            this.isUsing = false;
        }

    }
}
