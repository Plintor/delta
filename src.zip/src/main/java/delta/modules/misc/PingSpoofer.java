package delta.modules.misc;

import delta.DeltaHack;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.KeepAliveS2CPacket;
import net.minecraft.network.packet.c2s.play.KeepAliveC2SPacket;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;

@Environment(EnvType.CLIENT)
public class PingSpoofer extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> strict;
    private final Setting<Integer> ping;
    private final Setting<Integer> deviation;
    private long id;
    private long timer;
    private int nextPing;

    public PingSpoofer() {
        super(DeltaHack.Misc, "ping-spoof", "Modify your ping.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.strict = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("strict")).description("Responds as fast as possible to keep alive packets send by the server.")).defaultValue(false)).build());
        this.ping = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("ping")).description("The ping to set.")).defaultValue(250)).min(0).sliderMin(100).sliderMax(1000).noSlider().visible(() -> {
            return !(Boolean)this.strict.get();
        })).build());
        this.deviation = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("deviation")).description("Randomize the ping by this amount.")).defaultValue(0)).min(0).sliderMin(0).sliderMax(50).noSlider().visible(() -> {
            return !(Boolean)this.strict.get();
        })).build());
    }

    public void onActivate() {
        if (this.isDisallowed()) {
            this.toggle();
            meteordevelopment.meteorclient.utils.player.ChatUtils.warning("Ping Spoofer is not allowed on this server.", new Object[0]);
        }

        this.id = -1L;
        this.timer = System.currentTimeMillis();
        this.nextPing = this.getPing();
    }

    private boolean isDisallowed() {
        ServerInfo info = this.mc.getCurrentServerEntry();
        if (info == null) {
            return false;
        } else {
            String ip = info.address;
            return info.online && (ip.contains("hypixel") || ip.contains("cubecraft") || ip.contains("mineplex") || ip.contains("bedwarspractice") || ip.contains("mineverse"));
        }
    }

    private int getPing() {
        return (Integer)this.deviation.get() == 0 ? (Integer)this.ping.get() : (int)(Math.random() * (double)((Integer)this.deviation.get() * 2) - (double)(Integer)this.deviation.get() + (double)(Integer)this.ping.get());
    }

    @EventHandler
    private void onServerJoin(GameJoinedEvent event) {
        if (this.isDisallowed()) {
            this.toggle();
            meteordevelopment.meteorclient.utils.player.ChatUtils.warning("Ping Spoofer is not allowed on this server.", new Object[0]);
        }

    }

    @EventHandler
    private void onPreTick(Pre event) {
        if (System.currentTimeMillis() - this.timer >= (long)this.nextPing && this.id >= 0L && !(Boolean)this.strict.get()) {
            this.mc.getNetworkHandler().sendPacket(new KeepAliveC2SPacket(this.id));
            this.nextPing = this.getPing();
        }

    }

    @EventHandler
    private void onSendPacket(Send event) {
        Packet var3 = event.packet;
        if (var3 instanceof KeepAliveC2SPacket) {
            KeepAliveC2SPacket packet = (KeepAliveC2SPacket)var3;
            if (this.id != packet.getId()) {
                if ((Boolean)this.strict.get()) {
                    event.cancel();
                } else if ((Integer)this.ping.get() != 0) {
                    this.id = packet.getId();
                    this.timer = System.currentTimeMillis();
                    event.cancel();
                }
            }
        }

    }

    @EventHandler
    private void onReceivePacket(Receive event) {
        if ((Boolean)this.strict.get()) {
            Packet var3 = event.packet;
            if (var3 instanceof KeepAliveS2CPacket) {
                KeepAliveS2CPacket packet = (KeepAliveS2CPacket)var3;
                this.id = packet.getId();
                this.mc.getNetworkHandler().sendPacket(new KeepAliveC2SPacket(this.id));
            }
        }

    }

    public String getInfoString() {
        if (this.mc != null && this.mc.player != null && this.mc.getNetworkHandler() != null) {
            PlayerListEntry entry = this.mc.getNetworkHandler().getPlayerListEntry(this.mc.player.getUuid());
            return entry != null ? entry.getLatency() + "ms" : null;
        } else {
            return null;
        }
    }
}
