package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.world.biome.Biome;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.math.Vec3i;
import net.minecraft.text.Text;
import net.minecraft.client.network.ClientPlayerEntity;

public class HighwayBuilderPlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRepair;
    private final Setting<Integer> width;
    private final Setting<Integer> height;
    private final Setting<Boolean> obstruct;
    private final Setting<Boolean> compactMode;
    private final Setting<Boolean> swapBack;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> rotate;
    private final Setting<HighwayBuilderPlus.DirMode> dirMode;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> logoff;
    private final Setting<HighwayBuilderPlus.RailMode> railMode;
    private final Setting<HighwayBuilderPlus.Prio> prio;
    private final Setting<Boolean> lagPause;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> repair;
    private final Setting<Boolean> mineDiamonds;
    private final Setting<Boolean> mineRedstone;
    private final Setting<Integer> damage;
    private final Setting<Integer> repDamage;
    private Direction dir;
    private boolean shouldInfoWalk;
    private boolean repairing;
    private boolean goingBack;
    private boolean shouldInfoFound;
    private Vec3i repairPos;

    public HighwayBuilderPlus() {
        super(DeltaHack.Util, "highway-miner", "Automatically builds nether highways but better.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRepair = this.settings.createGroup("Pickaxe Repair");
        this.width = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("width")).description("Width away from the player.")).defaultValue(1)).range(0, 3).sliderRange(0, 2).build());
        this.height = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("height")).description("Height of the highway.")).defaultValue(3)).range(2, 5).sliderRange(2, 5).build());
        this.obstruct = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("obstruct-fluid")).description("Obstructs lava when needed.")).defaultValue(true)).build());
        this.compactMode = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("compact-mode")).description("Uses width 1 and height 2 when in basalt deltas biome")).defaultValue(false)).visible(() -> {
            return (Integer)this.width.get() != 0;
        })).build());
        this.swapBack = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swap-back")).description("Swaps back when placing blocks.")).defaultValue(false)).build());
        this.swing = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing")).description("Renders client-side swinging when placing and mining the blocks.")).defaultValue(false)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when placing and mining.")).defaultValue(false)).build());
        this.dirMode = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("direction-mode")).description("How to chose the direction of the highway.")).defaultValue(HighwayBuilderPlus.DirMode.Quadrant)).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("block")).description("What blocks to use for placing.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).build());
        this.logoff = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-on-error")).description("Toggles if neither of chosen blocks found.")).defaultValue(false)).build());
        this.railMode = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("railing-mode")).description("What mode to use when choosing blocks to build.")).defaultValue(HighwayBuilderPlus.RailMode.OnlyFloor)).build());
        this.prio = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("priority")).description("What action to prioritize over the other. ")).defaultValue(HighwayBuilderPlus.Prio.Placing)).build());
        this.lagPause = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("lag-pause")).description("Whether to pause if the server is not responding.")).defaultValue(true)).build());
        this.notify = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("notify")).description("Notifies you about certain events.")).defaultValue(false)).build());
        this.repair = this.sgRepair.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("repair-pickaxe")).description("Repairs your mending pickaxe when needed.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgRepair;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("mine-diamonds")).description("Repairs your mending pickaxe with diamond ore.")).defaultValue(true);
        Setting var10003 = this.repair;
        Objects.requireNonNull(var10003);
        this.mineDiamonds = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgRepair;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("mine-redstone")).description("Repairs your mending pickaxe with redstone ore.")).defaultValue(true);
        var10003 = this.repair;
        Objects.requireNonNull(var10003);
        this.mineRedstone = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgRepair;
        Builder var1 = ((Builder)((Builder)((Builder)(new Builder()).name("low-durability-percentage")).description("Launches repair sequence when your pickaxe durability is below this percentage.")).defaultValue(15)).range(0, 50).sliderRange(0, 25);
        var10003 = this.repair;
        Objects.requireNonNull(var10003);
        this.damage = var10001.add(((Builder)var1.visible(var10003::get)).build());
        var10001 = this.sgRepair;
        var1 = ((Builder)((Builder)((Builder)(new Builder()).name("high-durability-percentage")).description("Stops the repair sequence when your pickaxe durability is higher than this percentage.")).defaultValue(75)).range(15, 99).sliderRange(15, 80);
        var10003 = this.repair;
        Objects.requireNonNull(var10003);
        this.repDamage = var10001.add(((Builder)var1.visible(var10003::get)).build());
        this.shouldInfoWalk = false;
        this.repairing = false;
        this.goingBack = false;
        this.shouldInfoFound = false;
    }

    public void onActivate() {
        switch((HighwayBuilderPlus.DirMode)this.dirMode.get()) {
            case PlusX:
                this.dir = Direction.EAST;
                break;
            case MinusX:
                this.dir = Direction.WEST;
                break;
            case PlusZ:
                this.dir = Direction.SOUTH;
                break;
            case MinusZ:
                this.dir = Direction.NORTH;
                break;
            case Rotation:
                this.dir = this.mc.player.getHorizontalFacing();
                break;
            case Quadrant:
                int x = this.mc.player.getBlockX();
                int z = this.mc.player.getBlockZ();
                if (x >= Math.abs(z)) {
                    this.dir = Direction.EAST;
                } else if (z > Math.abs(x)) {
                    this.dir = Direction.SOUTH;
                } else if (x <= -Math.abs(z)) {
                    this.dir = Direction.WEST;
                } else if (z <= -Math.abs(x)) {
                    this.dir = Direction.NORTH;
                }
        }

    }

    public void onDeactivate() {
        if (this.repairing) {
            this.mc.player.sendChatMessage("#stop", (Text)null);
        }

        PlayerUtil.setPressed(this.mc.options.forwardKey, false);
        this.dir = null;
        this.shouldInfoFound = false;
        this.shouldInfoWalk = false;
        this.repairing = false;
        this.goingBack = false;
    }

    @EventHandler
    private void onTick(Pre event) {
        assert this.mc.player != null;

        if (TickRate.INSTANCE.getTimeSinceLastTick() >= 1.0F && (Boolean)this.lagPause.get()) {
            if ((Boolean)this.notify.get()) {
                this.warning("SortPrio Warning: Server is not responding!!!", new Object[0]);
            }

            PlayerUtil.setPressed(this.mc.options.forwardKey, false);
        } else {
            int var10001;
            if ((Boolean)this.repair.get()) {
                if (this.goingBack) {
                    if (this.mc.player.getBlockPos().equals(this.repairPos)) {
                        this.goingBack = false;
                    }

                    return;
                }

                ItemStack item = this.mc.player.getMainHandStack();
                if (item.getItem() instanceof PickaxeItem) {
                    ClientPlayerEntity var10000;
                    if (this.repairing) {
                        if (EnchantmentHelper.getLevel(Enchantments.SILK_TOUCH, item) > 0) {
                            FindItemResult a = InvUtils.find((itemStack) -> {
                                return itemStack.getItem() instanceof PickaxeItem && EnchantmentHelper.getLevel(Enchantments.SILK_TOUCH, itemStack) < 1;
                            });
                            if (!a.found()) {
                                if ((Boolean)this.notify.get()) {
                                    this.error("Fortune pickaxe not found!", new Object[0]);
                                }

                                this.toggle();
                            }

                            InvUtils.swap(a.slot(), false);
                        }

                        if ((float)(item.getMaxDamage() - item.getDamage()) / (float)item.getMaxDamage() * 100.0F > (float)(Integer)this.repDamage.get()) {
                            if ((Boolean)this.notify.get()) {
                                this.info("Pickaxe repaired!", new Object[0]);
                            }

                            var10000 = this.mc.player;
                            var10001 = this.repairPos.getX();
                            var10000.sendChatMessage("#goto  " + var10001 + " " + this.repairPos.getY() + " " + this.repairPos.getZ(), (Text)null);
                            this.repairing = false;
                            this.goingBack = true;
                        }
                    } else if (EnchantmentHelper.getLevel(Enchantments.MENDING, item) > 0 && (float)(item.getMaxDamage() - item.getDamage()) / (float)item.getMaxDamage() * 100.0F < (float)(Integer)this.damage.get()) {
                        this.repairPos = EntityUtil.playerPos(this.mc.player);
                        this.repairing = true;
                        var10000 = this.mc.player;
                        String var16 = this.mc.world.getDimension().comp_648() ? ((Boolean)this.mineDiamonds.get() ? "minecraft:diamond_ore minecraft:deepslate_diamond_ore" : "") + ((Boolean)this.mineRedstone.get() ? " minecraft:redstone_ore minecraft:deepslate_redstone_ore" : "") : "minecraft:nether_quartz_ore";
                        var10000.sendChatMessage("#mine " + var16, (Text)null);
                        if ((Boolean)this.notify.get()) {
                            this.warning("Pickaxe low durability reached. Repairing!", new Object[0]);
                        }
                    }
                }
            }

            if (!this.repairing) {
                List<BlockPos> obs = new ArrayList();
                List<BlockPos> minePos = new ArrayList();
                List<BlockPos> placePos = new ArrayList();
                this.mc.player.setYaw((float)Rotations.getYaw(EntityUtil.playerPos(this.mc.player).offset(this.dir, 1)));
                BlockPos p = EntityUtil.playerPos(this.mc.player);
                boolean basalt_deltas = (Integer)this.width.get() != 0 && (Boolean)this.compactMode.get() && this.mc.world.getRegistryManager().get(Registry.BIOME_KEY).getId((Biome)this.mc.world.getBiome(p).comp_349()).getPath().equals("basalt_deltas");

                int j;
                BlockPos l;
                for(j = basalt_deltas ? 0 : (Integer)this.width.get(); j >= (basalt_deltas ? 0 : -(Integer)this.width.get()); --j) {
                    l = p.offset(this.dir).offset(Direction.fromHorizontal(this.dir.getHorizontal() + 1), j);

                    for(int j = 0; j < (basalt_deltas ? 2 : (Integer)this.height.get()); ++j) {
                        BlockPos x = l.up(j);
                        if ((Boolean)this.obstruct.get() && this.mc.world.getBlockState(x.offset(this.dir)).getMaterial().isLiquid()) {
                            obs.add(x.offset(this.dir));
                        }

                        if (BlockUtil.isBreakable(x)) {
                            minePos.add(x);
                        }
                    }

                    if (BlockUtil.isReplaceable(l.down())) {
                        placePos.add(l.down());
                    }

                    BlockPos x = l.up((Integer)this.height.get());
                    if (this.railMode.get() == HighwayBuilderPlus.RailMode.Roof && BlockUtil.isReplaceable(x)) {
                        placePos.add(x);
                    }

                    if ((Boolean)this.obstruct.get() && this.mc.world.getBlockState(x).getMaterial().isLiquid()) {
                        obs.add(x);
                    }
                }

                if ((Boolean)this.obstruct.get()) {
                    for(j = 0; j < (basalt_deltas ? 2 : (Integer)this.height.get()); ++j) {
                        l = p.offset(this.dir).up(j);
                        Direction d = Direction.fromHorizontal(this.dir.getHorizontal() + 1);
                        if (this.mc.world.getBlockState(l.offset(d, (Integer)this.width.get() + 1)).getMaterial().isLiquid()) {
                            obs.add(l.offset(d, (Integer)this.width.get() + 1));
                        }

                        if (this.mc.world.getBlockState(l.offset(d.getOpposite(), (Integer)this.width.get() + 1)).getMaterial().isLiquid()) {
                            obs.add(l.offset(d.getOpposite(), (Integer)this.width.get() + 1));
                        }
                    }
                }

                if (this.railMode.get() != HighwayBuilderPlus.RailMode.OnlyFloor && !basalt_deltas) {
                    BlockPos k = p.offset(this.dir).offset(Direction.fromHorizontal(this.dir.getHorizontal() + 1), (Integer)this.width.get() + 1);
                    l = p.offset(this.dir).offset(Direction.fromHorizontal(this.dir.getHorizontal() + 1).getOpposite(), (Integer)this.width.get() + 1);
                    if (BlockUtil.isReplaceable(k)) {
                        placePos.add(k);
                    }

                    if (BlockUtil.isReplaceable(l)) {
                        placePos.add(l);
                    }
                }

                if (minePos.isEmpty() && placePos.isEmpty() && obs.isEmpty()) {
                    this.shouldInfoFound = true;
                    if (this.shouldInfoWalk && (Boolean)this.notify.get()) {
                        this.info("All done, moving forward", new Object[0]);
                        this.shouldInfoWalk = false;
                    }

                    PlayerUtil.setPressed(this.mc.options.forwardKey, true);
                } else {
                    PlayerUtil.setPressed(this.mc.options.forwardKey, false);
                    if (this.shouldInfoFound && (Boolean)this.notify.get()) {
                        this.shouldInfoFound = false;
                        var10001 = minePos.size();
                        this.info("Found " + var10001 + " blocks to mine and " + placePos.size() + obs.size() + " to place.", new Object[0]);
                    }

                    if (!obs.isEmpty()) {
                        obs.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                        this.place((BlockPos)obs.get(0));
                    } else if (this.prio.get() != HighwayBuilderPlus.Prio.Mining && !placePos.isEmpty()) {
                        if (this.prio.get() == HighwayBuilderPlus.Prio.Placing || minePos.isEmpty()) {
                            placePos.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                            this.place((BlockPos)placePos.get(0));
                        }
                    } else {
                        minePos.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                        BlockUtil.mineBlock((BlockPos)minePos.get(0), (Boolean)this.swing.get(), (Boolean)this.rotate.get());
                    }

                    this.shouldInfoWalk = true;
                }

            }
        }
    }

    private void place(BlockPos pos) {
        FindItemResult hbpfr = InvUtils.find((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        });
        if (!hbpfr.found()) {
            if ((Boolean)this.notify.get()) {
                this.error("Block to place not found!", new Object[0]);
            }

            if ((Boolean)this.logoff.get()) {
                this.toggle();
            }
        }

        WorldUtils.place(pos, hbpfr, (Boolean)this.rotate.get(), 80, false, (Boolean)this.swing.get(), true, (Boolean)this.swapBack.get());
    }

    public static enum DirMode {
        Rotation,
        Quadrant,
        PlusX,
        MinusX,
        PlusZ,
        MinusZ;

        // $FF: synthetic method
        private static HighwayBuilderPlus.DirMode[] $values() {
            return new HighwayBuilderPlus.DirMode[]{Rotation, Quadrant, PlusX, MinusX, PlusZ, MinusZ};
        }
    }

    public static enum RailMode {
        OnlyFloor("Only floor"),
        Railing("Railings"),
        Roof("Roof and railings");

        final String name;

        private RailMode(String name) {
            this.name = name;
        }

        public String toString() {
            return this.name;
        }

        // $FF: synthetic method
        private static HighwayBuilderPlus.RailMode[] $values() {
            return new HighwayBuilderPlus.RailMode[]{OnlyFloor, Railing, Roof};
        }
    }

    public static enum Prio {
        Placing,
        Mining;

        // $FF: synthetic method
        private static HighwayBuilderPlus.Prio[] $values() {
            return new HighwayBuilderPlus.Prio[]{Placing, Mining};
        }
    }
}
