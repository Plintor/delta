package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;

public class ChestSwapPlus extends Module {
    private final SettingGroup sgGeneral;
    public final Setting<Integer> del;
    public final Setting<Boolean> autoTake;
    public final Setting<Boolean> autoJump;
    public final Setting<Boolean> autoFirework;
    public final Setting<Boolean> swapToChest;
    private final Setting<Keybind> forceElytraBind;
    private int airTicks;
    private boolean shouldJump;

    public ChestSwapPlus() {
        super(DeltaHack.Misc, "chest-swap+", "Automatically swaps chestplate with elytra in air");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.del = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("delay")).defaultValue(12)).range(5, 15).sliderRange(5, 15).build());
        this.autoTake = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-take-off")).description("Whether to take off when elytra is taken on or not")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-jump")).description("Whether to take off when elytra is taken on or not")).defaultValue(true);
        Setting var10003 = this.autoTake;
        Objects.requireNonNull(var10003);
        this.autoJump = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("auto-firework")).description("Whether to use firework when elytra is taken on or not")).defaultValue(true);
        var10003 = this.autoTake;
        Objects.requireNonNull(var10003);
        this.autoFirework = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.swapToChest = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swap-back")).description("Whether to swap back to chestplate when on ground or not")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.KeybindSetting.Builder var1 = (meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("force-elytra-bind")).description("Teleports you when this button is pressed")).defaultValue(Keybind.fromButton(3));
        var10003 = this.swapToChest;
        Objects.requireNonNull(var10003);
        this.forceElytraBind = var10001.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)var1.visible(var10003::get)).build());
        this.shouldJump = false;
    }

    public void onActivate() {
        this.airTicks = 0;
    }

    @EventHandler
    private void onTick(Pre event) {
        if (!this.mc.player.isOnGround() && BlockUtil.getBlock(this.mc.player.getBlockPos()) != Blocks.WATER && BlockUtil.getBlock(this.mc.player.getBlockPos()) != Blocks.KELP && BlockUtil.getBlock(this.mc.player.getBlockPos()) != Blocks.KELP_PLANT) {
            ++this.airTicks;
        } else {
            this.airTicks = 0;
        }

        FindItemResult fN = InvUtils.find(new Item[]{Items.NETHERITE_CHESTPLATE});
        FindItemResult fD = InvUtils.find(new Item[]{Items.DIAMOND_CHESTPLATE});
        FindItemResult fE = InvUtils.find(new Item[]{Items.ELYTRA});
        if (this.shouldJump && (Boolean)this.autoTake.get() && !((Keybind)this.forceElytraBind.get()).isPressed() && this.airTicks >= (Integer)this.del.get()) {
            this.mc.options.jumpKey.setPressed(false);
            Input.setKeyState(this.mc.options.jumpKey, false);
            if ((Boolean)this.autoJump.get()) {
                this.mc.player.jump();
            }

            if ((Boolean)this.autoFirework.get()) {
                FindItemResult cspfR = InvUtils.find(new Item[]{Items.FIREWORK_ROCKET});
                if (cspfR.found()) {
                    if (InvUtils.findInHotbar(new Item[]{Items.FIREWORK_ROCKET}).found()) {
                        InvUtils.swap(cspfR.slot(), true);
                        if (this.mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET) {
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                        }

                        InvUtils.swapBack();
                    } else {
                        int slot = this.mc.player.getInventory().selectedSlot;
                        InvUtils.move().from(cspfR.slot()).to(slot);
                        if (this.mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET) {
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                        }

                        InvUtils.move().from(slot).to(cspfR.slot());
                    }
                }
            }

            this.shouldJump = false;
        }

        if (this.airTicks == 0 && (Boolean)this.swapToChest.get() && this.mc.player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA && !((Keybind)this.forceElytraBind.get()).isPressed()) {
            this.mc.player.stopFallFlying();
            this.mc.options.jumpKey.setPressed(false);
            Input.setKeyState(this.mc.options.jumpKey, false);
            if (fN.found()) {
                InvUtils.move().from(fN.slot()).toArmor(2);
            } else if (fD.found()) {
                InvUtils.move().from(fD.slot()).toArmor(2);
            }
        } else if ((this.airTicks >= (Integer)this.del.get() || ((Keybind)this.forceElytraBind.get()).isPressed()) && fE.found() && this.mc.player.getInventory().getArmorStack(2).getItem() != Items.ELYTRA) {
            InvUtils.move().from(fE.slot()).toArmor(2);
            this.shouldJump = true;
            if ((Boolean)this.autoTake.get() && !((Keybind)this.forceElytraBind.get()).isPressed()) {
                this.mc.options.jumpKey.setPressed(true);
                Input.setKeyState(this.mc.options.jumpKey, true);
            }
        }

    }
}
