package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class Newker extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgWhitelist;
    private final SettingGroup sgRender;
    private final Setting<Newker.Shape> shape;
    private final Setting<Newker.Mode> mode;
    private final Setting<Double> range;
    private final Setting<Boolean> autoWalk;
    private final Setting<Boolean> autoCenter;
    private final Setting<Newker.NukerDirection> direction;
    private final Setting<Integer> range_up;
    private final Setting<Integer> range_down;
    private final Setting<Integer> range_left;
    private final Setting<Integer> range_right;
    private final Setting<Integer> range_forward;
    private final Setting<Integer> range_back;
    private final Setting<Integer> delay;
    private final Setting<Integer> maxBlocksPerTick;
    private final Setting<Newker.SortMode> sortMode;
    private final Setting<Boolean> swingHand;
    private final Setting<Boolean> noMineUnder;
    private final Setting<Boolean> useless;
    private final Setting<Boolean> whitelistEnabled;
    private final Setting<List<Block>> whitelist;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> enableRenderBounding;
    private final Setting<ShapeMode> shapeModeBox;
    private final Setting<SettingColor> sideColorBox;
    private final Setting<SettingColor> lineColorBox;
    private final Setting<Boolean> enableRenderBreaking;
    private final Setting<ShapeMode> shapeModeBreak;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Pool<Mutable> blockPosPool;
    private final List<Mutable> blocks;
    private final Pool<Newker.RenderBlock> renderBlockPool;
    private final List<Newker.RenderBlock> renderBlocks;
    private boolean firstBlock;
    private final Mutable lastBlockPos;
    private int timer;
    private int noBlockTimer;
    private final Mutable pos1;
    private final Mutable pos2;
    private Box box;
    int maxh;
    int maxv;

    public Newker() {
        super(DeltaHack.Misc, "newker", "Nuker but idk");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgWhitelist = this.settings.createGroup("Whitelist");
        this.sgRender = this.settings.createGroup("Render");
        this.shape = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("shape")).description("The shape of nuking algorithm.")).defaultValue(Newker.Shape.Sphere)).build());
        this.mode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("mode")).description("The way the blocks are broken.")).defaultValue(Newker.Mode.Flatten)).build());
        this.range = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("range")).description("The break range.")).defaultValue(4.0D).min(0.0D).visible(() -> {
            return this.shape.get() != Newker.Shape.Cube;
        })).build());
        this.autoWalk = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("walk")).description("Walks when you don't mine")).defaultValue(true)).build());
        this.autoCenter = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("center")).description("Centers the player on mine")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("simple-direction")).description("The direction to walk in simple mode.")).defaultValue(Newker.NukerDirection.Forwards);
        Setting var10003 = this.autoWalk;
        Objects.requireNonNull(var10003);
        this.direction = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.range_up = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("up")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.range_down = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("down")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.range_left = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("left")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.range_right = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("right")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.range_forward = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("forward")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.range_back = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("back")).description("The break range.")).defaultValue(1)).min(0).visible(() -> {
            return this.shape.get() == Newker.Shape.Cube;
        })).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Delay in ticks between breaking blocks.")).defaultValue(0)).build());
        this.maxBlocksPerTick = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("max-blocks-per-tick")).description("Maximum blocks to try to break per tick. Useful when insta mining.")).defaultValue(1)).min(1).sliderRange(1, 6).build());
        this.sortMode = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("sort-mode")).description("The blocks you want to mine first.")).defaultValue(Newker.SortMode.Closest)).build());
        this.swingHand = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing-hand")).description("Swing hand client side.")).defaultValue(true)).build());
        this.noMineUnder = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("don't-mine-under")).description("-")).defaultValue(true)).build());
        var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var1 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("useless-setting")).description("does absolutely fucking nothing");
        var10003 = this.noMineUnder;
        Objects.requireNonNull(var10003);
        this.useless = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var1.visible(var10003::get)).defaultValue(true)).build());
        this.whitelistEnabled = this.sgWhitelist.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("whitelist-enabled")).description("Only mines selected blocks.")).defaultValue(false)).build());
        var10001 = this.sgWhitelist;
        meteordevelopment.meteorclient.settings.BlockListSetting.Builder var2 = (meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("whitelist")).description("The blocks you want to mine.");
        var10003 = this.whitelistEnabled;
        Objects.requireNonNull(var10003);
        this.whitelist = var10001.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)var2.visible(var10003::get)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Gulag moment")).defaultValue(false)).build());
        this.enableRenderBounding = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("bounding-box")).description("Enable rendering bounding box for Cube and Uniform Cube.")).defaultValue(true)).build());
        this.shapeModeBox = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("nuke-box-mode")).description("How the shape for the bounding box is rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColorBox = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color of the bounding box.")).defaultValue(new SettingColor(16, 106, 144, 100))).build());
        this.lineColorBox = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color of the bounding box.")).defaultValue(new SettingColor(16, 106, 144, 255))).build());
        this.enableRenderBreaking = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("broken-blocks")).description("Enable rendering bounding box for Cube and Uniform Cube.")).defaultValue(true)).build());
        this.shapeModeBreak = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("nuke-block-mode")).description("How the shapes for broken blocks are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The side color of the target block rendering.")).defaultValue(new SettingColor(255, 0, 0, 80))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The line color of the target block rendering.")).defaultValue(new SettingColor(255, 0, 0, 255))).build());
        this.blockPosPool = new Pool(Mutable::new);
        this.blocks = new ArrayList();
        this.renderBlockPool = new Pool(Newker.RenderBlock::new);
        this.renderBlocks = new ArrayList();
        this.lastBlockPos = new Mutable();
        this.pos1 = new Mutable();
        this.pos2 = new Mutable();
        this.maxh = 0;
        this.maxv = 0;
    }

    public void onActivate() {
        this.firstBlock = true;
        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            Newker.RenderBlock renderBlock = (Newker.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        this.timer = 0;
        this.noBlockTimer = 0;
    }

    public void onDeactivate() {
        if ((Boolean)this.autoWalk.get()) {
            PlayerUtil.unPress();
        }

        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            Newker.RenderBlock renderBlock = (Newker.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.enableRenderBreaking.get()) {
            this.renderBlocks.sort(Comparator.comparingInt((o) -> {
                return -o.ticks;
            }));
            this.renderBlocks.forEach((renderBlock) -> {
                renderBlock.render(event, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeModeBreak.get());
            });
        }

        if ((Boolean)this.enableRenderBounding.get() && this.shape.get() != Newker.Shape.Sphere && this.mode.get() != Newker.Mode.Smash) {
            this.box = new Box(this.pos1, this.pos2);
            event.renderer.box(this.box, (Color)this.sideColorBox.get(), (Color)this.lineColorBox.get(), (ShapeMode)this.shapeModeBox.get(), 0);
        }

    }

    @EventHandler
    private void onTickPre(Pre event) {
        this.renderBlocks.forEach(Newker.RenderBlock::tick);
        this.renderBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        if (this.timer > 0) {
            --this.timer;
        } else {
            double pX = (double)EntityUtil.playerPos(this.mc.player).getX();
            double pY = (double)EntityUtil.playerPos(this.mc.player).getY();
            double pZ = (double)EntityUtil.playerPos(this.mc.player).getZ();
            double rangeSq = Math.pow((Double)this.range.get(), 2.0D);
            if (this.shape.get() == Newker.Shape.UniformCube) {
                this.range.set((double)Math.round((Double)this.range.get()));
            }

            int r = (int)Math.round((Double)this.range.get());
            double pX_;
            if (this.shape.get() == Newker.Shape.UniformCube) {
                pX_ = pX + 1.0D;
                this.pos1.set(pX_ - (double)r, pY - (double)r + 1.0D, pZ - (double)r + 1.0D);
                this.pos2.set(pX_ + (double)r - 1.0D, pY + (double)r, pZ + (double)r);
            } else {
                int direction = Math.round(this.mc.player.getRotationClient().y % 360.0F / 90.0F);
                direction = Math.floorMod(direction, 4);
                this.pos1.set(pX - (double)(Integer)this.range_forward.get(), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ - (double)(Integer)this.range_right.get());
                this.pos2.set(pX + (double)(Integer)this.range_back.get() + 1.0D, Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ + (double)(Integer)this.range_left.get() + 1.0D);
                double pZ_;
                if (direction == 2) {
                    pX_ = pX + 1.0D;
                    pZ_ = pZ + 1.0D;
                    this.pos1.set(pX_ - (double)((Integer)this.range_left.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ_ - (double)((Integer)this.range_forward.get() + 1));
                    this.pos2.set(pX_ + (double)(Integer)this.range_right.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ_ + (double)(Integer)this.range_back.get());
                } else if (direction == 3) {
                    pX_ = pX + 1.0D;
                    this.pos1.set(pX_ - (double)((Integer)this.range_back.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ - (double)(Integer)this.range_left.get());
                    this.pos2.set(pX_ + (double)(Integer)this.range_forward.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ + (double)(Integer)this.range_right.get() + 1.0D);
                } else if (direction == 0) {
                    pZ_ = pZ + 1.0D;
                    pX_ = pX + 1.0D;
                    this.pos1.set(pX_ - (double)((Integer)this.range_right.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ_ - (double)((Integer)this.range_back.get() + 1));
                    this.pos2.set(pX_ + (double)(Integer)this.range_left.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ_ + (double)(Integer)this.range_forward.get());
                }

                this.maxh = 1 + Math.max(Math.max(Math.max((Integer)this.range_back.get(), (Integer)this.range_right.get()), (Integer)this.range_forward.get()), (Integer)this.range_left.get());
                this.maxv = 1 + Math.max((Integer)this.range_up.get(), (Integer)this.range_down.get());
            }

            if (this.mode.get() == Newker.Mode.Flatten) {
                this.pos1.setY((int)Math.floor(pY));
            }

            this.box = new Box(this.pos1, this.pos2);
            BlockIterator.register(Math.max((int)Math.ceil((Double)this.range.get() + 1.0D), this.maxh), Math.max((int)Math.ceil((Double)this.range.get()), this.maxv), (blockPos, blockState) -> {
                boolean toofarSphere = Utils.squaredDistance(pX, pY, pZ, (double)blockPos.getX() + 0.5D, (double)blockPos.getY() + 0.5D, (double)blockPos.getZ() + 0.5D) > rangeSq;
                boolean toofarUniformCube = maxDist(Math.floor(pX), Math.floor(pY), Math.floor(pZ), (double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ()) >= (Double)this.range.get();
                boolean toofarCube = !this.box.contains(Vec3d.ofCenter(blockPos));
                if (BlockUtils.canBreak(blockPos, blockState) && (!toofarSphere || this.shape.get() != Newker.Shape.Sphere) && (!toofarUniformCube || this.shape.get() != Newker.Shape.UniformCube) && (!toofarCube || this.shape.get() != Newker.Shape.Cube)) {
                    if (this.mode.get() != Newker.Mode.Flatten || !((double)blockPos.getY() < Math.floor(this.mc.player.getY()))) {
                        if (this.mode.get() != Newker.Mode.Smash || blockState.getHardness(this.mc.world, blockPos) == 0.0F) {
                            if (!(Boolean)this.whitelistEnabled.get() || ((List)this.whitelist.get()).contains(blockState.getBlock())) {
                                this.blocks.add(((Mutable)this.blockPosPool.get()).set(blockPos));
                            }
                        }
                    }
                }
            });
            BlockIterator.after(() -> {
                if (this.blocks.contains(((Mutable)this.blockPosPool.get()).set(EntityUtil.playerPos(this.mc.player).down())) && (Boolean)this.noMineUnder.get() && (!(Boolean)this.useless.get() || this.blocks.size() != 1)) {
                    this.blocks.remove(((Mutable)this.blockPosPool.get()).set(EntityUtil.playerPos(this.mc.player).down()));
                }

                if (this.sortMode.get() == Newker.SortMode.TopDown) {
                    this.blocks.sort(Comparator.comparingDouble((value) -> {
                        return (double)(-1 * value.getY());
                    }));
                } else if (this.sortMode.get() != Newker.SortMode.None) {
                    this.blocks.sort(Comparator.comparingDouble((value) -> {
                        return Utils.squaredDistance(pX, pY, pZ, (double)value.getX() + 0.5D, (double)value.getY() + 0.5D, (double)value.getZ() + 0.5D) * (double)(this.sortMode.get() == Newker.SortMode.Closest ? 1 : -1);
                    }));
                }

                if (this.blocks.isEmpty()) {
                    if ((Boolean)this.autoWalk.get()) {
                        switch((Newker.NukerDirection)this.direction.get()) {
                            case Forwards:
                                PlayerUtil.setPressed(this.mc.options.forwardKey, true);
                                break;
                            case Backwards:
                                PlayerUtil.setPressed(this.mc.options.backKey, true);
                                break;
                            case Left:
                                PlayerUtil.setPressed(this.mc.options.leftKey, true);
                                break;
                            case Right:
                                PlayerUtil.setPressed(this.mc.options.rightKey, true);
                        }
                    }

                    if (this.noBlockTimer++ >= (Integer)this.delay.get()) {
                        this.firstBlock = true;
                    }

                } else {
                    if ((Boolean)this.autoCenter.get()) {
                        PlayerUtils.centerPlayer();
                        this.mc.player.setYaw((float)(Math.round((this.mc.player.getYaw() + 1.0F) / 45.0F) * 45));
                    }

                    this.noBlockTimer = 0;
                    if ((Boolean)this.autoWalk.get()) {
                        PlayerUtil.unPress();
                    }

                    if (!this.firstBlock && !this.lastBlockPos.equals(this.blocks.get(0))) {
                        this.timer = (Integer)this.delay.get();
                        this.firstBlock = false;
                        this.lastBlockPos.set((Vec3i)this.blocks.get(0));
                        if (this.timer > 0) {
                            return;
                        }
                    }

                    int count = 0;
                    Iterator var8 = this.blocks.iterator();

                    while(var8.hasNext()) {
                        BlockPos block = (BlockPos)var8.next();
                        if (count >= (Integer)this.maxBlocksPerTick.get()) {
                            break;
                        }

                        boolean canInstaMine = BlockUtils.canInstaBreak(block);
                        if ((Boolean)this.rotate.get()) {
                            Rotations.rotate(Rotations.getYaw(block), Rotations.getPitch(block));
                        }

                        BlockUtils.breakBlock(block, (Boolean)this.swingHand.get());
                        this.renderBlocks.add(((Newker.RenderBlock)this.renderBlockPool.get()).set(block));
                        this.lastBlockPos.set(block);
                        ++count;
                        if (!canInstaMine) {
                            break;
                        }
                    }

                    this.firstBlock = false;
                    var8 = this.blocks.iterator();

                    while(var8.hasNext()) {
                        Mutable blockPos = (Mutable)var8.next();
                        this.blockPosPool.free(blockPos);
                    }

                    this.blocks.clear();
                }
            });
        }
    }

    public static double maxDist(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dX = Math.ceil(Math.abs(x2 - x1));
        double dY = Math.ceil(Math.abs(y2 - y1));
        double dZ = Math.ceil(Math.abs(z2 - z1));
        return Math.max(Math.max(dX, dY), dZ);
    }

    public static enum Shape {
        Cube,
        UniformCube,
        Sphere;

        // $FF: synthetic method
        private static Newker.Shape[] $values() {
            return new Newker.Shape[]{Cube, UniformCube, Sphere};
        }
    }

    public static enum Mode {
        All,
        Flatten,
        Smash;

        // $FF: synthetic method
        private static Newker.Mode[] $values() {
            return new Newker.Mode[]{All, Flatten, Smash};
        }
    }

    public static enum NukerDirection {
        Forwards,
        Backwards,
        Left,
        Right;

        // $FF: synthetic method
        private static Newker.NukerDirection[] $values() {
            return new Newker.NukerDirection[]{Forwards, Backwards, Left, Right};
        }
    }

    public static enum SortMode {
        None,
        Closest,
        Furthest,
        TopDown;

        // $FF: synthetic method
        private static Newker.SortMode[] $values() {
            return new Newker.SortMode[]{None, Closest, Furthest, TopDown};
        }
    }

    public static class RenderBlock {
        public Mutable pos = new Mutable();
        public int ticks;

        public Newker.RenderBlock set(BlockPos blockPos) {
            this.pos.set(blockPos);
            this.ticks = 8;
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
            int preSideA = sides.a;
            int preLineA = lines.a;
            sides.a = (int)((double)sides.a * ((double)this.ticks / 8.0D));
            lines.a = (int)((double)lines.a * ((double)this.ticks / 8.0D));
            event.renderer.box(this.pos, sides, lines, shapeMode, 0);
            sides.a = preSideA;
            lines.a = preLineA;
        }
    }
}
