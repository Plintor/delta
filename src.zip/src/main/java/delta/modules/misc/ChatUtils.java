package delta.modules.misc;

import delta.DeltaHack;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import meteordevelopment.meteorclient.events.game.SendMessageEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class ChatUtils extends Module {
    private final SettingGroup g;
    public final Setting<Boolean> translateActive;
    private final Setting<ChatUtils.translitModes> translateMode;
    public final Setting<Boolean> numActive;
    private final Setting<ChatUtils.PrintMode> numPos;
    private final Setting<Integer> num_length;
    public final Setting<Boolean> splitActive;
    private final Setting<String> space_char;
    public final Setting<Boolean> splitMamActive;
    private final Map<String, String> to_change;
    private final Map<String, String> to_change_upper;
    private final Map<String, String> mamChange;

    public ChatUtils() {
        super(DeltaHack.Autist, "retarded-chat", "Makes your message retarded or something idk this is a skid module.");
        this.g = this.settings.getDefaultGroup();
        this.translateActive = this.g.add(((Builder)((Builder)((Builder)(new Builder()).name("active")).description("-")).defaultValue(false)).build());
        SettingGroup var10001 = this.g;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("mode");
        Setting var10003 = this.translateActive;
        Objects.requireNonNull(var10003);
        this.translateMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var10002.visible(var10003::get)).defaultValue(ChatUtils.translitModes.FULL)).build());
        this.numActive = this.g.add(((Builder)((Builder)((Builder)(new Builder()).name("active")).description("Put the random number.")).defaultValue(false)).build());
        var10001 = this.g;
        var10002 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("position");
        var10003 = this.numActive;
        Objects.requireNonNull(var10003);
        this.numPos = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var10002.visible(var10003::get)).defaultValue(ChatUtils.PrintMode.Before)).build());
        var10001 = this.g;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var20 = (meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("length");
        var10003 = this.numActive;
        Objects.requireNonNull(var10003);
        this.num_length = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)var20.visible(var10003::get)).defaultValue(3)).range(1, 8).sliderRange(1, 8).build());
        this.splitActive = this.g.add(((Builder)((Builder)((Builder)(new Builder()).name("active")).description("Splits the text with given character.")).defaultValue(false)).build());
        var10001 = this.g;
        meteordevelopment.meteorclient.settings.StringSetting.Builder var21 = (meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("character");
        var10003 = this.splitActive;
        Objects.requireNonNull(var10003);
        this.space_char = var10001.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)var21.visible(var10003::get)).defaultValue("")).build());
        this.splitMamActive = this.g.add(((Builder)((Builder)((Builder)(new Builder()).name("active")).description("Split the word mam or mat.")).defaultValue(false)).build());
        this.to_change = new HashMap();
        this.to_change_upper = new HashMap();
        this.mamChange = new HashMap();
        String rus = "абвгдезийклмнопрстуфхыэ";
        String eng = "abvgdeziyklmnoprstufhie";

        String key;
        for(int i = 0; i < rus.length(); ++i) {
            char var10000 = rus.charAt(i);
            String key = var10000.makeConcatWithConstants<invokedynamic>(var10000);
            var10000 = eng.charAt(i);
            key = var10000.makeConcatWithConstants<invokedynamic>(var10000);
            this.to_change.put(key, key);
        }

        this.to_change.put("ё", "yo");
        this.to_change.put("ж", "j");
        this.to_change.put("ц", "ts");
        this.to_change.put("ч", "ch");
        this.to_change.put("ш", "sh");
        this.to_change.put("щ", "shch");
        this.to_change.put("ю", "yu");
        this.to_change.put("я", "ya");
        this.to_change.put("ь", "'");
        this.to_change.put("ъ", "");
        Iterator var13 = this.to_change.entrySet().iterator();

        while(var13.hasNext()) {
            Entry<String, String> entry = (Entry)var13.next();
            key = (String)entry.getKey();
            String val = (String)entry.getValue();
            this.to_change_upper.put(key.toUpperCase(), val.toUpperCase());
        }

        String[] toChange = new String[]{"мам", "мат", "mam", "mat"};
        String[] var16 = toChange;
        int var17 = toChange.length;

        for(int var18 = 0; var18 < var17; ++var18) {
            String word = var16[var18];

            for(int c = 0; (double)c < Math.pow(2.0D, (double)word.length()); ++c) {
                String[] splitWord = word.split("");
                String binNum = String.format("%3s", Integer.toBinaryString(c)).replace(' ', '0');

                for(int i = 0; i < word.length(); ++i) {
                    if (binNum.charAt(i) == '1') {
                        splitWord[i] = splitWord[i].toUpperCase();
                    }
                }

                String out = splitWord[0] + splitWord[1] + splitWord[2];
                splitWord[1] = splitWord[1].replace(splitWord[1], splitWord[1] + "-");
                String out2 = splitWord[0] + splitWord[1] + splitWord[2];
                this.mamChange.put(out, out2);
            }
        }

    }

    private String translit(String text) {
        StringBuilder text2 = new StringBuilder();
        if (this.translateMode.get() != ChatUtils.translitModes.Ruzian) {
            for(int i = 0; i < text.length(); ++i) {
                char var10000 = text.charAt(i);
                String character = var10000.makeConcatWithConstants<invokedynamic>(var10000);
                switch((ChatUtils.translitModes)this.translateMode.get()) {
                    case FULL:
                        text2.append((String)this.to_change.getOrDefault(character, (String)this.to_change_upper.getOrDefault(character, character)));
                        break;
                    case AutoZov:
                        if ("звЗВ".contains(character)) {
                            text2.append((String)this.to_change.getOrDefault(character, (String)this.to_change_upper.getOrDefault(character, character)));
                        } else {
                            text2.append(character);
                        }
                        break;
                    case AutoHohol:
                        byte var6 = -1;
                        switch(character.hashCode()) {
                            case 1045:
                                if (character.equals("Е")) {
                                    var6 = 7;
                                }
                                break;
                            case 1048:
                                if (character.equals("И")) {
                                    var6 = 1;
                                }
                                break;
                            case 1066:
                                if (character.equals("Ъ")) {
                                    var6 = 9;
                                }
                                break;
                            case 1067:
                                if (character.equals("Ы")) {
                                    var6 = 3;
                                }
                                break;
                            case 1069:
                                if (character.equals("Э")) {
                                    var6 = 5;
                                }
                                break;
                            case 1077:
                                if (character.equals("е")) {
                                    var6 = 6;
                                }
                                break;
                            case 1080:
                                if (character.equals("и")) {
                                    var6 = 0;
                                }
                                break;
                            case 1098:
                                if (character.equals("ъ")) {
                                    var6 = 8;
                                }
                                break;
                            case 1099:
                                if (character.equals("ы")) {
                                    var6 = 2;
                                }
                                break;
                            case 1101:
                                if (character.equals("э")) {
                                    var6 = 4;
                                }
                        }

                        switch(var6) {
                            case 0:
                                text2.append("i");
                                break;
                            case 1:
                                text2.append("I");
                                break;
                            case 2:
                                text2.append("и");
                                break;
                            case 3:
                                text2.append("И");
                                break;
                            case 4:
                                text2.append("е");
                                break;
                            case 5:
                                text2.append("Е");
                                break;
                            case 6:
                                text2.append("є");
                                break;
                            case 7:
                                text2.append("Є");
                                break;
                            case 8:
                            case 9:
                                text2.append("'");
                                break;
                            default:
                                text2.append(character);
                        }
                }
            }

            return text2.toString();
        } else {
            text = text.replace("дят", "дять");
            text = text.replace("дзи", "ζ");
            text = text.replace("дз", "ζ");
            text = text.replace("жу", "jy");
            text = text.replace("ай", "аj");
            text = text.replace("дт", "θт");
            text = text.replace("су", "sy");
            text = text.replace("шё", "шø");
            text = text.replace("уй", "yj");
            text = text.replace("ну", "нy");
            text = text.replace("ли", "λ");
            text = text.replace("ль", "λ");
            text = text.replace("ье", "ъ");
            text = text.replace("бо", "бø");
            text = text.replace("тс", "ţ");
            text = text.replace("ть", "θ");
            text = text.replace("гу", "гy");
            text = text.replace("ты", "θi");
            text = text.replace("тр", "θр");
            text = text.replace("та", "θа");
            text = text.replace("те", "θе");
            text = text.replace("ае", "аï");
            text = text.replace("чу", "чy");
            text = text.replace("ж", "ʤ");
            text = text.replace("з", "z");
            text = text.replace("э", "é");
            text = text.replace("я", "ä");
            text = text.replace("то", "θø");
            text = text.replace("т", "д");
            text = text.replace("ц", "ţ");
            text = text.replace("л", "ł");
            text = text.replace("с", "s");
            text = text.replace("х", "ĵ");
            text = text.replace("у", "j");
            text = text.replace("к", "k");
            text = text.replace("й", "ï");
            text = text.replace("ю", "ъу");
            text = text.replace("ы", "i");
            text = text.replace("п", "b");
            text = text.replace("ь", "");
            text = text.replace("koр", "køр");
            text = text.replace("вай", "jаï");
            text = text.replace("вообще", "вøше");
            text = text.replace("га", "ґа");
            text = text.replace("ав", "аj");
            text = text.replace("оï", "оъе");
            text = text.replace("ss", "s");
            text = text.replace("łλ", "λ");
            text = text.replace("ĵj", "ĵy");
            text = text.replace("бjдj", "бyд");
            text = text.replace("sд", "sθ");
            text = text.replace("ово", "овø");
            text = text.replace("поним", "пøним");
            text = text.replace("zθø", "zdо");
            text = text.replace("оz", "øζ");
            return text;
        }
    }

    private String Split(String text) {
        StringBuilder text2 = new StringBuilder();

        for(int i = 0; i < text.length(); ++i) {
            char char_ind = text.charAt(i);
            text2.append(char_ind);
            if (i != text.length() - 1) {
                text2.append((String)this.space_char.get());
            }
        }

        return text2.toString();
    }

    private String pastNumber(String text) {
        int length = (Integer)this.num_length.get();
        int multiplier = (int)Math.pow(10.0D, (double)length);

        int random;
        for(random = (int)(Math.random() * (double)multiplier); random.makeConcatWithConstants<invokedynamic>(random).length() < length; random = (int)(Math.random() * (double)multiplier)) {
        }

        String randstr = random.makeConcatWithConstants<invokedynamic>(random);
        if (this.numPos.get() == ChatUtils.PrintMode.Before) {
            text = "(" + randstr + ") " + text;
        } else if (this.numPos.get() == ChatUtils.PrintMode.After) {
            text = text + " (" + randstr + ")";
        }

        return text;
    }

    private String splitMam(String text) {
        String text2 = "";
        Iterator var3 = this.mamChange.entrySet().iterator();

        while(var3.hasNext()) {
            Entry<String, String> entry = (Entry)var3.next();
            String key = (String)entry.getKey();
            if (text.contains(key)) {
                String replace = (String)entry.getValue();
                text2 = text.replace(key, replace);
            }
        }

        if (text2.isEmpty()) {
            return text;
        } else {
            return text2;
        }
    }

    private String convert(String text) {
        if ((Boolean)this.translateActive.get()) {
            text = this.translit(text);
        }

        if ((Boolean)this.splitActive.get()) {
            text = this.Split(text);
        }

        if ((Boolean)this.numActive.get()) {
            text = this.pastNumber(text);
        }

        if ((Boolean)this.splitMamActive.get()) {
            text = this.splitMam(text);
        }

        return text;
    }

    @EventHandler(
        priority = 80
    )
    private void onTick(SendMessageEvent event) {
        event.message = this.convert(event.message);
    }

    public static enum translitModes {
        FULL,
        AutoZov,
        AutoHohol,
        Ruzian;

        // $FF: synthetic method
        private static ChatUtils.translitModes[] $values() {
            return new ChatUtils.translitModes[]{FULL, AutoZov, AutoHohol, Ruzian};
        }
    }

    public static enum PrintMode {
        Before,
        After;

        // $FF: synthetic method
        private static ChatUtils.PrintMode[] $values() {
            return new ChatUtils.PrintMode[]{Before, After};
        }
    }
}
