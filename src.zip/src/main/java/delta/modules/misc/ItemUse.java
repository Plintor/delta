package delta.modules.misc;

import delta.DeltaHack;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.PotionUtil;

public class ItemUse extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgBinds;
    private final Setting<Boolean> dropBottles;
    private final Setting<ItemUse.potionsType> potionPriority;
    public final Setting<Keybind> pearlBind;
    public final Setting<Keybind> fireworkBind;
    public final Setting<Keybind> silkaBind;
    public final Setting<Keybind> turtleBind;
    private int mainSlot;
    private boolean invMove;
    boolean pearlThrown;
    boolean gapUsed;
    boolean fireworkUsed;
    boolean potionUsing;
    boolean potionClicked;
    boolean bottleDropped;
    int potionSlot;
    int selectedSlot;
    int[] potionType;

    public ItemUse() {
        super(DeltaHack.Combat, "item-use", "Uses items from your inventory.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgBinds = this.settings.createGroup("Binds");
        this.dropBottles = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("drop-empty-bottles")).defaultValue(true)).build());
        this.potionPriority = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("potion-priority")).defaultValue(ItemUse.potionsType.Splash)).build());
        this.pearlBind = this.sgBinds.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("pearl")).description("Bind for throw a pearl.")).defaultValue(Keybind.none())).build());
        this.fireworkBind = this.sgBinds.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("firework")).description("Bind for use a pearl.")).defaultValue(Keybind.none())).build());
        this.silkaBind = this.sgBinds.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("strength-2")).description("Bind for a strength 2 pot.")).defaultValue(Keybind.none())).build());
        this.turtleBind = this.sgBinds.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("turtle")).description("Bind for a turtle pot.")).defaultValue(Keybind.none())).build());
        this.potionUsing = false;
        this.potionClicked = false;
    }

    public void onDeactivate() {
        this.invMove = false;
        this.mainSlot = -1;
        this.selectedSlot = -1;
        this.potionClicked = false;
        this.potionUsing = false;
        this.hold(false);
    }

    private int[] getPotionSlot(StatusEffect findEffect) {
        Item[] potItems = new Item[0];
        if (this.potionPriority.get() == ItemUse.potionsType.Default) {
            potItems = new Item[]{Items.POTION, Items.SPLASH_POTION};
        } else if (this.potionPriority.get() == ItemUse.potionsType.Splash) {
            potItems = new Item[]{Items.SPLASH_POTION, Items.POTION};
        }

        Item[] var3 = potItems;
        int var4 = potItems.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            Item checkingItem = var3[var5];

            for(int i = 0; i <= this.mc.player.getInventory().size(); ++i) {
                ItemStack item = this.mc.player.getInventory().getStack(i);
                if (item.getItem() == checkingItem) {
                    List<StatusEffectInstance> effects = PotionUtil.getPotionEffects(item);
                    if (!effects.isEmpty()) {
                        Iterator var10 = effects.iterator();

                        while(var10.hasNext()) {
                            StatusEffectInstance eff = (StatusEffectInstance)var10.next();
                            if (eff.getEffectType() == findEffect) {
                                if (checkingItem.equals(Items.SPLASH_POTION)) {
                                    return new int[]{1, i};
                                }

                                return new int[]{2, i};
                            }
                        }
                    }
                }
            }
        }

        return new int[]{0, -1};
    }

    private void hold(boolean pressed) {
        this.mc.options.useKey.setPressed(pressed);
    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.mc.currentScreen == null) {
            FindItemResult firework;
            int fireworkSlot;
            if (((Keybind)this.pearlBind.get()).isPressed()) {
                if (!this.pearlThrown) {
                    this.invMove = false;
                    this.mainSlot = this.mc.player.getInventory().selectedSlot;
                    firework = InvUtils.find(new Item[]{Items.ENDER_PEARL});
                    if (firework.found()) {
                        fireworkSlot = firework.slot();
                        InvUtils.move().from(fireworkSlot).to(this.mainSlot);
                        if (this.mc.player.getMainHandStack().getItem() == Items.ENDER_PEARL) {
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                            this.invMove = true;
                        }

                        if (this.invMove) {
                            InvUtils.move().from(this.mainSlot).to(fireworkSlot);
                        }

                        this.pearlThrown = true;
                    }
                }
            } else {
                this.pearlThrown = false;
            }

            if (((Keybind)this.fireworkBind.get()).isPressed()) {
                if (!this.fireworkUsed) {
                    this.invMove = false;
                    this.mainSlot = this.mc.player.getInventory().selectedSlot;
                    firework = InvUtils.find(new Item[]{Items.FIREWORK_ROCKET});
                    if (firework.found()) {
                        fireworkSlot = firework.slot();
                        InvUtils.move().from(fireworkSlot).to(this.mainSlot);
                        if (this.mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET) {
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                            this.invMove = true;
                        }

                        if (this.invMove) {
                            InvUtils.move().from(this.mainSlot).to(fireworkSlot);
                        }

                        this.fireworkUsed = true;
                    }
                }
            } else if (this.fireworkUsed) {
                this.fireworkUsed = false;
            }

            if (!((Keybind)this.silkaBind.get()).isPressed() && !((Keybind)this.turtleBind.get()).isPressed()) {
                this.potionType = new int[]{0, -1};
                if (this.potionUsing) {
                    this.potionUsing = false;
                    if (!this.bottleDropped) {
                        this.hold(false);
                        InvUtils.move().from(this.potionSlot).to(this.selectedSlot);
                    }
                }

                if (this.potionClicked) {
                    this.potionClicked = false;
                }
            } else {
                if (this.mainSlot != -1 && this.potionUsing && !this.bottleDropped) {
                    this.mc.player.getInventory().selectedSlot = this.mainSlot;
                }

                if (((Keybind)this.silkaBind.get()).isPressed() && ((Keybind)this.turtleBind.get()).isPressed()) {
                    return;
                }

                if (!this.potionUsing && !this.potionClicked) {
                    if (((Keybind)this.silkaBind.get()).isPressed()) {
                        this.potionType = this.getPotionSlot(StatusEffects.STRENGTH);
                    } else {
                        this.potionType = this.getPotionSlot(StatusEffects.RESISTANCE);
                    }

                    this.potionSlot = this.potionType[1];
                    if (this.potionSlot != -1) {
                        this.mainSlot = this.mc.player.getInventory().selectedSlot;
                        if (this.potionType[0] == 1) {
                            InvUtils.move().from(this.mainSlot).to(this.potionSlot);
                            this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND);
                            InvUtils.move().from(this.potionSlot).to(this.mainSlot);
                            this.potionClicked = true;
                        } else if (this.potionType[0] == 2) {
                            this.selectedSlot = this.mainSlot;
                            InvUtils.move().from(this.selectedSlot).to(this.potionSlot);
                            this.hold(true);
                            this.potionUsing = true;
                            this.bottleDropped = false;
                        }
                    }
                }

                if ((Boolean)this.dropBottles.get() && !this.bottleDropped && this.potionUsing && this.mc.player.getInventory().getMainHandStack().getItem().equals(Items.GLASS_BOTTLE)) {
                    this.hold(false);
                    this.mc.player.dropSelectedItem(true);
                    InvUtils.move().from(this.potionSlot).to(this.selectedSlot);
                    this.bottleDropped = true;
                }
            }

        }
    }

    public static enum potionsType {
        Splash,
        Default;

        // $FF: synthetic method
        private static ItemUse.potionsType[] $values() {
            return new ItemUse.potionsType[]{Splash, Default};
        }
    }
}
