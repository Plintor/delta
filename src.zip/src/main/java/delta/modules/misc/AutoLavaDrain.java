package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class AutoLavaDrain extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> range_up;
    private final Setting<Integer> range_down;
    private final Setting<Integer> range_left;
    private final Setting<Integer> range_right;
    private final Setting<Integer> range_forward;
    private final Setting<Integer> range_back;
    private final Setting<Boolean> swingHand;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> maxBlocksPerTick;
    private final Setting<Integer> delay;
    private final Pool<Mutable> blockPosPool;
    private final List<Mutable> blocks;
    private final Pool<AutoKovchegBreak.RenderBlock> renderBlockPool;
    private final List<AutoKovchegBreak.RenderBlock> renderBlocks;
    private boolean firstBlock;
    private final Mutable lastBlockPos;
    private int timer;
    private int noBlockTimer;
    private final Mutable pos1;
    private final Mutable pos2;
    private Box box;
    int maxh;
    int maxv;

    public AutoLavaDrain() {
        super(DeltaHack.Util, "auto-lava-drain", "Automatically mines blocks under lava in certain order.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.range_up = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("up")).description("The break range.")).defaultValue(1)).min(0).build());
        this.range_down = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("down")).description("The break range.")).defaultValue(1)).min(0).build());
        this.range_left = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("left")).description("The break range.")).defaultValue(1)).min(0).build());
        this.range_right = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("right")).description("The break range.")).defaultValue(1)).min(0).build());
        this.range_forward = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("forward")).description("The break range.")).defaultValue(1)).min(0).build());
        this.range_back = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("back")).description("The break range.")).defaultValue(1)).min(0).build());
        this.swingHand = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("swing-hand")).description("Swing hand client side.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Gulag moment")).defaultValue(false)).build());
        this.maxBlocksPerTick = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("max-blocks-per-tick")).description("Maximum blocks to try to break per tick. Useful when insta mining.")).defaultValue(1)).min(1).sliderRange(1, 6).build());
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("Delay in ticks between breaking blocks.")).defaultValue(0)).build());
        this.blockPosPool = new Pool(Mutable::new);
        this.blocks = new ArrayList();
        this.renderBlockPool = new Pool(AutoKovchegBreak.RenderBlock::new);
        this.renderBlocks = new ArrayList();
        this.lastBlockPos = new Mutable();
        this.pos1 = new Mutable();
        this.pos2 = new Mutable();
        this.maxh = 0;
        this.maxv = 0;
    }

    public void onActivate() {
        this.firstBlock = true;
        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            AutoKovchegBreak.RenderBlock renderBlock = (AutoKovchegBreak.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
        this.timer = 0;
        this.noBlockTimer = 0;
    }

    public void onDeactivate() {
        Iterator var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            AutoKovchegBreak.RenderBlock renderBlock = (AutoKovchegBreak.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    @EventHandler
    private void onTick(Pre event) {
        this.renderBlocks.forEach(AutoKovchegBreak.RenderBlock::tick);
        this.renderBlocks.removeIf((renderBlock) -> {
            return renderBlock.ticks <= 0;
        });
        if (this.timer > 0) {
            --this.timer;
        } else {
            double pX = (double)EntityUtil.playerPos(this.mc.player).getX();
            double pY = (double)EntityUtil.playerPos(this.mc.player).getY();
            double pZ = (double)EntityUtil.playerPos(this.mc.player).getZ();
            int direction = Math.round(this.mc.player.getRotationClient().y % 360.0F / 90.0F);
            direction = Math.floorMod(direction, 4);
            this.pos1.set(pX - (double)(Integer)this.range_forward.get(), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ - (double)(Integer)this.range_right.get());
            this.pos2.set(pX + (double)(Integer)this.range_back.get() + 1.0D, Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ + (double)(Integer)this.range_left.get() + 1.0D);
            double pX_;
            double pZ_;
            if (direction == 2) {
                pX_ = pX + 1.0D;
                pZ_ = pZ + 1.0D;
                this.pos1.set(pX_ - (double)((Integer)this.range_left.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ_ - (double)((Integer)this.range_forward.get() + 1));
                this.pos2.set(pX_ + (double)(Integer)this.range_right.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ_ + (double)(Integer)this.range_back.get());
            } else if (direction == 3) {
                pX_ = pX + 1.0D;
                this.pos1.set(pX_ - (double)((Integer)this.range_back.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ - (double)(Integer)this.range_left.get());
                this.pos2.set(pX_ + (double)(Integer)this.range_forward.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ + (double)(Integer)this.range_right.get() + 1.0D);
            } else if (direction == 0) {
                pZ_ = pZ + 1.0D;
                pX_ = pX + 1.0D;
                this.pos1.set(pX_ - (double)((Integer)this.range_right.get() + 1), Math.ceil(pY) - (double)(Integer)this.range_down.get(), pZ_ - (double)((Integer)this.range_back.get() + 1));
                this.pos2.set(pX_ + (double)(Integer)this.range_left.get(), Math.ceil(pY + (double)(Integer)this.range_up.get() + 1.0D), pZ_ + (double)(Integer)this.range_forward.get());
            }

            this.maxh = 1 + Math.max(Math.max(Math.max((Integer)this.range_back.get(), (Integer)this.range_right.get()), (Integer)this.range_forward.get()), (Integer)this.range_left.get());
            this.maxv = 1 + Math.max((Integer)this.range_up.get(), (Integer)this.range_down.get());
            this.box = new Box(this.pos1, this.pos2);
            BlockIterator.register(Math.max(5, this.maxh), Math.max(5, this.maxv), (blockPos, blockState) -> {
                if (BlockUtils.canBreak(blockPos, blockState) && this.box.contains(Vec3d.ofCenter(blockPos)) && BlockUtil.isWater(blockPos.down())) {
                    if (BlockUtil.isLava(blockPos.up()) && !BlockUtil.isWater(blockPos.north()) && !BlockUtil.isWater(blockPos.south()) && !BlockUtil.isWater(blockPos.west()) && !BlockUtil.isWater(blockPos.east())) {
                        this.blocks.add(((Mutable)this.blockPosPool.get()).set(blockPos));
                    }
                }
            });
            BlockIterator.after(() -> {
                this.blocks.sort(Comparator.comparingDouble((value) -> {
                    return Utils.squaredDistance(pX, pY, pZ, (double)value.getX() + 0.5D, (double)value.getY() + 0.5D, (double)value.getZ() + 0.5D);
                }));
                if (this.blocks.isEmpty()) {
                    if (this.noBlockTimer++ >= (Integer)this.delay.get()) {
                        this.firstBlock = true;
                    }

                } else {
                    this.noBlockTimer = 0;
                    if (!this.firstBlock && !this.lastBlockPos.equals(this.blocks.get(0))) {
                        this.timer = (Integer)this.delay.get();
                        this.firstBlock = false;
                        this.lastBlockPos.set((Vec3i)this.blocks.get(0));
                        if (this.timer > 0) {
                            return;
                        }
                    }

                    int count = 0;

                    Iterator var8;
                    for(var8 = this.blocks.iterator(); var8.hasNext(); ++count) {
                        BlockPos block = (BlockPos)var8.next();
                        if (count >= (Integer)this.maxBlocksPerTick.get()) {
                            break;
                        }

                        if ((Boolean)this.rotate.get()) {
                            Rotations.rotate(Rotations.getYaw(block), Rotations.getPitch(block));
                        }

                        BlockUtils.breakBlock(block, (Boolean)this.swingHand.get());
                        this.renderBlocks.add(((AutoKovchegBreak.RenderBlock)this.renderBlockPool.get()).set(block));
                        this.lastBlockPos.set(block);
                    }

                    this.firstBlock = false;
                    var8 = this.blocks.iterator();

                    while(var8.hasNext()) {
                        Mutable blockPos = (Mutable)var8.next();
                        this.blockPosPool.free(blockPos);
                    }

                    this.blocks.clear();
                }
            });
        }
    }
}
