package delta.modules.misc.AutoL;

import delta.DeltaHack;
import delta.utils.ConfigManager;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;

public class ALutility {
   private static final String path = ConfigManager.getPath();
   private static final String cfgName = "accounts";
   private static final String folderName = "AutoLogin";
   private static final String fullPath;
   private static String server;
   private static String nickname;
   private static String password;
   static Map<String, String[]> config;

   public static void updateCfg(String server, String nickname, String password) {
      config = ConfigManager.getParseConfig(fullPath, "accounts", "AutoLogin");
      if (server != null) {
         boolean newVal = false;
         if (config == null) {
            ConfigManager.create("accounts", "AutoLogin");
            config = ConfigManager.getParseConfig(fullPath, "accounts", "AutoLogin");
         } else {
            String[] serverValues;
            if (!config.containsKey(server)) {
               serverValues = new String[1];
               config.put(server, serverValues);
               newVal = true;
            }

            serverValues = (String[])config.get(server);
            if (serverValues != null) {
               DeltaHack.Log(Arrays.toString(serverValues));
               if (!Arrays.asList(serverValues).contains(nickname + ":" + password)) {
                  config.remove(server);
                  String[] newValues;
                  String[] serverValues2;
                  if (password != null) {
                     int newAccIndex = serverValues.length - 1;
                     byte hueta = 1;
                     if (newVal) {
                        hueta = 0;
                     }

                     serverValues2 = new String[newAccIndex + 1 + hueta];
                     System.arraycopy(serverValues, 0, serverValues2, 0, newAccIndex + 1);
                     if (!newVal) {
                        ++newAccIndex;
                     }

                     serverValues2[newAccIndex] = nickname + ":" + password;
                     newValues = serverValues2;
                  } else {
                     String[] serverValues2 = new String[serverValues.length - 1];
                     int c = 0;
                     serverValues2 = serverValues;
                     int var9 = serverValues.length;

                     for(int var10 = 0; var10 < var9; ++var10) {
                        String serverValue = serverValues2[var10];
                        if (serverValue != null) {
                           String name = serverValue.split(":")[0];
                           if (name.equals(nickname)) {
                              DeltaHack.Log(serverValue);
                           } else if (c < serverValues2.length) {
                              serverValues2[c] = serverValue;
                              ++c;
                           }
                        }
                     }

                     DeltaHack.Log(String.valueOf(serverValues2.length));
                     DeltaHack.Log(Arrays.toString(serverValues2));
                     DeltaHack.Log(String.valueOf(serverValues.length));
                     DeltaHack.Log(Arrays.toString(serverValues));
                     newValues = serverValues2;
                  }

                  if (newValues.length > 0) {
                     config.put(server, newValues);
                  }

                  ConfigManager.writeParse(fullPath, config);
               }
            }
         }
      }
   }

   public static Map<String, String[]> getConfig() {
      return config;
   }

   public static void fillWidget(GuiTheme theme, WVerticalList list) {
      password = "";
      nickname = "";
      ALutility.server = "";
      WSection accountAdd = (WSection)list.add(theme.section("Add account")).expandX().widget();
      WTable table = (WTable)accountAdd.add(theme.table()).expandX().widget();
      table.add(theme.label("Server"));
      table.add(theme.label("Nickname"));
      table.add(theme.label("Password"));
      table.row();
      WTextBox getServer = (WTextBox)table.add(theme.textBox("")).minWidth(100.0D).expandX().widget();
      getServer.action = () -> {
         server = getServer.get();
      };
      getServer.tooltip = "";
      WTextBox getName = (WTextBox)table.add(theme.textBox("")).minWidth(100.0D).expandX().widget();
      getName.action = () -> {
         nickname = getName.get();
      };
      getName.tooltip = "";
      WTextBox getPassword = (WTextBox)table.add(theme.textBox("")).minWidth(100.0D).expandX().widget();
      getPassword.action = () -> {
         password = getPassword.get();
      };
      getPassword.tooltip = "";
      WPlus save = (WPlus)table.add(theme.plus()).widget();
      save.action = () -> {
         list.clear();
         updateCfg(server, nickname, password);
         getServer.set("");
         getName.set("");
         getPassword.set("");
         fillWidget(theme, list);
      };
      WSection accounts = (WSection)list.add(theme.section("Accounts")).expandX().widget();
      WTable accsTable = (WTable)accounts.add(theme.table()).expandX().widget();
      accsTable.add(theme.label("Server"));
      accsTable.add(theme.label("Nickname"));
      accsTable.add(theme.label("Password"));
      accsTable.row();
      if (config != null) {
         Iterator var10 = config.entrySet().iterator();

         while(var10.hasNext()) {
            Entry<String, String[]> entry = (Entry)var10.next();
            String server = (String)entry.getKey();
            String[] Values = (String[])entry.getValue();
            String[] var14 = Values;
            int var15 = Values.length;

            for(int var16 = 0; var16 < var15; ++var16) {
               String val = var14[var16];
               String[] data = val.split(":");
               if (data.length >= 2) {
                  String pass = data[1];
                  String hidePass = "";

                  for(int i = 0; i < pass.length(); ++i) {
                     hidePass = hidePass + "*";
                     if (i >= 25) {
                        hidePass = hidePass + "...";
                        break;
                     }
                  }

                  accsTable.add(theme.label(server + "   "));
                  accsTable.add(theme.label(data[0] + "   "));
                  accsTable.add(theme.label(hidePass + "   "));
                  WMinus remove = (WMinus)accsTable.add(theme.minus()).widget();
                  remove.action = () -> {
                     list.clear();
                     updateCfg(server, data[0], (String)null);
                     fillWidget(theme, list);
                  };
                  accsTable.row();
               }
            }
         }
      }

   }

   static {
      fullPath = path + "\\AutoLogin\\accounts.cfg";
      server = "";
      nickname = "";
      password = "";
   }
}
