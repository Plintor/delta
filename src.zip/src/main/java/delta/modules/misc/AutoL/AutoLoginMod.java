package delta.modules.misc.AutoL;

import delta.DeltaHack;
import delta.utils.PlayerUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoLoginMod extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<String> command;
    private final Setting<Boolean> gulagMoment;
    private final Setting<Integer> gulagDelay;
    private final Setting<Integer> speed;
    private final Setting<Boolean> notify;
    private boolean logged;
    private boolean shouldGulag;
    private int timer;

    public AutoLoginMod() {
        super(DeltaHack.Misc, "auto-login", "Automatically login on server.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.command = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("command")).description("Command for login.")).defaultValue("login")).build());
        this.gulagMoment = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("gulag-enter")).description("-")).defaultValue(false)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("gulag-delay")).description("-")).defaultValue(3)).range(1, 200).sliderRange(1, 200);
        Setting var10003 = this.gulagMoment;
        Objects.requireNonNull(var10003);
        this.gulagDelay = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        var10002 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("gulag-speed")).description("-")).defaultValue(20)).range(1, 30).sliderRange(1, 30);
        var10003 = this.gulagMoment;
        Objects.requireNonNull(var10003);
        this.speed = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var10002.visible(var10003::get)).build());
        this.notify = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("debug")).description("-")).defaultValue(false)).build());
        this.logged = false;
        this.shouldGulag = false;
        this.timer = 0;
        ALutility.updateCfg((String)null, (String)null, (String)null);
    }

    public void onDeactivate() {
        this.shouldGulag = false;
        this.logged = false;
        this.timer = 0;
    }

    @EventHandler(
        priority = -200
    )
    private void onMessageReceive(ReceiveMessageEvent event) {
        if (this.mc.world != null && this.mc.player != null & !this.logged) {
            String msg = event.getMessage().getString();
            if (!msg.startsWith(">") && msg.contains("login ")) {
                if ((Boolean)this.notify.get()) {
                    this.info("LOGIN REQUEST RECEIVED", new Object[0]);
                }

                if (this.mc.getCurrentServerEntry() != null) {
                    String password = this.getPassword(this.mc.player.getEntityName(), this.mc.getCurrentServerEntry().address);
                    if (!password.equals("")) {
                        this.login(password);
                        if ((Boolean)this.notify.get()) {
                            this.info("success!", new Object[0]);
                        }

                        if ((Boolean)this.gulagMoment.get()) {
                            this.shouldGulag = true;
                        }
                    }

                    this.logged = true;
                }
            }
        }

    }

    @EventHandler(
        priority = -200
    )
    public void onTick(Pre event) {
        if ((Boolean)this.gulagMoment.get() && this.shouldGulag) {
            if ((Boolean)this.notify.get()) {
                this.info("ShouldGulag", new Object[0]);
            }

            if (this.timer >= (Integer)this.gulagDelay.get()) {
                PlayerUtil.teleport(5.0D, 5.0D, -9.0D);
                this.mc.player.setVelocity((double)(-(Integer)this.speed.get()), 1.0D, 0.0D);
                this.shouldGulag = false;
            } else {
                ++this.timer;
            }
        }

    }

    @EventHandler(
        priority = -200
    )
    private void onGameLeft(GameLeftEvent event) {
        this.logged = false;
        this.shouldGulag = false;
    }

    public WWidget getWidget(GuiTheme theme) {
        WVerticalList list = theme.verticalList();
        ALutility.fillWidget(theme, list);
        return list;
    }

    private String getPassword(String nick, String server) {
        Map<String, String[]> accs = ALutility.getConfig();
        if (accs == null) {
            return "";
        } else {
            Iterator var4 = accs.entrySet().iterator();

            while(true) {
                String key;
                String[] Values;
                do {
                    if (!var4.hasNext()) {
                        return "";
                    }

                    Entry<String, String[]> entry = (Entry)var4.next();
                    key = (String)entry.getKey();
                    Values = (String[])entry.getValue();
                } while(!server.equals(key));

                String[] var8 = Values;
                int var9 = Values.length;

                for(int var10 = 0; var10 < var9; ++var10) {
                    String val = var8[var10];
                    String[] userData = val.split(":");
                    String username = userData[0];
                    String password = userData[1];
                    if (nick.equals(username)) {
                        return password;
                    }
                }
            }
        }
    }

    private void login(String pass) {
        ClientPlayerEntity var10000 = this.mc.player;
        String var10001 = ((String)this.command.get()).replace("/", "");
        var10000.sendCommand(var10001 + " " + pass);
    }
}
