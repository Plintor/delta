package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.BlockUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;

public class KovchegEsp extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final Setting<Integer> horizontalRadius;
    private final Setting<Integer> verticalRadius;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final Pool<Mutable> kovchegPool;
    private final List<Mutable> kovchegBlockList;

    public KovchegEsp() {
        super(DeltaHack.Util, "kovcheg-esp", "shows kovcheg positions.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("Render");
        this.horizontalRadius = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("horizontal-radius")).description("Horizontal radius in which to search for holes.")).defaultValue(5)).range(0, 32).sliderRange(0, 32).build());
        this.verticalRadius = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("vertical-radius")).description("Vertical radius in which to search for holes.")).defaultValue(5)).range(0, 32).sliderRange(0, 32).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Sides)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(0, 255, 40, 15))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(0, 200, 120, 255))).build());
        this.kovchegPool = new Pool(Mutable::new);
        this.kovchegBlockList = new ArrayList();
    }

    @EventHandler
    private void onTickPre(Pre event) {
        Iterator var2 = this.kovchegBlockList.iterator();

        while(var2.hasNext()) {
            Mutable blockPos = (Mutable)var2.next();
            this.kovchegPool.free(blockPos);
        }

        this.kovchegBlockList.clear();
        BlockIterator.register((Integer)this.horizontalRadius.get(), (Integer)this.verticalRadius.get(), (blockPosx, blockState) -> {
            if (blockState.isOf(Blocks.WATER) && blockState.getFluidState().getLevel() > 7 && BlockUtil.isFullBlock(blockPosx.down())) {
                this.kovchegBlockList.add(((Mutable)this.kovchegPool.get()).set(blockPosx));
            }

        });
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Iterator var2 = this.kovchegBlockList.iterator();

        while(var2.hasNext()) {
            BlockPos pos = (BlockPos)var2.next();
            event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }

    }
}
