package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.EntityUtil;
import delta.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BlockListSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.item.ChorusFruitItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.s2c.play.DeathMessageS2CPacket;
import net.minecraft.util.math.BlockPos.Mutable;

public class Platform extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgPlacing;
    private final SettingGroup sgForce;
    private final SettingGroup sgToggle;
    private final SettingGroup sgRender;
    private final Setting<List<Block>> blocks;
    private final Setting<List<Block>> fallbackBlocks;
    private final Setting<Integer> platformRange;
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> doubleHeight;
    private final Setting<Boolean> onlyGround;
    private final Setting<Boolean> cancelMove;
    private final Setting<Boolean> toggleModules;
    private final Setting<Boolean> toggleBack;
    private final Setting<List<Module>> modules;
    private final Setting<WorldUtils.SwitchMode> switchMode;
    private final Setting<Boolean> switchBack;
    private final Setting<WorldUtils.PlaceMode> placeMode;
    private final Setting<Boolean> airPlace;
    private final Setting<Boolean> onlyAirPlace;
    private final Setting<WorldUtils.AirPlaceDirection> airPlaceDirection;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> rotationPrio;
    private final Setting<Keybind> doubleHeightKeybind;
    private final Setting<Boolean> toggleOnYChange;
    private final Setting<Boolean> toggleOnComplete;
    private final Setting<Boolean> onPearl;
    private final Setting<Boolean> onChorus;
    private final Setting<Boolean> onDeath;
    private final Setting<Boolean> renderSwing;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> placeColor;
    private final Setting<SettingColor> placeLineColor;
    private final Setting<Integer> renderTime;
    private final Setting<Integer> fadeAmount;
    private BlockPos playerPos;
    private int ticksPassed;
    private int blocksPlaced;
    public boolean cancelJump;
    public ArrayList<Module> toActivate;
    private final Mutable renderPos;
    private final Pool<Platform.RenderBlock> renderBlockPool;
    private final List<Platform.RenderBlock> renderBlocks;

    public Platform() {
        super(DeltaHack.Misc, "platform", "Platforms around your feet to make building easier.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgPlacing = this.settings.createGroup("Placing");
        this.sgForce = this.settings.createGroup("Force Keybinds");
        this.sgToggle = this.settings.createGroup("Toggle Modes");
        this.sgRender = this.settings.createGroup("Render");
        this.blocks = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("primary-blocks")).description("What blocks to use for VHSurround+.")).defaultValue(new Block[]{Blocks.OBSIDIAN}).build());
        this.fallbackBlocks = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("fallback-blocks")).description("What blocks to use for VHSurround+ if no target block is found.")).defaultValue(new Block[]{Blocks.CRYING_OBSIDIAN}).build());
        this.platformRange = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("platform-range")).description("The range to platform around you.")).defaultValue(2)).range(1, 5).sliderRange(1, 5).build());
        this.delay = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("delay")).description("Tick delay between block placements.")).defaultValue(2)).range(0, 20).sliderRange(0, 20).build());
        this.blocksPerTick = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("blocks-per-tick")).description("Blocks placed per delay interval.")).defaultValue(3)).range(1, 20).sliderRange(1, 20).build());
        this.doubleHeight = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("double-height")).description("Places below of the original surround blocks to prevent people from face-placing you.")).defaultValue(false)).build());
        this.onlyGround = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Will only try to place if you are on the ground.")).defaultValue(false)).build());
        this.cancelMove = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("cancel-jump")).description("Prevents you from jumping.")).defaultValue(false)).build());
        this.toggleModules = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-modules")).description("Turn off other modules when surround is activated.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-back-on")).description("Turn the other modules back on when surround is deactivated.")).defaultValue(false);
        Setting var10003 = this.toggleModules;
        Objects.requireNonNull(var10003);
        this.toggleBack = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.ModuleListSetting.Builder var1 = (meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)((meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)(new meteordevelopment.meteorclient.settings.ModuleListSetting.Builder()).name("modules")).description("Which modules to disable on activation.");
        var10003 = this.toggleModules;
        Objects.requireNonNull(var10003);
        this.modules = var10001.add(((meteordevelopment.meteorclient.settings.ModuleListSetting.Builder)var1.visible(var10003::get)).build());
        this.switchMode = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("switch-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.SwitchMode.Both)).build());
        this.switchBack = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("switch-back")).description("Switches back to your original slot after placing.")).defaultValue(true)).build());
        this.placeMode = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("place-mode")).description("How to switch to your target block.")).defaultValue(WorldUtils.PlaceMode.Both)).build());
        this.airPlace = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("air-place")).description("Whether to place blocks mid air or not.")).defaultValue(true)).build());
        var10001 = this.sgPlacing;
        var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-air-place")).description("Forces you to only airplace to help with stricter rotations.")).defaultValue(false);
        var10003 = this.airPlace;
        Objects.requireNonNull(var10003);
        this.onlyAirPlace = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        var10001 = this.sgPlacing;
        meteordevelopment.meteorclient.settings.EnumSetting.Builder var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("air-place-direction")).description("Side to try to place at when you are trying to air place.")).defaultValue(WorldUtils.AirPlaceDirection.Down);
        var10003 = this.airPlace;
        Objects.requireNonNull(var10003);
        this.airPlaceDirection = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        this.rotate = this.sgPlacing.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Whether to face towards the block you are placing or not.")).defaultValue(false)).build());
        var10001 = this.sgPlacing;
        meteordevelopment.meteorclient.settings.IntSetting.Builder var3 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("rotation-priority")).description("Rotation priority for VHSurround+.")).defaultValue(97)).sliderRange(0, 200);
        var10003 = this.rotate;
        Objects.requireNonNull(var10003);
        this.rotationPrio = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var3.visible(var10003::get)).build());
        this.doubleHeightKeybind = this.sgForce.add(((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)((meteordevelopment.meteorclient.settings.KeybindSetting.Builder)(new meteordevelopment.meteorclient.settings.KeybindSetting.Builder()).name("double-height-keybind")).description("Turns on double height.")).defaultValue(Keybind.none())).build());
        this.toggleOnYChange = this.sgToggle.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-on-y-change")).description("Automatically disables when your y level (step, jumping, etc).")).defaultValue(true)).build());
        this.toggleOnComplete = this.sgToggle.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("toggle-on-complete")).description("Automatically disables when all blocks are placed.")).defaultValue(false)).build());
        this.onPearl = this.sgToggle.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("disable-on-pearl")).description("Automatically disables when you throw a pearl (work if u use middle/bind click extra).")).defaultValue(true)).build());
        this.onChorus = this.sgToggle.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("disable-on-chorus")).description("Automatically disables after you eat a chorus.")).defaultValue(true)).build());
        this.onDeath = this.sgToggle.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("disable-on-death")).description("Automatically disables after you die.")).defaultValue(true)).build());
        this.renderSwing = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render-swing")).description("Renders hand swing when trying to place a block.")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders a block overlay where the block will be placed.")).defaultValue(true)).build());
        var10001 = this.sgRender;
        var2 = (meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.shapeMode = var10001.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)var2.visible(var10003::get)).build());
        this.placeColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("place-side-color")).description("The color of placing blocks.")).defaultValue(new SettingColor(255, 255, 255, 25))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.render.get();
        })).build());
        this.placeLineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("place-line-color")).description("The color of placing line.")).defaultValue(new SettingColor(255, 255, 255, 150))).visible(() -> {
            return this.shapeMode.get() != ShapeMode.Sides && (Boolean)this.render.get();
        })).build());
        var10001 = this.sgRender;
        var3 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("render-time")).description("Tick duration for rendering placing.")).defaultValue(8)).range(0, 40).sliderRange(0, 40);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.renderTime = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var3.visible(var10003::get)).build());
        var10001 = this.sgRender;
        var3 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("fade-amount")).description("How strong the fade should be.")).defaultValue(8)).range(0, 100).sliderRange(0, 100);
        var10003 = this.render;
        Objects.requireNonNull(var10003);
        this.fadeAmount = var10001.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var3.visible(var10003::get)).build());
        this.renderPos = new Mutable();
        this.renderBlockPool = new Pool(() -> {
            return new Platform.RenderBlock();
        });
        this.renderBlocks = new ArrayList();
    }

    public void onActivate() {
        this.ticksPassed = 0;
        this.blocksPlaced = 0;
        this.toActivate = new ArrayList();
        this.playerPos = EntityUtil.playerPos(this.mc.player);
        Iterator var1;
        if ((Boolean)this.toggleModules.get() && !((List)this.modules.get()).isEmpty() && this.mc.world != null && this.mc.player != null) {
            var1 = ((List)this.modules.get()).iterator();

            while(var1.hasNext()) {
                Module module = (Module)var1.next();
                if (module.isActive()) {
                    module.toggle();
                    this.toActivate.add(module);
                }
            }
        }

        var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            Platform.RenderBlock renderBlock = (Platform.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    public void onDeactivate() {
        Iterator var1;
        if ((Boolean)this.toggleBack.get() && !this.toActivate.isEmpty() && this.mc.world != null && this.mc.player != null) {
            var1 = this.toActivate.iterator();

            while(var1.hasNext()) {
                Module module = (Module)var1.next();
                if (!module.isActive()) {
                    module.toggle();
                }
            }
        }

        var1 = this.renderBlocks.iterator();

        while(var1.hasNext()) {
            Platform.RenderBlock renderBlock = (Platform.RenderBlock)var1.next();
            this.renderBlockPool.free(renderBlock);
        }

        this.renderBlocks.clear();
    }

    @EventHandler
    public void onTick(Pre event) {
        if (this.ticksPassed >= 0) {
            --this.ticksPassed;
        } else {
            this.ticksPassed = (Integer)this.delay.get();
            this.blocksPlaced = 0;
        }

        this.playerPos = EntityUtil.playerPos(this.mc.player);
        if ((Boolean)this.toggleOnYChange.get() && this.mc.player.prevY < this.mc.player.getY()) {
            this.toggle();
        } else if ((Boolean)this.toggleOnComplete.get() && this.allPlaced(this.placePos())) {
            this.toggle();
        } else if (!(Boolean)this.onlyGround.get() || this.mc.player.isOnGround()) {
            if (this.getTargetBlock().found()) {
                this.cancelJump = (Boolean)this.cancelMove.get();
                if (this.ticksPassed <= 0) {
                    Iterator var2 = this.centerPos().iterator();

                    BlockPos pos;
                    while(var2.hasNext()) {
                        pos = (BlockPos)var2.next();
                        if (this.blocksPlaced >= (Integer)this.blocksPerTick.get()) {
                            return;
                        }

                        if (WorldUtils.place(pos, this.getTargetBlock(), (Boolean)this.rotate.get(), (Integer)this.rotationPrio.get(), (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), (Boolean)this.onlyAirPlace.get(), (WorldUtils.AirPlaceDirection)this.airPlaceDirection.get(), (Boolean)this.renderSwing.get(), true, (Boolean)this.switchBack.get())) {
                            this.renderBlocks.add(((Platform.RenderBlock)this.renderBlockPool.get()).set(pos));
                            ++this.blocksPlaced;
                        }
                    }

                    var2 = this.extraPos().iterator();

                    while(var2.hasNext()) {
                        pos = (BlockPos)var2.next();
                        if (this.blocksPlaced >= (Integer)this.blocksPerTick.get()) {
                            return;
                        }

                        if (WorldUtils.place(pos, this.getTargetBlock(), (Boolean)this.rotate.get(), (Integer)this.rotationPrio.get(), (WorldUtils.SwitchMode)this.switchMode.get(), (WorldUtils.PlaceMode)this.placeMode.get(), (Boolean)this.onlyAirPlace.get(), (WorldUtils.AirPlaceDirection)this.airPlaceDirection.get(), (Boolean)this.renderSwing.get(), true, (Boolean)this.switchBack.get())) {
                            this.renderBlocks.add(((Platform.RenderBlock)this.renderBlockPool.get()).set(pos));
                            ++this.blocksPlaced;
                        }
                    }
                }

                this.renderBlocks.forEach(Platform.RenderBlock::tick);
                this.renderBlocks.removeIf((renderBlock) -> {
                    return renderBlock.ticks <= 0;
                });
            }
        }
    }

    private List<BlockPos> placePos() {
        List<BlockPos> pos = new ArrayList();
        Iterator var2 = this.centerPos().iterator();

        BlockPos extraPos;
        while(var2.hasNext()) {
            extraPos = (BlockPos)var2.next();
            this.add(pos, extraPos);
        }

        var2 = this.extraPos().iterator();

        while(var2.hasNext()) {
            extraPos = (BlockPos)var2.next();
            this.add(pos, extraPos);
        }

        return pos;
    }

    private List<BlockPos> centerPos() {
        List<BlockPos> pos = new ArrayList();

        for(int x = -(Integer)this.platformRange.get(); x <= (Integer)this.platformRange.get(); ++x) {
            for(int z = -(Integer)this.platformRange.get(); z <= (Integer)this.platformRange.get(); ++z) {
                pos.add(new BlockPos(this.playerPos.getX() + x, this.playerPos.getY() - 1, this.playerPos.getZ() + z));
            }
        }

        return pos;
    }

    private List<BlockPos> extraPos() {
        List<BlockPos> pos = new ArrayList();
        if ((Boolean)this.doubleHeight.get() || ((Keybind)this.doubleHeightKeybind.get()).isPressed()) {
            Iterator var2 = this.centerPos().iterator();

            while(var2.hasNext()) {
                BlockPos centerPos = (BlockPos)var2.next();
                this.add(pos, centerPos.down());
            }
        }

        return pos;
    }

    private void add(List<BlockPos> list, BlockPos pos) {
        if (this.mc.world.getBlockState(pos).isAir() && this.allAir(pos.north(), pos.east(), pos.south(), pos.west(), pos.up(), pos.down()) && !(Boolean)this.airPlace.get()) {
            list.add(pos.down());
        }

        list.add(pos);
    }

    private boolean allAir(BlockPos... pos) {
        return Arrays.stream(pos).allMatch((blockPos) -> {
            return this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable();
        });
    }

    private boolean anyAir(BlockPos... pos) {
        return Arrays.stream(pos).anyMatch((blockPos) -> {
            return this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable();
        });
    }

    private FindItemResult getTargetBlock() {
        return !InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        }).found() ? InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.fallbackBlocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        }) : InvUtils.findInHotbar((itemStack) -> {
            return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
        });
    }

    @EventHandler
    private void onPacketReceive(Receive event) {
        Packet var3 = event.packet;
        if (var3 instanceof DeathMessageS2CPacket) {
            DeathMessageS2CPacket packet = (DeathMessageS2CPacket)var3;
            Entity entity = this.mc.world.getEntityById(packet.getEntityId());
            if (entity == this.mc.player && (Boolean)this.onDeath.get()) {
                this.toggle();
            }
        }

    }

    @EventHandler
    private void onPacketSend(Send event) {
        if (event.packet instanceof PlayerInteractItemC2SPacket && (this.mc.player.getOffHandStack().getItem() instanceof EnderPearlItem || this.mc.player.getMainHandStack().getItem() instanceof EnderPearlItem) && (Boolean)this.onPearl.get()) {
            this.toggle();
        }

    }

    @EventHandler
    private void onFinishUsingItem(FinishUsingItemEvent event) {
        if (event.itemStack.getItem() instanceof ChorusFruitItem && (Boolean)this.onChorus.get()) {
            this.toggle();
        }

    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get()) {
            Iterator var2 = this.placePos().iterator();

            while(var2.hasNext()) {
                BlockPos pos = (BlockPos)var2.next();
                this.renderPos.set(pos);
                this.renderBlocks.sort(Comparator.comparingInt((o) -> {
                    return -o.ticks;
                }));
                this.renderBlocks.forEach((renderBlock) -> {
                    renderBlock.render(event, (Color)this.placeColor.get(), (Color)this.placeLineColor.get(), (ShapeMode)this.shapeMode.get());
                });
            }
        }

    }

    private boolean allPlaced(List<BlockPos> posList) {
        Iterator var2 = posList.iterator();

        BlockPos pos;
        do {
            if (!var2.hasNext()) {
                return true;
            }

            pos = (BlockPos)var2.next();
        } while(this.mc.world.getBlockState(pos).getBlock() != Blocks.AIR);

        return false;
    }

    public class RenderBlock {
        public Mutable pos = new Mutable();
        public int ticks;

        public Platform.RenderBlock set(BlockPos blockPos) {
            this.pos.set(blockPos);
            this.ticks = (Integer)Platform.this.renderTime.get();
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
            int preSideA = sides.a;
            int preLineA = lines.a;
            sides.a = (int)((double)sides.a * ((double)this.ticks / (double)(Integer)Platform.this.fadeAmount.get()));
            lines.a = (int)((double)lines.a * ((double)this.ticks / (double)(Integer)Platform.this.fadeAmount.get()));
            event.renderer.box(this.pos, sides, lines, shapeMode, 0);
            sides.a = preSideA;
            lines.a = preLineA;
        }
    }
}
