package delta.modules.misc;

import delta.DeltaHack;
import java.util.Objects;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Direction;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class InstaMinePlus extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgDelay;
    private final SettingGroup sgRender;
    private final Setting<Boolean> debug;
    private final Setting<Boolean> pick;
    private final Setting<Boolean> ironPick;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> bypassDelay;
    private final Setting<Integer> bypassIterations;
    private final Setting<Integer> normalDelay;
    private final Setting<Integer> normalIterations;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private int ticksPassed;
    private int ticks;
    private int iteration;
    private boolean updated;
    private final Mutable blockPos;
    private Direction direction;

    public InstaMinePlus() {
        super(DeltaHack.Autist, "insta-mine+", "Attempts to bypass instant mine.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgDelay = this.settings.createGroup("Delays");
        this.sgRender = this.settings.createGroup("Render");
        this.debug = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("debug")).defaultValue(false)).build());
        this.pick = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("only-pick")).description("Only tries to mine the block if you are holding a pickaxe.")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("iron-pick")).description("Allows iron pickaxe to count as a pickaxe for instamine.")).defaultValue(false);
        Setting var10003 = this.pick;
        Objects.requireNonNull(var10003);
        this.ironPick = var10001.add(((Builder)var10002.visible(var10003::get)).build());
        this.rotate = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rotate")).description("Faces the blocks being mined server side.")).defaultValue(true)).build());
        this.bypassDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("bypass delay")).description("The delay between breaks for bypass mode.")).defaultValue(4)).min(1).sliderMax(100).build());
        this.bypassIterations = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("bypass iterations")).description("The amount of times bypass mode should happen.")).defaultValue(0)).min(0).sliderMax(20).build());
        this.normalDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("normal delay")).description("The delay between breaks for normal mode.")).defaultValue(41)).min(1).sliderMax(100).build());
        this.normalIterations = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("normal iterations")).description("The amount of times bypass mode should happen.")).defaultValue(1)).min(0).sliderMax(20).build());
        this.render = this.sgRender.add(((Builder)((Builder)((Builder)(new Builder()).name("render")).description("Renders a block overlay on the block being broken.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
        this.blockPos = new Mutable(0, -1, 0);
    }

    public void onActivate() {
        this.ticksPassed = 0;
        this.ticks = 0;
        this.blockPos.set(0, -1, 0);
        this.iteration = 0;
        this.updated = false;
    }

    @EventHandler
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        this.direction = event.direction;
        this.blockPos.set(event.blockPos);
    }

    private int getDelay() {
        if ((Integer)this.bypassIterations.get() >= this.iteration && this.iteration > 0) {
            if ((Boolean)this.debug.get()) {
                this.warning("Starting bypass iterations", new Object[0]);
            }

            return (Integer)this.bypassDelay.get();
        } else if ((Integer)this.normalIterations.get() >= this.iteration && this.iteration > (Integer)this.bypassIterations.get()) {
            if ((Boolean)this.debug.get()) {
                this.warning("Starting normal iterations", new Object[0]);
            }

            return (Integer)this.normalDelay.get();
        } else {
            if (this.iteration > (Integer)this.normalIterations.get() + (Integer)this.bypassIterations.get()) {
                if ((Boolean)this.debug.get()) {
                    this.warning("Restarting iterations", new Object[0]);
                }

                this.iteration = 0;
            }

            return (Integer)this.normalDelay.get();
        }
    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.mc.world.getBlockState(this.blockPos).isOf(Blocks.AIR) && !this.updated) {
            ++this.iteration;
            this.updated = true;
        }

        if (this.ticksPassed < 1) {
            ++this.ticksPassed;
        } else if (!this.mc.world.getBlockState(this.blockPos).isOf(Blocks.AIR)) {
            this.updated = false;
            this.ticksPassed = 0;
        }

        if (this.ticks >= this.getDelay()) {
            this.ticks = 0;
            if (this.shouldMine()) {
                if ((Boolean)this.rotate.get()) {
                    Rotations.rotate(Rotations.getYaw(this.blockPos), Rotations.getPitch(this.blockPos), () -> {
                        this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                    });
                } else {
                    this.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, this.blockPos, this.direction));
                }

                this.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }
        } else {
            ++this.ticks;
        }

    }

    private boolean shouldMine() {
        if (this.blockPos.getY() == -1) {
            return false;
        } else if (!BlockUtils.canBreak(this.blockPos)) {
            return false;
        } else {
            Item item = this.mc.player.getMainHandStack().getItem();
            return !(Boolean)this.pick.get() || item == Items.DIAMOND_PICKAXE || item == Items.NETHERITE_PICKAXE || (Boolean)this.ironPick.get() && item == Items.IRON_PICKAXE;
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && this.shouldMine()) {
            event.renderer.box(this.blockPos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }
    }
}
