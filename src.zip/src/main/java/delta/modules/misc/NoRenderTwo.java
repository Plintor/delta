package delta.modules.misc;

import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.List;
import meteordevelopment.meteorclient.events.world.ChunkOcclusionEvent;
import meteordevelopment.meteorclient.events.world.ParticleEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;

public class NoRenderTwo extends Module {
    private final SettingGroup sgOverlay;
    private final SettingGroup sgHUD;
    private final SettingGroup sgWorld;
    private final SettingGroup sgEntity;
    private final Setting<Boolean> noHurtCam;
    private final Setting<Boolean> noPortalOverlay;
    private final Setting<Boolean> noSpyglassOverlay;
    private final Setting<Boolean> noNausea;
    private final Setting<Boolean> noPumpkinOverlay;
    private final Setting<Boolean> noPowderedSnowOverlay;
    private final Setting<Boolean> noFireOverlay;
    private final Setting<Boolean> noLiquidOverlay;
    private final Setting<Boolean> noInWallOverlay;
    private final Setting<Boolean> noVignette;
    private final Setting<Boolean> noGuiBackground;
    private final Setting<Boolean> noTotemAnimation;
    private final Setting<Boolean> noEatParticles;
    private final Setting<Boolean> noBossBar;
    private final Setting<Boolean> noScoreboard;
    private final Setting<Boolean> noCrosshair;
    private final Setting<Boolean> noHeldItemName;
    private final Setting<Boolean> noPotionIcons;
    private final Setting<Boolean> noMessageSignatureIndicator;
    private final Setting<Boolean> noWeather;
    private final Setting<Boolean> noBlindness;
    private final Setting<Boolean> noDarkness;
    private final Setting<Boolean> noFog;
    private final Setting<Boolean> noEnchTableBook;
    private final Setting<Boolean> noSignText;
    private final Setting<Boolean> noBlockBreakParticles;
    private final Setting<Boolean> noBlockBreakOverlay;
    private final Setting<Boolean> noSkylightUpdates;
    private final Setting<Boolean> noFallingBlocks;
    private final Setting<Boolean> noCaveCulling;
    private final Setting<Boolean> noMapMarkers;
    private final Setting<NoRenderTwo.BannerRenderMode> bannerRender;
    private final Setting<Boolean> noFireworkExplosions;
    private final Setting<List<ParticleType<?>>> particles;
    private final Setting<Boolean> noBarrierInvis;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<Boolean> dropSpawnPacket;
    private final Setting<Boolean> noArmor;
    private final Setting<Boolean> noInvisibility;
    private final Setting<Boolean> noGlowing;
    private final Setting<Boolean> noMobInSpawner;
    private final Setting<Boolean> noDeadEntities;
    private final Setting<Boolean> noNametags;

    public NoRenderTwo() {
        super(Categories.Render, "no-render-two", "Disables certain animations or overlays from rendering.");
        this.sgOverlay = this.settings.createGroup("Overlay");
        this.sgHUD = this.settings.createGroup("HUD");
        this.sgWorld = this.settings.createGroup("World");
        this.sgEntity = this.settings.createGroup("Entity");
        this.noHurtCam = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("hurt-cam")).description("Disables rendering of the hurt camera effect.")).defaultValue(true)).build());
        this.noPortalOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("portal-overlay")).description("Disables rendering of the nether portal overlay.")).defaultValue(true)).build());
        this.noSpyglassOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("spyglass-overlay")).description("Disables rendering of the spyglass overlay.")).defaultValue(true)).build());
        this.noNausea = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("nausea")).description("Disables rendering of the nausea overlay.")).defaultValue(true)).build());
        this.noPumpkinOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("pumpkin-overlay")).description("Disables rendering of the pumpkin head overlay")).defaultValue(true)).build());
        this.noPowderedSnowOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("powdered-snow-overlay")).description("Disables rendering of the powdered snow overlay.")).defaultValue(true)).build());
        this.noFireOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("fire-overlay")).description("Disables rendering of the fire overlay.")).defaultValue(true)).build());
        this.noLiquidOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("liquid-overlay")).description("Disables rendering of the liquid overlay.")).defaultValue(true)).build());
        this.noInWallOverlay = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("in-wall-overlay")).description("Disables rendering of the overlay when inside blocks.")).defaultValue(true)).build());
        this.noVignette = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("vignette")).description("Disables rendering of the vignette overlay.")).defaultValue(true)).build());
        this.noGuiBackground = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("gui-background")).description("Disables rendering of the GUI background overlay.")).defaultValue(true)).build());
        this.noTotemAnimation = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("totem-animation")).description("Disables rendering of the totem animation when you pop a totem.")).defaultValue(true)).build());
        this.noEatParticles = this.sgOverlay.add(((Builder)((Builder)((Builder)(new Builder()).name("eating-particles")).description("Disables rendering of eating particles.")).defaultValue(true)).build());
        this.noBossBar = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("boss-bar")).description("Disable rendering of boss bars.")).defaultValue(true)).build());
        this.noScoreboard = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("scoreboard")).description("Disable rendering of the scoreboard.")).defaultValue(true)).build());
        this.noCrosshair = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("crosshair")).description("Disables rendering of the crosshair.")).defaultValue(true)).build());
        this.noHeldItemName = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("held-item-name")).description("Disables rendering of the held item name.")).defaultValue(true)).build());
        this.noPotionIcons = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("potion-icons")).description("Disables rendering of status effect icons.")).defaultValue(true)).build());
        this.noMessageSignatureIndicator = this.sgHUD.add(((Builder)((Builder)((Builder)(new Builder()).name("message-signature-indicator")).description("Disables uncategorized message signature indicator on the left of the message.")).defaultValue(true)).build());
        this.noWeather = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("weather")).description("Disables rendering of weather.")).defaultValue(true)).build());
        this.noBlindness = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("blindness")).description("Disables rendering of blindness.")).defaultValue(true)).build());
        this.noDarkness = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("darkness")).description("Disables rendering of darkness.")).defaultValue(true)).build());
        this.noFog = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("fog")).description("Disables rendering of fog.")).defaultValue(true)).build());
        this.noEnchTableBook = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("enchantment-table-book")).description("Disables rendering of books above enchanting tables.")).defaultValue(true)).build());
        this.noSignText = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("sign-text")).description("Disables rendering of text on signs.")).defaultValue(true)).build());
        this.noBlockBreakParticles = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("block-break-particles")).description("Disables rendering of block-break particles.")).defaultValue(true)).build());
        this.noBlockBreakOverlay = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("block-break-overlay")).description("Disables rendering of block-break overlay.")).defaultValue(true)).build());
        this.noSkylightUpdates = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("skylight-updates")).description("Disables rendering of skylight updates.")).defaultValue(true)).build());
        this.noFallingBlocks = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("falling-blocks")).description("Disables rendering of falling blocks.")).defaultValue(true)).build());
        this.noCaveCulling = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("cave-culling")).description("Disables Minecraft's cave culling algorithm.")).defaultValue(true)).build());
        this.noMapMarkers = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("map-markers")).description("Disables markers on maps.")).defaultValue(true)).build());
        this.bannerRender = this.sgWorld.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("banners")).description("Changes rendering of banners.")).defaultValue(NoRenderTwo.BannerRenderMode.Everything)).build());
        this.noFireworkExplosions = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("firework-explosions")).description("Disables rendering of firework explosions.")).defaultValue(true)).build());
        this.particles = this.sgWorld.add(((meteordevelopment.meteorclient.settings.ParticleTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.ParticleTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.ParticleTypeListSetting.Builder()).name("particles")).description("Particles to not render.")).build());
        this.noBarrierInvis = this.sgWorld.add(((Builder)((Builder)((Builder)(new Builder()).name("barrier-invisibility")).description("Disables barriers being invisible when not holding one.")).defaultValue(true)).build());
        this.entities = this.sgEntity.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("entities")).description("Disables rendering of selected entities.")).build());
        this.dropSpawnPacket = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("drop-spawn-packets")).description("WARNING! Drops all spawn packets of entities selected in the above list.")).defaultValue(true)).build());
        this.noArmor = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("armor")).description("Disables rendering of armor on entities.")).defaultValue(true)).build());
        this.noInvisibility = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("invisibility")).description("Shows invisible entities.")).defaultValue(true)).build());
        this.noGlowing = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("glowing")).description("Disables rendering of the glowing effect")).defaultValue(true)).build());
        this.noMobInSpawner = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("spawner-entities")).description("Disables rendering of spinning mobs inside of mob spawners")).defaultValue(true)).build());
        this.noDeadEntities = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("dead-entities")).description("Disables rendering of dead entities")).defaultValue(true)).build());
        this.noNametags = this.sgEntity.add(((Builder)((Builder)((Builder)(new Builder()).name("nametags")).description("Disables rendering of entity nametags")).defaultValue(true)).build());
    }

    public boolean noHurtCam() {
        return this.isActive() && (Boolean)this.noHurtCam.get();
    }

    public boolean noPortalOverlay() {
        return this.isActive() && (Boolean)this.noPortalOverlay.get();
    }

    public boolean noSpyglassOverlay() {
        return this.isActive() && (Boolean)this.noSpyglassOverlay.get();
    }

    public boolean noNausea() {
        return this.isActive() && (Boolean)this.noNausea.get();
    }

    public boolean noPumpkinOverlay() {
        return this.isActive() && (Boolean)this.noPumpkinOverlay.get();
    }

    public boolean noFireOverlay() {
        return this.isActive() && (Boolean)this.noFireOverlay.get();
    }

    public boolean noLiquidOverlay() {
        return this.isActive() && (Boolean)this.noLiquidOverlay.get();
    }

    public boolean noPowderedSnowOverlay() {
        return this.isActive() && (Boolean)this.noPowderedSnowOverlay.get();
    }

    public boolean noInWallOverlay() {
        return this.isActive() && (Boolean)this.noInWallOverlay.get();
    }

    public boolean noVignette() {
        return this.isActive() && (Boolean)this.noVignette.get();
    }

    public boolean noGuiBackground() {
        return this.isActive() && (Boolean)this.noGuiBackground.get();
    }

    public boolean noTotemAnimation() {
        return this.isActive() && (Boolean)this.noTotemAnimation.get();
    }

    public boolean noEatParticles() {
        return this.isActive() && (Boolean)this.noEatParticles.get();
    }

    public boolean noBossBar() {
        return this.isActive() && (Boolean)this.noBossBar.get();
    }

    public boolean noScoreboard() {
        return this.isActive() && (Boolean)this.noScoreboard.get();
    }

    public boolean noCrosshair() {
        return this.isActive() && (Boolean)this.noCrosshair.get();
    }

    public boolean noHeldItemName() {
        return this.isActive() && (Boolean)this.noHeldItemName.get();
    }

    public boolean noPotionIcons() {
        return this.isActive() && (Boolean)this.noPotionIcons.get();
    }

    public boolean noMessageSignatureIndicator() {
        return this.isActive() && (Boolean)this.noMessageSignatureIndicator.get();
    }

    public boolean noWeather() {
        return this.isActive() && (Boolean)this.noWeather.get();
    }

    public boolean noBlindness() {
        return this.isActive() && (Boolean)this.noBlindness.get();
    }

    public boolean noDarkness() {
        return this.isActive() && (Boolean)this.noDarkness.get();
    }

    public boolean noFog() {
        return this.isActive() && (Boolean)this.noFog.get();
    }

    public boolean noEnchTableBook() {
        return this.isActive() && (Boolean)this.noEnchTableBook.get();
    }

    public boolean noSignText() {
        return this.isActive() && (Boolean)this.noSignText.get();
    }

    public boolean noBlockBreakParticles() {
        return this.isActive() && (Boolean)this.noBlockBreakParticles.get();
    }

    public boolean noBlockBreakOverlay() {
        return this.isActive() && (Boolean)this.noBlockBreakOverlay.get();
    }

    public boolean noSkylightUpdates() {
        return this.isActive() && (Boolean)this.noSkylightUpdates.get();
    }

    public boolean noFallingBlocks() {
        return this.isActive() && (Boolean)this.noFallingBlocks.get();
    }

    @EventHandler
    private void onChunkOcclusion(ChunkOcclusionEvent event) {
        if ((Boolean)this.noCaveCulling.get()) {
            event.cancel();
        }

    }

    public boolean noMapMarkers() {
        return this.isActive() && (Boolean)this.noMapMarkers.get();
    }

    public NoRenderTwo.BannerRenderMode getBannerRenderMode() {
        return !this.isActive() ? NoRenderTwo.BannerRenderMode.Everything : (NoRenderTwo.BannerRenderMode)this.bannerRender.get();
    }

    public boolean noFireworkExplosions() {
        return this.isActive() && (Boolean)this.noFireworkExplosions.get();
    }

    @EventHandler
    private void onAddParticle(ParticleEvent event) {
        if ((Boolean)this.noWeather.get() && event.particle.getType() == ParticleTypes.RAIN) {
            event.cancel();
        } else if ((Boolean)this.noFireworkExplosions.get() && event.particle.getType() == ParticleTypes.FIREWORK) {
            event.cancel();
        } else if (((List)this.particles.get()).contains(event.particle.getType())) {
            event.cancel();
        }

    }

    public boolean noBarrierInvis() {
        return this.isActive() && (Boolean)this.noBarrierInvis.get();
    }

    public boolean noEntity(Entity entity) {
        return this.isActive() && ((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType());
    }

    public boolean noEntity(EntityType<?> entity) {
        return this.isActive() && ((Object2BooleanMap)this.entities.get()).getBoolean(entity);
    }

    public boolean getDropSpawnPacket() {
        return this.isActive() && (Boolean)this.dropSpawnPacket.get();
    }

    public boolean noArmor() {
        return this.isActive() && (Boolean)this.noArmor.get();
    }

    public boolean noInvisibility() {
        return this.isActive() && (Boolean)this.noInvisibility.get();
    }

    public boolean noGlowing() {
        return this.isActive() && (Boolean)this.noGlowing.get();
    }

    public boolean noMobInSpawner() {
        return this.isActive() && (Boolean)this.noMobInSpawner.get();
    }

    public boolean noDeadEntities() {
        return this.isActive() && (Boolean)this.noDeadEntities.get();
    }

    public boolean noNametags() {
        return this.isActive() && (Boolean)this.noNametags.get();
    }

    public static enum BannerRenderMode {
        Everything,
        Pillar,
        None;

        // $FF: synthetic method
        private static NoRenderTwo.BannerRenderMode[] $values() {
            return new NoRenderTwo.BannerRenderMode[]{Everything, Pillar, None};
        }
    }
}
