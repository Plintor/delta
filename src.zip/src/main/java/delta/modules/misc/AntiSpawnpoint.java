package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.EntityUtil;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Send;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;

public class AntiSpawnpoint extends Module {
    private final SettingGroup sgDefault;
    private final Setting<Boolean> fakeUse;
    private final Setting<Boolean> useDistance;
    private final Setting<Integer> distance;

    public AntiSpawnpoint() {
        super(DeltaHack.Misc, "anti-spawnpoint", "Protects the player from losing the respawn point.");
        this.sgDefault = this.settings.getDefaultGroup();
        this.fakeUse = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("fake-use")).description("Fake using the bed or anchor.")).defaultValue(true)).build());
        this.useDistance = this.sgDefault.add(((Builder)((Builder)((Builder)(new Builder()).name("use-distance")).description("Actually uses the bed or anchor when you are far away from spawn.")).defaultValue(true)).build());
        this.distance = this.sgDefault.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("distance")).description("-")).defaultValue(130000)).noSlider().build());
    }

    @EventHandler
    private void onSendPacket(Send event) {
        if (this.mc.world != null) {
            Packet var3 = event.packet;
            if (var3 instanceof PlayerInteractBlockC2SPacket) {
                PlayerInteractBlockC2SPacket p = (PlayerInteractBlockC2SPacket)var3;
                BlockPos blockPos = p.getBlockHitResult().getBlockPos();
                boolean IsOverWorld = this.mc.world.getDimension().comp_648();
                boolean IsNetherWorld = this.mc.world.getDimension().comp_649();
                boolean BlockIsBed = this.mc.world.getBlockState(blockPos).getBlock() instanceof BedBlock;
                boolean BlockIsAnchor = this.mc.world.getBlockState(blockPos).getBlock().equals(Blocks.RESPAWN_ANCHOR);
                if ((Boolean)this.fakeUse.get()) {
                    if (BlockIsBed && IsOverWorld) {
                        this.mc.player.swingHand(Hand.MAIN_HAND);
                    } else if (BlockIsAnchor && IsNetherWorld) {
                        this.mc.player.swingHand(Hand.MAIN_HAND);
                    }
                }

                BlockPos pos = EntityUtil.playerPos(this.mc.player);
                if (BlockIsBed && IsOverWorld || BlockIsAnchor && IsNetherWorld && pos.isWithinDistance(new Vec3d(0.0D, 0.0D, 0.0D), (double)(Integer)this.distance.get())) {
                    event.cancel();
                }

            }
        }
    }
}
