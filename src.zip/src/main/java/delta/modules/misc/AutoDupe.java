package delta.modules.misc;

import delta.DeltaHack;
import delta.util.StorageUtility;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.InvUtil;
import delta.utils.Vec3dInfo;
import delta.utils.WorldUtils;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.hit.BlockHitResult;

public class AutoDupe extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> putDelay;
    private final Setting<Integer> hitDelay;
    public final Setting<Boolean> placeFrame;
    public final Setting<Boolean> placeBlock;
    private final Setting<Boolean> rotate;
    private final Setting<Double> range;
    private final Setting<Boolean> lagPause;
    private final Setting<Boolean> put;
    private final Setting<Integer> delay;
    private Entity frame;
    private int timer;
    private int putTimer;
    private int breakTimer;

    public AutoDupe() {
        super(DeltaHack.Misc, "auto-frame-dupe", "sex bee sex tea");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.putDelay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("-")).defaultValue(20)).min(0).sliderMax(60).build());
        this.hitDelay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("hit-delay")).description("-")).defaultValue(12)).min(0).sliderMax(20).build());
        this.placeFrame = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-frame")).defaultValue(true)).build());
        this.placeBlock = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("place-block")).defaultValue(true)).build());
        SettingGroup var10001 = this.sgGeneral;
        meteordevelopment.meteorclient.settings.BoolSetting.Builder var10002 = (meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).defaultValue(true);
        Setting var10003 = this.placeBlock;
        Objects.requireNonNull(var10003);
        this.rotate = var10001.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)var10002.visible(var10003::get)).build());
        this.range = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name("range")).description("-")).defaultValue(4.5D).range(0.0D, 6.0D).sliderRange(0.0D, 6.0D).build());
        this.lagPause = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("lag-pause")).description("Whether to pause if the server is not responding.")).defaultValue(true)).build());
        this.put = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("put-shulkers-into-chests")).description("Puts shulkers into the nearest chest when your inventory is full")).defaultValue(true)).build());
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("put-delay")).description("-")).defaultValue(3)).min(0).sliderMax(10).build());
        this.timer = 0;
        this.putTimer = 0;
        this.breakTimer = 0;
    }

    public void onActivate() {
        this.frame = null;
        this.timer = 0;
        this.putTimer = 0;
        this.breakTimer = 0;
    }

    @EventHandler
    private void onTick(Post event) {
        if (this.mc.interactionManager != null && !this.mc.player.isCreative() && (!(TickRate.INSTANCE.getTimeSinceLastTick() >= 1.0F) || !(Boolean)this.lagPause.get())) {
            BlockPos хуй;
            int x;
            if ((Boolean)this.put.get()) {
                if (InvUtil.checkFullSlots() == 36) {
                    if (this.putTimer < (Integer)this.putDelay.get()) {
                        ++this.putTimer;
                        return;
                    }

                    this.putTimer = 0;
                    if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                        int ф = InvUtil.findShulker();
                        ф = ф >= 9 && ф <= 35 ? ф - 9 : ф + 27;
                        StorageUtility.putInStorage(this.mc.player.currentScreenHandler, ф);
                        return;
                    }

                    if (InvUtil.shulkerCount() < 3) {
                        return;
                    }

                    хуй = null;

                    for(int i = -3; i <= 3; ++i) {
                        for(int j = -3; j <= 3; ++j) {
                            for(x = -3; x <= 3; ++x) {
                                BlockPos a = EntityUtil.playerPos(this.mc.player).add(i, j, x);
                                if (BlockUtil.getBlock(a).equals(Blocks.CHEST) && (хуй == null || PlayerUtils.distanceTo(хуй) > PlayerUtils.distanceTo(a))) {
                                    хуй = a;
                                }
                            }
                        }
                    }

                    if (хуй != null) {
                        StorageUtility.openStorage(хуй, true);
                    }
                } else if (this.mc.player.currentScreenHandler != null) {
                    this.mc.player.closeHandledScreen();
                }
            }

            if (this.frame != null && (double)this.mc.player.distanceTo(this.frame) < (Double)this.range.get()) {
                if (!((ItemFrameEntity)this.frame).getHeldItemStack().equals(ItemStack.EMPTY)) {
                    if (this.breakTimer == 0) {
                        this.mc.interactionManager.interactEntity(this.mc.player, this.frame, Hand.MAIN_HAND);
                        this.mc.interactionManager.attackEntity(this.mc.player, this.frame);
                        this.mc.player.swingHand(Hand.MAIN_HAND);
                        this.breakTimer = (Integer)this.hitDelay.get();
                    } else {
                        --this.breakTimer;
                    }
                } else {
                    this.breakTimer = 0;
                }
            } else if ((Boolean)this.placeFrame.get()) {
                хуй = this.getNetherBlock();
                FindItemResult fra = InvUtils.findInHotbar(new Item[]{Items.ITEM_FRAME});
                if (хуй != null) {
                    if (fra.found() && !fra.isMainHand()) {
                        InvUtils.swap(fra.slot(), false);
                    }

                    if (fra.isMainHand()) {
                        this.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, new BlockHitResult(Vec3dInfo.closestVec3d(хуй), this.mc.player.getHorizontalFacing().getOpposite(), хуй, false), 0));
                    }
                } else if ((Boolean)this.placeBlock.get()) {
                    FindItemResult netF = InvUtils.findInHotbar(new Item[]{Items.NETHERITE_BLOCK});
                    if (netF.found()) {
                        for(x = -4; x < 4; ++x) {
                            for(int y = -2; y < 2; ++y) {
                                for(int z = -4; z < 4; ++z) {
                                    BlockPos pPos = EntityUtil.playerPos(this.mc.player).add(x, y, z);
                                    if (this.mc.world.getBlockState(pPos).getMaterial().isReplaceable() && !this.mc.world.getBlockState(pPos.down()).isAir()) {
                                        WorldUtils.place(pPos, netF, (Boolean)this.rotate.get(), 60, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, false, true, true);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (this.timer <= (Integer)this.putDelay.get()) {
                FindItemResult shb = InvUtils.findInHotbar((itemStack) -> {
                    return Utils.isShulker(itemStack.getItem());
                });
                this.frame = TargetUtils.get((entity) -> {
                    if (!entity.isAlive()) {
                        return false;
                    } else if ((double)this.mc.player.distanceTo(entity) >= (Double)this.range.get()) {
                        return false;
                    } else {
                        return !PlayerUtils.canSeeEntity(entity) ? false : entity instanceof ItemFrameEntity;
                    }
                }, SortPriority.LowestDistance);
                if (this.frame == null) {
                    return;
                }

                if (((ItemFrameEntity)this.frame).getHeldItemStack().equals(ItemStack.EMPTY)) {
                    if (!shb.found()) {
                        return;
                    }

                    if (!shb.isMainHand()) {
                        InvUtils.swap(shb.slot(), false);
                        return;
                    }

                    this.mc.interactionManager.interactEntity(this.mc.player, this.frame, Hand.MAIN_HAND);
                }

                Rotations.rotate(Rotations.getYaw(this.frame), Rotations.getPitch(this.frame, Target.Body), (Runnable)null);
                this.timer = 0;
            } else {
                ++this.timer;
            }

        }
    }

    private BlockPos getNetherBlock() {
        for(int x = -4; x < 4; ++x) {
            for(int y = -2; y < 2; ++y) {
                for(int z = -4; z < 4; ++z) {
                    BlockPos pPos = EntityUtil.playerPos(this.mc.player).add(x, y, z);
                    if (this.mc.world.getBlockState(pPos).getBlock().equals(Blocks.NETHERITE_BLOCK)) {
                        return pPos;
                    }
                }
            }
        }

        return null;
    }
}
