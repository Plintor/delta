package delta.modules.misc.villager_trader;

import delta.DeltaHack;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.MerchantScreenHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.world.GameMode;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;

public class VillagerTrader extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgDelay;
    private final Setting<Double> tradeRange;
    private final Setting<Double> wallsRange;
    private final Setting<Boolean> ignoreWalls;
    private final Setting<Boolean> tradeAura;
    private final Setting<List<Item>> trades;
    private final Setting<Object2BooleanMap<EntityType<?>>> entities;
    private final Setting<Integer> tradeDelay;
    private final Setting<Integer> retardDelay;
    private final List<Entity> entityList;
    private final List<Entity> alreadyTradedVillagers;
    private int hitDelayTimer;
    private int tradeRefreshTimer;

    public VillagerTrader() {
        super(DeltaHack.Misc, "trade-aura", "Automates villager trading.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgDelay = this.settings.createGroup("Delay");
        this.tradeRange = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("trade-range")).description("-")).defaultValue(5.0D).sliderRange(1.0D, 6.0D).range(1.0D, 6.0D).build());
        this.wallsRange = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("walls-range")).description("-")).defaultValue(5.0D).sliderRange(1.0D, 6.0D).range(1.0D, 6.0D).build());
        this.ignoreWalls = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("ignore-walls")).description("Whether or not to trade through walls.")).defaultValue(true)).build());
        this.tradeAura = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("aura")).description("Automatically opens the guis of nearby villagers to trade.")).defaultValue(true)).build());
        this.trades = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)((meteordevelopment.meteorclient.settings.ItemListSetting.Builder)(new meteordevelopment.meteorclient.settings.ItemListSetting.Builder()).name("selected-trades")).description("-")).defaultValue(Collections.singletonList(Items.GLASS))).build());
        this.entities = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)((meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder)(new meteordevelopment.meteorclient.settings.EntityTypeListSetting.Builder()).name("Entities to trade with.")).description("What blocks to use for surrounding.")).build());
        this.tradeDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("trade-delay")).description("How many ticks to wait between opening guis.")).defaultValue(5)).sliderRange(0, 20).range(0, 50).build());
        this.retardDelay = this.sgDelay.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("cool-down")).description("How long in seconds it takes to trade again.")).defaultValue(5)).sliderRange(0, 20).range(0, 50).build());
        this.entityList = new ArrayList();
        this.alreadyTradedVillagers = new ArrayList();
    }

    public ArrayList<Item> getWantedTradeItems() {
        return new ArrayList((Collection)this.trades.get());
    }

    public BetterGuiMerchant initVillagerTrader(MerchantScreenHandler handler, PlayerInventory inv, Text title) {
        ArrayList<Item> wantedTrades = this.getWantedTradeItems();
        return new BetterGuiMerchant(handler, inv, title, wantedTrades);
    }

    public void onDeactivate() {
        this.hitDelayTimer = 0;
        this.tradeRefreshTimer = 0;
        this.alreadyTradedVillagers.clear();
        this.entityList.clear();
    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.mc.player.isAlive() && !this.mc.player.isDead() && PlayerUtils.getGameMode() != GameMode.SPECTATOR && (Boolean)this.tradeAura.get()) {
            Vec3d pos = this.mc.player.getPos();
            double range = (Double)this.tradeRange.get();
            this.entityList.clear();
            Iterator var5 = this.mc.world.getEntities().iterator();

            while(var5.hasNext()) {
                Entity entity2 = (Entity)var5.next();
                this.entityList.add(entity2);
            }

            TargetUtils.getList(this.entityList, (entity) -> {
                if (!entity.equals(this.mc.player) && !entity.equals(this.mc.cameraEntity)) {
                    if ((!(entity instanceof LivingEntity) || !((LivingEntity)entity).isDead()) && entity.isAlive()) {
                        if (entity.getPos().distanceTo(pos) > range) {
                            return false;
                        } else if (!((Object2BooleanMap)this.entities.get()).getBoolean(entity.getType())) {
                            return false;
                        } else if (this.alreadyTraded(entity)) {
                            return false;
                        } else {
                            if ((Boolean)this.ignoreWalls.get()) {
                                if (entity.getPos().distanceTo(pos) > (Double)this.wallsRange.get()) {
                                    return false;
                                }
                            } else if (!PlayerUtils.canSeeEntity(entity)) {
                                return false;
                            }

                            if ((double)entity.getBlockPos().getY() > pos.getY() + 1.0D) {
                                return false;
                            } else {
                                return !(entity instanceof VillagerEntity) || !((VillagerEntity)entity).isBaby();
                            }
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }, SortPriority.LowestDistance, 1);
            if (this.delayCheck() && this.entityList.size() > 0) {
                this.entityList.forEach(this::trade);
            }

            this.resetTradedVillagers();
        }
    }

    private boolean alreadyTraded(Entity target) {
        return this.alreadyTradedVillagers.contains(target);
    }

    private boolean delayCheck() {
        if (this.hitDelayTimer >= 0) {
            --this.hitDelayTimer;
            return false;
        } else {
            this.hitDelayTimer = (Integer)this.tradeDelay.get();
            return true;
        }
    }

    private void resetTradedVillagers() {
        if (this.tradeRefreshTimer >= 0) {
            --this.tradeRefreshTimer;
        } else {
            this.alreadyTradedVillagers.clear();
            this.tradeRefreshTimer = (Integer)this.retardDelay.get() * 20;
        }

    }

    private void trade(Entity target) {
        this.mc.interactionManager.interactEntity(this.mc.player, target, Hand.MAIN_HAND);
        this.mc.player.swingHand(Hand.MAIN_HAND);
        this.alreadyTradedVillagers.add(target);
    }
}
