package delta.modules.misc;

import delta.DeltaHack;
import delta.util.PacketUtils;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.ShapeContext;

public class HeadProtect extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgMisc;
    private final SettingGroup sgRender;
    private final Setting<Integer> bpt;
    private final Setting<Integer> delay;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> range;
    private final Setting<Integer> height;
    private final Setting<List<Block>> blocks;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private static final List<BlockPos> placePositions = new ArrayList();
    private int timer;

    public HeadProtect() {
        super(DeltaHack.Misc, "head-prot", "-");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgMisc = this.settings.createGroup("Misc");
        this.sgRender = this.settings.createGroup("Render");
        this.bpt = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("blocks-per-tick")).description("How many blocks can be placed per one tick.")).defaultValue(3)).sliderRange(1, 5).range(1, 5).build());
        this.delay = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("delay")).description("How many ticks do you wait before yeah.")).defaultValue(1)).sliderRange(0, 5).range(0, 20).build());
        this.packet = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("packet")).description("Packet block placing method.")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("rotate")).description("Sends rotation packets to the server when placing.")).defaultValue(false)).build());
        this.range = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("range")).description("Goofy aaah")).defaultValue(3)).sliderRange(0, 3).range(0, 3).build());
        this.height = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("height")).description("Among us!!!")).defaultValue(2)).sliderRange(1, 4).range(1, 4).build());
        this.blocks = this.sgGeneral.add(((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)((meteordevelopment.meteorclient.settings.BlockListSetting.Builder)(new meteordevelopment.meteorclient.settings.BlockListSetting.Builder()).name("blocks")).description("Which blocks used for placing.")).defaultValue(Collections.singletonList(Blocks.OBSIDIAN))).build());
        this.onlyOnGround = this.sgMisc.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("only-on-ground")).description("Works only when you standing on blocks.")).defaultValue(true)).build());
        this.render = this.sgRender.add(((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)(new meteordevelopment.meteorclient.settings.BoolSetting.Builder()).name("render")).description("Renders a block overlay where the obsidian will be placed.")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)(new meteordevelopment.meteorclient.settings.EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("side-color")).description("The color of the sides of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 10))).build());
        this.lineColor = this.sgRender.add(((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)(new meteordevelopment.meteorclient.settings.ColorSetting.Builder()).name("line-color")).description("The color of the lines of the blocks being rendered.")).defaultValue(new SettingColor(204, 0, 0, 255))).build());
        this.timer = 0;
    }

    public void onActivate() {
        if (!placePositions.isEmpty()) {
            placePositions.clear();
        }

    }

    @EventHandler
    private void onTick(Pre event) {
        if (this.timer < (Integer)this.delay.get()) {
            ++this.timer;
        } else {
            this.timer = 0;
            if (!(Boolean)this.onlyOnGround.get() || this.mc.player.isOnGround()) {
                FindItemResult block = InvUtils.findInHotbar((itemStack) -> {
                    return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                });
                if (!block.found()) {
                    placePositions.clear();
                } else {
                    if (!placePositions.isEmpty()) {
                        placePositions.clear();
                    }

                    this.findPlacePos();
                    int places = 0;
                    if (!placePositions.isEmpty()) {
                        Iterator var4 = placePositions.iterator();

                        while(var4.hasNext()) {
                            BlockPos b = (BlockPos)var4.next();
                            if (places <= (Integer)this.bpt.get() && b != null) {
                                if ((Boolean)this.packet.get()) {
                                    PacketUtils.packetPlace(b, InvUtils.findInHotbar((itemStack) -> {
                                        return ((List)this.blocks.get()).contains(Block.getBlockFromItem(itemStack.getItem()));
                                    }), (Boolean)this.rotate.get(), false);
                                } else {
                                    BlockUtils.place(b, block, (Boolean)this.rotate.get(), 50);
                                }

                                ++places;
                            }
                        }

                    }
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((Boolean)this.render.get() && !placePositions.isEmpty()) {
            Iterator var2 = placePositions.iterator();

            while(var2.hasNext()) {
                BlockPos pos = (BlockPos)var2.next();
                event.renderer.box(pos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
            }

        }
    }

    private void findPlacePos() {
        placePositions.clear();
        BlockPos pos = EntityUtil.playerPos(this.mc.player);
        if (this.mc.player.isInSwimmingPose()) {
            pos = pos.down();
        }

        if ((Integer)this.range.get() > 0) {
            for(int i = -(Integer)this.range.get(); i < (Integer)this.range.get() + 1; ++i) {
                for(int j = -(Integer)this.range.get(); j < (Integer)this.range.get() + 1; ++j) {
                    this.add(pos.add(i, (Integer)this.height.get(), j));
                }
            }
        } else {
            this.add(pos.up((Integer)this.height.get()));
        }

    }

    private void add(BlockPos blockPos) {
        if (!placePositions.contains(blockPos) && this.mc.world.getBlockState(blockPos).getMaterial().isReplaceable() && this.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent())) {
            placePositions.add(blockPos);
        }

    }
}
