package delta.modules.misc;

import delta.DeltaHack;
import delta.utils.TimerUtils;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class Twerk extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> twerkDelay;
    private boolean upp;
    private final TimerUtils onTwerk;

    public Twerk() {
        super(DeltaHack.Misc, "twerk", "Twerk like the true queen Miley Cyrus.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.twerkDelay = this.sgGeneral.add(((Builder)((Builder)(new Builder()).name("Twerk Delay")).description("In Millis.")).defaultValue(4.0D).min(2.0D).sliderRange(2.0D, 100.0D).build());
        this.upp = false;
        this.onTwerk = new TimerUtils();
    }

    @EventHandler
    private void onTick(Pre event) {
        this.mc.options.sneakKey.setPressed(this.upp);
        if (this.onTwerk.passedMillis(((Double)this.twerkDelay.get()).longValue()) && !this.upp) {
            this.onTwerk.reset();
            this.upp = true;
        }

        if (this.onTwerk.passedMillis(((Double)this.twerkDelay.get()).longValue()) && this.upp) {
            this.onTwerk.reset();
            this.upp = false;
        }

    }

    public void onDeactivate() {
        this.upp = false;
        this.mc.options.sneakKey.setPressed(false);
        this.onTwerk.reset();
    }
}
