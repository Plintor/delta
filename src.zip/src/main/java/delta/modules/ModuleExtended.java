package delta.modules;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BlockPosSetting;
import meteordevelopment.meteorclient.settings.BlockSetting;
import meteordevelopment.meteorclient.settings.ColorListSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.PotionSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StatusEffectAmplifierMapSetting;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.MyPotion;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.item.Item;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;

public class ModuleExtended extends Module {
    public SettingGroup sgGeneral;

    public ModuleExtended(Category category, String name, String description) {
        super(category, name, description);
    }

    public SettingGroup getGroup(String group) {
        SettingGroup settingGroup = this.settings.getGroup(group);
        return settingGroup == null ? this.settings.createGroup(group) : settingGroup;
    }

    public SettingGroup getGroup() {
        if (this.sgGeneral == null) {
            this.sgGeneral = this.settings.getDefaultGroup();
        }

        return this.sgGeneral;
    }

    public Setting<Boolean> setting(String name, String description, boolean defaultValue, SettingGroup group) {
        return group.add(((Builder)((Builder)((Builder)(new Builder()).name(name)).description(description)).defaultValue(defaultValue)).build());
    }

    public Setting<Boolean> setting(String name, String description, boolean defaultValue, SettingGroup group, IVisible visible) {
        return group.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name(name)).description(description)).defaultValue(defaultValue)).visible(visible)).build());
    }

    public Setting<Integer> setting(String name, String description, int defaultValue, SettingGroup group, int minimum, int maximum, int sliderMin, int sliderMax) {
        return group.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name(name)).description(description)).defaultValue(defaultValue)).max(maximum).min(minimum).sliderRange(sliderMin, sliderMax).build());
    }

    public Setting<Integer> setting(String name, String description, int defaultValue, SettingGroup group, int minimum, int maximum, int sliderMin, int sliderMax, IVisible visible) {
        return group.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name(name)).description(description)).defaultValue(defaultValue)).visible(visible)).max(maximum).min(minimum).sliderRange(sliderMin, sliderMax).build());
    }

    public Setting<Double> setting(String name, String description, double defaultValue, SettingGroup group, double minimum, double maximum, double sliderMin, double sliderMax) {
        return group.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name(name)).description(description)).defaultValue(defaultValue).max(maximum).min(minimum).sliderRange(sliderMin, sliderMax).build());
    }

    public Setting<Double> setting(String name, String description, double defaultValue, SettingGroup group, double minimum, double maximum, double sliderMin, double sliderMax, IVisible visible) {
        return group.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name(name)).description(description)).defaultValue(defaultValue).visible(visible)).max(maximum).min(minimum).sliderRange(sliderMin, sliderMax).build());
    }

    public <T> Setting setting(String name, String description, T defaultValue, SettingGroup group) {
        return this.setting(name, description, defaultValue, group, (Consumer)null, (Consumer)null, (IVisible)null);
    }

    public <T> Setting setting(String name, String description, T defaultValue, SettingGroup group, IVisible visible) {
        return this.setting(name, description, defaultValue, group, (Consumer)null, (Consumer)null, visible);
    }

    public <T> Setting setting(String name, String description, T defaultValue, SettingGroup group, Consumer<T> onModuleActivated) {
        return this.setting(name, description, defaultValue, group, (Consumer)null, onModuleActivated, (IVisible)null);
    }

    public <T> Setting setting(String name, String description, T defaultValue, SettingGroup group, Consumer<T> onModuleActivated, IVisible visible) {
        return this.setting(name, description, defaultValue, group, (Consumer)null, onModuleActivated, visible);
    }

    private <T> Setting setting(String name, String description, T defaultValue, SettingGroup group, Consumer<T> onChanged, Consumer<T> onModuleActivated, IVisible visible) {
        if (defaultValue instanceof Enum) {
            Enum anEnum = (Enum)defaultValue;
            return anEnum instanceof MyPotion ? group.add(new PotionSetting(name, description, (MyPotion)defaultValue, onChanged, onModuleActivated, visible)) : group.add(new EnumSetting(name, description, (Enum)defaultValue, onChanged, onModuleActivated, visible));
        } else if (defaultValue instanceof SettingColor) {
            SettingColor defaultVal = (SettingColor)defaultValue;
            return group.add(new ColorSetting(name, description, defaultVal, onChanged, onModuleActivated, visible));
        } else if (defaultValue instanceof Keybind) {
            Keybind defaultVal = (Keybind)defaultValue;
            return group.add(new KeybindSetting(name, description, defaultVal, onChanged, onModuleActivated, visible, (Runnable)null));
        } else if (defaultValue instanceof String) {
            String defaultVal = (String)defaultValue;
            return group.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name(name)).description(defaultVal)).visible(visible)).build());
        } else if (defaultValue instanceof BlockPos) {
            BlockPos defaultVal = (BlockPos)defaultValue;
            return group.add(new BlockPosSetting(name, description, defaultVal, onChanged, onModuleActivated, visible));
        } else if (defaultValue instanceof Object2IntMap) {
            Object2IntMap defaultVal = (Object2IntMap)defaultValue;
            return group.add(new StatusEffectAmplifierMapSetting(name, description, defaultVal, onChanged, onModuleActivated, visible));
        } else if (defaultValue instanceof Integer) {
            Integer defaultVal = (Integer)defaultValue;
            return group.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name(name)).description(description)).defaultValue(defaultVal)).onChanged(onChanged)).onModuleActivated(onModuleActivated)).visible(visible)).build());
        } else if (defaultValue instanceof Double) {
            Double defaultVal = (Double)defaultValue;
            return group.add(((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)(new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()).name(name)).description(description)).defaultValue(defaultVal)).onChanged(onChanged)).onModuleActivated(onModuleActivated)).visible(visible)).build());
        } else if (defaultValue instanceof Boolean) {
            Boolean defaultVal = (Boolean)defaultValue;
            return group.add(((Builder)((Builder)((Builder)((Builder)((Builder)((Builder)(new Builder()).name(name)).description(description)).defaultValue(defaultVal)).onChanged(onChanged)).onModuleActivated(onModuleActivated)).visible(visible)).build());
        } else if (defaultValue instanceof Block) {
            Block defaultVal = (Block)defaultValue;
            return group.add(new BlockSetting(name, description, defaultVal, onChanged, onModuleActivated, visible, (Predicate)null));
        } else {
            if (defaultValue instanceof List) {
                List defaultVal = (List)defaultValue;
                Iterator var19 = defaultVal.iterator();

                while(var19.hasNext()) {
                    Object val = var19.next();
                    if (val instanceof SettingColor) {
                        return group.add(new ColorListSetting(name, description, defaultVal, onChanged, onModuleActivated, visible));
                    }

                    if (val instanceof Item) {
                        return group.add(new ItemListSetting(name, description, defaultVal, onChanged, onModuleActivated, visible, (Predicate)null, false));
                    }

                    if (val instanceof Block) {
                        return group.add(new BlockListSetting(name, description, defaultVal, onChanged, onModuleActivated, (Predicate)null, visible));
                    }
                }
            }

            return null;
        }
    }
}
