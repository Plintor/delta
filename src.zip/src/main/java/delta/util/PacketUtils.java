package delta.util;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.util.Hand;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.world.BlockView;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;

public class PacketUtils {
    private double progress = 0.0D;
    private BlockPos blockPos;

    public static void start(BlockPos pos) {
        MeteorClient.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.UP));
    }

    public static void stop(BlockPos pos) {
        MeteorClient.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
    }

    public static void startPacketMine(BlockPos blockpos, boolean clientSwing) {
        start(blockpos);
        if (clientSwing) {
            MeteorClient.mc.player.swingHand(Hand.MAIN_HAND);
        } else {
            MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        }

        stop(blockpos);
    }

    public static void packetPlace(BlockPos pos, FindItemResult slot, boolean rotate, boolean clientSwing) {
        if (pos != null) {
            if (rotate) {
                Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos));
            }

            BlockHitResult result = new BlockHitResult(Utils.vec3d(pos), Direction.DOWN, pos, true);
            int prevSlot = MeteorClient.mc.player.getInventory().selectedSlot;
            InvUtils.swap(slot.slot(), false);
            MeteorClient.mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, result, 0));
            MeteorClient.mc.player.getInventory().selectedSlot = prevSlot;
            if (clientSwing) {
                MeteorClient.mc.player.swingHand(Hand.MAIN_HAND);
            } else {
                MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }
        }

    }

    public void reset() {
        this.progress = 0.0D;
    }

    public BlockPos getBlockPos() {
        return this.blockPos;
    }

    public void setBlockPos(BlockPos blockPos) {
        this.blockPos = blockPos;
    }

    public void mine(BlockPos blockPos, Task task) {
        task.run(() -> {
            MeteorClient.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, blockPos, Direction.UP));
            MeteorClient.mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, blockPos, Direction.UP));
        });
        BlockState blockState = MeteorClient.mc.world.getBlockState(blockPos);
        double bestScore = -1.0D;
        int bestSlot = -1;

        for(int i = 0; i < 9; ++i) {
            double score = (double)MeteorClient.mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(blockState);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        this.progress += this.getBreakDelta(bestSlot != -1 ? bestSlot : MeteorClient.mc.player.getInventory().selectedSlot, blockState);
    }

    private double getBreakDelta(int slot, BlockState state) {
        float hardness = state.getHardness((BlockView)null, (BlockPos)null);
        return hardness == -1.0F ? 0.0D : this.getBlockBreakingSpeed(slot, state) / (double)hardness / (double)(state.isToolRequired() && !((ItemStack)MeteorClient.mc.player.getInventory().main.get(slot)).isSuitableFor(state) ? 100 : 30);
    }

    private double getBlockBreakingSpeed(int slot, BlockState block) {
        double speed = (double)((ItemStack)MeteorClient.mc.player.getInventory().main.get(slot)).getMiningSpeedMultiplier(block);
        if (speed > 1.0D) {
            ItemStack tool = MeteorClient.mc.player.getInventory().getStack(slot);
            int efficiency = EnchantmentHelper.getLevel(Enchantments.EFFICIENCY, tool);
            if (efficiency > 0 && !tool.isEmpty()) {
                speed += (double)(efficiency * efficiency + 1);
            }
        }

        if (StatusEffectUtil.hasHaste(MeteorClient.mc.player)) {
            speed *= (double)(1.0F + (float)(StatusEffectUtil.getHasteAmplifier(MeteorClient.mc.player) + 1) * 0.2F);
        }

        if (MeteorClient.mc.player.hasStatusEffect(StatusEffects.MINING_FATIGUE)) {
            float var10000;
            switch(MeteorClient.mc.player.getStatusEffect(StatusEffects.MINING_FATIGUE).getAmplifier()) {
                case 0:
                    var10000 = 0.3F;
                    break;
                case 1:
                    var10000 = 0.09F;
                    break;
                case 2:
                    var10000 = 0.0027F;
                    break;
                default:
                    var10000 = 8.1E-4F;
            }

            float k = var10000;
            speed *= (double)k;
        }

        if (MeteorClient.mc.player.isSubmergedIn(FluidTags.WATER) && !EnchantmentHelper.hasAquaAffinity(MeteorClient.mc.player)) {
            speed /= 5.0D;
        }

        if (!MeteorClient.mc.player.isOnGround()) {
            speed /= 5.0D;
        }

        return speed;
    }
}
