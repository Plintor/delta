package delta.util;

import delta.utils.BlockUtil;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class RenderUtils {
    public static boolean visibleHeight(RenderUtils.RenderMode renderMode) {
        return renderMode == RenderUtils.RenderMode.UpperSide || renderMode == RenderUtils.RenderMode.LowerSide;
    }

    public static boolean visibleSide(ShapeMode shapeMode) {
        return shapeMode == ShapeMode.Both || shapeMode == ShapeMode.Sides;
    }

    public static boolean visibleLine(ShapeMode shapeMode) {
        return shapeMode == ShapeMode.Both || shapeMode == ShapeMode.Lines;
    }

    public static void render(RenderInfo ri, BlockPos blockPos, Color sideColor, Color lineColor, double height) {
        if (!BlockUtil.isNull(blockPos)) {
            switch(ri.renderMode) {
                case Box:
                    box(ri, blockPos, sideColor, lineColor);
                    break;
                case UpperSide:
                    side(ri, blockPos, sideColor, lineColor, RenderUtils.Side.Upper, height);
                    break;
                case LowerSide:
                    side(ri, blockPos, sideColor, lineColor, RenderUtils.Side.Lower, height);
                    break;
                case Shape:
                    shape(ri, blockPos, sideColor, lineColor);
                    break;
                case Romb:
                    romb(ri, blockPos, sideColor, lineColor, RenderUtils.Side.Default);
                    break;
                case UpperRomb:
                    romb(ri, blockPos, sideColor, lineColor, RenderUtils.Side.Upper);
            }

        }
    }

    private static void romb(RenderInfo ri, BlockPos blockPos, Color sideColor, Color lineColor, RenderUtils.Side side) {
        switch(side) {
            case Default:
                render(ri, blockPos, 0.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.0D, 1.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.0D, 1.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.5D, 1.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.5D, 1.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 1.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 1.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 1.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 1.0D, -0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 1.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, -0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 1.0D, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 1.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 1.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 1.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 1.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 0.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                break;
            case Upper:
                render(ri, blockPos, 0.0D, 1.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 1.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.5D, 1.0D, 0.5D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.5D, 0.0D, sideColor, lineColor, ri.shapeMode);
                render(ri, blockPos, 0.0D, 1.0D, 0.5D, 0.5D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, 0.5D, 0.0D, 0.0D, sideColor, lineColor, ri.shapeMode);
        }

    }

    private static void render(RenderInfo ri, BlockPos blockPos, double x, double y, double z, double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double x4, double y4, Color sideColor, Color lineColor, ShapeMode shapeMode) {
        Vec3d vec3d = new Vec3d((double)blockPos.getX() + x, (double)blockPos.getY() + y, (double)blockPos.getZ() + z);
        ri.event.renderer.side(vec3d.x + x1, vec3d.y + y1, vec3d.z + z1, vec3d.x + x2, vec3d.y + y2, vec3d.z + z2, vec3d.x + x3, vec3d.y + y3, vec3d.z + z3, vec3d.x + x4, vec3d.y + y4, vec3d.z + 0.0D, sideColor, lineColor, shapeMode);
    }

    private static void shape(RenderInfo ri, BlockPos blockPos, Color sideColor, Color lineColor) {
        if (!BlockUtil.getShape(blockPos).isEmpty()) {
            render(ri, blockPos, BlockUtil.getBox(blockPos), sideColor, lineColor);
        }
    }

    private static void box(RenderInfo ri, BlockPos blockPos, Color sideColor, Color lineColor) {
        ri.event.renderer.box(blockPos, sideColor, lineColor, ri.shapeMode, 0);
    }

    private static void side(RenderInfo ri, BlockPos blockPos, Color sideColor, Color lineColor, RenderUtils.Side side, double height) {
        double y = side == RenderUtils.Side.Upper ? (double)(blockPos.getY() + 1) : (double)blockPos.getY();
        ri.event.renderer.box((double)blockPos.getX(), (double)blockPos.getY() + height, (double)blockPos.getZ(), (double)(blockPos.getX() + 1), y, (double)(blockPos.getZ() + 1), sideColor, lineColor, ri.shapeMode, 0);
    }

    private static void render(RenderInfo ri, BlockPos blockPos, Box box, Color sideColor, Color lineColor) {
        ri.event.renderer.box((double)blockPos.getX() + box.minX, (double)blockPos.getY() + box.minY, (double)blockPos.getZ() + box.minZ, (double)blockPos.getX() + box.maxX, (double)blockPos.getY() + box.maxY, (double)blockPos.getZ() + box.maxZ, sideColor, lineColor, ri.shapeMode, 0);
    }

    public static enum RenderMode {
        Box,
        UpperSide,
        LowerSide,
        Shape,
        Romb,
        UpperRomb,
        None;

        // $FF: synthetic method
        private static RenderUtils.RenderMode[] $values() {
            return new RenderUtils.RenderMode[]{Box, UpperSide, LowerSide, Shape, Romb, UpperRomb, None};
        }
    }

    public static enum Side {
        Default,
        Upper,
        Lower;

        // $FF: synthetic method
        private static RenderUtils.Side[] $values() {
            return new RenderUtils.Side[]{Default, Upper, Lower};
        }
    }

    public static enum Render {
        Meteor,
        BedTrap,
        None;

        // $FF: synthetic method
        private static RenderUtils.Render[] $values() {
            return new RenderUtils.Render[]{Meteor, BedTrap, None};
        }
    }
}
