package delta.util;

import delta.modules.combat.CevBreaker;
import delta.modules.combat.KillAuraPlus;
import delta.modules.combat.StrawberryBomb;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.util.Iterator;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixininterface.IExplosion;
import meteordevelopment.meteorclient.mixininterface.IRaycastContext;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.util.Hand;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.world.BlockView;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class CrystalUtils {
    static StrawberryBomb BBomber = (StrawberryBomb)Modules.get().get(StrawberryBomb.class);
    private static final Vec3d vec3d = new Vec3d(0.0D, 0.0D, 0.0D);
    private static RaycastContext raycastContext;
    private static Explosion explosion;

    public static int getPlaceDelay() {
        if (isBurrowBreaking()) {
            return (Integer)BBomber.burrowBreakDelay.get();
        } else {
            return isSurroundBreaking() ? (Integer)BBomber.surroundBreakDelay.get() : (Integer)BBomber.placeDelay.get();
        }
    }

    public static void attackCrystal(Entity entity) {
        MeteorClient.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, MeteorClient.mc.player.isSneaking()));
        Hand hand = Hand.MAIN_HAND;
        if ((Boolean)BBomber.renderSwing.get()) {
            MeteorClient.mc.player.swingHand(hand);
        }

        if (!(Boolean)BBomber.hideSwings.get()) {
            MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
        }

        ++BBomber.attacks;
        getBreakDelay();
        if ((Boolean)BBomber.debug.get()) {
            BBomber.warning("Breaking", new Object[0]);
        }

    }

    public static void attackCrystal(Entity entity, boolean swing) {
        MeteorClient.mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, MeteorClient.mc.player.isSneaking()));
        Hand hand = Hand.MAIN_HAND;
        if (swing) {
            MeteorClient.mc.player.swingHand(hand);
        }

        MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
        getBreakDelay();
    }

    public static boolean targetJustPopped() {
        if ((Boolean)BBomber.targetPopInvincibility.get()) {
            return !BBomber.targetPoppedTimer.passedMillis((long)(Integer)BBomber.targetPopInvincibilityTime.get());
        } else {
            return false;
        }
    }

    private static double getExposure(Vec3d source, Entity entity, boolean predictMovement, boolean collision, int ii, RaycastContext raycastContext, BlockPos obsidianPos, boolean ignoreTerrain) {
        Box box = EntityInfo.getBoundingBox(entity);
        if (predictMovement) {
            box = PredictionUtils.returnPredictBox((PlayerEntity)entity, collision, ii);
        }

        double d = 1.0D / ((box.maxX - box.minX) * 2.0D + 1.0D);
        double e = 1.0D / ((box.maxY - box.minY) * 2.0D + 1.0D);
        double f = 1.0D / ((box.maxZ - box.minZ) * 2.0D + 1.0D);
        double g = (1.0D - Math.floor(1.0D / d) * d) / 2.0D;
        double h = (1.0D - Math.floor(1.0D / f) * f) / 2.0D;
        if (!(d < 0.0D) && !(e < 0.0D) && !(f < 0.0D)) {
            int i = 0;
            int j = 0;

            for(double k = 0.0D; k <= 1.0D; k += d) {
                for(double l = 0.0D; l <= 1.0D; l += e) {
                    for(double m = 0.0D; m <= 1.0D; m += f) {
                        double n = MathHelper.lerp(k, box.minX, box.maxX);
                        double o = MathHelper.lerp(l, box.minY, box.maxY);
                        double p = MathHelper.lerp(m, box.minZ, box.maxZ);
                        ((IVec3d)vec3d).set(n + g, o, p + h);
                        ((IRaycastContext)raycastContext).set(vec3d, source, ShapeType.COLLIDER, FluidHandling.NONE, entity);
                        if (raycast(raycastContext, obsidianPos, ignoreTerrain).getType() == Type.MISS) {
                            ++i;
                        }

                        ++j;
                    }
                }
            }

            return (double)i / (double)j;
        } else {
            return 0.0D;
        }
    }

    private static double resistanceReduction(LivingEntity player, double damage) {
        if (player.hasStatusEffect(StatusEffects.RESISTANCE)) {
            int lvl = player.getStatusEffect(StatusEffects.RESISTANCE).getAmplifier() + 1;
            damage *= 1.0D - (double)lvl * 0.2D;
        }

        return damage < 0.0D ? 0.0D : damage;
    }

    public static void placeCrystal(FindItemResult item, BlockPos pos, boolean swing, boolean switchBack) {
        if (item.found()) {
            int prevSlot = MeteorClient.mc.player.getInventory().selectedSlot;
            MeteorClient.mc.player.getOffHandStack();
            if (!item.isOffhand()) {
                InvUtils.swap(item.slot(), false);
            }

            Hand hand = item.getHand();
            if (hand != null) {
                MeteorClient.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(hand, new BlockHitResult(Vec3d.of(pos), Direction.UP, pos.down(), false), 0));
                if (swing) {
                    MeteorClient.mc.player.swingHand(hand);
                }

                MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
                if (switchBack) {
                    InvUtils.swap(prevSlot, false);
                }

            }
        }
    }

    private static BlockHitResult raycast(RaycastContext context, BlockPos obsidianPos, boolean ignoreTerrain) {
        return (BlockHitResult)BlockView.raycast(context.getStart(), context.getEnd(), context, (raycastContext, blockPos) -> {
            BlockState blockState;
            if (blockPos.equals(obsidianPos)) {
                blockState = Blocks.OBSIDIAN.getDefaultState();
            } else {
                blockState = MeteorClient.mc.world.getBlockState(blockPos);
                if (blockState.getBlock().getBlastResistance() < 600.0F && ignoreTerrain) {
                    blockState = Blocks.AIR.getDefaultState();
                }
            }

            Vec3d vec3d = raycastContext.getStart();
            Vec3d vec3d2 = raycastContext.getEnd();
            VoxelShape voxelShape = raycastContext.getBlockShape(blockState, MeteorClient.mc.world, blockPos);
            BlockHitResult blockHitResult = MeteorClient.mc.world.raycastBlock(vec3d, vec3d2, blockPos, voxelShape, blockState);
            VoxelShape voxelShape2 = VoxelShapes.empty();
            BlockHitResult blockHitResult2 = voxelShape2.raycast(vec3d, vec3d2, blockPos);
            double d = blockHitResult == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult.getPos());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult2.getPos());
            return d <= e ? blockHitResult : blockHitResult2;
        }, (raycastContext) -> {
            Vec3d vec3d = raycastContext.getStart().subtract(raycastContext.getEnd());
            return BlockHitResult.createMissed(raycastContext.getEnd(), Direction.getFacing(vec3d.x, vec3d.y, vec3d.z), new BlockPos(raycastContext.getEnd()));
        });
    }

    public static double crystalDamage(PlayerEntity player, Vec3d crystal, boolean predictMovement, boolean collision, int i, BlockPos obsidianPos, boolean ignoreTerrain) {
        if (!EntityInfo.notNull(player)) {
            return 0.0D;
        } else if (EntityInfo.isCreative(player) && !(player instanceof FakePlayerEntity)) {
            return 0.0D;
        } else {
            Vec3d pVec = PredictionUtils.returnPredictVec(player, collision, i);
            ((IVec3d)vec3d).set(player.getPos().x, player.getPos().y, player.getPos().z);
            if (predictMovement) {
                ((IVec3d)vec3d).set(pVec.getX(), pVec.getY(), pVec.getZ());
            }

            double modDistance = Math.sqrt(vec3d.squaredDistanceTo(crystal));
            if (modDistance > 12.0D) {
                return 0.0D;
            } else {
                double exposure = getExposure(crystal, player, predictMovement, collision, i, raycastContext, obsidianPos, ignoreTerrain);
                double impact = (1.0D - modDistance / 12.0D) * exposure;
                double damage = (impact * impact + impact) / 2.0D * 7.0D * 12.0D + 1.0D;
                damage = getDamageForDifficulty(damage);
                damage = (double)DamageUtil.getDamageLeft((float)damage, (float)player.getArmor(), (float)player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue());
                damage = resistanceReduction(player, damage);
                ((IExplosion)explosion).set(crystal, 6.0F, false);
                damage = blastProtReduction(player, damage, explosion);
                return damage < 0.0D ? 0.0D : damage;
            }
        }
    }

    public static double crystalDamage(PlayerEntity player, Vec3d crystal) {
        return crystalDamage(player, crystal, false, false, 0, (BlockPos)null, false);
    }

    public static boolean shouldIgnoreSelfPlaceDamage() {
        return BBomber.PDamageIgnore.get() == StrawberryBomb.DamageIgnore.Always || BBomber.PDamageIgnore.get() == StrawberryBomb.DamageIgnore.WhileSafe && (EntityUtil.isSurrounded(MeteorClient.mc.player, BlockUtil.BlastResistantType.Any) || EntityUtil.isBurrowed(MeteorClient.mc.player)) || (Boolean)BBomber.selfPopInvincibility.get() && BBomber.selfPopIgnore.get() != StrawberryBomb.SelfPopIgnore.Break && !BBomber.selfPoppedTimer.passedMillis((long)(Integer)BBomber.selfPopInvincibilityTime.get());
    }

    public static boolean shouldIgnoreSelfBreakDamage() {
        return BBomber.BDamageIgnore.get() == StrawberryBomb.DamageIgnore.Always || BBomber.BDamageIgnore.get() == StrawberryBomb.DamageIgnore.WhileSafe && (EntityUtil.isSurrounded(MeteorClient.mc.player, BlockUtil.BlastResistantType.Any) || EntityUtil.isBurrowed(MeteorClient.mc.player)) || (Boolean)BBomber.selfPopInvincibility.get() && BBomber.selfPopIgnore.get() != StrawberryBomb.SelfPopIgnore.Place && !BBomber.selfPoppedTimer.passedMillis((long)(Integer)BBomber.selfPopInvincibilityTime.get());
    }

    private static void getBreakDelay() {
        if (isSurroundHolding() && BBomber.surroundHoldMode.get() != StrawberryBomb.SlowMode.Age) {
            BBomber.breakTimer = (Integer)BBomber.surroundHoldDelay.get();
        } else if ((Boolean)BBomber.slowFacePlace.get() && BBomber.slowFPMode.get() != StrawberryBomb.SlowMode.Age && isFacePlacing() && BBomber.bestTarget != null && BBomber.bestTarget.getY() < (double)BBomber.placingCrystalBlockPos.getY()) {
            BBomber.breakTimer = (Integer)BBomber.slowFPDelay.get();
        } else {
            BBomber.breakTimer = (Integer)BBomber.breakDelay.get();
        }

    }

    private static double getDamageForDifficulty(double damage) {
        double var10000;
        switch(MeteorClient.mc.world.getDifficulty()) {
            case PEACEFUL:
                var10000 = 0.0D;
                break;
            case EASY:
                var10000 = Math.min(damage / 2.0D + 1.0D, damage);
                break;
            case HARD:
                var10000 = damage * 3.0D / 2.0D;
                break;
            default:
                var10000 = damage;
        }

        return var10000;
    }

    public static boolean shouldFacePlace(BlockPos crystal) {
        Iterator var1 = BBomber.targets.iterator();

        label70:
        while(var1.hasNext()) {
            PlayerEntity target = (PlayerEntity)var1.next();
            BlockPos pos = target.getBlockPos();
            if ((Boolean)BBomber.CevPause.get() && Modules.get().isActive(CevBreaker.class)) {
                return false;
            }

            if ((Boolean)BBomber.KAPause.get() && (Modules.get().isActive(KillAura.class) || Modules.get().isActive(KillAuraPlus.class))) {
                return false;
            }

            if (EntityUtil.isFaceSurrounded(target, BlockUtil.BlastResistantType.Any)) {
                return false;
            }

            if ((Boolean)BBomber.surrHoldPause.get() && isSurroundHolding()) {
                return false;
            }

            if (crystal.getY() == pos.getY() + 1 && Math.abs(pos.getX() - crystal.getX()) <= 1 && Math.abs(pos.getZ() - crystal.getZ()) <= 1) {
                if ((double)EntityUtils.getTotalHealth(target) <= (Double)BBomber.facePlaceHealth.get()) {
                    return true;
                }

                Iterator var4 = target.getArmorItems().iterator();

                ItemStack itemStack;
                label68:
                do {
                    do {
                        if (!var4.hasNext()) {
                            continue label70;
                        }

                        itemStack = (ItemStack)var4.next();
                        if (itemStack != null && !itemStack.isEmpty()) {
                            continue label68;
                        }
                    } while(!(Boolean)BBomber.facePlaceArmor.get());

                    return true;
                } while(!((double)((float)(itemStack.getMaxDamage() - itemStack.getDamage()) / (float)itemStack.getMaxDamage() * 100.0F) <= (Double)BBomber.facePlaceDurability.get()));

                return true;
            }
        }

        return false;
    }

    private static double blastProtReduction(Entity player, double damage, Explosion explosion) {
        int protLevel = EnchantmentHelper.getProtectionAmount(player.getArmorItems(), DamageSource.explosion(explosion));
        if (protLevel > 20) {
            protLevel = 20;
        }

        damage *= 1.0D - (double)protLevel / 25.0D;
        return damage < 0.0D ? 0.0D : damage;
    }

    public static boolean isFacePlacing() {
        return (Boolean)BBomber.facePlace.get() || ((Keybind)BBomber.forceFacePlace.get()).isPressed();
    }

    public static boolean shouldBurrowBreak(BlockPos crystal) {
        BlockPos pos = BBomber.bestTarget.getBlockPos();
        if (!isBurrowBreaking()) {
            return false;
        } else {
            return (crystal.getY() == pos.getY() - 1 || crystal.getY() == pos.getY()) && Math.abs(pos.getX() - crystal.getX()) <= 1 && Math.abs(pos.getZ() - crystal.getZ()) <= 1;
        }
    }

    public static boolean isBurrowBreaking() {
        if (((Boolean)BBomber.burrowBreak.get() || ((Keybind)BBomber.forceBurrowBreak.get()).isPressed()) && BBomber.bestTarget != null && EntityUtil.isBurrowed(BBomber.bestTarget, true)) {
            switch((StrawberryBomb.TrapType)BBomber.burrowBWhen.get()) {
                case BothTrapped:
                    return EntityUtil.isBothTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case AnyTrapped:
                    return EntityUtil.isAnyTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case TopTrapped:
                    return EntityUtil.isTopTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case FaceTrapped:
                    return EntityUtil.isFaceSurrounded(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case Always:
                    return true;
            }
        }

        return false;
    }

    public static boolean shouldSurroundBreak(BlockPos crystal) {
        BlockPos pos = BBomber.bestTarget.getBlockPos();
        if (!isSurroundBreaking()) {
            return false;
        } else {
            return !MeteorClient.mc.world.getBlockState(pos.north()).isOf(Blocks.BEDROCK) && (crystal.equals(pos.north(2)) || (Boolean)BBomber.surroundBHorse.get() && (crystal.equals(pos.north(2).west()) || crystal.equals(pos.north(2).east())) || (Boolean)BBomber.surroundBDiagonal.get() && (crystal.equals(pos.north().west()) || crystal.equals(pos.north().east()))) || !MeteorClient.mc.world.getBlockState(pos.south()).isOf(Blocks.BEDROCK) && (crystal.equals(pos.south(2)) || (Boolean)BBomber.surroundBHorse.get() && (crystal.equals(pos.south(2).west()) || crystal.equals(pos.south(2).east())) || (Boolean)BBomber.surroundBDiagonal.get() && (crystal.equals(pos.south().west()) || crystal.equals(pos.south().east()))) || !MeteorClient.mc.world.getBlockState(pos.west()).isOf(Blocks.BEDROCK) && (crystal.equals(pos.west(2)) || (Boolean)BBomber.surroundBHorse.get() && (crystal.equals(pos.west(2).north()) || crystal.equals(pos.west(2).south())) || (Boolean)BBomber.surroundBDiagonal.get() && (crystal.equals(pos.west().north()) || crystal.equals(pos.west().south()))) || !MeteorClient.mc.world.getBlockState(pos.east()).isOf(Blocks.BEDROCK) && (crystal.equals(pos.east(2)) || (Boolean)BBomber.surroundBHorse.get() && (crystal.equals(pos.east(2).north()) || crystal.equals(pos.east(2).south())) || (Boolean)BBomber.surroundBDiagonal.get() && (crystal.equals(pos.east().north()) || crystal.equals(pos.east().south())));
        }
    }

    public static boolean isSurroundBreaking() {
        if (((Boolean)BBomber.surroundBreak.get() || ((Keybind)BBomber.forceSurroundBreak.get()).isPressed()) && BBomber.bestTarget != null && EntityUtil.isSurrounded(BBomber.bestTarget, BlockUtil.BlastResistantType.Mineable)) {
            switch((StrawberryBomb.TrapType)BBomber.surroundBWhen.get()) {
                case BothTrapped:
                    return EntityUtil.isBothTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case AnyTrapped:
                    return EntityUtil.isAnyTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case TopTrapped:
                    return EntityUtil.isTopTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case FaceTrapped:
                    return EntityUtil.isFaceSurrounded(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case Always:
                    return true;
            }
        }

        return false;
    }

    public static boolean isSurroundHolding() {
        if ((Boolean)BBomber.surroundHold.get() && BBomber.bestTarget != null && EntityUtil.isSurroundBroken(BBomber.bestTarget, BlockUtil.BlastResistantType.Any)) {
            switch((StrawberryBomb.TrapType)BBomber.surroundHWhen.get()) {
                case BothTrapped:
                    return EntityUtil.isBothTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case AnyTrapped:
                    return EntityUtil.isAnyTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case TopTrapped:
                    return EntityUtil.isTopTrapped(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case FaceTrapped:
                    return EntityUtil.isFaceSurrounded(BBomber.bestTarget, BlockUtil.BlastResistantType.Any);
                case Always:
                    return true;
            }
        }

        return false;
    }

    public static boolean isPosCrystal(BlockPos pos, boolean autist, boolean retard) {
        BlockPos ppos = EntityUtil.playerPos(MeteorClient.mc.player);
        if (!pos.equals(ppos.north()) && !pos.equals(ppos.south()) && !pos.equals(ppos.west()) && !pos.equals(ppos.east())) {
            if (!pos.equals(ppos.north(2)) && !pos.equals(ppos.south(2)) && !pos.equals(ppos.west(2)) && !pos.equals(ppos.east(2))) {
                if (!autist || !pos.equals(ppos.north().west()) && !pos.equals(ppos.south().west()) && !pos.equals(ppos.south().east()) && !pos.equals(ppos.north().east())) {
                    if (pos.equals(ppos.north(2).west()) && (BlockUtil.isAir(ppos.north().west()) || retard) || pos.equals(ppos.north(2).east()) && (BlockUtil.isAir(ppos.north().east()) || retard) || pos.equals(ppos.north().west(2)) && (BlockUtil.isAir(ppos.north().west()) || retard) || pos.equals(ppos.north().east(2)) && (BlockUtil.isAir(ppos.north().east()) || retard)) {
                        return true;
                    } else {
                        return pos.equals(ppos.south(2).west()) && (BlockUtil.isAir(ppos.south().west()) || retard) || pos.equals(ppos.south(2).east()) && (BlockUtil.isAir(ppos.south().east()) || retard) || pos.equals(ppos.south().west(2)) && (BlockUtil.isAir(ppos.south().west()) || retard) || pos.equals(ppos.south().east(2)) && (BlockUtil.isAir(ppos.south().east()) || retard);
                    }
                } else {
                    return true;
                }
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public static boolean isSurrCrystal(BlockPos pos, Entity pe) {
        BlockPos pePos = EntityUtil.playerPos(MeteorClient.mc.player).up(2);
        if (pe != null) {
            pePos = EntityUtil.playerPos((PlayerEntity)pe);
        }

        return pos.equals(pePos.south()) || pos.equals(pePos.west()) || pos.equals(pePos.east()) || pos.equals(pePos.north());
    }

    public static boolean isCrystalOnPos(BlockPos pos) {
        Iterator var1 = MeteorClient.mc.world.getEntities().iterator();

        Entity entity;
        do {
            if (!var1.hasNext()) {
                return false;
            }

            entity = (Entity)var1.next();
        } while(!(entity instanceof EndCrystalEntity) || !entity.getBlockPos().equals(pos));

        return true;
    }

    public static boolean doesCrystalInterfere(BlockPos crystalPos, BlockPos pos) {
        return Box.from(Vec3d.ofBottomCenter(crystalPos).add(0.0D, 0.5D, 0.0D)).expand(0.5D).intersects(Box.from(Vec3d.of(pos)));
    }

    public static boolean doesCrystalInterfere(Entity entity, BlockPos pos) {
        return entity instanceof EndCrystalEntity && entity.getBoundingBox().intersects(Box.from(Vec3d.of(pos)));
    }

    public static boolean autoTrapUtil(BlockPos pos) {
        if (BlockUtil.isAir(pos.up()) && BlockUtil.canPlace(pos.up(), true)) {
            Iterator var1 = MeteorClient.mc.world.getEntities().iterator();

            Entity entity;
            do {
                if (!var1.hasNext()) {
                    return true;
                }

                entity = (Entity)var1.next();
                if (entity.getBlockPos().equals(pos.up())) {
                    return false;
                }
            } while(!(entity instanceof EndCrystalEntity) || !doesCrystalInterfere(entity.getBlockPos(), pos.up()));

            return false;
        } else {
            return false;
        }
    }

    public static boolean isPosFacePlaceCrystal(Entity ce) {
        BlockPos pos = ce.getBlockPos();
        BlockPos plPos = EntityUtil.playerPos(MeteorClient.mc.player).up();
        return doesCrystalInterfere(pos, plPos.south()) || doesCrystalInterfere(pos, plPos.west()) || doesCrystalInterfere(pos, plPos.north()) || doesCrystalInterfere(pos, plPos.east());
    }

    public static boolean isPosCrystal(Entity ce, boolean autist, boolean retard) {
        return isPosCrystal(ce.getBlockPos(), autist, retard);
    }

    public static boolean isSurrCrystal(Entity ce, Entity pe) {
        return isSurrCrystal(ce.getBlockPos(), pe);
    }

    public static boolean canPlace(BlockPos crystalPos, double distance, boolean checkEntities) {
        if (PlayerUtil.distanceFromEye(crystalPos) > distance) {
            return false;
        } else if (EntityUtils.intersectsWithEntity(Box.from(Vec3d.of(crystalPos)), (entity) -> {
            return !entity.isSpectator();
        }) && checkEntities) {
            return false;
        } else {
            Block block = BlockUtil.getBlock(crystalPos.down());
            return block != Blocks.OBSIDIAN && block != Blocks.BEDROCK ? false : BlockUtil.isAir(crystalPos);
        }
    }

    public static int strawberryUtil(BlockPos crystalPos, boolean checkEntities) {
        if (!BlockUtil.isAir(crystalPos) || checkEntities && EntityUtils.intersectsWithEntity(Box.from(Vec3d.of(crystalPos)), (entity) -> {
            return !entity.isSpectator();
        })) {
            return 0;
        } else {
            Block block = BlockUtil.getBlock(crystalPos.down());
            if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) {
                return BlockUtil.isReplaceable(crystalPos.down()) ? 1 : 0;
            } else {
                return 2;
            }
        }
    }
}
