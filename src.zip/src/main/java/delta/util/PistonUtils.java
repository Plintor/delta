package delta.util;

import delta.modules.combat.SurroundPlus;
import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import delta.utils.PlayerUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class PistonUtils {
    public static List<PistonUtils.PresumePiston> getPresumablePistons(BlockPos checkPos, boolean farawayPos, boolean sidePos, boolean upperPos, boolean straight, boolean upPos) {
        List<PistonUtils.PresumePiston> a = new ArrayList();

        for(int i = 0; i < 4; ++i) {
            Direction dire = Direction.fromHorizontal(i);
            if (upPos) {
                a.add(new PistonUtils.PresumePiston(checkPos, dire));
            }

            if (straight) {
                a.add(new PistonUtils.PresumePiston(checkPos, dire, 2));
            }

            if (farawayPos) {
                a.add(new PistonUtils.PresumePiston(checkPos, dire, 3));
                if (upperPos) {
                    a.add(new PistonUtils.PresumePiston(checkPos, dire, 3, Direction.UP));
                }
            }

            if (sidePos) {
                a.add(new PistonUtils.PresumePiston(checkPos, dire, 2, Direction.fromHorizontal(i + 1)));
                a.add(new PistonUtils.PresumePiston(checkPos, dire, 2, Direction.fromHorizontal(i == 0 ? 3 : i - 1)));
                if (upperPos) {
                    a.add(new PistonUtils.PresumePiston(checkPos, dire, 2, Direction.fromHorizontal(i + 1), true));
                    a.add(new PistonUtils.PresumePiston(checkPos, dire, 2, Direction.fromHorizontal(i == 0 ? 3 : i - 1), true));
                }

                if (farawayPos) {
                    if (upperPos) {
                        a.add(new PistonUtils.PresumePiston(checkPos, dire, 3, Direction.fromHorizontal(i + 1), true));
                        a.add(new PistonUtils.PresumePiston(checkPos, dire, 3, Direction.fromHorizontal(i == 0 ? 3 : i - 1), true));
                    }

                    a.add(new PistonUtils.PresumePiston(checkPos, dire, 3, Direction.fromHorizontal(i + 1)));
                    a.add(new PistonUtils.PresumePiston(checkPos, dire, 3, Direction.fromHorizontal(i == 0 ? 3 : i - 1)));
                }
            }

            if (upperPos) {
                a.add(new PistonUtils.PresumePiston(checkPos, dire, 2, Direction.UP));
            }
        }

        a.sort(Comparator.comparingDouble(PistonUtils::distanceToPiston));
        return a;
    }

    private static double distanceToPiston(PistonUtils.PresumePiston pistonSequence) {
        return PlayerUtil.distanceFromEye(pistonSequence.getPos());
    }

    private static boolean isGoodPiston(BlockPos pos, Direction dir) {
        if (!isPiston(pos)) {
            return false;
        } else {
            Direction[] var2 = Direction.values();
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                Direction d = var2[var4];
                if (isPistonHead(pos.offset(d))) {
                    return false;
                }
            }

            return BlockUtil.isReplaceable(pos.offset(dir.getOpposite()));
        }
    }

    public static boolean isLever(BlockPos pos) {
        return BlockUtil.getBlock(pos).equals(Blocks.LEVER);
    }

    public static boolean isPiston(BlockPos pos) {
        Block block = BlockUtil.getBlock(pos);
        return block == Blocks.PISTON || block == Blocks.STICKY_PISTON || block == Blocks.MOVING_PISTON;
    }

    private static boolean isPistonHead(BlockPos pos) {
        Block a = BlockUtil.getBlock(pos);
        return a == Blocks.PISTON_HEAD || a == Blocks.MOVING_PISTON;
    }

    public static BlockPos getRecursiveSupportBlock(BlockPos pos, double maxDistance) {
        if (PlayerUtil.distanceFromEye(pos) > maxDistance) {
            return null;
        } else {
            Direction[] var3 = Direction.values();
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                Direction dir = var3[var5];
                if (dir != Direction.UP && !BlockUtil.isAir(pos.offset(dir))) {
                    return pos;
                }
            }

            return BlockUtil.canPlace(pos, true) ? getRecursiveSupportBlock(pos.down(), maxDistance) : null;
        }
    }

    public static class PresumePiston {
        private final BlockPos pos;
        private final BlockPos crystalPos;
        private final Direction dir;
        private final Direction adir;
        public final boolean isSupportable;

        public PresumePiston(BlockPos center, Direction placeRotateDir, int offset, Direction side) {
            this.pos = center.offset(placeRotateDir, offset).offset(side);
            this.crystalPos = center.offset(placeRotateDir);
            this.dir = placeRotateDir;
            this.adir = placeRotateDir.getOpposite();
            this.isSupportable = true;
        }

        public PresumePiston(BlockPos center, Direction placeRotateDir, int offset, Direction side, boolean up) {
            this.pos = up ? center.offset(placeRotateDir, offset).offset(side).up() : center.offset(placeRotateDir, offset).offset(side);
            this.crystalPos = center.offset(placeRotateDir);
            this.dir = placeRotateDir;
            this.adir = placeRotateDir.getOpposite();
            this.isSupportable = true;
        }

        public PresumePiston(BlockPos center, Direction placeRotateDir, int offset) {
            this.pos = center.offset(placeRotateDir, offset);
            this.crystalPos = center.offset(placeRotateDir);
            this.dir = placeRotateDir;
            this.adir = placeRotateDir.getOpposite();
            this.isSupportable = true;
        }

        public PresumePiston(BlockPos center, Direction placeRotateDir) {
            this.pos = center.offset(placeRotateDir).up();
            this.crystalPos = center.offset(placeRotateDir);
            this.dir = placeRotateDir;
            this.adir = placeRotateDir.getOpposite();
            this.isSupportable = false;
        }

        public Direction getRotateDir() {
            return this.dir;
        }

        public BlockPos getPos() {
            return this.pos;
        }

        public BlockPos getCrystalPos() {
            return this.crystalPos;
        }

        public List<BlockPos> getRedstonePos(double distance) {
            List<BlockPos> a = new ArrayList();
            if (this.isNull()) {
                return a;
            } else {
                Iterator var4 = this.getPlaceRedstonePos(distance).iterator();

                while(var4.hasNext()) {
                    BlockPos pos = (BlockPos)var4.next();
                    if (BlockUtil.canPlace(pos, true)) {
                        a.add(pos);
                    }
                }

                return a;
            }
        }

        public List<BlockPos> getPlaceRedstonePos(double distance) {
            List<BlockPos> a = new ArrayList();
            if (this.isNull()) {
                return a;
            } else {
                Direction[] var4 = Direction.values();
                int var5 = var4.length;

                for(int var6 = 0; var6 < var5; ++var6) {
                    Direction d = var4[var6];
                    if (!d.equals(this.adir)) {
                        BlockPos p = this.pos.offset(d);
                        if (!(PlayerUtil.distanceFromEye(p) > distance) && !CrystalUtils.doesCrystalInterfere(this.crystalPos, p)) {
                            a.add(p);
                        }
                    }
                }

                a.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
                return a;
            }
        }

        private boolean isNull() {
            if (this.pos != null && this.crystalPos != null && !this.pos.equals(this.crystalPos)) {
                return !CrystalUtils.doesCrystalInterfere(this.crystalPos.offset(this.dir), this.pos);
            } else {
                return true;
            }
        }

        public boolean shouldUseLever() {
            return BlockUtil.isBlastResist(this.crystalPos.offset(this.adir)) && !this.getLeverPlacePair().isEmpty();
        }

        public boolean isActivated() {
            return PistonUtils.isPistonHead(this.pos.offset(this.adir)) && PistonUtils.isPiston(this.pos);
        }

        public BlockPos getRedstoneBlock() {
            Direction[] var1 = Direction.values();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
                Direction d = var1[var3];
                BlockPos p = this.pos.offset(d);
                if (BlockUtil.getBlock(p).equals(Blocks.REDSTONE_BLOCK)) {
                    if (BlockUtil.isReplaceable(this.pos.offset(this.adir)) && PistonUtils.isPiston(this.pos)) {
                        return this.pos;
                    }

                    return p;
                }
            }

            return null;
        }

        public List<PistonUtils.PosDirPair> getLeverPlacePair() {
            List<PistonUtils.PosDirPair> ac = new ArrayList();
            if (BlockUtil.isReplaceable(this.pos.down())) {
                for(int i = 0; i < 4; ++i) {
                    Direction a = Direction.fromHorizontal(i);
                    if (BlockUtil.isFullBlock(this.pos.down().offset(a))) {
                        ac.add(new PistonUtils.PosDirPair(this.pos.down(), a));
                    }
                }
            }

            if (BlockUtil.isReplaceable(this.pos.offset(this.dir))) {
                ac.add(new PistonUtils.PosDirPair(this.pos.offset(this.dir), this.dir));
            }

            int var4;
            Direction dire;
            Direction[] var6;
            int var7;
            if (BlockUtil.isFullBlock(this.pos.down())) {
                var6 = Direction.values();
                var7 = var6.length;

                for(var4 = 0; var4 < var7; ++var4) {
                    dire = var6[var4];
                    if (BlockUtil.isReplaceable(this.pos.down().offset(dire))) {
                        ac.add(new PistonUtils.PosDirPair(this.pos.down().offset(dire), dire.getOpposite()));
                    }
                }
            }

            if (BlockUtil.isFullBlock(this.pos.offset(this.dir))) {
                var6 = Direction.values();
                var7 = var6.length;

                for(var4 = 0; var4 < var7; ++var4) {
                    dire = var6[var4];
                    if (dire != this.adir && BlockUtil.isReplaceable(this.pos.offset(this.dir).offset(dire))) {
                        ac.add(new PistonUtils.PosDirPair(this.pos.offset(this.dir).offset(dire), dire.getOpposite()));
                    }
                }
            }

            ac.sort(Comparator.comparingDouble(PlayerUtil::distanceFromEye));
            return ac;
        }

        public BlockPos getLeverPos() {
            if (PistonUtils.isLever(this.pos.down())) {
                return this.pos.down();
            } else if (PistonUtils.isLever(this.pos.offset(this.dir))) {
                return this.pos.offset(this.dir);
            } else {
                Direction[] var1 = Direction.values();
                int var2 = var1.length;

                for(int var3 = 0; var3 < var2; ++var3) {
                    Direction dire = var1[var3];
                    if (dire != this.adir) {
                        if (PistonUtils.isLever(this.pos.down().offset(dire))) {
                            return this.pos.down().offset(dire);
                        }

                        if (PistonUtils.isLever(this.pos.offset(this.dir).offset(dire))) {
                            return this.pos.offset(this.dir).offset(dire);
                        }
                    }
                }

                return null;
            }
        }

        public boolean isPlaceable(double distance, boolean pushSelf, boolean surBreak, boolean useLever) {
            if (this.isNull()) {
                return false;
            } else if (!pushSelf && this.pos.offset(this.adir).equals(EntityUtil.playerPos(MeteorClient.mc.player).up())) {
                return false;
            } else {
                if (!surBreak) {
                    for(int i = 0; i < 4; ++i) {
                        if (CrystalUtils.doesCrystalInterfere(this.crystalPos, EntityUtil.playerPos(MeteorClient.mc.player).offset(Direction.fromHorizontal(i)))) {
                            return false;
                        }
                    }
                }

                if (!BlockUtil.isReplaceable(this.pos.offset(this.adir))) {
                    return false;
                } else if (!CrystalUtils.canPlace(this.crystalPos, distance, true)) {
                    return false;
                } else {
                    return !this.getRedstonePos(distance).isEmpty() || useLever && this.shouldUseLever() ? BlockUtil.canPlace(this.pos, true) : false;
                }
            }
        }

        public boolean isReadyPiston(double distance, boolean pushSelf) {
            if (this.isNull()) {
                return false;
            } else if (!pushSelf && this.pos.offset(this.adir).equals(EntityUtil.playerPos(MeteorClient.mc.player).up())) {
                return false;
            } else if (!CrystalUtils.canPlace(this.crystalPos, distance, true)) {
                return false;
            } else {
                return this.getRedstonePos(distance).isEmpty() ? false : PistonUtils.isGoodPiston(this.pos, this.dir);
            }
        }

        public boolean isReady(double distance) {
            if (!this.isNull() && !(PlayerUtil.distanceFromEye(this.pos) > distance)) {
                if (this.isReadyPiston(distance, true)) {
                    return false;
                } else {
                    return !PistonUtils.isGoodPiston(this.pos, this.dir) && PistonUtils.isPiston(this.pos) && BlockUtil.isReplaceable(this.pos.offset(this.dir));
                }
            } else {
                return false;
            }
        }

        public boolean isReadyCrystal(double distance) {
            if (this.isNull()) {
                return false;
            } else if (!CrystalUtils.isCrystalOnPos(this.crystalPos)) {
                return false;
            } else {
                return this.getRedstonePos(distance).isEmpty() ? false : PistonUtils.isGoodPiston(this.pos, this.dir);
            }
        }

        public boolean isSupported() {
            return !BlockUtil.isAir(this.pos.down());
        }

        public boolean shouldSupportCrystal(BlockPos target) {
            if (!BlockUtil.isAir(this.crystalPos.down())) {
                return false;
            } else if (!BlockUtil.isAir(this.crystalPos)) {
                return false;
            } else {
                int blast = 0;

                for(int i = 0; i < 4; ++i) {
                    if (BlockUtil.isBlastResist(target.offset(Direction.fromHorizontal(i)))) {
                        ++blast;
                    }
                }

                return blast < 3;
            }
        }

        public Entity getInterferingCrystal(double distance) {
            if (!BlockUtil.isReplaceable(this.pos)) {
                return null;
            } else {
                Iterator var3 = MeteorClient.mc.world.getEntities().iterator();

                Entity entity;
                do {
                    if (!var3.hasNext()) {
                        return null;
                    }

                    entity = (Entity)var3.next();
                } while(!CrystalUtils.doesCrystalInterfere(entity, this.pos) || !(PlayerUtil.distanceFromEye(entity) <= distance) || entity.getBlockPos() == this.crystalPos);

                return entity;
            }
        }

        public BlockPos getInterferingBlock(double distance) {
            BlockPos pon = null;
            if (!this.isNull() && !this.isReadyCrystal(distance) && !this.isReadyCrystal(distance) && !this.isPlaceable(distance, false, false, false)) {
                if (BlockUtil.isBreakable(this.crystalPos) && PlayerUtil.distanceFromEye(this.crystalPos) <= distance && (!((SurroundPlus)Modules.get().get(SurroundPlus.class)).isActive() || !BlockUtil.isSurroundBlock(this.crystalPos))) {
                    pon = this.crystalPos;
                }

                if (BlockUtil.isBreakable(this.pos) && PlayerUtil.distanceFromEye(this.pos) <= distance && (!((SurroundPlus)Modules.get().get(SurroundPlus.class)).isActive() || !BlockUtil.isSurroundBlock(this.pos))) {
                    pon = this.pos;
                }

                if (this.getRedstonePos(distance).isEmpty()) {
                    Iterator var4 = this.getPlaceRedstonePos(distance).iterator();

                    BlockPos p;
                    do {
                        do {
                            if (!var4.hasNext()) {
                                return pon;
                            }

                            p = (BlockPos)var4.next();
                        } while(!BlockUtil.isBreakable(p));
                    } while(((SurroundPlus)Modules.get().get(SurroundPlus.class)).isActive() && BlockUtil.isSurroundBlock(p));

                    pon = p;
                }
            }

            return pon;
        }
    }

    public static record PosDirPair(BlockPos pos, Direction dir) {
        public PosDirPair(BlockPos pos, Direction dir) {
            this.pos = pos;
            this.dir = dir;
        }

        public BlockPos pos() {
            return this.pos;
        }

        public Direction dir() {
            return this.dir;
        }
    }
}
