package delta.util;

import delta.utils.BlockUtil;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.inventory.Inventory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class EntityInfo {
    public static Box getBoundingBox(PlayerEntity entity) {
        return entity.getBoundingBox();
    }

    public static Box getBoundingBox(Entity entity) {
        return entity.getBoundingBox();
    }

    public static boolean isCreative(PlayerEntity entity) {
        return entity.getAbilities().creativeMode;
    }

    public static Inventory getInventory(PlayerEntity entity) {
        return entity.getInventory();
    }

    public static boolean notNull(PlayerEntity entity) {
        return entity != null;
    }

    public static String getName(PlayerEntity entity) {
        return entity.getGameProfile().getName();
    }

    public static Iterable<Entity> getEntities() {
        return MeteorClient.mc.world.getEntities();
    }

    public static List<AbstractClientPlayerEntity> getPlayers() {
        return MeteorClient.mc.world.getPlayers();
    }

    public static boolean isSurrounded(LivingEntity entity) {
        return BlockUtil.isBlastResist(entity.getBlockPos().south()) && BlockUtil.isBlastResist(entity.getBlockPos().west()) && BlockUtil.isBlastResist(entity.getBlockPos().east()) && BlockUtil.isBlastResist(entity.getBlockPos().north()) && BlockUtil.isBlastResist(entity.getBlockPos().down());
    }

    public static boolean isTrapped(LivingEntity entity) {
        return BlockUtil.isBlastResist(entity.getBlockPos().south().up()) && BlockUtil.isBlastResist(entity.getBlockPos().west().up()) && BlockUtil.isBlastResist(entity.getBlockPos().east().up()) && BlockUtil.isBlastResist(entity.getBlockPos().north().up()) && BlockUtil.isBlastResist(entity.getBlockPos().up(2));
    }

    public static boolean isNotFaceTrapped(LivingEntity entity) {
        return !BlockUtil.isBlastResist(entity.getBlockPos().south().up()) || !BlockUtil.isBlastResist(entity.getBlockPos().west().up()) || !BlockUtil.isBlastResist(entity.getBlockPos().east().up()) || !BlockUtil.isBlastResist(entity.getBlockPos().north().up());
    }
}
