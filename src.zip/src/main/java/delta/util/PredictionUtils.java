package delta.util;

import delta.utils.BlockUtil;
import java.util.ArrayList;
import java.util.Iterator;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class PredictionUtils {
    public static ArrayList<BlockPos> getPredictCollisionBlocks(BlockPos blockpos) {
        ArrayList<BlockPos> array = new ArrayList();
        if (BlockUtil.isBlastResist(blockpos)) {
            array.add(blockpos);
        }

        Direction[] var2 = Direction.values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Direction d = var2[var4];
            if (d != Direction.UP && d != Direction.DOWN) {
                BlockPos pos = blockpos.offset(d);
                if (BlockUtil.isBlastResist(pos)) {
                    array.add(pos);
                }
            }
        }

        return array;
    }

    public static Box returnPredictBox(PlayerEntity entity, boolean collision, int i) {
        Box eBox = EntityInfo.getBoundingBox(entity);
        Vec3d eVec = entity.getVelocity();
        Box pBox = eBox.offset(eVec.getX() * (double)i, 0.0D, eVec.getZ() * (double)i);
        if (getEntitySpeed(entity) < 4.0D) {
            return eBox;
        } else {
            if (collision) {
                ArrayList<BlockPos> l = new ArrayList(getPredictCollisionBlocks(new BlockPos(pBox.getCenter())));
                Iterator var7 = l.iterator();

                while(var7.hasNext()) {
                    BlockPos p = (BlockPos)var7.next();
                    Box bBox = new Box(p);
                    if (bBox.intersects(pBox)) {
                        return eBox;
                    }
                }
            }

            return pBox;
        }
    }

    public static Vec3d returnPredictVec(PlayerEntity entity, boolean collision, int i) {
        Box eBox = EntityInfo.getBoundingBox(entity);
        Vec3d eVec = entity.getVelocity();
        Vec3d pVec = new Vec3d(entity.getPos().x, entity.getPos().y, entity.getPos().z);
        Box pBox = eBox.offset(eVec.getX() * (double)i, 0.0D, eVec.getZ() * (double)i);
        if (getEntitySpeed(entity) < 4.0D) {
            return pVec;
        } else {
            if (collision) {
                ArrayList<BlockPos> l = new ArrayList(getPredictCollisionBlocks(new BlockPos(pBox.getCenter())));
                Iterator var8 = l.iterator();

                while(var8.hasNext()) {
                    BlockPos p = (BlockPos)var8.next();
                    Box bBox = new Box(p);
                    if (bBox.intersects(pBox)) {
                        return pVec;
                    }
                }
            }

            Vec3d spVec = new Vec3d(pVec.x + eVec.x * (double)i, pVec.y, pVec.z + eVec.z * (double)i);
            return MeteorClient.mc.player.getPos().distanceTo(spVec) > 7.0D ? pVec : spVec;
        }
    }

    public static double getEntitySpeed(PlayerEntity entity) {
        if (entity == null) {
            return 0.0D;
        } else {
            double tX = Math.abs(entity.getX() - entity.prevX);
            double tZ = Math.abs(entity.getZ() - entity.prevZ);
            double length = Math.sqrt(tX * tX + tZ * tZ);
            if (entity == MeteorClient.mc.player) {
                Timer timer = (Timer)Modules.get().get(Timer.class);
                if (timer.isActive()) {
                    length *= ((Timer)Modules.get().get(Timer.class)).getMultiplier();
                }
            }

            return length * 20.0D;
        }
    }
}
