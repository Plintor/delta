package delta.util;

import delta.utils.BlockUtil;
import delta.utils.EntityUtil;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.mixininterface.IExplosion;
import meteordevelopment.meteorclient.mixininterface.IRaycastContext;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.utils.PreInit;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.world.BlockView;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.world.explosion.Explosion.DestructionType;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class BedUtils {
    private static Explosion explosion;
    private static final Vec3d vec3d = new Vec3d(0.0D, 0.0D, 0.0D);
    private static RaycastContext raycastContext;

    @PreInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(BedUtils.class);
        MeteorClient.EVENT_BUS.subscribe(CrystalUtils.class);
    }

    @EventHandler
    private static void onGameJoined(GameJoinedEvent event) {
        explosion = new Explosion(MeteorClient.mc.world, (Entity)null, 0.0D, 0.0D, 0.0D, 6.0F, false, DestructionType.DESTROY);
        raycastContext = new RaycastContext((Vec3d)null, (Vec3d)null, ShapeType.COLLIDER, FluidHandling.ANY, MeteorClient.mc.player);
    }

    public static boolean canBed(BlockPos canPlace, BlockPos replace) {
        return BlockUtil.getBlock(canPlace) instanceof BedBlock && BlockUtil.getBlock(replace) instanceof BedBlock || BlockUtils.canPlace(canPlace) && MeteorClient.mc.world.getBlockState(replace).getMaterial().isReplaceable();
    }

    public static void packetMine(BlockPos blockpos, boolean autoSwap, Task task) {
        task.run(() -> {
            FindItemResult best = InvUtils.findFastestTool(BlockUtil.getState(blockpos));
            if (best.found()) {
                if (autoSwap) {
                    InvUtils.swap(best.slot(), false);
                }

                PacketUtils.startPacketMine(blockpos, true);
            }
        });
    }

    public static void normalMine(BlockPos blockpos, boolean autoSwap) {
        FindItemResult best = InvUtils.findFastestTool(BlockUtil.getState(blockpos));
        if (best.found()) {
            if (autoSwap) {
                InvUtils.swap(best.slot(), false);
            }

            BlockUtils.breakBlock(blockpos, false);
        }
    }

    public static ArrayList<BlockPos> getTargetSphere(PlayerEntity target, int xRadius, int yRadius) {
        ArrayList<BlockPos> al = new ArrayList();
        BlockPos tPos = EntityUtil.playerPos(target);
        Mutable p = new Mutable();

        for(int x = -xRadius; x <= xRadius; ++x) {
            for(int y = -yRadius; y <= yRadius; ++y) {
                for(int z = -xRadius; z <= xRadius; ++z) {
                    p.set(tPos).move(x, y, z);
                    if (MathHelper.sqrt((float)((tPos.getX() - p.toImmutable().getX()) * (tPos.getX() - p.toImmutable().getX()) + (tPos.getZ() - p.toImmutable().getZ()) * (tPos.getZ() - p.toImmutable().getZ()))) <= (float)xRadius && MathHelper.sqrt((float)((tPos.getY() - p.toImmutable().getY()) * (tPos.getY() - p.toImmutable().getY()))) <= (float)yRadius && !al.contains(p.toImmutable())) {
                        al.add(p.toImmutable());
                    }
                }
            }
        }

        return al;
    }

    public static BlockPos getTrapBlock(PlayerEntity target, double distance) {
        if (target == null) {
            return null;
        } else {
            Direction[] var3 = Direction.values();
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                Direction direction = var3[var5];
                if (direction != Direction.UP && direction != Direction.DOWN) {
                    BlockPos pos = EntityUtil.playerPos(target).up().offset(direction);
                    if (BlockUtil.isCombatBlock(pos) && BlockUtil.isWithinRange(pos, distance)) {
                        return pos;
                    }
                }
            }

            return null;
        }
    }

    public static boolean shouldBurrowBreak(PlayerEntity tar) {
        BlockPos b = EntityUtil.playerPos(tar);
        return BlockUtil.isCombatBlock(b) && MeteorClient.mc.player.getPos().distanceTo(BlockUtil.getCenterVec3d(b)) < 4.5D;
    }

    public static boolean shouldTrapBreak(PlayerEntity tar) {
        return EntityInfo.isSurrounded(tar) && EntityInfo.isTrapped(tar) && getTrapBlock(tar, 4.5D) != null;
    }

    public static boolean shouldStringBreak(PlayerEntity tar) {
        List<BlockPos> strings = new ArrayList();
        CardinalDirection[] var2 = CardinalDirection.values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            CardinalDirection d = var2[var4];
            BlockPos cPos = EntityUtil.playerPos(tar).up();
            if (BlockUtil.getBlock(cPos).asItem().equals(Items.STRING) && MeteorClient.mc.player.getPos().distanceTo(BlockUtil.getCenterVec3d(cPos)) < 4.5D) {
                strings.add(cPos);
            }

            if (BlockUtil.getBlock(cPos.offset(d.toDirection())).asItem().equals(Items.STRING) && MeteorClient.mc.player.getPos().distanceTo(BlockUtil.getCenterVec3d(cPos.offset(d.toDirection()))) < 4.5D) {
                strings.add(cPos.offset(d.toDirection()));
            }
        }

        return !strings.isEmpty() && !shouldTrapBreak(tar);
    }

    public static double getDamage(PlayerEntity player, Vec3d cVec, boolean predictMovement, boolean collision, int i, boolean ignoreTerrain) {
        Vec3d pVec = PredictionUtils.returnPredictVec(player, collision, i);
        ((IVec3d)vec3d).set(player.getPos().x, player.getPos().y, player.getPos().z);
        if (predictMovement) {
            ((IVec3d)vec3d).set(pVec.getX(), pVec.getY(), pVec.getZ());
        }

        double modDistance = Math.sqrt(vec3d.squaredDistanceTo(cVec));
        if (modDistance > 10.0D) {
            return 0.0D;
        } else {
            double exposure = getExposure(cVec, player, predictMovement, collision, i, raycastContext, ignoreTerrain);
            double impact = (1.0D - modDistance / 10.0D) * exposure;
            double damage = (impact * impact + impact) / 2.0D * 7.0D * 10.0D + 1.0D;
            damage = getDamageForDifficulty(damage);
            damage = resistanceReduction(player, damage);
            damage = (double)DamageUtil.getDamageLeft((float)damage, (float)player.getArmor(), (float)player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue());
            ((IExplosion)explosion).set(cVec, 5.0F, true);
            damage = blastProtReduction(player, damage, explosion);
            if (damage < 0.0D) {
                damage = 0.0D;
            }

            return damage;
        }
    }

    private static double getDamageForDifficulty(double damage) {
        double var10000;
        switch(MeteorClient.mc.world.getDifficulty()) {
            case PEACEFUL:
                var10000 = 0.0D;
                break;
            case EASY:
                var10000 = Math.min(damage / 2.0D + 1.0D, damage);
                break;
            case HARD:
                var10000 = damage * 3.0D / 2.0D;
                break;
            default:
                var10000 = damage;
        }

        return var10000;
    }

    private static double resistanceReduction(LivingEntity player, double damage) {
        if (player.hasStatusEffect(StatusEffects.RESISTANCE)) {
            int lvl = player.getStatusEffect(StatusEffects.RESISTANCE).getAmplifier() + 1;
            damage *= 1.0D - (double)lvl * 0.2D;
        }

        return damage < 0.0D ? 0.0D : damage;
    }

    private static double blastProtReduction(Entity player, double damage, Explosion explosion) {
        int protLevel = EnchantmentHelper.getProtectionAmount(player.getArmorItems(), DamageSource.explosion(explosion));
        if (protLevel > 20) {
            protLevel = 20;
        }

        damage *= 1.0D - (double)protLevel / 25.0D;
        return damage < 0.0D ? 0.0D : damage;
    }

    private static double getExposure(Vec3d source, Entity entity, boolean predictMovement, boolean collision, int ii, RaycastContext raycastContext, boolean ignoreTerrain) {
        Box box = EntityInfo.getBoundingBox((PlayerEntity)entity);
        if (predictMovement) {
            box = PredictionUtils.returnPredictBox((PlayerEntity)entity, collision, ii);
        }

        double d = 1.0D / ((box.maxX - box.minX) * 2.0D + 1.0D);
        double e = 1.0D / ((box.maxY - box.minY) * 2.0D + 1.0D);
        double f = 1.0D / ((box.maxZ - box.minZ) * 2.0D + 1.0D);
        double g = (1.0D - Math.floor(1.0D / d) * d) / 2.0D;
        double h = (1.0D - Math.floor(1.0D / f) * f) / 2.0D;
        if (!(d < 0.0D) && !(e < 0.0D) && !(f < 0.0D)) {
            int i = 0;
            int j = 0;

            for(double k = 0.0D; k <= 1.0D; k += d) {
                for(double l = 0.0D; l <= 1.0D; l += e) {
                    for(double m = 0.0D; m <= 1.0D; m += f) {
                        double n = MathHelper.lerp(k, box.minX, box.maxX);
                        double o = MathHelper.lerp(l, box.minY, box.maxY);
                        double p = MathHelper.lerp(m, box.minZ, box.maxZ);
                        ((IVec3d)vec3d).set(n + g, o, p + h);
                        ((IRaycastContext)raycastContext).set(vec3d, source, ShapeType.COLLIDER, FluidHandling.NONE, entity);
                        if (raycast(raycastContext, ignoreTerrain).getType() == Type.MISS) {
                            ++i;
                        }

                        ++j;
                    }
                }
            }

            return (double)i / (double)j;
        } else {
            return 0.0D;
        }
    }

    private static BlockHitResult raycast(RaycastContext context, boolean ignoreTerrain) {
        return (BlockHitResult)BlockView.raycast(context.getStart(), context.getEnd(), context, (raycastContext, blockpos) -> {
            BlockState blockState = BlockUtil.getState(blockpos);
            if (!BlockUtil.isBlastResist(blockpos) && ignoreTerrain) {
                blockState = Blocks.AIR.getDefaultState();
            }

            Vec3d vec3d = raycastContext.getStart();
            Vec3d vec3d2 = raycastContext.getEnd();
            VoxelShape voxelShape = raycastContext.getBlockShape(blockState, MeteorClient.mc.world, blockpos);
            BlockHitResult blockHitResult = MeteorClient.mc.world.raycastBlock(vec3d, vec3d2, blockpos, voxelShape, blockState);
            VoxelShape voxelShape2 = VoxelShapes.empty();
            BlockHitResult blockHitResult2 = voxelShape2.raycast(vec3d, vec3d2, blockpos);
            double d = blockHitResult == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult.getPos());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult2.getPos());
            return d <= e ? blockHitResult : blockHitResult2;
        }, (raycastContext) -> {
            Vec3d vec3d = raycastContext.getStart().subtract(raycastContext.getEnd());
            return BlockHitResult.createMissed(raycastContext.getEnd(), Direction.getFacing(vec3d.x, vec3d.y, vec3d.z), new BlockPos(raycastContext.getEnd()));
        });
    }

    public static <T> List<List<T>> split(List<T> list, int count) {
        List<List<T>> part = new ArrayList();

        int i;
        for(i = 0; i < count; ++i) {
            part.add(new ArrayList());
        }

        for(i = 0; i < list.size(); ++i) {
            ((List)part.get(i % count)).add(list.get(i));
        }

        return part;
    }

    public static class RenderText {
        public Mutable pos = new Mutable();
        public String text;
        public int ticks;
        private final Vec3 vec3 = new Vec3();

        public BedUtils.RenderText set(BlockPos pos, String text) {
            this.text = text;
            this.pos.set(pos);
            this.ticks = 30;
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render2DEvent event, Color textColor) {
            if (this.text != null) {
                int preTextA = textColor.a;
                textColor.a = (int)((double)textColor.a * ((double)this.ticks / 5.0D));
                this.vec3.set((double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.2D, (double)this.pos.getZ() + 0.5D);
                if (NametagUtils.to2D(this.vec3, 1.5D)) {
                    NametagUtils.begin(this.vec3);
                    TextRenderer.get().begin(1.0D, false, true);
                    double w = TextRenderer.get().getWidth(this.text) / 2.0D;
                    TextRenderer.get().render(this.text, -w, 0.0D, textColor, true);
                    TextRenderer.get().end();
                    NametagUtils.end();
                }

                textColor.a = preTextA;
            }

        }
    }

    public static class RenderBreak {
        public Mutable pos = new Mutable();
        public int ticks;

        public BedUtils.RenderBreak set(BlockPos blockPos) {
            this.pos.set(blockPos);
            this.ticks = 50;
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
            if (this.pos != null) {
                int preSideA = sides.a;
                int preLineA = lines.a;
                sides.a = (int)((double)sides.a + ((double)this.ticks - 1.0D));
                lines.a = (int)((double)lines.a + ((double)this.ticks - 1.0D));
                event.renderer.box(this.pos, sides, lines, shapeMode, 0);
                sides.a = preSideA;
                lines.a = preLineA;
            }

        }
    }

    public static class RenderBlock {
        public Mutable pos = new Mutable();
        public CardinalDirection renderDir;
        public int ticks;

        public BedUtils.RenderBlock set(BlockPos blockPos, CardinalDirection dir) {
            this.renderDir = dir;
            this.pos.set(blockPos);
            this.ticks = 10;
            return this;
        }

        public void tick() {
            --this.ticks;
        }

        public void render(Render3DEvent event, Color sides, Color lines, ShapeMode shapeMode) {
            if (this.renderDir != null) {
                int x = this.pos.getX();
                int y = this.pos.getY();
                int z = this.pos.getZ();
                int preSideA = sides.a;
                int preLineA = lines.a;
                sides.a = (int)((double)sides.a * ((double)this.ticks / 5.0D));
                lines.a = (int)((double)lines.a * ((double)this.ticks / 5.0D));
                switch(this.renderDir) {
                    case South:
                        event.renderer.box((double)x, (double)y, (double)z, (double)(x + 1), (double)y + 0.56D, (double)(z + 2), sides, lines, shapeMode, 0);
                        break;
                    case North:
                        event.renderer.box((double)x, (double)y, (double)(z - 1), (double)(x + 1), (double)y + 0.56D, (double)(z + 1), sides, lines, shapeMode, 0);
                        break;
                    case West:
                        event.renderer.box((double)(x - 1), (double)y, (double)z, (double)(x + 1), (double)y + 0.56D, (double)(z + 1), sides, lines, shapeMode, 0);
                        break;
                    case East:
                        event.renderer.box((double)x, (double)y, (double)z, (double)(x + 2), (double)y + 0.56D, (double)(z + 1), sides, lines, shapeMode, 0);
                }

                sides.a = preSideA;
                lines.a = preLineA;
            }

        }
    }
}
