package delta.util;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.util.Hand;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;

public class StorageUtility {
    public static void putInStorage(ScreenHandler handler, int slot) {
        if (!invalidHandler(handler)) {
            int offset = getRows(handler) * 9;
            InvUtils.quickMove().slotId(offset + slot);
        }
    }

    private static boolean invalidHandler(ScreenHandler handler) {
        if (handler == null) {
            return true;
        } else {
            return !(handler instanceof GenericContainerScreenHandler) && !(handler instanceof ShulkerBoxScreenHandler);
        }
    }

    public static int getRows(ScreenHandler handler) {
        return handler instanceof GenericContainerScreenHandler ? ((GenericContainerScreenHandler)handler).getRows() : 3;
    }

    public static void openStorage(BlockPos pos, boolean swing) {
        MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, Hand.MAIN_HAND, new BlockHitResult(new Vec3d((double)pos.getX(), (double)pos.getY(), (double)pos.getZ()), Direction.UP, pos, false));
        if (swing) {
            MeteorClient.mc.player.swingHand(Hand.MAIN_HAND);
        }

    }
}
