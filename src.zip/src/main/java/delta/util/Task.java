package delta.util;

public class Task {
   private boolean called = false;

   public void run(Runnable task) {
      if (!this.isCalled()) {
         task.run();
         this.setCalled();
      }

   }

   public void reset() {
      this.called = false;
   }

   public boolean isCalled() {
      return this.called;
   }

   public void setCalled() {
      this.called = true;
   }
}
