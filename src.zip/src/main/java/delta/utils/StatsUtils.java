package delta.utils;

import delta.event.PlayerListChangeEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.PostInit;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.starscript.value.Value;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.client.network.PlayerListEntry;

public class StatsUtils {
    public static Integer kills = 0;
    private final Collection<PlayerListEntry> lastList = new ArrayList();
    public static Integer deaths = 0;
    public static Integer highScore = 0;
    public static Integer killStreak = 0;
    private static int ticksPassed;
    public static int crystalsPerSec;
    public static int first;

    @PostInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(StatsUtils.class);
    }

    public static Value getKills() {
        return Value.number((double)kills);
    }

    public static Value getDeaths() {
        return Value.number((double)kills);
    }

    public static Value getKDR() {
        return Value.string(KDR());
    }

    public static Value getKillstreak() {
        return Value.number((double)killStreak);
    }

    public static Value getHighscore() {
        return Value.number((double)highScore);
    }

    public static Value getCrystalsPs() {
        return Value.number((double)crystalsPerSec);
    }

    public static boolean isTarget() {
        Iterator var0 = Modules.get().getAll().iterator();

        Module module;
        do {
            if (!var0.hasNext()) {
                return false;
            }

            module = (Module)var0.next();
        } while(module.getInfoString() == null || !module.getInfoString().contains(EntityUtil.deadEntity.getEntityName()));

        return true;
    }

    @EventHandler
    private static void onReceivePacket(Receive event) {
        if (EntityUtil.isDeathPacket(event)) {
            Integer var1;
            if (EntityUtil.deadEntity == MeteorClient.mc.player) {
                var1 = deaths;
                deaths = deaths + 1;
                killStreak = 0;
            }

            if (isTarget()) {
                var1 = kills;
                kills = kills + 1;
                var1 = killStreak;
                killStreak = killStreak + 1;
                var1 = highScore;
                highScore = highScore + 1;
            }
        }

    }

    public static String KDR() {
        if (deaths < 2) {
            return kills + ".00";
        } else {
            Double doubleKD = (double)kills / (double)deaths;
            return String.format("%.2f", doubleKD);
        }
    }

    @EventHandler
    private static void onGameJoin(GameJoinedEvent event) {
        kills = 0;
        deaths = 0;
        highScore = 0;
        killStreak = 0;
    }

    @EventHandler
    private void onTick(Pre event) {
        if (Utils.canUpdate()) {
            if (!MeteorClient.mc.isInSingleplayer() && MeteorClient.mc.getNetworkHandler() != null) {
                Collection nowList = MeteorClient.mc.getNetworkHandler().getPlayerList();
                ArrayList<PlayerListEntry> tempList = new ArrayList(nowList);
                tempList.removeAll(this.lastList);
                tempList.forEach((player) -> {
                    MeteorClient.EVENT_BUS.post(PlayerListChangeEvent.Join.get(player));
                });
                this.lastList.removeAll(nowList);
                this.lastList.forEach((player) -> {
                    MeteorClient.EVENT_BUS.post(PlayerListChangeEvent.Leave.get(player));
                });
                this.lastList.clear();
                this.lastList.addAll(nowList);
            }

            if (ticksPassed < 21) {
                ++ticksPassed;
            } else {
                ticksPassed = 0;
            }

            if (ticksPassed == 1) {
                first = InvUtils.find(new Item[]{Items.END_CRYSTAL}).count();
            }

            if (ticksPassed == 21) {
                int second = InvUtils.find(new Item[]{Items.END_CRYSTAL}).count();
                int difference = -(second - first);
                crystalsPerSec = Math.max(0, difference);
            }

        }
    }
}
