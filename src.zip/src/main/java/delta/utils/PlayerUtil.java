package delta.utils;

import delta.util.PistonUtils;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.PositionAndOnGround;

public class PlayerUtil {
    public static double distanceFromEye(Entity entity) {
        double feet = distanceFromEye(entity.getX(), entity.getY(), entity.getZ());
        double head = distanceFromEye(entity.getX(), entity.getY() + (double)entity.getHeight(), entity.getZ());
        return Math.min(head, feet);
    }

    public static double distanceFromEye(double x, double y, double z) {
        double f = MeteorClient.mc.player.getX() - x;
        double g = MeteorClient.mc.player.getY() + (double)MeteorClient.mc.player.getEyeHeight(MeteorClient.mc.player.getPose()) - y;
        double h = MeteorClient.mc.player.getZ() - z;
        return Math.sqrt(f * f + g * g + h * h);
    }

    public static void unPress() {
        setPressed(MeteorClient.mc.options.forwardKey, false);
        setPressed(MeteorClient.mc.options.backKey, false);
        setPressed(MeteorClient.mc.options.leftKey, false);
        setPressed(MeteorClient.mc.options.rightKey, false);
    }

    public static void setPressed(KeyBinding key, boolean pressed) {
        key.setPressed(pressed);
        Input.setKeyState(key, pressed);
    }

    public static double squaredDistance(double x, double y, double z) {
        double f = MeteorClient.mc.player.getX() - x;
        double g = MeteorClient.mc.player.getY() - y;
        double h = MeteorClient.mc.player.getZ() - z;
        return f * f + g * g + h * h;
    }

    public static double distanceFromEye(BlockPos pos) {
        return distanceFromEye((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
    }

    public static double distanceFromEye(PistonUtils.PosDirPair pos) {
        return distanceFromEye(pos.pos());
    }

    public static Vec3d eyePos(PlayerEntity player) {
        return player.getPos().add(0.0D, (double)player.getEyeHeight(player.getPose()), 0.0D);
    }

    public static void sendPlayerMsg(String message) {
        MeteorClient.mc.inGameHud.getChatHud().addToMessageHistory(message);
        if (message.startsWith("/")) {
            MeteorClient.mc.player.sendCommand(message.substring(1), (Text)null);
        } else {
            MeteorClient.mc.player.sendChatMessage(message, (Text)null);
        }

    }

    public static void stopPlayer() {
        MeteorClient.mc.player.setVelocity(0.0D, 0.03D, 0.0D);
    }

    public static void centerTwo(double threshold) {
        MeteorClient.mc.player.setPosition((double)MeteorClient.mc.player.getBlockX() + MathHelper.clamp(MeteorClient.mc.player.getX() - (double)MeteorClient.mc.player.getBlockX(), threshold, 1.0D - threshold), MeteorClient.mc.player.getY(), (double)MeteorClient.mc.player.getBlockZ() + MathHelper.clamp(MeteorClient.mc.player.getZ() - (double)MeteorClient.mc.player.getBlockZ(), threshold, 1.0D - threshold));
    }

    public static void teleport(double x, double y, double z) {
        MeteorClient.mc.player.updatePosition(x, y, z);
        MeteorClient.mc.player.networkHandler.sendPacket(new PositionAndOnGround(x, y, z, false));
        MeteorClient.mc.player.setPosition(x, y, z);
    }

    public static void teleportVec(Vec3d pos) {
        teleport(pos.x, pos.y, pos.z);
    }

    public static boolean place(BlockPos blockPos, Hand hand, int slot, boolean checkEntities) {
        if (slot != -1 && BlockUtils.canPlace(blockPos, checkEntities)) {
            Direction side = BlockUtils.getPlaceSide(blockPos);
            Vec3d hitPos = new Vec3d(0.0D, 0.0D, 0.0D);
            BlockPos neighbour;
            if (side != null && side != Direction.UP) {
                neighbour = blockPos.offset(side.getOpposite());
                ((IVec3d)hitPos).set((double)neighbour.getX() + 0.5D + (double)side.getOffsetX() * 0.5D, (double)neighbour.getY() + 0.5D + (double)side.getOffsetY() * 0.5D, (double)neighbour.getZ() + 0.5D + (double)side.getOffsetZ() * 0.5D);
            } else {
                side = Direction.UP;
                neighbour = blockPos;
                hitPos = getCenter(blockPos);
            }

            place(slot, hitPos, hand, side, neighbour);
            return true;
        } else {
            return false;
        }
    }

    public static double horizontalSpeed() {
        return Math.sqrt(MeteorClient.mc.player.getVelocity().getX() * MeteorClient.mc.player.getVelocity().getX() + MeteorClient.mc.player.getVelocity().getZ() * MeteorClient.mc.player.getVelocity().getZ());
    }

    public static boolean isSurrounded(LivingEntity target, boolean doubles, boolean onlyBlastProof) {
        BlockPos blockPos = target.getBlockPos();
        int air = 0;
        Direction[] var5 = Direction.values();
        int var6 = var5.length;

        label60:
        for(int var7 = 0; var7 < var6; ++var7) {
            Direction direction = var5[var7];
            BlockState state;
            if (direction != Direction.UP && ((state = MeteorClient.mc.world.getBlockState(blockPos.offset(direction))).getMaterial().isReplaceable() || onlyBlastProof && state.getBlock().getBlastResistance() < 600.0F)) {
                if (doubles && direction != Direction.DOWN) {
                    ++air;
                    Direction[] var10 = Direction.values();
                    int var11 = var10.length;
                    int var12 = 0;

                    while(true) {
                        if (var12 >= var11) {
                            continue label60;
                        }

                        Direction dir = var10[var12];
                        BlockState state2;
                        if (dir != direction.getOpposite() && dir != Direction.UP && ((state2 = MeteorClient.mc.world.getBlockState(blockPos.offset(direction).offset(dir))).getMaterial().isReplaceable() || onlyBlastProof && state2.getBlock().getBlastResistance() < 600.0F)) {
                            return false;
                        }

                        ++var12;
                    }
                }

                return false;
            }
        }

        return air < 2;
    }

    public static boolean isElytraFlying() {
        return MeteorClient.mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA && MeteorClient.mc.player.isFallFlying();
    }

    public static void log(String text) {
        if (MeteorClient.mc.player != null) {
            MeteorClient.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(Text.literal(text)));
        }
    }

    public static void openElytras() {
        if (!MeteorClient.mc.player.isOnGround()) {
            MeteorClient.mc.options.jumpKey.setPressed(true);
            Input.setKeyState(MeteorClient.mc.options.jumpKey, true);
        }
    }

    public static void place(int slot, Vec3d hitPos, Hand hand, Direction side, BlockPos neighbour) {
        assert MeteorClient.mc.player != null;

        if (hand == Hand.MAIN_HAND) {
            MeteorClient.mc.player.getInventory().selectedSlot = slot;
        }

        boolean wasSneaking = MeteorClient.mc.player.input.sneaking;
        MeteorClient.mc.player.input.sneaking = false;
        MeteorClient.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(hand, new BlockHitResult(hitPos, side, neighbour, false), 0));
        MeteorClient.mc.player.swingHand(Hand.MAIN_HAND);
        MeteorClient.mc.player.input.sneaking = wasSneaking;
    }

    public static Vec3d getCenter(BlockPos block) {
        return (new Vec3d((double)block.getX(), (double)block.getY(), (double)block.getZ())).add(0.5D, 0.5D, 0.5D);
    }
}
