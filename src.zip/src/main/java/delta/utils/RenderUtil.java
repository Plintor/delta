package delta.utils;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.util.math.BlockPos;

public class RenderUtil {
    public static void FS(Render3DEvent event, BlockPos pos, double y, boolean top, boolean bottom, Color c1, Color c2) {
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ(), c1, c2);
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)pos.getZ(), (double)pos.getX(), (double)(pos.getY() + 1), (double)(pos.getZ() + 1), c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ(), c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)pos.getX(), (double)(pos.getY() + 1), (double)(pos.getZ() + 1), c1, c2);
        if (top) {
            event.renderer.quadHorizontal((double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getZ() + 1), c1);
        }

        if (bottom) {
            event.renderer.quadHorizontal((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getZ() + 1), c1);
        }

    }

    public static void S(Render3DEvent event, BlockPos pos, double x, double y, double z, Color c1, Color c2) {
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)pos.getZ(), (double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ() + z, c1, c2);
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)pos.getZ(), (double)pos.getX() + z, (double)(pos.getY() + 1), (double)pos.getZ(), c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ() + z, c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)pos.getZ(), (double)pos.getX() + x, (double)(pos.getY() + 1), (double)pos.getZ(), c1, c2);
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ() + x, c1, c2);
        event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)pos.getX() + z, (double)(pos.getY() + 1), (double)(pos.getZ() + 1), c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ() + x, c1, c2);
        event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY() + y, (double)(pos.getZ() + 1), (double)pos.getX() + x, (double)(pos.getY() + 1), (double)(pos.getZ() + 1), c1, c2);
    }

    public static void TAB(Render3DEvent event, BlockPos pos, double x, double z, boolean top, boolean down, Color c1, Color c2) {
        if (top) {
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getY() + x, (double)pos.getZ(), c1, c1);
            event.renderer.quadHorizontal((double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getZ() + z, c1);
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ(), (double)pos.getX(), (double)pos.getY() + x, (double)(pos.getZ() + 1), c1, c1);
            event.renderer.quadHorizontal((double)pos.getX(), (double)(pos.getY() + 1), (double)pos.getZ(), (double)pos.getX() + z, (double)(pos.getZ() + 1), c1);
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)(pos.getY() + 1), (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)pos.getY() + x, (double)(pos.getZ() + 1), c1, c1);
            event.renderer.quadHorizontal((double)pos.getX(), (double)(pos.getY() + 1), (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)pos.getZ() + x, c1);
            event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getY() + x, (double)(pos.getZ() + 1), c1, c1);
            event.renderer.quadHorizontal((double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)pos.getZ(), (double)pos.getX() + x, (double)(pos.getZ() + 1), c1);
        }

        if (down) {
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getY() + z, (double)pos.getZ(), c2, c2);
            event.renderer.quadHorizontal((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getZ() + z, c2);
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)pos.getX(), (double)pos.getY() + z, (double)(pos.getZ() + 1), c2, c2);
            event.renderer.quadHorizontal((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)pos.getX() + z, (double)(pos.getZ() + 1), c2);
            event.renderer.gradientQuadVertical((double)pos.getX(), (double)pos.getY(), (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)pos.getY() + z, (double)(pos.getZ() + 1), c2, c2);
            event.renderer.quadHorizontal((double)pos.getX(), (double)pos.getY(), (double)(pos.getZ() + 1), (double)(pos.getX() + 1), (double)pos.getZ() + x, c2);
            event.renderer.gradientQuadVertical((double)(pos.getX() + 1), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)pos.getY() + z, (double)(pos.getZ() + 1), c2, c2);
            event.renderer.quadHorizontal((double)(pos.getX() + 1), (double)pos.getY(), (double)pos.getZ(), (double)pos.getX() + x, (double)(pos.getZ() + 1), c2);
        }

    }
}
