package delta.utils;

import com.sun.jna.Platform;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.utils.PostInit;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.orbit.EventHandler;

public class AntiNarrator {
   @PostInit
   public static void init() {
      MeteorClient.EVENT_BUS.subscribe(AntiNarrator.class);
   }

   @EventHandler
   private static void onKey(KeyEvent event) {
      if (Input.isKeyPressed(66) && Input.isKeyPressed(343) && Platform.isMac()) {
         event.cancel();
      } else if (Input.isKeyPressed(66) && Input.isKeyPressed(341)) {
         event.cancel();
      }

   }
}
