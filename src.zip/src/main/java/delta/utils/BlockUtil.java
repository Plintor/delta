package delta.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.modules.player.AutoTool;
import meteordevelopment.meteorclient.systems.modules.player.AutoTool.EnchantPreference;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.util.math.Box;
import net.minecraft.block.NoteBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.ShapeContext;

public class BlockUtil {
    private static final Vec3d hitPos = new Vec3d(0.0D, 0.0D, 0.0D);

    public static boolean isSurroundBlock(BlockPos p) {
        Iterator var1 = EntityUtil.getSurroundBlocks(MeteorClient.mc.player).iterator();

        BlockPos pos;
        do {
            if (!var1.hasNext()) {
                return false;
            }

            pos = (BlockPos)var1.next();
        } while(!p.equals(pos));

        return true;
    }

    public static boolean isLava(BlockPos pos) {
        return MeteorClient.mc.world.getBlockState(pos).isOf(Blocks.LAVA);
    }

    public static boolean isWater(BlockPos pos) {
        return MeteorClient.mc.world.getBlockState(pos).isOf(Blocks.WATER);
    }

    public static void mineBlock(BlockPos pos, boolean swing, boolean rotate) {
        FindItemResult pick = InvUtil.findPick();
        if (pick.found()) {
            InvUtils.swap(pick.slot(), false);
        }

        if (rotate) {
            ((IVec3d)hitPos).set((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D);
            Rotations.rotate(Rotations.getYaw(hitPos), Rotations.getPitch(hitPos), 100, () -> {
                BlockUtils.breakBlock(pos, swing);
            });
        } else {
            BlockUtils.breakBlock(pos, swing);
        }

    }

    public static void breakAT(BlockPos pos, boolean swing, boolean rotate) {
        if (isBreakable(pos)) {
            BlockState blockState = MeteorClient.mc.world.getBlockState(pos);
            ItemStack currentStack = MeteorClient.mc.player.getMainHandStack();
            double bestScore = -1.0D;
            int bestSlot = -1;

            for(int i = 0; i < 9; ++i) {
                ItemStack itemStack = MeteorClient.mc.player.getInventory().getStack(i);
                double score = AutoTool.getScore(itemStack, blockState, true, EnchantPreference.SilkTouch, (itemStack2) -> {
                    return false;
                });
                if (!(score < 0.0D) && score > bestScore) {
                    bestScore = score;
                    bestSlot = i;
                }
            }

            if (bestSlot != -1 && bestScore > AutoTool.getScore(currentStack, blockState, true, EnchantPreference.SilkTouch, (itemStackx) -> {
                return true;
            }) || !AutoTool.isTool(currentStack)) {
                InvUtils.swap(bestSlot, true);
            }

            if (rotate) {
                ((IVec3d)hitPos).set((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D);
                Rotations.rotate(Rotations.getYaw(hitPos), Rotations.getPitch(hitPos), 100, () -> {
                    BlockUtils.breakBlock(pos, swing);
                });
            } else {
                BlockUtils.breakBlock(pos, swing);
            }

        }
    }

    public static boolean isAir(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).isAir();
    }

    public static Block getBlock(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).getBlock();
    }

    public static boolean inPlaceRange(BlockPos pos, BlockUtil.Origin origin, double range) {
        if (origin == BlockUtil.Origin.VANILLA) {
            return !(MeteorClient.mc.player.squaredDistanceTo((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D) >= range * range);
        } else {
            Vec3d eyesPos = PlayerUtil.eyePos(MeteorClient.mc.player);
            double dx = eyesPos.x - (double)pos.getX() - 0.5D;
            double dz;
            double dy;
            return !(dx * dx + (dy = eyesPos.y - (double)pos.getY() - 0.5D) * dy + (dz = eyesPos.z - (double)pos.getZ() - 0.5D) * dz > range * range);
        }
    }

    public static boolean isFullBlock(BlockPos pos) {
        return MeteorClient.mc.world.getBlockState(pos).isFullCube(MeteorClient.mc.world, pos);
    }

    public static Vec3d getCenterVec3d(BlockPos block) {
        return new Vec3d((double)block.getX() + 0.5D, (double)block.getY() + 0.5D, (double)block.getZ() + 0.5D);
    }

    public static double horizontalDistance(Vec3d vec1, Vec3d vec2) {
        double dx = vec1.x - vec2.x;
        double dz = vec1.z - vec2.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static double horizontalDistance(BlockPos vec1, BlockPos vec2) {
        double dx = (double)(vec1.getX() - vec2.getX());
        double dz = (double)(vec1.getZ() - vec2.getZ());
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static BlockState getState(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos);
    }

    public static float getHardness(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).getHardness(MeteorClient.mc.world, blockPos);
    }

    public static boolean isNull(BlockPos block) {
        return block == null;
    }

    public static boolean isWithinRange(BlockPos block, double range) {
        return MeteorClient.mc.player.getBlockPos().isWithinDistance(block, range);
    }

    public static Vec3d closestVec3d(BlockPos blockpos) {
        if (blockpos == null) {
            return new Vec3d(0.0D, 0.0D, 0.0D);
        } else {
            double x = MathHelper.clamp(MeteorClient.mc.player.getX() - (double)blockpos.getX(), 0.0D, 1.0D);
            double y = MathHelper.clamp(MeteorClient.mc.player.getY() - (double)blockpos.getY(), 0.0D, 0.6D);
            double z = MathHelper.clamp(MeteorClient.mc.player.getZ() - (double)blockpos.getZ(), 0.0D, 1.0D);
            return new Vec3d((double)blockpos.getX() + x, (double)blockpos.getY() + y, (double)blockpos.getZ() + z);
        }
    }

    public static float getBlastResistance(BlockPos block) {
        return MeteorClient.mc.world.getBlockState(block).getBlock().getBlastResistance();
    }

    public static boolean isBlastResist(BlockPos block) {
        return getBlastResistance(block) >= 600.0F;
    }

    public static boolean isBlastResist(BlockPos pos, BlockUtil.BlastResistantType type) {
        return isBlastResist(MeteorClient.mc.world.getBlockState(pos).getBlock(), type);
    }

    public static boolean isBlastResist(Block block, BlockUtil.BlastResistantType type) {
        switch(type) {
            case Any:
            case Mineable:
                return block == Blocks.OBSIDIAN || block == Blocks.CRYING_OBSIDIAN || block instanceof AnvilBlock || block == Blocks.NETHERITE_BLOCK || block == Blocks.ENDER_CHEST || block == Blocks.RESPAWN_ANCHOR || block == Blocks.ANCIENT_DEBRIS || block == Blocks.ENCHANTING_TABLE || block == Blocks.BEDROCK && type == BlockUtil.BlastResistantType.Any || block == Blocks.END_PORTAL_FRAME && type == BlockUtil.BlastResistantType.Any;
            case Unbreakable:
                return block == Blocks.BEDROCK || block == Blocks.END_PORTAL_FRAME;
            case AnyBlock:
                return block != Blocks.AIR;
            default:
                return false;
        }
    }

    public static boolean isReplaceable(BlockPos pos) {
        return MeteorClient.mc.world.getBlockState(pos).getMaterial().isReplaceable();
    }

    public static boolean isCombatBlock(BlockPos block) {
        return isBlastResist(block) && isBreakable(block);
    }

    public static boolean isBreakable(BlockPos pos) {
        if (pos == null) {
            return false;
        } else {
            return getHardness(pos) > 0.0F && !MeteorClient.mc.world.getBlockState(pos).getMaterial().isLiquid();
        }
    }

    public static boolean canPlace(BlockPos blockPos, boolean checkEntities) {
        if (blockPos == null) {
            return false;
        } else if (blockPos.getY() <= 319 && blockPos.getY() >= -64) {
            if (!isReplaceable(blockPos)) {
                return false;
            } else {
                return !checkEntities || MeteorClient.mc.world.canPlace(Blocks.STONE.getDefaultState(), blockPos, ShapeContext.absent());
            }
        } else {
            return false;
        }
    }

    public static boolean isClickable(Block block) {
        return block instanceof CraftingTableBlock || block instanceof AnvilBlock || block instanceof AbstractButtonBlock || block instanceof AbstractPressurePlateBlock || block instanceof BlockWithEntity || block instanceof BedBlock || block instanceof FenceGateBlock || block instanceof DoorBlock || block instanceof NoteBlock || block instanceof TrapdoorBlock;
    }

    public static List<BlockPos> getSphere(BlockPos centerPos, int radius, int height) {
        ArrayList<BlockPos> blocks = new ArrayList();

        for(int i = centerPos.getX() - radius; i < centerPos.getX() + radius; ++i) {
            for(int j = centerPos.getY() - height; j < centerPos.getY() + height; ++j) {
                for(int k = centerPos.getZ() - radius; k < centerPos.getZ() + radius; ++k) {
                    BlockPos pos = new BlockPos(i, j, k);
                    if (distance(centerPos, pos) <= (double)radius && !blocks.contains(pos)) {
                        blocks.add(pos);
                    }
                }
            }
        }

        return blocks;
    }

    public static VoxelShape getShape(BlockPos block) {
        return getState(block).getOutlineShape(MeteorClient.mc.world, block);
    }

    public static Box getBox(BlockPos block) {
        return getShape(block).getBoundingBox();
    }

    public static double distance(BlockPos block1, BlockPos block2) {
        double dX = (double)(block2.getX() - block1.getX());
        double dY = (double)(block2.getY() - block1.getY());
        double dZ = (double)(block2.getZ() - block1.getZ());
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

    public static double distance(Vec3d vec1, Vec3d vec2) {
        double dX = vec2.x - vec1.x;
        double dY = vec2.y - vec1.y;
        double dZ = vec2.z - vec1.z;
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

    public static double distanceXZ(Vec3d pos1, Vec3d pos2) {
        double dX = pos1.getX() - pos2.getX();
        double dZ = pos1.getZ() - pos2.getZ();
        return (double)MathHelper.sqrt((float)(dX * dX + dZ * dZ));
    }

    public static double distanceY(double y1, double y2) {
        return Math.abs(y1 - y2);
    }

    public static enum Origin {
        VANILLA;

        // $FF: synthetic method
        private static BlockUtil.Origin[] $values() {
            return new BlockUtil.Origin[]{VANILLA};
        }
    }

    public static enum BlastResistantType {
        Any,
        Unbreakable,
        Mineable,
        AnyBlock;

        // $FF: synthetic method
        private static BlockUtil.BlastResistantType[] $values() {
            return new BlockUtil.BlastResistantType[]{Any, Unbreakable, Mineable, AnyBlock};
        }
    }
}
