package delta.utils;

import meteordevelopment.meteorclient.utils.world.TickRate;

public class TimerUtils {
   private long nanoTime = -1L;
   private long time = System.currentTimeMillis();

   public void reset() {
      this.time = System.currentTimeMillis();
      this.nanoTime = System.nanoTime();
   }

   public void setTicks(long ticks) {
      this.nanoTime = System.nanoTime() - this.convertTicksToNano(ticks);
   }

   public long getTicks() {
      return this.convertNanoToTicks(this.nanoTime);
   }

   public boolean hasPassed(double ms) {
      return (double)(System.currentTimeMillis() - this.time) >= ms;
   }

   public boolean passedNano(long time) {
      return System.nanoTime() - this.nanoTime >= time;
   }

   public boolean passedMillis(long time) {
      return this.passedNano(this.convertMillisToNano(time));
   }

   public boolean passedTicks(long ticks) {
      return this.passedNano(this.convertTicksToNano(ticks));
   }

   public long convertMillisToTicks(long time) {
      return time / 50L;
   }

   public long convertTicksToMillis(long ticks) {
      return ticks * 50L;
   }

   public long convertNanoToTicks(long time) {
      return this.convertMillisToTicks(this.convertNanoToMillis(time));
   }

   public long convertTicksToNano(long ticks) {
      return this.convertMillisToNano(this.convertTicksToMillis(ticks));
   }

   public long convertMillisToMicro(long time) {
      return time * 1000L;
   }

   public long convertMillisToNano(long time) {
      return this.convertMicroToNano(this.convertMillisToMicro(time));
   }

   public long convertMicroToNano(long time) {
      return time * 1000L;
   }

   public long convertNanoToMicro(long time) {
      return time / 1000L;
   }

   public long convertNanoToMillis(long time) {
      return this.convertMicroToMillis(this.convertNanoToMicro(time));
   }

   public long convertMicroToMillis(long time) {
      return time / 1000L;
   }

   public static double getTPSMatch(boolean TPSSync) {
      return TPSSync ? (double)(TickRate.INSTANCE.getTickRate() / 20.0F) : 1.0D;
   }
}
