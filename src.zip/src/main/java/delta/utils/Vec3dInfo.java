package delta.utils;

import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class Vec3dInfo {
    public static boolean isInRange(Vec3d vec3d, double radius) {
        return vec3d.isInRange(vec3d, radius);
    }

    public static boolean isWithinRange(Vec3d vec3d, double range) {
        return MeteorClient.mc.player.getBlockPos().isWithinDistance(vec3d, range);
    }

    public static Vec3d add(Vec3d vec3d, Vec3d added) {
        return new Vec3d(vec3d.add(added).getX(), vec3d.add(added).getY(), vec3d.add(added).getZ());
    }

    public static Vec3d add(Vec3d vec3d, double x, double y, double z) {
        return new Vec3d(vec3d.add(x, y, z).getX(), vec3d.add(x, y, z).getY(), vec3d.add(x, y, z).getZ());
    }

    public static Vec3d closestVec3d(BlockPos blockpos) {
        if (blockpos == null) {
            return new Vec3d(0.0D, 0.0D, 0.0D);
        } else {
            double x = MathHelper.clamp(MeteorClient.mc.player.getX() - (double)blockpos.getX(), 0.0D, 1.0D);
            double y = MathHelper.clamp(MeteorClient.mc.player.getY() - (double)blockpos.getY(), 0.0D, 0.6D);
            double z = MathHelper.clamp(MeteorClient.mc.player.getZ() - (double)blockpos.getZ(), 0.0D, 1.0D);
            return new Vec3d((double)blockpos.getX() + x, (double)blockpos.getY() + y, (double)blockpos.getZ() + z);
        }
    }

    public static Vec3d xzAdd(Vec3d fi, Vec3d se, int amount) {
        return fi.add(se.getX() * (double)amount, 0.0D, se.getZ() * (double)amount);
    }
}
