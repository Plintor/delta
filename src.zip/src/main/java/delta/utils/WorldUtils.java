package delta.utils;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.util.Hand;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.world.World;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.block.LoomBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.block.CartographyTableBlock;
import net.minecraft.block.GrindstoneBlock;
import net.minecraft.block.StonecutterBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;

public class WorldUtils {
    private static final Vec3d hitPos = new Vec3d(0.0D, 0.0D, 0.0D);

    public static boolean place(BlockPos blockPos, FindItemResult findItemResult, boolean rotate, boolean swingHand) {
        return place(blockPos, findItemResult, rotate, 81, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, false, WorldUtils.AirPlaceDirection.Down, swingHand, true, true);
    }

    public static boolean place(BlockPos blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority, boolean onlyAirPlace, boolean swingHand, boolean checkEntities, boolean swapBack) {
        return place(blockPos, findItemResult, rotate, rotationPriority, WorldUtils.SwitchMode.Both, WorldUtils.PlaceMode.Both, onlyAirPlace, WorldUtils.AirPlaceDirection.Down, swingHand, checkEntities, swapBack);
    }

    public static boolean place(BlockPos blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority, WorldUtils.SwitchMode switchMode, WorldUtils.PlaceMode placeMode, boolean onlyAirplace, WorldUtils.AirPlaceDirection airPlaceDirection, boolean swingHand, boolean checkEntities, boolean swapBack) {
        if (findItemResult.found() && blockPos != null) {
            if (findItemResult.isOffhand()) {
                return place(blockPos, Hand.OFF_HAND, MeteorClient.mc.player.getInventory().selectedSlot, MeteorClient.mc.player.getInventory().selectedSlot, rotate, rotationPriority, switchMode, placeMode, onlyAirplace, airPlaceDirection, swingHand, checkEntities, swapBack);
            } else {
                return findItemResult.isHotbar() ? place(blockPos, Hand.MAIN_HAND, MeteorClient.mc.player.getInventory().selectedSlot, findItemResult.slot(), rotate, rotationPriority, switchMode, placeMode, onlyAirplace, airPlaceDirection, swingHand, checkEntities, swapBack) : false;
            }
        } else {
            return false;
        }
    }

    public static boolean place(BlockPos blockPos, Hand hand, int oldSlot, int targetSlot, boolean rotate, int rotationPriority, WorldUtils.SwitchMode switchMode, WorldUtils.PlaceMode placeMode, boolean onlyAirplace, WorldUtils.AirPlaceDirection airPlaceDirection, boolean swingHand, boolean checkEntities, boolean swapBack) {
        if (targetSlot >= 0 && targetSlot <= 8) {
            if (!canPlace(blockPos, checkEntities)) {
                return false;
            } else {
                ((IVec3d)hitPos).set((double)blockPos.getX() + 0.5D, (double)blockPos.getY() + 0.5D, (double)blockPos.getZ() + 0.5D);
                Direction side = getPlaceSide(blockPos);
                BlockPos neighbour;
                if (side != null && !onlyAirplace) {
                    neighbour = blockPos.offset(side.getOpposite());
                    hitPos.add((double)side.getOffsetX() * 0.5D, (double)side.getOffsetY() * 0.5D, (double)side.getOffsetZ() * 0.5D);
                } else {
                    if (airPlaceDirection == WorldUtils.AirPlaceDirection.Up) {
                        side = Direction.UP;
                    } else {
                        side = Direction.DOWN;
                    }

                    neighbour = blockPos;
                }

                if (rotate) {
                    Rotations.rotate(Rotations.getYaw(hitPos), Rotations.getPitch(hitPos), rotationPriority, () -> {
                        place(new BlockHitResult(hitPos, side, neighbour, false), hand, oldSlot, targetSlot, switchMode, placeMode, swingHand, swapBack);
                    });
                } else {
                    place(new BlockHitResult(hitPos, side, neighbour, false), hand, oldSlot, targetSlot, switchMode, placeMode, swingHand, swapBack);
                }

                return true;
            }
        } else {
            return false;
        }
    }

    private static void place(BlockHitResult blockHitResult, Hand hand, int oldSlot, int targetSlot, WorldUtils.SwitchMode switchMode, WorldUtils.PlaceMode placeMode, boolean swing, boolean swapBack) {
        assert MeteorClient.mc.player != null;

        MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.PRESS_SHIFT_KEY));
        if (switchMode != WorldUtils.SwitchMode.Client) {
            MeteorClient.mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(targetSlot));
        }

        if (switchMode != WorldUtils.SwitchMode.Packet) {
            InvUtils.swap(targetSlot, swapBack);
        }

        if (placeMode != WorldUtils.PlaceMode.Client) {
            MeteorClient.mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(hand, blockHitResult, 0));
        }

        if (placeMode != WorldUtils.PlaceMode.Packet) {
            MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, blockHitResult);
        }

        if (swing) {
            MeteorClient.mc.player.swingHand(hand);
        } else {
            MeteorClient.mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(hand));
        }

        if (swapBack) {
            if (switchMode != WorldUtils.SwitchMode.Client) {
                MeteorClient.mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(oldSlot));
            }

            if (switchMode != WorldUtils.SwitchMode.Packet) {
                InvUtils.swapBack();
            }
        }

        MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.RELEASE_SHIFT_KEY));
    }

    public static boolean canPlace(BlockPos blockPos, boolean checkEntities) {
        if (!World.isValid(blockPos)) {
            return false;
        } else if (!MeteorClient.mc.world.getBlockState(blockPos).getMaterial().isReplaceable()) {
            return false;
        } else {
            return !checkEntities || MeteorClient.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), blockPos, ShapeContext.absent());
        }
    }

    public static Direction getPlaceSide(BlockPos blockPos) {
        Direction[] var1 = Direction.values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            Direction side = var1[var3];
            BlockPos neighbor = blockPos.offset(side);
            Direction side2 = side.getOpposite();
            BlockState state = MeteorClient.mc.world.getBlockState(neighbor);
            if (!state.isAir() && !isClickable(state.getBlock()) && state.getFluidState().isEmpty()) {
                return side2;
            }
        }

        return null;
    }

    public static boolean isClickable(Block block) {
        return block instanceof CraftingTableBlock || block instanceof AnvilBlock || block instanceof AbstractButtonBlock || block instanceof AbstractPressurePlateBlock || block instanceof BlockWithEntity || block instanceof BedBlock || block instanceof FenceGateBlock || block instanceof DoorBlock || block instanceof NoteBlock || block instanceof TrapdoorBlock || block instanceof LoomBlock || block instanceof CartographyTableBlock || block instanceof GrindstoneBlock || block instanceof StonecutterBlock;
    }

    public static void rotate(float yaw, float pitch) {
        MeteorClient.mc.player.setYaw(yaw);
        MeteorClient.mc.player.setPitch(pitch);
    }

    public static BlockPos roundBlockPos(Vec3d vec) {
        return new BlockPos(vec.x, (double)((int)Math.round(vec.y)), vec.z);
    }

    public static boolean doesBoxTouchBlock(Box box, Block block) {
        for(int x = (int)Math.floor(box.minX); (double)x < Math.ceil(box.maxX); ++x) {
            for(int y = (int)Math.floor(box.minY); (double)y < Math.ceil(box.maxY); ++y) {
                for(int z = (int)Math.floor(box.minZ); (double)z < Math.ceil(box.maxZ); ++z) {
                    if (MeteorClient.mc.world.getBlockState(new BlockPos(x, y, z)).getBlock() == block) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public static void spawnLightning(double x, double y, double z) {
        LightningEntity lightning = new LightningEntity(EntityType.LIGHTNING_BOLT, MeteorClient.mc.world);
        lightning.updatePosition(x, y, z);
        lightning.refreshPositionAfterTeleport(x, y, z);
        MeteorClient.mc.world.addEntity(lightning.getId(), lightning);
    }

    public static enum SwitchMode {
        Packet,
        Client,
        Both;

        // $FF: synthetic method
        private static WorldUtils.SwitchMode[] $values() {
            return new WorldUtils.SwitchMode[]{Packet, Client, Both};
        }
    }

    public static enum PlaceMode {
        Packet,
        Client,
        Both;

        // $FF: synthetic method
        private static WorldUtils.PlaceMode[] $values() {
            return new WorldUtils.PlaceMode[]{Packet, Client, Both};
        }
    }

    public static enum AirPlaceDirection {
        Up,
        Down;

        // $FF: synthetic method
        private static WorldUtils.AirPlaceDirection[] $values() {
            return new WorldUtils.AirPlaceDirection[]{Up, Down};
        }
    }
}
