package delta.utils;

import java.util.Iterator;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.mixininterface.IExplosion;
import meteordevelopment.meteorclient.mixininterface.IRaycastContext;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.PostInit;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.Dimension;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.world.BlockView;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.GameMode;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.world.explosion.Explosion.DestructionType;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class DamageUtil {
    private static final Vec3d vec3d = new Vec3d(0.0D, 0.0D, 0.0D);
    private static Explosion explosion;
    private static RaycastContext raycastContext;

    @PostInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(DamageUtil.class);
    }

    @EventHandler
    private static void onGameJoined(GameJoinedEvent event) {
        explosion = new Explosion(MeteorClient.mc.world, (Entity)null, 0.0D, 0.0D, 0.0D, 6.0F, false, DestructionType.DESTROY);
        raycastContext = new RaycastContext((Vec3d)null, (Vec3d)null, ShapeType.COLLIDER, FluidHandling.ANY, MeteorClient.mc.player);
    }

    public static float crystalDamage(PlayerEntity player, Vec3d crystal, boolean predictMovement, double explosionRadius, boolean ignoreTerrain, boolean fullBlocks) {
        if (player == null) {
            return 0.0F;
        } else if (EntityUtils.getGameMode(player) == GameMode.CREATIVE && !(player instanceof FakePlayerEntity) && player != MeteorClient.mc.player) {
            return 0.0F;
        } else {
            ((IVec3d)vec3d).set(player.getPos().x, player.getPos().y, player.getPos().z);
            if (predictMovement) {
                ((IVec3d)vec3d).set(vec3d.x + player.getVelocity().x, vec3d.y + player.getVelocity().y, vec3d.z + player.getVelocity().z);
            }

            float modDistance = (float)Math.sqrt(vec3d.squaredDistanceTo(crystal));
            if ((double)modDistance > explosionRadius) {
                return 0.0F;
            } else {
                float exposure = getExposure(crystal, player, predictMovement, raycastContext, ignoreTerrain, fullBlocks);
                float impact = (1.0F - modDistance / 12.0F) * exposure;
                float damage = (impact * impact + impact) * 42.0F + 1.0F;
                damage = getDamageForDifficulty(damage);
                damage = DamageUtil.getDamageLeft(damage, (float)player.getArmor(), (float)player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue());
                damage = resistanceReduction(player, damage);
                ((IExplosion)explosion).set(crystal, 6.0F, false);
                damage = blastProtReduction(player, damage, explosion);
                return damage < 0.0F ? 0.0F : damage;
            }
        }
    }

    public static float crystalDamage(PlayerEntity player, Vec3d crystal, double explosionRadius) {
        return crystalDamage(player, crystal, false, explosionRadius, false, false);
    }

    public static float bedDamage(PlayerEntity player, Vec3d bed, boolean predictMovement, boolean ignoreTerrain, boolean fullBlocks) {
        if (EntityUtils.getGameMode(player) == GameMode.CREATIVE && !(player instanceof FakePlayerEntity)) {
            return 0.0F;
        } else {
            ((IVec3d)vec3d).set(player.getPos().x, player.getPos().y, player.getPos().z);
            if (predictMovement) {
                ((IVec3d)vec3d).set(vec3d.x + player.getVelocity().x, vec3d.y + player.getVelocity().y, vec3d.z + player.getVelocity().z);
            }

            float modDistance = (float)Math.sqrt(player.squaredDistanceTo(bed));
            float exposure = getExposure(bed, player, predictMovement, raycastContext, ignoreTerrain, fullBlocks);
            float impact = (1.0F - modDistance * 0.1F) * exposure;
            float damage = (impact * impact + impact) * 35.0F + 1.0F;
            damage = getDamageForDifficulty(damage);
            damage = DamageUtil.getDamageLeft(damage, (float)player.getArmor(), (float)player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue());
            damage = resistanceReduction(player, damage);
            ((IExplosion)explosion).set(bed, 5.0F, true);
            damage = blastProtReduction(player, damage, explosion);
            return damage < 0.0F ? 0.0F : damage;
        }
    }

    public static float bedDamage(PlayerEntity player, Vec3d bed) {
        return bedDamage(player, bed, false, false, false);
    }

    public static float getSwordDamage(PlayerEntity entity, boolean charged) {
        float damage = 0.0F;
        if (charged) {
            if (entity.getActiveItem().getItem() == Items.NETHERITE_SWORD) {
                damage += 8.0F;
            } else if (entity.getActiveItem().getItem() == Items.DIAMOND_SWORD) {
                damage += 7.0F;
            } else if (entity.getActiveItem().getItem() == Items.GOLDEN_SWORD) {
                damage += 4.0F;
            } else if (entity.getActiveItem().getItem() == Items.IRON_SWORD) {
                damage += 6.0F;
            } else if (entity.getActiveItem().getItem() == Items.STONE_SWORD) {
                damage += 5.0F;
            } else if (entity.getActiveItem().getItem() == Items.WOODEN_SWORD) {
                damage += 4.0F;
            }

            damage = (float)((double)damage * 1.5D);
        }

        int strength;
        if (entity.getActiveItem().getEnchantments() != null && EnchantmentHelper.get(entity.getActiveItem()).containsKey(Enchantments.SHARPNESS)) {
            strength = EnchantmentHelper.getLevel(Enchantments.SHARPNESS, entity.getActiveItem());
            damage = (float)((double)damage + 0.5D * (double)strength + 0.5D);
        }

        if (entity.getActiveStatusEffects().containsKey(StatusEffects.STRENGTH)) {
            strength = ((StatusEffectInstance)Objects.requireNonNull(entity.getStatusEffect(StatusEffects.STRENGTH))).getAmplifier() + 1;
            damage += (float)(3 * strength);
        }

        damage = resistanceReduction(entity, damage);
        damage = DamageUtil.getDamageLeft(damage, (float)entity.getArmor(), (float)entity.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue());
        damage = normalProtReduction(entity, damage);
        return damage < 0.0F ? 0.0F : damage;
    }

    public static double anchorDamage(PlayerEntity player, BlockPos pos, boolean ignoreTerrain) {
        if (player != null && !player.getAbilities().creativeMode) {
            Vec3d position = Vec3d.ofCenter(pos);
            if (explosion == null) {
                explosion = new Explosion(MeteorClient.mc.world, (Entity)null, position.x, position.y, position.z, 5.0F, true, DestructionType.DESTROY);
            } else {
                ((IExplosion)explosion).set(position, 5.0F, true);
            }

            double distance = Math.sqrt(player.squaredDistanceTo(position));
            if (distance > 10.5D) {
                return 0.0D;
            } else {
                if (raycastContext == null) {
                    raycastContext = new RaycastContext((Vec3d)null, (Vec3d)null, ShapeType.COLLIDER, FluidHandling.ANY, MeteorClient.mc.player);
                }

                double exposure = getAnchorExposure(position, player, raycastContext, pos, ignoreTerrain);
                double impact = (1.0D - distance / 10.0D) * exposure;
                double damage = (impact * impact + impact) / 2.0D * 7.0D * 10.0D + 1.0D;
                EntityAttributeInstance attribute = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
                damage = (double)getDamageForDifficulty((float)damage);
                damage = (double)resistanceReduction(player, (float)damage);
                damage = (double)DamageUtil.getDamageLeft((float)damage, (float)player.getArmor(), attribute != null ? (float)attribute.getValue() : 0.0F);
                damage = (double)blastProtReduction(player, (float)damage, explosion);
                return damage < 0.0D ? 0.0D : damage;
            }
        } else {
            return 0.0D;
        }
    }

    private static double getAnchorExposure(Vec3d source, Entity entity, RaycastContext context, BlockPos pos, boolean ignoreTerrain) {
        Box box = entity.getBoundingBox();
        double xFactor = 1.0D / ((box.maxX - box.minX) * 2.0D + 1.0D);
        double yFactor = 1.0D / ((box.maxY - box.minY) * 2.0D + 1.0D);
        double zFactor = 1.0D / ((box.maxZ - box.minZ) * 2.0D + 1.0D);
        double dX = (1.0D - Math.floor(1.0D / xFactor) * xFactor) / 2.0D;
        double dZ = (1.0D - Math.floor(1.0D / zFactor) * zFactor) / 2.0D;
        if (xFactor >= 0.0D && yFactor >= 0.0D && zFactor >= 0.0D) {
            int miss = 0;
            int hit = 0;

            for(double x = 0.0D; x <= 1.0D; x += xFactor) {
                for(double y = 0.0D; y <= 1.0D; y += yFactor) {
                    for(double z = 0.0D; z <= 1.0D; z += zFactor) {
                        double nX = MathHelper.lerp(x, box.minX, box.maxX);
                        double nY = MathHelper.lerp(y, box.minY, box.maxY);
                        double nZ = MathHelper.lerp(z, box.minZ, box.maxZ);
                        ((IRaycastContext)context).set(new Vec3d(nX + dX, nY, nZ + dZ), source, ShapeType.COLLIDER, FluidHandling.NONE, entity);
                        if (anchorRaycast(context, pos, ignoreTerrain).getType() == Type.MISS) {
                            ++miss;
                        }

                        ++hit;
                    }
                }
            }

            return (double)((float)miss / (float)hit);
        } else {
            return 0.0D;
        }
    }

    private static BlockHitResult anchorRaycast(RaycastContext context, BlockPos anchor, boolean ignoreTerrain) {
        return (BlockHitResult)BlockView.raycast(context.getStart(), context.getEnd(), context, (raycast, pos) -> {
            BlockState state = MeteorClient.mc.world.getBlockState(pos);
            if (ignoreTerrain && state.getBlock().getBlastResistance() < 600.0F) {
                state = Blocks.AIR.getDefaultState();
            }

            if (pos != null && state.getBlock() == Blocks.RESPAWN_ANCHOR) {
                state = Blocks.AIR.getDefaultState();
            }

            Vec3d start = raycast.getStart();
            Vec3d end = raycast.getEnd();
            BlockHitResult blockResult = MeteorClient.mc.world.raycastBlock(start, end, pos, raycast.getBlockShape(state, MeteorClient.mc.world, pos), state);
            BlockHitResult emptyResult = VoxelShapes.empty().raycast(start, end, pos);
            double block = blockResult == null ? Double.MAX_VALUE : raycast.getStart().squaredDistanceTo(blockResult.getPos());
            double empty = emptyResult == null ? Double.MAX_VALUE : raycast.getStart().squaredDistanceTo(emptyResult.getPos());
            return block <= empty ? blockResult : emptyResult;
        }, (raycast) -> {
            Vec3d diff = raycast.getStart().subtract(raycast.getEnd());
            return BlockHitResult.createMissed(raycast.getEnd(), Direction.getFacing(diff.x, diff.y, diff.z), new BlockPos(raycast.getEnd()));
        });
    }

    private static float getDamageForDifficulty(float damage) {
        float var10000;
        switch(MeteorClient.mc.world.getDifficulty()) {
            case PEACEFUL:
                var10000 = 0.0F;
                break;
            case EASY:
                var10000 = Math.min(damage * 0.5F + 1.0F, damage);
                break;
            case HARD:
                var10000 = damage * 1.5F;
                break;
            default:
                var10000 = damage;
        }

        return var10000;
    }

    private static float normalProtReduction(Entity player, float damage) {
        int protLevel = EnchantmentHelper.getProtectionAmount(player.getArmorItems(), DamageSource.GENERIC);
        if (protLevel > 20) {
            protLevel = 20;
        }

        damage = (float)((double)damage * (1.0D - (double)protLevel * 0.04D));
        return damage < 0.0F ? 0.0F : damage;
    }

    private static float blastProtReduction(Entity player, float damage, Explosion explosion) {
        int protLevel = EnchantmentHelper.getProtectionAmount(player.getArmorItems(), DamageSource.explosion(explosion));
        if (protLevel > 20) {
            protLevel = 20;
        }

        damage = (float)((double)damage * (1.0D - (double)protLevel * 0.04D));
        return damage < 0.0F ? 0.0F : damage;
    }

    private static float resistanceReduction(LivingEntity player, float damage) {
        if (player.hasStatusEffect(StatusEffects.RESISTANCE)) {
            int lvl = player.getStatusEffect(StatusEffects.RESISTANCE).getAmplifier() + 1;
            damage = (float)((double)damage * (1.0D - (double)lvl * 0.2D));
        }

        return damage < 0.0F ? 0.0F : damage;
    }

    private static float getExposure(Vec3d source, Entity entity, boolean predictMovement, RaycastContext raycastContext, boolean ignoreTerrain, boolean fullBlocks) {
        Box box = entity.getBoundingBox();
        if (predictMovement) {
            Vec3d v = entity.getVelocity();
            box.offset(v);
        }

        double d = 1.0D / ((box.maxX - box.minX) * 2.0D + 1.0D);
        double e = 1.0D / ((box.maxY - box.minY) * 2.0D + 1.0D);
        double f = 1.0D / ((box.maxZ - box.minZ) * 2.0D + 1.0D);
        double g = (1.0D - Math.floor(1.0D / d) * d) * 0.5D;
        double h = (1.0D - Math.floor(1.0D / f) * f) * 0.5D;
        if (!(d < 0.0D) && !(e < 0.0D) && !(f < 0.0D)) {
            int i = 0;
            int j = 0;

            for(float k = 0.0F; k <= 1.0F; k = (float)((double)k + d)) {
                for(float l = 0.0F; l <= 1.0F; l = (float)((double)l + e)) {
                    for(float m = 0.0F; m <= 1.0F; m = (float)((double)m + f)) {
                        double n = MathHelper.lerp((double)k, box.minX, box.maxX);
                        double o = MathHelper.lerp((double)l, box.minY, box.maxY);
                        double p = MathHelper.lerp((double)m, box.minZ, box.maxZ);
                        ((IVec3d)vec3d).set(n + g, o, p + h);
                        ((IRaycastContext)raycastContext).set(vec3d, source, ShapeType.COLLIDER, FluidHandling.NONE, entity);
                        if (raycast(raycastContext, ignoreTerrain, fullBlocks).getType() == Type.MISS) {
                            ++i;
                        }

                        ++j;
                    }
                }
            }

            return (float)i / (float)j;
        } else {
            return 0.0F;
        }
    }

    private static BlockHitResult raycast(RaycastContext context, boolean ignoreTerrain, boolean fullBlocks) {
        return (BlockHitResult)BlockView.raycast(context.getStart(), context.getEnd(), context, (raycastContext, blockPos) -> {
            BlockState blockState = MeteorClient.mc.world.getBlockState(blockPos);
            if (blockState.getBlock() instanceof AnvilBlock && fullBlocks) {
                blockState = Blocks.OBSIDIAN.getDefaultState();
            } else if (blockState.getBlock() instanceof EnderChestBlock && fullBlocks) {
                blockState = Blocks.OBSIDIAN.getDefaultState();
            } else if (blockState.getBlock().getBlastResistance() < 600.0F && ignoreTerrain) {
                blockState = Blocks.AIR.getDefaultState();
            }

            Vec3d vec3d = raycastContext.getStart();
            Vec3d vec3d2 = raycastContext.getEnd();
            VoxelShape voxelShape = raycastContext.getBlockShape(blockState, MeteorClient.mc.world, blockPos);
            BlockHitResult blockHitResult = MeteorClient.mc.world.raycastBlock(vec3d, vec3d2, blockPos, voxelShape, blockState);
            VoxelShape voxelShape2 = VoxelShapes.empty();
            BlockHitResult blockHitResult2 = voxelShape2.raycast(vec3d, vec3d2, blockPos);
            double d = blockHitResult == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult.getPos());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : raycastContext.getStart().squaredDistanceTo(blockHitResult2.getPos());
            return d <= e ? blockHitResult : blockHitResult2;
        }, (raycastContext) -> {
            Vec3d vec3d = raycastContext.getStart().subtract(raycastContext.getEnd());
            return BlockHitResult.createMissed(raycastContext.getEnd(), Direction.getFacing(vec3d.x, vec3d.y, vec3d.z), new BlockPos(raycastContext.getEnd()));
        });
    }

    public static float possibleHealthReductions(boolean crystals, double explosionRadius, boolean swords, float enemyDistance) {
        float damageTaken = 0.0F;
        Iterator var6 = MeteorClient.mc.world.getEntities().iterator();

        while(var6.hasNext()) {
            Entity entity = (Entity)var6.next();
            if (crystals && entity instanceof EndCrystalEntity && damageTaken < crystalDamage(MeteorClient.mc.player, entity.getPos(), explosionRadius)) {
                damageTaken = crystalDamage(MeteorClient.mc.player, entity.getPos(), explosionRadius);
            }

            if (swords && entity instanceof PlayerEntity && damageTaken < getSwordDamage((PlayerEntity)entity, true) && !Friends.get().isFriend((PlayerEntity)entity) && MeteorClient.mc.player.getPos().distanceTo(entity.getPos()) < (double)enemyDistance && ((PlayerEntity)entity).getActiveItem().getItem() instanceof SwordItem) {
                damageTaken = getSwordDamage((PlayerEntity)entity, true);
            }
        }

        if (PlayerUtils.getDimension() != Dimension.Overworld) {
            var6 = Utils.blockEntities().iterator();

            while(var6.hasNext()) {
                BlockEntity blockEntity = (BlockEntity)var6.next();
                BlockPos bp = blockEntity.getPos();
                Vec3d pos = new Vec3d((double)bp.getX(), (double)bp.getY(), (double)bp.getZ());
                if (blockEntity instanceof BedBlockEntity && damageTaken < bedDamage(MeteorClient.mc.player, pos)) {
                    damageTaken = bedDamage(MeteorClient.mc.player, pos);
                }
            }
        }

        return damageTaken;
    }
}
