package delta.utils;

import delta.modules.combat.AutoTotemPlus;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.util.Hand;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.block.Block;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

public class InvUtil {
    public static int checkFullSlots() {
        int slots = 0;
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i < 36; ++i) {
            if (!inv.getStack(i).isEmpty()) {
                ++slots;
            }
        }

        return slots;
    }

    public static void syncSlot() {
        MeteorClient.mc.player.getInventory().selectedSlot = MeteorClient.mc.player.getInventory().selectedSlot;
        MeteorClient.mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(MeteorClient.mc.player.getInventory().selectedSlot));
    }

    public static int shulkerCount() {
        int slots = 0;
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i < 36; ++i) {
            if (Block.getBlockFromItem(inv.getStack(i).getItem()) instanceof ShulkerBoxBlock) {
                ++slots;
            }
        }

        return slots;
    }

    public static DefaultedList<ItemStack> getShulkerBySlot(Inventory inv, int slot) {
        ItemStack stack = inv.getStack(slot);
        if (stack != null && Block.getBlockFromItem(stack.getItem()) instanceof ShulkerBoxBlock) {
            DefaultedList<ItemStack> shulker = DefaultedList.ofSize(27, ItemStack.EMPTY);
            NbtCompound compoundTag = stack.getSubNbt("BlockEntityTag");
            if (compoundTag == null) {
                return shulker;
            } else {
                Inventories.readNbt(compoundTag, shulker);
                return shulker;
            }
        } else {
            return null;
        }
    }

    public static int findEmptyShulker(int maxFullSlots) {
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i < 36; ++i) {
            DefaultedList<ItemStack> shulker = getShulkerBySlot(inv, i);
            if (shulker != null && 27 - getEmptySlotsInShulker(shulker) <= maxFullSlots) {
                return i;
            }
        }

        return -1;
    }

    public static int findShulker() {
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i < 36; ++i) {
            if (Block.getBlockFromItem(inv.getStack(i).getItem()) instanceof ShulkerBoxBlock) {
                return i;
            }
        }

        return -1;
    }

    public static int getEmptySlotsInShulker(DefaultedList<ItemStack> shulker) {
        int emptySlots = 0;
        Iterator var2 = shulker.iterator();

        while(var2.hasNext()) {
            ItemStack shulkerStack = (ItemStack)var2.next();
            if (shulkerStack.isEmpty()) {
                ++emptySlots;
            }
        }

        return emptySlots;
    }

    public static void dropSelected(List<Item> items) {
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i <= 35; ++i) {
            ItemStack itemStack = inv.getStack(i);
            if (items.contains(itemStack.getItem())) {
                InvUtils.drop().slot(i);
            }
        }

    }

    public static void swapToItem(Item item) {
        if (MeteorClient.mc.player.getMainHandStack().getItem() != item) {
            FindItemResult findItem = InvUtils.findInHotbar(new Item[]{item});
            if (findItem.found()) {
                InvUtils.swap(findItem.slot(), false);
            }
        }
    }

    public static void updateSlot(int newSlot) {
        MeteorClient.mc.player.getInventory().selectedSlot = newSlot;
    }

    private static void ClickSlot(int id, int button, SlotActionType action) {
        MeteorClient.mc.interactionManager.clickSlot(MeteorClient.mc.player.currentScreenHandler.syncId, id, button, action, MeteorClient.mc.player);
    }

    public static void move(int from, int to) {
        if (from >= 0 && to >= 0) {
            InvUtils.move().from(from).to(to);
        }
    }

    public static void Click(int id) {
        ClickSlot(id, 0, SlotActionType.PICKUP);
    }

    public static void Swap(int id, int button) {
        ClickSlot(id, button, SlotActionType.SWAP);
    }

    public static void Move(int id) {
        if (AutoTotemPlus.isClassic()) {
            Click(id);
        } else {
            Swap(id, 40);
        }

    }

    public static int GetFirstHotbarSlotId() {
        return MeteorClient.mc.player.currentScreenHandler instanceof PlayerScreenHandler ? 36 : MeteorClient.mc.player.currentScreenHandler.slots.size() - 9;
    }

    public static FindItemResult findPick() {
        return InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof PickaxeItem;
        });
    }

    public static void useItem(Item item) {
        int mainSlot = MeteorClient.mc.player.getInventory().selectedSlot;
        FindItemResult findedItem = InvUtils.find(new Item[]{item});
        if (findedItem.found()) {
            int fireworkSlot = findedItem.slot();
            InvUtils.move().from(fireworkSlot).to(mainSlot);
            if (MeteorClient.mc.player.getMainHandStack().getItem() == item) {
                MeteorClient.mc.interactionManager.interactItem(MeteorClient.mc.player, Hand.MAIN_HAND);
            }

            InvUtils.move().from(mainSlot).to(fireworkSlot);
        }
    }

    public static int getEquippedElytraDurability() {
        ItemStack itemStack = MeteorClient.mc.player.getEquippedStack(EquipmentSlot.CHEST);
        return itemStack.getItem() == Items.ELYTRA ? 432 - itemStack.getDamage() : 0;
    }

    public static void swapChargedElytra(int minDurability) {
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i <= 36; ++i) {
            ItemStack stack = inv.getStack(i);
            if (stack.getItem() instanceof ElytraItem && 432 - stack.getDamage() >= minDurability) {
                InvUtils.move().from(i).toArmor(2);
                return;
            }
        }

    }

    public static int getElytraWithMinDurability() {
        Inventory inv = MeteorClient.mc.player.getInventory();
        List<Integer> elytrasDamages = new ArrayList();
        List<Integer> slots = new ArrayList();

        int slot;
        for(slot = 0; slot <= 36; ++slot) {
            ItemStack stack = inv.getStack(slot);
            if (stack.getItem() instanceof ElytraItem) {
                slots.add(slot);
                elytrasDamages.add(stack.getDamage());
            }
        }

        if (slots.isEmpty()) {
            return -1;
        } else {
            slot = (Integer)slots.get(elytrasDamages.indexOf(Collections.max(elytrasDamages)));
            return slot >= 9 && slot <= 35 ? slot - 9 : slot + 27;
        }
    }

    public static int getAllElytraDurability() {
        int durabilityPoints = 0;
        Inventory inv = MeteorClient.mc.player.getInventory();

        for(int i = 0; i <= 36; ++i) {
            ItemStack stack = inv.getStack(i);
            if (stack.getItem() instanceof ElytraItem) {
                durabilityPoints += 432 - stack.getDamage();
            }
        }

        return durabilityPoints + getEquippedElytraDurability();
    }
}
