package delta.utils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Blocks;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.MathHelper;

public class EntityUtil {
    public static Entity deadEntity;

    public static boolean isDeathPacket(Receive event) {
        Packet var2 = event.packet;
        if (var2 instanceof EntityStatusS2CPacket) {
            EntityStatusS2CPacket packet = (EntityStatusS2CPacket)var2;
            if (packet.getStatus() == 3) {
                deadEntity = packet.getEntity(MeteorClient.mc.world);
                return deadEntity instanceof PlayerEntity;
            }
        }

        return false;
    }

    public static boolean isTopTrapped(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        return BlockUtil.isBlastResist(playerPos(targetEntity).add(0, 2, 0), type);
    }

    public static List<PlayerEntity> getTargetsInRange(Double enemyRange) {
        return (List)MeteorClient.mc.world.getPlayers().stream().filter((e) -> {
            return e != MeteorClient.mc.player;
        }).filter(LivingEntity::isAlive).filter((e) -> {
            return !Friends.get().isFriend(e);
        }).filter((e) -> {
            return e.getHealth() > 0.0F;
        }).filter((e) -> {
            return (double)MeteorClient.mc.player.distanceTo(e) < enemyRange;
        }).sorted(Comparator.comparing((e) -> {
            return MeteorClient.mc.player.distanceTo(e);
        })).collect(Collectors.toList());
    }

    public static double getPlayerSpeed(PlayerEntity player) {
        if (player == null) {
            return 0.0D;
        } else {
            double tX = Math.abs(player.getX() - player.prevX);
            double tZ = Math.abs(player.getZ() - player.prevZ);
            double length = Math.sqrt(tX * tX + tZ * tZ);
            Timer timer = (Timer)Modules.get().get(Timer.class);
            if (timer.isActive()) {
                length *= ((Timer)Modules.get().get(Timer.class)).getMultiplier();
            }

            return length * 20.0D;
        }
    }

    public static boolean isFaceSurrounded(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        return BlockUtil.isBlastResist(playerPos(targetEntity).add(1, 1, 0), type) && BlockUtil.isBlastResist(playerPos(targetEntity).add(-1, 1, 0), type) && BlockUtil.isBlastResist(playerPos(targetEntity).add(0, 1, 1), type) && BlockUtil.isBlastResist(playerPos(targetEntity).add(0, 1, -1), type);
    }

    public static boolean isBothTrapped(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        return isTopTrapped(targetEntity, type) && isFaceSurrounded(targetEntity, type);
    }

    public static boolean isAnyTrapped(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        return isTopTrapped(targetEntity, type) || isFaceSurrounded(targetEntity, type);
    }

    public static ArrayList<BlockPos> getSurroundBlocks(PlayerEntity player) {
        ArrayList<BlockPos> poses = new ArrayList();
        BlockPos pos = playerPos(player);
        Direction[] var3 = Direction.values();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            Direction direction = var3[var5];
            if (direction != Direction.UP) {
                poses.add(pos.offset(direction));
            }
        }

        return poses;
    }

    public static BlockPos playerPos(PlayerEntity targetEntity) {
        return WorldUtils.roundBlockPos(targetEntity.getPos());
    }

    public static double getYaw(Entity entity, BlockPos pos) {
        return (double)(entity.getYaw() + MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2((double)pos.getZ() - entity.getZ(), (double)pos.getX() - entity.getX())) - 90.0F - entity.getYaw()));
    }

    public static boolean isSurroundBroken(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        int blast = 0;
        BlockPos penis = playerPos(targetEntity);

        for(int i = 0; i < 4; ++i) {
            if (BlockUtil.isBlastResist(penis.offset(Direction.fromHorizontal(i)), type)) {
                ++blast;
            }
        }

        return blast == 3;
    }

    public static boolean isBurrowed(LivingEntity target) {
        return BlockUtil.isBlastResist(playerPos((PlayerEntity)target));
    }

    public static boolean isMonke(PlayerEntity targetEntity, boolean doubles, BlockUtil.BlastResistantType type) {
        if (!Utils.canUpdate()) {
            return true;
        } else {
            BlockPos blockPos = playerPos(targetEntity);
            int air = 0;
            Direction[] var5 = Direction.values();
            int var6 = var5.length;

            for(int var7 = 0; var7 < var6; ++var7) {
                Direction direction = var5[var7];
                if (direction != Direction.UP && !BlockUtil.isBlastResist(blockPos.offset(direction), type)) {
                    if (!doubles || direction == Direction.DOWN) {
                        return true;
                    }

                    ++air;
                    Direction[] var9 = Direction.values();
                    int var10 = var9.length;

                    for(int var11 = 0; var11 < var10; ++var11) {
                        Direction dir = var9[var11];
                        if (dir != direction.getOpposite() && dir != Direction.UP && !BlockUtil.isBlastResist(blockPos.offset(direction).offset(dir), type)) {
                            return true;
                        }
                    }
                }
            }

            return air >= 2;
        }
    }

    public static boolean isNaked(PlayerEntity player) {
        if (player == null) {
            return true;
        } else if (player.isAlive() && !(player.getHealth() <= 0.0F)) {
            return ((ItemStack)player.getInventory().armor.get(0)).isEmpty() && ((ItemStack)player.getInventory().armor.get(1)).isEmpty() && ((ItemStack)player.getInventory().armor.get(2)).isEmpty() && ((ItemStack)player.getInventory().armor.get(3)).isEmpty();
        } else {
            return true;
        }
    }

    public static boolean isBurrowed(LivingEntity target, boolean mineUpOnly) {
        assert MeteorClient.mc.world != null;

        BlockPos pos = target.getBlockPos();
        return BlockUtil.getBlock(pos) == Blocks.OBSIDIAN || BlockUtil.getBlock(pos) == Blocks.BEDROCK && !mineUpOnly || BlockUtil.getBlock(pos) == Blocks.ENDER_CHEST || BlockUtil.getBlock(pos) == Blocks.ANVIL || BlockUtil.getBlock(pos) == Blocks.DAMAGED_ANVIL || BlockUtil.getBlock(pos) == Blocks.CHIPPED_ANVIL || BlockUtil.getBlock(pos) == Blocks.CRYING_OBSIDIAN || BlockUtil.getBlock(pos) == Blocks.ANCIENT_DEBRIS || BlockUtil.getBlock(pos) == Blocks.NETHERITE_BLOCK;
    }

    public static boolean isBurrowed(PlayerEntity targetEntity, BlockUtil.BlastResistantType type, boolean onlyDouble) {
        return BlockUtil.isBlastResist(playerPos(targetEntity), type) && (BlockUtil.isBlastResist(playerPos(targetEntity).up(), type) || !onlyDouble);
    }

    public static boolean isSurrounded(PlayerEntity targetEntity, BlockUtil.BlastResistantType type) {
        Iterator var2 = getSurroundPos(targetEntity).iterator();

        BlockPos pos;
        do {
            if (!var2.hasNext()) {
                return true;
            }

            pos = (BlockPos)var2.next();
        } while(BlockUtil.isBlastResist(pos, type));

        return false;
    }

    public static boolean isButtoned(PlayerEntity targetEntity) {
        return BlockUtil.getBlock(targetEntity.getBlockPos()) instanceof AbstractButtonBlock && !MeteorClient.mc.world.getDimension().comp_648();
    }

    public static boolean isAutist(PlayerEntity targetEntity, boolean selfTrap, boolean antiCevTwo, BlockUtil.BlastResistantType type) {
        if (isSurrounded(targetEntity, BlockUtil.BlastResistantType.Unbreakable)) {
            return false;
        } else {
            Iterator var4 = getAutistPos(targetEntity, selfTrap, antiCevTwo).iterator();

            BlockPos pos;
            do {
                if (!var4.hasNext()) {
                    return true;
                }

                pos = (BlockPos)var4.next();
            } while(BlockUtil.isBlastResist(pos, type));

            return false;
        }
    }

    public static List<BlockPos> getAutistPos(PlayerEntity targetEntity, boolean selfTrap, boolean antiCevTwo) {
        final BlockPos pos = playerPos(targetEntity);
        return new ArrayList<BlockPos>() {
            {
                this.addAll(EntityUtil.getSurroundPos(targetEntity));
                this.add(pos.north(2));
                this.add(pos.south(2));
                this.add(pos.east(2));
                this.add(pos.west(2));
                this.add(pos.west().south());
                this.add(pos.west().north());
                this.add(pos.east().north());
                this.add(pos.east().south());
                this.add(pos.south().east());
                this.add(pos.south().west());
                this.add(pos.north().west());
                this.add(pos.north().east());
                if (selfTrap) {
                    this.add(pos.up(2));
                    this.add(pos.up(3));
                    this.add(pos.up().west());
                    this.add(pos.up().east());
                    this.add(pos.up().north());
                    this.add(pos.up().south());
                    if (antiCevTwo) {
                        this.add(pos.up(2).west());
                        this.add(pos.up(2).east());
                        this.add(pos.up(2).north());
                        this.add(pos.up(2).south());
                    }
                }

            }
        };
    }

    public static boolean isWebbed(PlayerEntity targetEntity) {
        return WorldUtils.doesBoxTouchBlock(targetEntity.getBoundingBox(), Blocks.COBWEB);
    }

    public static List<BlockPos> getSurroundPos(PlayerEntity player) {
        return new ArrayList<BlockPos>() {
            {
                this.add(EntityUtil.playerPos(player).north());
                this.add(EntityUtil.playerPos(player).east());
                this.add(EntityUtil.playerPos(player).west());
                this.add(EntityUtil.playerPos(player).south());
            }
        };
    }

    public static boolean isMonke(boolean doubles, Entity entity) {
        if (!Utils.canUpdate()) {
            return true;
        } else {
            BlockPos blockPos = entity.getBlockPos();
            int air = 0;
            Direction[] var4 = Direction.values();
            int var5 = var4.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                Direction direction = var4[var6];
                if (direction != Direction.UP) {
                    BlockState state = MeteorClient.mc.world.getBlockState(blockPos.offset(direction));
                    if (state.getBlock() != Blocks.BEDROCK && state.getBlock() != Blocks.OBSIDIAN && state.getBlock() != Blocks.CRYING_OBSIDIAN) {
                        if (!doubles || direction == Direction.DOWN) {
                            return true;
                        }

                        ++air;
                        Direction[] var9 = Direction.values();
                        int var10 = var9.length;

                        for(int var11 = 0; var11 < var10; ++var11) {
                            Direction dir = var9[var11];
                            if (dir != direction.getOpposite() && dir != Direction.UP) {
                                BlockState blockState1 = MeteorClient.mc.world.getBlockState(blockPos.offset(direction).offset(dir));
                                if (blockState1.getBlock() != Blocks.BEDROCK && blockState1.getBlock() != Blocks.OBSIDIAN) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }

            return air >= 2;
        }
    }
}
