package delta.utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;

public class ConfigManager {
   private static final Path currentRelativePath = Paths.get("");
   private static final String mc_path;
   private static final String configs_path;

   public static void create(String name, String dir) {
      String catalog = mc_path;
      catalog = catalog + "\\meteor-client";
      checkDir(catalog, true);
      catalog = catalog + "\\moonlight_config";
      checkDir(catalog, true);
      catalog = catalog + "\\" + dir;
      checkDir(catalog, true);
      catalog = catalog + "\\" + name + ".cfg";
      File config = new File(catalog);

      try {
         config.createNewFile();
      } catch (IOException var5) {
      }

   }

   public static boolean write(String catalog, String options) {
      if (checkFile(catalog)) {
         return false;
      } else {
         try {
            FileWriter writer = new FileWriter(catalog, false);

            try {
               writer.write(options);
            } catch (Throwable var6) {
               try {
                  writer.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }

               throw var6;
            }

            writer.close();
            return true;
         } catch (IOException var7) {
            System.out.println(var7.getMessage());
            return false;
         }
      }
   }

   public static void writeParse(String catalog, Map<String, String[]> options) {
      if (!checkFile(catalog)) {
         StringBuilder config = new StringBuilder();
         Iterator var3 = options.entrySet().iterator();

         while(var3.hasNext()) {
            Entry<String, String[]> entry = (Entry)var3.next();
            String key = (String)entry.getKey();
            String[] value = (String[])entry.getValue();
            if (key.isEmpty()) {
               return;
            }

            StringBuilder line = new StringBuilder(key + " ");
            String[] var8 = value;
            int var9 = value.length;

            for(int var10 = 0; var10 < var9; ++var10) {
               String val = var8[var10];
               line.append(val).append(" ");
            }

            config.append(line).append("\n");
         }

         try {
            FileWriter writer = new FileWriter(catalog, false);

            try {
               writer.write(config.toString());
            } catch (Throwable var13) {
               try {
                  writer.close();
               } catch (Throwable var12) {
                  var13.addSuppressed(var12);
               }

               throw var13;
            }

            writer.close();
         } catch (IOException var14) {
            System.out.println(var14.getMessage());
         }

      }
   }

   public static Map<String, String[]> getParseConfig(String catalog, String cfgName, String folderName) {
      if (checkFile(catalog)) {
         create(cfgName, folderName);
         return null;
      } else {
         try {
            FileReader reader = new FileReader(catalog);

            HashMap var19;
            try {
               StringBuilder config = new StringBuilder();

               while(true) {
                  int char_num;
                  if ((char_num = reader.read()) == -1) {
                     Map<String, String[]> configDICT = new HashMap();
                     String config2 = config.toString();
                     String[] cfgLines = config2.split("\n");
                     String[] var9 = cfgLines;
                     int var10 = cfgLines.length;

                     for(int var11 = 0; var11 < var10; ++var11) {
                        String line = var9[var11];
                        String[] args1 = line.split(" ");
                        if (args1.length >= 2) {
                           String key = args1[0];
                           if (!Objects.equals(key, " ")) {
                              String[] args2 = new String[args1.length - 1];
                              System.arraycopy(args1, 1, args2, 0, args1.length - 1);
                              configDICT.put(key, args2);
                           }
                        }
                     }

                     var19 = configDICT;
                     break;
                  }

                  config.append((char)char_num);
               }
            } catch (Throwable var17) {
               try {
                  reader.close();
               } catch (Throwable var16) {
                  var17.addSuppressed(var16);
               }

               throw var17;
            }

            reader.close();
            return var19;
         } catch (IOException var18) {
            System.out.println(var18.getMessage());
            return null;
         }
      }
   }

   public static String getPath() {
      return configs_path;
   }

   public static void checkDir(String catalog, Boolean create) {
      boolean dirExists = Files.exists(Path.of(catalog, new String[0]), new LinkOption[0]);
      if (!dirExists && create) {
         (new File(catalog)).mkdirs();
      }

   }

   public static boolean checkFile(String catalog) {
      File file = new File(catalog);
      return !file.exists();
   }

   static {
      mc_path = currentRelativePath.toAbsolutePath().toString();
      configs_path = mc_path + "\\meteor-client\\moonlight_config";
   }
}
