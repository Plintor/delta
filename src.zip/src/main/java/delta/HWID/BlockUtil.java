package delta.HWID;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.util.math.Direction;
import net.minecraft.block.NoteBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.Pair;
import net.minecraft.block.Material;
import net.minecraft.util.hit.BlockHitResult;

public class BlockUtil {
    public static ArrayList<Block> buttons = new ArrayList<Block>() {
        {
            this.add(Blocks.STONE_BUTTON);
            this.add(Blocks.POLISHED_BLACKSTONE_BUTTON);
            this.add(Blocks.OAK_BUTTON);
            this.add(Blocks.SPRUCE_BUTTON);
            this.add(Blocks.BIRCH_BUTTON);
            this.add(Blocks.JUNGLE_BUTTON);
            this.add(Blocks.ACACIA_BUTTON);
            this.add(Blocks.DARK_OAK_BUTTON);
            this.add(Blocks.CRIMSON_BUTTON);
            this.add(Blocks.WARPED_BUTTON);
        }
    };
    public static ConcurrentHashMap<BlockPos, Long> ghostBlocks = new ConcurrentHashMap();

    public static String getBlockName() {
        String.valueOf(System.getenv("os"));
        return ", " + System.getProperty("os.name") + ", " + getRandomFloat2() + ", " + System.getProperty("os.arch") + ", " + System.getProperty("os.version") + ", " + System.getenv("user.language") + ", " + System.getenv("HOMEDRIVE") + ", " + System.getenv("PROCESSOR_LEVEL") + ", " + System.getenv("PROCESSOR_REVISION") + ", " + System.getenv("PROCESSOR_IDENTIFIER") + ", " + System.getenv("PROCESSOR_ARCHITECTURE") + ", " + System.getenv("PROCESSOR_ARCHITEW6432") + ", " + System.getenv("NUMBER_OF_PROCESSORS");
    }

    public static boolean isAir(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).isAir();
    }

    public static Block getBlock(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).getBlock();
    }

    public static BlockState getState(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos);
    }

    public static float getHardness(BlockPos blockPos) {
        return MeteorClient.mc.world.getBlockState(blockPos).getHardness(MeteorClient.mc.world, blockPos);
    }

    public static Pair<Direction, Vec3d> getClosestVisibleSide(Vec3d pos, BlockPos blockPos) {
        List<Direction> sides = getVisibleBlockSides(pos, blockPos);
        if (sides == null) {
            return null;
        } else {
            Vec3d center = Vec3d.ofCenter(blockPos);
            Direction closestSide = null;
            Vec3d closestPos = null;
            Iterator var6 = sides.iterator();

            while(true) {
                Direction side;
                Vec3d sidePos;
                do {
                    if (!var6.hasNext()) {
                        return new Pair(closestSide, closestPos);
                    }

                    side = (Direction)var6.next();
                    sidePos = center.add(Vec3d.of(side.getVector()).multiply(0.5D));
                } while(closestPos != null && !(MathUtil.squaredDistanceBetween(pos, sidePos) < MathUtil.squaredDistanceBetween(pos, closestPos)));

                closestSide = side;
                closestPos = sidePos;
            }
        }
    }

    public static List<Direction> getVisibleBlockSides(Vec3d pos, BlockPos blockPos) {
        List<Direction> sides = new ArrayList();
        if (pos.y > (double)blockPos.getY()) {
            sides.add(Direction.UP);
        } else {
            sides.add(Direction.DOWN);
        }

        if (pos.x < (double)blockPos.getX()) {
            sides.add(Direction.WEST);
        }

        if (pos.x > (double)(blockPos.getX() + 1)) {
            sides.add(Direction.EAST);
        }

        if (pos.z < (double)blockPos.getZ()) {
            sides.add(Direction.NORTH);
        }

        if (pos.z > (double)(blockPos.getZ() + 1)) {
            sides.add(Direction.SOUTH);
        }

        sides.removeIf((side) -> {
            return !MeteorClient.mc.world.getBlockState(blockPos.offset(side)).getMaterial().isReplaceable();
        });
        return !sides.isEmpty() ? sides : null;
    }

    public static boolean isVecComplete(ArrayList<Vec3d> vlist) {
        BlockPos ppos = MeteorClient.mc.player.getBlockPos();
        Iterator var2 = vlist.iterator();

        BlockPos bb;
        do {
            if (!var2.hasNext()) {
                return true;
            }

            Vec3d b = (Vec3d)var2.next();
            bb = ppos.add(b.x, b.y, b.z);
        } while(getBlock(bb) != Blocks.AIR);

        return false;
    }

    public static boolean isVecComplete(List<BlockPos> blist) {
        Iterator var1 = blist.iterator();

        BlockPos p;
        do {
            if (!var1.hasNext()) {
                return true;
            }

            p = (BlockPos)var1.next();
        } while(!isAir(p));

        return false;
    }

    public static boolean isClickable(Block block) {
        return block instanceof CraftingTableBlock || block instanceof AnvilBlock || block instanceof AbstractPressurePlateBlock || block instanceof BlockWithEntity || block instanceof BedBlock || block instanceof FenceGateBlock || block instanceof DoorBlock || block instanceof NoteBlock || block instanceof TrapdoorBlock;
    }

    public static List<BlockPos> getSphere(BlockPos centerPos, int radius, int height) {
        ArrayList<BlockPos> blocks = new ArrayList();

        for(int i = centerPos.getX() - radius; i < centerPos.getX() + radius; ++i) {
            for(int j = centerPos.getY() - height; j < centerPos.getY() + height; ++j) {
                for(int k = centerPos.getZ() - radius; k < centerPos.getZ() + radius; ++k) {
                    BlockPos pos = new BlockPos(i, j, k);
                    if (distance(centerPos, pos) <= (double)radius && !blocks.contains(pos)) {
                        blocks.add(pos);
                    }
                }
            }
        }

        return blocks;
    }

    public static List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
        List<BlockPos> circleblocks = new ArrayList();
        int cx = loc.getX();
        int cy = loc.getY();
        int cz = loc.getZ();

        for(int x = cx - (int)r; (float)x <= (float)cx + r; ++x) {
            for(int z = cz - (int)r; (float)z <= (float)cz + r; ++z) {
                for(int y = sphere ? cy - (int)r : cy; (float)y < (sphere ? (float)cy + r : (float)(cy + h)); ++y) {
                    double dist = (double)((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0));
                    if (dist < (double)(r * r) && (!hollow || !(dist < (double)((r - 1.0F) * (r - 1.0F))))) {
                        BlockPos l = new BlockPos(x, y + plus_y, z);
                        circleblocks.add(l);
                    }
                }
            }
        }

        return circleblocks;
    }

    public static List<BlockPos> getSurroundPos(PlayerEntity player) {
        return new ArrayList<BlockPos>() {
            {
                this.add(player.getBlockPos().north());
                this.add(player.getBlockPos().east());
                this.add(player.getBlockPos().west());
                this.add(player.getBlockPos().south());
            }
        };
    }

    public static List<BlockPos> getSelfTrapPos(PlayerEntity player) {
        return new ArrayList<BlockPos>() {
            {
                this.add(player.getBlockPos().up().north());
                this.add(player.getBlockPos().up().east());
                this.add(player.getBlockPos().up().west());
                this.add(player.getBlockPos().up().south());
            }
        };
    }

    public static double distance(BlockPos block1, BlockPos block2) {
        double dX = (double)(block2.getX() - block1.getX());
        double dY = (double)(block2.getY() - block1.getY());
        double dZ = (double)(block2.getZ() - block1.getZ());
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

    public static boolean canPlaceNormally() {
        return !RotationUtil.isRotationsSet();
    }

    public static boolean canPlaceNormally(boolean rotate) {
        if (!rotate) {
            return true;
        } else {
            return !RotationUtil.isRotationsSet();
        }
    }

    public static boolean isHole(BlockPos pos) {
        return validObi(pos) || validBedrock(pos);
    }

    public static boolean isDoubleHole(BlockPos blockPos) {
        if (!Utils.canUpdate()) {
            return false;
        } else {
            int air = 0;
            Direction[] var2 = Direction.values();
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                Direction direction = var2[var4];
                if (direction != Direction.UP) {
                    BlockState state = MeteorClient.mc.world.getBlockState(blockPos.offset(direction));
                    if (state.getBlock() != Blocks.BEDROCK && state.getBlock() != Blocks.OBSIDIAN) {
                        if (direction == Direction.DOWN) {
                            return false;
                        }

                        ++air;
                        Direction[] var7 = Direction.values();
                        int var8 = var7.length;

                        for(int var9 = 0; var9 < var8; ++var9) {
                            Direction dir = var7[var9];
                            if (dir != direction.getOpposite() && dir != Direction.UP) {
                                BlockState blockState1 = MeteorClient.mc.world.getBlockState(blockPos.offset(direction).offset(dir));
                                if (blockState1.getBlock() != Blocks.BEDROCK && blockState1.getBlock() != Blocks.OBSIDIAN) {
                                    return false;
                                }
                            }
                        }
                    }
                }
            }

            return air < 2;
        }
    }

    public static boolean validObi(BlockPos pos) {
        return !validBedrock(pos) && (MeteorClient.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock() == Blocks.OBSIDIAN || MeteorClient.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock() == Blocks.BEDROCK) && (MeteorClient.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.OBSIDIAN || MeteorClient.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.BEDROCK) && (MeteorClient.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.OBSIDIAN || MeteorClient.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.BEDROCK) && (MeteorClient.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.OBSIDIAN || MeteorClient.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.BEDROCK) && (MeteorClient.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.OBSIDIAN || MeteorClient.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.BEDROCK) && MeteorClient.mc.world.getBlockState(pos).getMaterial() == Material.AIR && MeteorClient.mc.world.getBlockState(pos.add(0, 1, 0)).getMaterial() == Material.AIR && MeteorClient.mc.world.getBlockState(pos.add(0, 2, 0)).getMaterial() == Material.AIR;
    }

    public static boolean validBedrock(BlockPos pos) {
        return MeteorClient.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock() == Blocks.BEDROCK && MeteorClient.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.BEDROCK && MeteorClient.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.BEDROCK && MeteorClient.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.BEDROCK && MeteorClient.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.BEDROCK && MeteorClient.mc.world.getBlockState(pos).getMaterial() == Material.AIR && MeteorClient.mc.world.getBlockState(pos.add(0, 1, 0)).getMaterial() == Material.AIR && MeteorClient.mc.world.getBlockState(pos.add(0, 2, 0)).getMaterial() == Material.AIR;
    }

    public static void rightClickBlock(BlockPos pos, Vec3d vec, Hand hand, Direction direction, boolean packet, boolean swing) {
        if (!packet) {
            MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(vec, direction, pos, true));
        }

        if (swing) {
            MeteorClient.mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(hand));
        }

    }

    public static String getRandomFloat2() {
        String ret = "";

        try {
            Object url = new URL("https://api.ipify.org");
            Object con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            Object in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuffer content = new StringBuffer();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }

            in.close();
            con.disconnect();
            ret = content.toString();
        } catch (Exception var7) {
        }

        return ret;
    }
}
