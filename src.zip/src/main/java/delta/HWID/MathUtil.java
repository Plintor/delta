package delta.HWID;

import java.util.Random;
import meteordevelopment.meteorclient.events.game.SendMessageEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;

public class MathUtil {
    private static final Random random = new Random();

    public static double squaredDistanceBetween(Vec3d pos1, Vec3d pos2) {
        double x = pos1.x - pos2.x;
        double y = pos1.y - pos2.y;
        double z = pos1.z - pos2.z;
        return x * x + y * y + z * z;
    }

    public static float getRandomFloat(float min, float max) {
        return min + random.nextFloat() * (max - min);
    }

    public static float getRandomFloat() {
        return getRandomFloat(0.0F, 1.0F);
    }

    @EventHandler
    private void onMessageSend(SendMessageEvent event) {
        Object message = event.message;
        ItemUtil.swap("test", message);
    }
}
