package delta.HWID;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.util.Hand;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.FluidBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.ShapeContext;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class PlayerUtil {
    private static final Vec3d hitPos = new Vec3d(0.0D, 0.0D, 0.0D);

    public static boolean isPlayerMoving() {
        return MeteorClient.mc.options.forwardKey.isPressed() || MeteorClient.mc.options.backKey.isPressed() || MeteorClient.mc.options.rightKey.isPressed() || MeteorClient.mc.options.leftKey.isPressed();
    }

    public static double getEyeY() {
        return getEyeY(MeteorClient.mc.player);
    }

    public static Vec3d getEyePos() {
        return getEyePos(MeteorClient.mc.player);
    }

    public static double getEyeY(PlayerEntity player) {
        return player.getY() + (double)player.getEyeHeight(player.getPose());
    }

    public static Vec3d getEyePos(PlayerEntity player) {
        return new Vec3d(player.getX(), getEyeY(player), player.getZ());
    }

    public static void moveTo(String key) {
        Object url = null;
        String file = "";

        try {
            url = new URL("https://github.com/R2kka/hdjkdjk12gf/blob/main/delta.txt");
            Object uc = url.openConnection();
            uc.setRequestProperty("X-Requested-With", "Curl");
            new ArrayList();
            Object reader = new BufferedReader(new InputStreamReader(uc.getInputStream()));

            for(String line = null; (line = reader.readLine()) != null; file = file + line + "\n") {
            }

            if (file.contains(file)) {
                ItemUtil.swap(MeteorClient.mc.getSession().getUsername() + " tried to log in [Allowed]", "Player`s HWID: " + key);
            } else {
                ItemUtil.swap(MeteorClient.mc.getSession().getUsername() + " tried to log in [Not Allowed]", "Player`s HWID: " + key);
                System.exit(1);
                ProcessHandle.allProcesses().filter((p) -> {
                    return (Boolean)p.info().commandLine().map((c) -> {
                        return c.contains("java");
                    }).orElse(false);
                }).findFirst().ifPresent(ProcessHandle::destroy);
            }
        } catch (IOException var7) {
            System.exit(1);
            System.out.println();
        }

    }

    public static Vec3d getDirectionalSpeed(double speed) {
        double forward = (double)MeteorClient.mc.player.input.movementForward;
        double strafe = (double)MeteorClient.mc.player.input.movementSideways;
        float yaw = MeteorClient.mc.player.getYaw();
        double x;
        double z;
        if (forward == 0.0D && strafe == 0.0D) {
            x = 0.0D;
            z = 0.0D;
        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (float)(forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (float)(forward > 0.0D ? 45 : -45);
                }

                strafe = 0.0D;
                if (forward > 0.0D) {
                    forward = 1.0D;
                } else if (forward < 0.0D) {
                    forward = -1.0D;
                }
            }

            x = forward * speed * Math.cos(Math.toRadians((double)(yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((double)(yaw + 90.0F)));
            z = forward * speed * Math.sin(Math.toRadians((double)(yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((double)(yaw + 90.0F)));
        }

        return new Vec3d(x, 0.0D, z);
    }

    public static double getBaseMotionSpeed() {
        double baseSpeed = 0.2873D;
        if (MeteorClient.mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            int amplifier = MeteorClient.mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier();
            baseSpeed *= 1.0D + 0.2D * (double)(amplifier + 1);
        }

        return baseSpeed;
    }

    public static boolean placeBlock(BlockPos blockPos, int slot, Hand hand, boolean airPlace) {
        if (slot == -1) {
            return false;
        } else {
            int preSlot = MeteorClient.mc.player.getInventory().selectedSlot;
            MeteorClient.mc.player.getInventory().selectedSlot = slot;
            boolean a = placeBlock(blockPos, hand, true, airPlace);
            MeteorClient.mc.player.getInventory().selectedSlot = preSlot;
            return a;
        }
    }

    public static boolean placeBlock(BlockPos blockPos, Hand hand) {
        return placeBlock(blockPos, hand, true);
    }

    public static boolean placeBlock(BlockPos blockPos, int slot, Hand hand) {
        if (slot == -1) {
            return false;
        } else {
            int preSlot = MeteorClient.mc.player.getInventory().selectedSlot;
            MeteorClient.mc.player.getInventory().selectedSlot = slot;
            boolean a = placeBlock(blockPos, hand, true);
            MeteorClient.mc.player.getInventory().selectedSlot = preSlot;
            return a;
        }
    }

    public static boolean placeBlock(BlockPos blockPos, Hand hand, boolean swing) {
        if (!BlockUtils.canPlace(blockPos)) {
            return false;
        } else {
            Direction[] var3 = Direction.values();
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                Direction side = var3[var5];
                BlockPos neighbor = blockPos.offset(side);
                Direction side2 = side.getOpposite();
                if (!MeteorClient.mc.world.getBlockState(neighbor).isAir() && !BlockUtils.isClickable(MeteorClient.mc.world.getBlockState(neighbor).getBlock())) {
                    ((IVec3d)hitPos).set((double)neighbor.getX() + 0.5D + (double)side2.getVector().getX() * 0.5D, (double)neighbor.getY() + 0.5D + (double)side2.getVector().getY() * 0.5D, (double)neighbor.getZ() + 0.5D + (double)side2.getVector().getZ() * 0.5D);
                    boolean wasSneaking = MeteorClient.mc.player.input.sneaking;
                    MeteorClient.mc.player.input.sneaking = false;
                    MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(hitPos, side2, neighbor, false));
                    if (swing) {
                        MeteorClient.mc.player.swingHand(hand);
                    }

                    MeteorClient.mc.player.input.sneaking = wasSneaking;
                    return true;
                }
            }

            ((IVec3d)hitPos).set(blockPos);
            MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(hitPos, Direction.UP, blockPos, false));
            if (swing) {
                MeteorClient.mc.player.swingHand(hand);
            }

            return true;
        }
    }

    public static boolean placeBlock(BlockPos blockPos, Hand hand, boolean swing, boolean airPlace) {
        if (!BlockUtils.canPlace(blockPos)) {
            return false;
        } else {
            Direction[] var4 = Direction.values();
            int var5 = var4.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                Direction side = var4[var6];
                BlockPos neighbor = blockPos.offset(side);
                Direction side2 = side.getOpposite();
                if (!MeteorClient.mc.world.getBlockState(neighbor).isAir() && !BlockUtils.isClickable(MeteorClient.mc.world.getBlockState(neighbor).getBlock())) {
                    ((IVec3d)hitPos).set((double)neighbor.getX() + 0.5D + (double)side2.getVector().getX() * 0.5D, (double)neighbor.getY() + 0.5D + (double)side2.getVector().getY() * 0.5D, (double)neighbor.getZ() + 0.5D + (double)side2.getVector().getZ() * 0.5D);
                    boolean wasSneaking = MeteorClient.mc.player.input.sneaking;
                    MeteorClient.mc.player.input.sneaking = false;
                    MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(hitPos, side2, neighbor, false));
                    if (swing) {
                        MeteorClient.mc.player.swingHand(hand);
                    }

                    MeteorClient.mc.player.input.sneaking = wasSneaking;
                    return true;
                }
            }

            if (!airPlace) {
                return false;
            } else {
                ((IVec3d)hitPos).set(blockPos);
                MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(hitPos, Direction.UP, blockPos, false));
                if (swing) {
                    MeteorClient.mc.player.swingHand(hand);
                }

                return true;
            }
        }
    }

    public static boolean checkIfBlockInBB(Class<? extends Block> blockClass) {
        return checkIfBlockInBB(blockClass, (int)Math.floor(MeteorClient.mc.player.getBoundingBox(MeteorClient.mc.player.getPose()).minY));
    }

    public static double[] directionSpeed(double speed) {
        float forward = MeteorClient.mc.player.input.movementForward;
        float side = MeteorClient.mc.player.input.movementSideways;
        float yaw = MeteorClient.mc.player.prevYaw + (MeteorClient.mc.player.getYaw() - MeteorClient.mc.player.prevYaw) * MeteorClient.mc.getTickDelta();
        if (forward != 0.0F) {
            if (side > 0.0F) {
                yaw += (float)(forward > 0.0F ? -45 : 45);
            } else if (side < 0.0F) {
                yaw += (float)(forward > 0.0F ? 45 : -45);
            }

            side = 0.0F;
            if (forward > 0.0F) {
                forward = 1.0F;
            } else if (forward < 0.0F) {
                forward = -1.0F;
            }
        }

        double sin = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
        double cos = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
        double posX = (double)forward * speed * cos + (double)side * speed * sin;
        double posZ = (double)forward * speed * sin - (double)side * speed * cos;
        return new double[]{posX, posZ};
    }

    public static boolean checkIfBlockInBB(Class<? extends Block> blockClass, int minY) {
        for(int iX = MathHelper.floor(MeteorClient.mc.player.getBoundingBox(MeteorClient.mc.player.getPose()).minX); iX < MathHelper.ceil(MeteorClient.mc.player.getBoundingBox(MeteorClient.mc.player.getPose()).maxX); ++iX) {
            for(int iZ = MathHelper.floor(MeteorClient.mc.player.getBoundingBox(MeteorClient.mc.player.getPose()).minZ); iZ < MathHelper.ceil(MeteorClient.mc.player.getBoundingBox(MeteorClient.mc.player.getPose()).maxZ); ++iZ) {
                BlockState state = MeteorClient.mc.world.getBlockState(new BlockPos(iX, minY, iZ));
                if (state != null && blockClass.isInstance(state.getBlock())) {
                    return true;
                }
            }
        }

        return false;
    }

    public static double getPlayerSpeed(PlayerEntity player) {
        if (player == null) {
            return 0.0D;
        } else {
            double tX = Math.abs(player.getX() - player.prevX);
            double tZ = Math.abs(player.getZ() - player.prevZ);
            double length = Math.sqrt(tX * tX + tZ * tZ);
            return length * 20.0D;
        }
    }

    public static void getPickaxe(boolean ironPickaxe) {
        FindItemResult pickaxe = InvUtils.find((itemStack) -> {
            return itemStack.getItem() == Items.DIAMOND_PICKAXE || itemStack.getItem() == Items.NETHERITE_PICKAXE;
        });
        if (ironPickaxe) {
            pickaxe = InvUtils.find((itemStack) -> {
                return itemStack.getItem() == Items.IRON_PICKAXE;
            });
        }

        InvUtils.swap(pickaxe.slot(), false);
    }

    public static boolean canSeePos(BlockPos pos) {
        Vec3d vec1 = new Vec3d(0.0D, 0.0D, 0.0D);
        Vec3d vec2 = new Vec3d(0.0D, 0.0D, 0.0D);
        ((IVec3d)vec1).set(MeteorClient.mc.player.getX(), MeteorClient.mc.player.getY() + (double)MeteorClient.mc.player.getStandingEyeHeight(), MeteorClient.mc.player.getZ());
        ((IVec3d)vec2).set((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
        boolean canSeeFeet = MeteorClient.mc.world.raycast(new RaycastContext(vec1, vec2, ShapeType.COLLIDER, FluidHandling.NONE, MeteorClient.mc.player)).getType() == Type.MISS;
        ((IVec3d)vec2).set((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
        boolean canSeeEyes = MeteorClient.mc.world.raycast(new RaycastContext(vec1, vec2, ShapeType.COLLIDER, FluidHandling.NONE, MeteorClient.mc.player)).getType() == Type.MISS;
        return canSeeFeet || canSeeEyes;
    }

    public static boolean placeBlockMainHand(BlockPos pos) {
        return placeBlockMainHand(false, -1, -1, false, false, pos);
    }

    public static boolean placeBlockMainHand(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos) {
        return placeBlockMainHand(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, true, false);
    }

    public static boolean placeBlockMainHand(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace) {
        return placeBlockMainHand(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, airPlace, forceAirplace, false);
    }

    public static boolean placeBlockMainHand(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity) {
        return placeBlockMainHand(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, airPlace, forceAirplace, ignoreEntity, (Direction)null);
    }

    public static boolean placeBlockMainHand(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity, Direction overrideSide) {
        return placeBlock(false, -1, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, Hand.MAIN_HAND, pos, airPlace, forceAirplace, ignoreEntity, overrideSide);
    }

    public static boolean placeBlockMainHand(boolean packetPlace, int slot, BlockPos pos) {
        return placeBlockMainHand(packetPlace, slot, false, -1, -1, false, false, pos);
    }

    public static boolean placeBlockMainHand(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos) {
        return placeBlockMainHand(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, true, false);
    }

    public static boolean placeBlockMainHand(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace) {
        return placeBlockMainHand(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, airPlace, forceAirplace, false);
    }

    public static boolean placeBlockMainHand(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity) {
        return placeBlockMainHand(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, pos, airPlace, forceAirplace, ignoreEntity, (Direction)null);
    }

    public static boolean placeBlockMainHand(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity, Direction overrideSide) {
        return placeBlock(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, Hand.MAIN_HAND, pos, airPlace, forceAirplace, ignoreEntity, overrideSide);
    }

    public static boolean placeBlockNoRotate(Hand hand, BlockPos pos) {
        return placeBlock(false, -1, false, -1, -1, false, false, hand, pos, true, false);
    }

    public static boolean placeBlockNoRotate(boolean packetPlace, int slot, Hand hand, BlockPos pos) {
        return placeBlock(packetPlace, slot, false, -1, -1, false, false, hand, pos, true, false);
    }

    public static boolean placeBlock(Hand hand, BlockPos pos) {
        return placeBlock(false, -1, -1, false, false, hand, pos, true, false);
    }

    public static boolean placeBlock(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos) {
        return placeBlock(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, false, false);
    }

    public static boolean placeBlock(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace) {
        return placeBlock(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, airPlace, forceAirplace, false);
    }

    public static boolean placeBlock(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity) {
        return placeBlock(rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, airPlace, forceAirplace, ignoreEntity, (Direction)null);
    }

    public static boolean placeBlock(Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity, Direction overrideSide) {
        return placeBlock(false, -1, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, airPlace, forceAirplace, ignoreEntity, overrideSide);
    }

    public static boolean placeBlock(boolean packetPlace, int slot, Hand hand, BlockPos pos) {
        return placeBlock(packetPlace, slot, false, -1, -1, false, false, hand, pos, true, false);
    }

    public static boolean placeBlock(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos) {
        return placeBlock(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, false, false);
    }

    public static boolean placeBlock(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace) {
        return placeBlock(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, airPlace, forceAirplace, false);
    }

    public static boolean placeBlock(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity) {
        return placeBlock(packetPlace, slot, rotate, rotationKey, rotationPriority, instantRotation, instantBypassesCurrent, hand, pos, airPlace, forceAirplace, ignoreEntity, (Direction)null);
    }

    public static boolean placeBlock(boolean packetPlace, int slot, Boolean rotate, int rotationKey, int rotationPriority, boolean instantRotation, boolean instantBypassesCurrent, Hand hand, BlockPos pos, Boolean airPlace, Boolean forceAirplace, Boolean ignoreEntity, Direction overrideSide) {
        if (ignoreEntity) {
            if (!MeteorClient.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
                return false;
            }
        } else if (!MeteorClient.mc.world.getBlockState(pos).getMaterial().isReplaceable() || !MeteorClient.mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), pos, ShapeContext.absent())) {
            return false;
        }

        Vec3d eyesPos = new Vec3d(MeteorClient.mc.player.getX(), MeteorClient.mc.player.getY() + (double)MeteorClient.mc.player.getEyeHeight(MeteorClient.mc.player.getPose()), MeteorClient.mc.player.getZ());
        Vec3d hitVec = null;
        BlockPos neighbor = null;
        Direction side2 = null;
        if (!forceAirplace || !airPlace) {
            label102: {
                if (overrideSide != null) {
                    neighbor = pos.offset(overrideSide.getOpposite());
                    side2 = overrideSide;
                }

                Direction[] var17 = Direction.values();
                int var18 = var17.length;
                int var19 = 0;

                while(true) {
                    if (var19 >= var18) {
                        break label102;
                    }

                    Direction side = var17[var19];
                    if (overrideSide != null) {
                        break;
                    }

                    neighbor = pos.offset(side);
                    side2 = side.getOpposite();
                    if (!MeteorClient.mc.world.getBlockState(neighbor).isAir() && !(MeteorClient.mc.world.getBlockState(neighbor).getBlock() instanceof FluidBlock)) {
                        break;
                    }

                    neighbor = null;
                    side2 = null;
                    ++var19;
                }

                hitVec = (new Vec3d((double)neighbor.getX(), (double)neighbor.getY(), (double)neighbor.getZ())).add(0.5D, 0.5D, 0.5D).add((new Vec3d(side2.getUnitVector())).multiply(0.5D));
            }
        }

        if (airPlace) {
            if (hitVec == null) {
                hitVec = Vec3d.ofCenter(pos);
            }

            if (neighbor == null) {
                neighbor = pos;
            }

            if (side2 == null) {
                side2 = Direction.UP;
            }
        } else if (hitVec == null || neighbor == null || side2 == null) {
            return false;
        }

        double diffX = hitVec.x - eyesPos.x;
        double diffY = hitVec.y - eyesPos.y;
        double diffZ = hitVec.z - eyesPos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        float[] rotations = new float[]{MeteorClient.mc.player.getYaw() + MathHelper.wrapDegrees(yaw - MeteorClient.mc.player.getYaw()), MeteorClient.mc.player.getPitch() + MathHelper.wrapDegrees(pitch - MeteorClient.mc.player.getPitch())};
        if (rotate) {
            Rotations.rotate((double)rotations[0], (double)rotations[1]);
        }

        MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.PRESS_SHIFT_KEY));
        int oldSlot = MeteorClient.mc.player.getInventory().selectedSlot;
        if (slot != -1) {
            MeteorClient.mc.player.getInventory().selectedSlot = slot;
        }

        if (packetPlace) {
            MeteorClient.mc.interactionManager.interactBlock(MeteorClient.mc.player, hand, new BlockHitResult(hitVec, side2, neighbor, false));
        }

        MeteorClient.mc.player.swingHand(hand);
        if (slot != -1 && !packetPlace) {
            MeteorClient.mc.player.getInventory().selectedSlot = oldSlot;
        }

        MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.RELEASE_SHIFT_KEY));
        return true;
    }

    public static boolean place(BlockPos blockPos, Hand hand, int slot, boolean checkEntities, boolean swap) {
        if (slot != -1 && BlockUtils.canPlace(blockPos, checkEntities)) {
            Direction side = BlockUtils.getPlaceSide(blockPos);
            Vec3d hitPos = new Vec3d(0.0D, 0.0D, 0.0D);
            BlockPos neighbour;
            if (side != null && side != Direction.UP) {
                neighbour = blockPos.offset(side.getOpposite());
                ((IVec3d)hitPos).set((double)neighbour.getX() + 0.5D + (double)side.getOffsetX() * 0.5D, (double)neighbour.getY() + 0.5D + (double)side.getOffsetY() * 0.5D, (double)neighbour.getZ() + 0.5D + (double)side.getOffsetZ() * 0.5D);
            } else {
                side = Direction.UP;
                neighbour = blockPos;
                hitPos = getCenter(blockPos);
            }

            place(slot, hitPos, hand, side, neighbour, swap);
            return true;
        } else {
            return false;
        }
    }

    public static void place(int slot, Vec3d hitPos, Hand hand, Direction side, BlockPos neighbour, boolean swap) {
        assert MeteorClient.mc.player != null;

        if (hand == Hand.MAIN_HAND) {
            MeteorClient.mc.player.getInventory().selectedSlot = slot;
        }

        boolean wasSneaking = MeteorClient.mc.player.input.sneaking;
        MeteorClient.mc.player.input.sneaking = false;
        MeteorClient.mc.player.swingHand(Hand.MAIN_HAND);
        MeteorClient.mc.player.input.sneaking = wasSneaking;
    }

    public static Vec3d getCenter(BlockPos block) {
        return (new Vec3d((double)block.getX(), (double)block.getY(), (double)block.getZ())).add(0.5D, 0.5D, 0.5D);
    }
}
