package delta.HWID;

import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;

public class RotationUtil {
    private float yaw;
    private float pitch;
    private static boolean rotationsSet = false;

    public static boolean isRotationsSet() {
        return rotationsSet;
    }

    public void lookAtVec3d(Vec3d vec3d) {
        float[] angle = calculateAngle(MeteorClient.mc.player.getEyePos(), new Vec3d(vec3d.x, vec3d.y, vec3d.z));
        this.setRotations(angle[0], angle[1]);
    }

    public void reset() {
        this.yaw = MeteorClient.mc.player.getYaw();
        this.pitch = MeteorClient.mc.player.getPitch();
        rotationsSet = false;
    }

    public void setRotations(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
        rotationsSet = true;
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void lookAtXYZ(double x, double y, double z) {
        Vec3d vec3d = new Vec3d(x, y, z);
        this.lookAtVec3d(vec3d);
    }

    public static float[] calculateAngle(Vec3d from, Vec3d to) {
        double difX = to.x - from.x;
        double difY = (to.y - from.y) * -1.0D;
        double difZ = to.z - from.z;
        double dist = (double)MathHelper.sqrt((float)(difX * difX + difZ * difZ));
        float yD = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D);
        float pD = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist)));
        if (pD > 90.0F) {
            pD = 90.0F;
        } else if (pD < -90.0F) {
            pD = -90.0F;
        }

        return new float[]{yD, pD};
    }

    public static double[] calculateLookAt(double px, double py, double pz, PlayerEntity me) {
        double dirx = me.getX() - px;
        double diry = me.getY() - py;
        double dirz = me.getZ() - pz;
        double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
        dirx /= len;
        diry /= len;
        dirz /= len;
        double pitch = Math.asin(diry);
        double yaw = Math.atan2(dirz, dirx);
        pitch = pitch * 180.0D / 3.141592653589793D;
        yaw = yaw * 180.0D / 3.141592653589793D;
        yaw += 90.0D;
        return new double[]{yaw, pitch};
    }

    public static void update(float yaw, float pitch) {
        boolean flag = MeteorClient.mc.player.isSprinting();
        if (flag != MeteorClient.mc.player.isSprinting()) {
            if (flag) {
                MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.START_SPRINTING));
            } else {
                MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.STOP_SPRINTING));
            }

            MeteorClient.mc.player.setSprinting(flag);
        }

        boolean flag1 = MeteorClient.mc.player.isSneaking();
        if (flag1 != MeteorClient.mc.player.isSneaking()) {
            if (flag1) {
                MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.PRESS_SHIFT_KEY));
            } else {
                MeteorClient.mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(MeteorClient.mc.player, Mode.RELEASE_SHIFT_KEY));
            }

            MeteorClient.mc.player.setSneaking(flag);
        }

        MeteorClient.mc.player.setYaw(yaw);
        MeteorClient.mc.player.setPitch(pitch);
    }

    public static Direction getClockWise(Direction direction) {
        switch(direction) {
            case WEST:
                return Direction.SOUTH;
            case EAST:
                return Direction.NORTH;
            case NORTH:
                return Direction.WEST;
            case SOUTH:
                return Direction.EAST;
            default:
                return null;
        }
    }

    public static Direction getCounterClockWise(Direction direction) {
        switch(direction) {
            case WEST:
                return Direction.NORTH;
            case EAST:
                return Direction.SOUTH;
            case NORTH:
                return Direction.EAST;
            case SOUTH:
                return Direction.WEST;
            default:
                return null;
        }
    }
}
