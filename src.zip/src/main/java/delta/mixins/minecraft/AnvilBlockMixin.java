package delta.mixins.minecraft;

import delta.utils.BetterAnvils;
import net.minecraft.world.BlockView;
import net.minecraft.block.AnvilBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AnvilBlock.class})
public class AnvilBlockMixin {
    @Inject(
        method = {"getOutlineShape"},
        at = {@At("HEAD")},
        cancellable = true
    )
    public void getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context, CallbackInfoReturnable<VoxelShape> cir) {
        cir.setReturnValue(BetterAnvils.voxelShape(state));
    }
}
