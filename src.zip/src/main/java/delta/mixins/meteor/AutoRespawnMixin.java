package delta.mixins.meteor;

import java.util.List;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoRespawn;
import meteordevelopment.meteorclient.systems.modules.render.WaypointsModule;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.text.Text;
import net.minecraft.client.gui.screen.DeathScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({AutoRespawn.class})
public class AutoRespawnMixin extends Module {
    private Setting<Boolean> autoRekit;
    private Setting<Boolean> chatInfo;
    private Setting<String> kitName;
    private boolean shouldRekit;
    private int rekitWait;
    private Setting<Boolean> autoCope;
    private Setting<Integer> copeDelay;
    private Setting<List<String>> messages;
    private boolean shouldCope;
    private int copeWait;

    public AutoRespawnMixin(Category category, String name, String description) {
        super(category, name, description);
    }

    @Inject(
        method = {"<init>"},
        at = {@At("TAIL")},
        remap = false
    )
    private void onInit(CallbackInfo ci) {
        SettingGroup sgGeneral = this.settings.getDefaultGroup();
        SettingGroup sgCope = this.settings.createGroup("Auto Cope");
        this.autoRekit = sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("rekit")).description("Whether to automatically get a kit after dying.")).defaultValue(false)).build());
        Builder var10002 = (Builder)((Builder)((Builder)(new Builder()).name("chat-info")).description("Whether to send info about rekitting.")).defaultValue(true);
        Setting var10003 = this.autoRekit;
        Objects.requireNonNull(var10003);
        this.chatInfo = sgGeneral.add(((Builder)var10002.visible(var10003::get)).build());
        meteordevelopment.meteorclient.settings.StringSetting.Builder var4 = (meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)((meteordevelopment.meteorclient.settings.StringSetting.Builder)(new meteordevelopment.meteorclient.settings.StringSetting.Builder()).name("kit-name")).description("The name of your kit.")).defaultValue("");
        var10003 = this.autoRekit;
        Objects.requireNonNull(var10003);
        this.kitName = sgGeneral.add(((meteordevelopment.meteorclient.settings.StringSetting.Builder)var4.visible(var10003::get)).build());
        this.autoCope = sgCope.add(((Builder)((Builder)((Builder)(new Builder()).name("auto-cope")).description("Automatically make excuses after you die.")).defaultValue(false)).build());
        meteordevelopment.meteorclient.settings.IntSetting.Builder var5 = ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)(new meteordevelopment.meteorclient.settings.IntSetting.Builder()).name("cope-delay")).description("How long to wait in seconds after you die to cope.")).defaultValue(1)).range(0, 5).sliderRange(0, 5);
        var10003 = this.autoCope;
        Objects.requireNonNull(var10003);
        this.copeDelay = sgCope.add(((meteordevelopment.meteorclient.settings.IntSetting.Builder)var5.visible(var10003::get)).build());
        meteordevelopment.meteorclient.settings.StringListSetting.Builder var6 = (meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)((meteordevelopment.meteorclient.settings.StringListSetting.Builder)(new meteordevelopment.meteorclient.settings.StringListSetting.Builder()).name("cope-messages")).description("What messages to choose from after you die.")).defaultValue(List.of("Why am I lagging so hard wtf??", "I totem failed that doesn't count", "Leave the green hole challenge", "You're actually so braindead", "How many totems do you have??"));
        var10003 = this.autoCope;
        Objects.requireNonNull(var10003);
        this.messages = sgCope.add(((meteordevelopment.meteorclient.settings.StringListSetting.Builder)var6.visible(var10003::get)).build());
    }

    @EventHandler(
        priority = 100
    )
    private void onOpenScreenEvent(OpenScreenEvent event) {
        if (event.screen instanceof DeathScreen) {
            ((WaypointsModule)Modules.get().get(WaypointsModule.class)).addDeath(this.mc.player.getPos());
            this.mc.player.requestRespawn();
            event.cancel();
            if ((Boolean)this.autoRekit.get()) {
                this.shouldRekit = true;
            }

            if ((Boolean)this.autoCope.get()) {
                this.copeWait = (Integer)this.copeDelay.get() * 20;
                this.shouldCope = true;
            }

        }
    }

    @EventHandler
    private void onTick(Post event) {
        if (this.rekitWait == 0 && this.shouldRekit) {
            if ((Boolean)this.chatInfo.get()) {
                this.info("Rekitting with kit " + (String)this.kitName.get() + ".", new Object[0]);
            }

            this.mc.player.sendChatMessage("/kit " + (String)this.kitName.get(), Text.literal("/kit" + (String)this.kitName.get()));
            this.shouldRekit = false;
            this.rekitWait = 60;
        } else if (this.rekitWait > 0) {
            --this.rekitWait;
        }

        if (this.copeWait <= 0 && this.shouldCope) {
            this.mc.player.sendChatMessage(this.getExcuseMessage(), Text.literal(this.getExcuseMessage()));
            this.shouldCope = false;
        } else if (this.copeWait > 0) {
            --this.copeWait;
        }

    }

    private String getExcuseMessage() {
        if (((List)this.messages.get()).isEmpty()) {
            this.error("Your message list is empty!", new Object[0]);
            return "Literally how??";
        } else {
            String excuseMessage = (String)((List)this.messages.get()).get((new Random()).nextInt(((List)this.messages.get()).size()));
            return excuseMessage;
        }
    }
}
