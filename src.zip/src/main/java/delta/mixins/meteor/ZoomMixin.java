package delta.mixins.meteor;

import delta.DeltaHack;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.render.Zoom;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Zoom.class})
public class ZoomMixin extends Module {
   @Shadow(
      remap = false
   )
   @Final
   private SettingGroup sgGeneral;
   private Setting<Boolean> f1;

   public ZoomMixin() {
      super(DeltaHack.Misc, "zoom", "is there a better way 2 do this? idk");
   }

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onInit(CallbackInfo ci) {
      this.f1 = this.sgGeneral.add(((Builder)((Builder)((Builder)(new Builder()).name("toggle-hud")).description("Toggles the Heads-Up Display.")).defaultValue(false)).build());
   }

   @Inject(
      method = {"onActivate"},
      at = {@At("TAIL")},
      remap = false
   )
   public void onActivate(CallbackInfo info) {
      if ((Boolean)this.f1.get()) {
         this.mc.field_1690.field_1842 = true;
      }

   }

   public void onDeactivate() {
      if ((Boolean)this.f1.get()) {
         this.mc.field_1690.field_1842 = false;
      }

   }
}
