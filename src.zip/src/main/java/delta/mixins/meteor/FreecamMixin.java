package delta.mixins.meteor;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.meteorclient.utils.Utils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Freecam.class})
public class FreecamMixin {
   @Shadow(
      remap = false
   )
   @Final
   private SettingGroup sgGeneral;
   @Final
   @Shadow(
      remap = false
   )
   private Setting<Boolean> rotate;
   private Setting<Boolean> parallelView;
   @Shadow(
      remap = false
   )
   public float yaw;
   @Shadow(
      remap = false
   )
   public float pitch;
   private boolean forward;
   private boolean backward;
   private boolean right;
   private boolean left;
   private boolean up;
   private boolean down;

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")},
      remap = false
   )
   private void onInit(CallbackInfo ci) {
      this.parallelView = this.sgGeneral.add(((Builder)((Builder)((Builder)((Builder)(new Builder()).name("parallel-view-B+")).description("Rotates the player same way the camera does (good for building).")).defaultValue(false)).visible(() -> {
         return !(Boolean)this.rotate.get();
      })).build());
   }

   @Inject(
      method = {"onTick"},
      at = {@At("TAIL")},
      remap = false
   )
   public void onTick(CallbackInfo info) {
      if ((Boolean)this.parallelView.get() && !(Boolean)this.rotate.get()) {
         this.pitch = Utils.clamp(this.pitch, -90.0F, 90.0F);
         MeteorClient.mc.field_1724.method_36456(this.yaw);
         MeteorClient.mc.field_1724.method_36457(this.pitch);
      }

   }
}
