package delta.mixininterface;

public interface IVec3d {
   void setX(double var1);

   void setY(double var1);

   void setZ(double var1);

   void set(double var1, double var3, double var5);
}
